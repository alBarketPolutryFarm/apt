import pytest

pytestmark = pytest.mark.asyncio


@pytest.fixture(scope="module")
def file1():
    return b"0"
