from datetime import date

import pytest
import pytest_asyncio
from deepdiff import DeepDiff
from httpx import AsyncClient
from starlette import status

from ss_api.models.file import DBFileTemp
from ss_api.models.measures import MeasureType, NewBloodPressure
from ss_api.models.measures.blood_pressure import NewBloodPressureMetadata
from ss_api.models.monitoring_plan.monitored_measure import (
    NewMonitoredBloodPressureMeasure,
)
from ss_api.models.monitoring_plan.monitoring_plan import NewMonitoringPlan
from ss_api.models.report import DBExternalReport

pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture(scope="module")
async def external_report1(patient1, nurse1):
    file = DBFileTemp(
        path="foo1", filename="test_report", contentType="plain", size=1, ownerId=patient1.id, createdBy=nurse1.id
    )
    with open(file.absolute_path, "w+") as f:
        f.write("test")

    await file.create()
    report = DBExternalReport(
        file=file, patientId=patient1.id, createdBy=nurse1.id, date=date.today(), description="test external report"
    )
    await report.create()

    return report


@pytest.fixture(scope="module")
def monitoring_plan_blood_pressure(nurse1, patient1, external_report1):
    return NewMonitoringPlan(
        bloodPressure=NewMonitoredBloodPressureMeasure(limitMinSystolic=70, schedule=[]), reportId=external_report1.id
    )


@pytest.fixture(scope="module")
def blood_pressure1(monitoring_plan_blood_pressure):
    return NewBloodPressure(
        systolic=70,
        diastolic=100,
        metadata=NewBloodPressureMetadata(type=MeasureType.bloodPressure),
    )


@pytest.fixture(scope="module")
def blood_pressure2(monitoring_plan_blood_pressure):
    return NewBloodPressure(
        systolic=80,
        diastolic=95,
        metadata=NewBloodPressureMetadata(type=MeasureType.bloodPressure),
    )


async def test_measures_summary(
    client: AsyncClient,
    patient1,
    auth_nurse1,
    auth_patient1,
    auth_patient2,
    monitoring_plan_blood_pressure,
    blood_pressure1,
    blood_pressure2,
):
    response = await client.post(
        f"/patients/{patient1.id}/monitoring-plans",
        headers=auth_nurse1,
        json=monitoring_plan_blood_pressure.model_dump(mode="json"),
    )
    assert response.status_code == status.HTTP_201_CREATED, response.json()

    response = await client.get(f"/patients/{patient1.id}/measures/summary", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK, response.json()

    response = await client.post(
        "/measures", headers=auth_patient1, json=[blood_pressure1.model_dump(mode="json", exclude={"timestamp"})]
    )
    assert response.status_code == status.HTTP_201_CREATED, response.json()

    response = await client.get(f"/patients/{patient1.id}/measures/summary", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK, response.json()
    summary = response.json()
    assert summary["bloodPressure"]["diastolic"] == blood_pressure1.diastolic
    assert summary["bloodPressure"]["systolic"] == blood_pressure1.systolic

    response = await client.get(f"/patients/{patient1.id}/measures/summary", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK, response.json()
    assert not DeepDiff(response.json(), summary)

    response = await client.post(
        "/measures", headers=auth_patient1, json=[blood_pressure2.model_dump(mode="json", exclude={"timestamp"})]
    )
    assert response.status_code == status.HTTP_201_CREATED, response.json()

    response = await client.get(f"/patients/{patient1.id}/measures/summary", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK, response.json()
    summary = response.json()
    assert summary["bloodPressure"]["diastolic"] == blood_pressure2.diastolic
    assert summary["bloodPressure"]["systolic"] == blood_pressure2.systolic

    response = await client.get(f"/patients/{patient1.id}/measures/summary", headers=auth_patient2)
    assert response.status_code == status.HTTP_404_NOT_FOUND, response.json()
