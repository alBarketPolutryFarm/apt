import pytest
from deepdiff import DeepDiff
from httpx import AsyncClient
from starlette import status

from ss_api.models.index import (
    BarthelIndexMeasure,
    IndexMeasuresSummary,
    NewBarthelIndexMeasure,
)

pytestmark = pytest.mark.asyncio


async def test_indexes(client: AsyncClient, patient1, auth_nurse1, auth_patient1, auth_nurse2):
    response = await client.get("/indexes/summary", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK, response.json()
    patient_summary = IndexMeasuresSummary(**response.json())

    response = await client.get(f"/patients/{patient1.id}/indexes/summary", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK, response.json()
    nurse_summary = IndexMeasuresSummary(**response.json())
    assert DeepDiff(patient_summary.model_dump(), nurse_summary.model_dump(), ignore_order=True) == {}

    response = await client.get(f"/patients/{patient1.id}/indexes/summary", headers=auth_nurse2)
    assert response.status_code == status.HTTP_404_NOT_FOUND, response.json()

    new_barthel_index_measure = NewBarthelIndexMeasure(metadata={"type": "barthel"}, value=100)
    response = await client.post(
        f"/patients/{patient1.id}/indexes",
        headers=auth_nurse1,
        json=[new_barthel_index_measure.model_dump(mode="json")],
    )
    assert response.status_code == status.HTTP_201_CREATED, response.json()

    response = await client.get("/indexes/barthel", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK, response.json()
    response = response.json()
    assert len(response) == 1
    barthel_index_measure = BarthelIndexMeasure(**response[0])
    assert barthel_index_measure.value == new_barthel_index_measure.value

    response = await client.get("/indexes/summary", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK, response.json()
    patient_summary = IndexMeasuresSummary(**response.json())
    assert patient_summary.barthel.value == new_barthel_index_measure.value

    response = await client.get(f"/patients/{patient1.id}/indexes/summary", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK, response.json()
    nurse_summary = IndexMeasuresSummary(**response.json())
    assert DeepDiff(patient_summary.model_dump(), nurse_summary.model_dump(), ignore_order=True) == {}
