from typing import Dict

import pytest

from ss_api.models.users import User
from ss_api.utils.typing import JWT


@pytest.fixture(scope="session")
def make_auth():
    def _make_auth(user: User) -> Dict[str, str]:
        token = JWT.create(user)
        return {"Authorization": f"Bearer {token}"}

    return _make_auth


@pytest.fixture(scope="session")
def auth_admin(admin, make_auth):
    return make_auth(admin)


@pytest.fixture(scope="session")
def auth_nurse1(nurse1, make_auth):
    return make_auth(nurse1)


@pytest.fixture(scope="session")
def auth_nurse2(nurse2, make_auth):
    return make_auth(nurse2)


@pytest.fixture(scope="session")
def auth_doctor1(doctor1, make_auth):
    return make_auth(doctor1)


@pytest.fixture(scope="session")
def auth_doctor2(doctor2, make_auth):
    return make_auth(doctor2)


@pytest.fixture(scope="session")
def auth_patient1(patient1, make_auth):
    return make_auth(patient1)


@pytest.fixture(scope="session")
def auth_patient2(patient2, make_auth):
    return make_auth(patient2)
