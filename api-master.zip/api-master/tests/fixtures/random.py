from datetime import datetime, timedelta
from random import choice, choices, randrange
from string import ascii_lowercase, digits
from uuid import uuid4

import pytest
from codicefiscale import codicefiscale


def make_random_fiscal_code():
    return codicefiscale.encode(
        firstname="".join(choices(ascii_lowercase, k=8)),
        lastname="".join(choices(ascii_lowercase, k=8)),
        gender=choice(["M", "F"]),
        birthdate=(datetime.now() - timedelta(days=randrange(int(1e2), int(1e4)))).strftime("%d/%m/%Y"),
        birthplace="Roma",
    )


def make_random_phone_number():
    return f"+39346{''.join(choices(digits, k=7))}"


def make_random_email():
    return f"{uuid4()}@auto.test.dev"


def make_random_user_data():
    return {
        "firstName": "".join(choices(ascii_lowercase, k=8)),
        "lastName": "".join(choices(ascii_lowercase, k=8)),
        "fiscalCode": make_random_fiscal_code(),
        "phone": make_random_phone_number(),
        "email": make_random_email(),
    }


@pytest.fixture
def random_fiscal_code():
    return make_random_fiscal_code()


@pytest.fixture
def random_phone_number():
    return make_random_phone_number()


@pytest.fixture
def random_email():
    return make_random_email()


@pytest.fixture
def random_user_data():
    return make_random_user_data()
