from datetime import datetime, timezone

import pytest

from ss_api.models.permissions import DBPermission
from ss_api.models.users import DBAdmin, DBDoctor, DBNurse, DBPatient

SHARED_PASSWORD = "UUgXvoVc7Eww"


@pytest.fixture(scope="session")
def admin():
    return DBAdmin(
        id="b0".rjust(24, "0"), firstName="admin", lastName="test", email="admin@test.ts", newPassword=SHARED_PASSWORD
    )


@pytest.fixture(scope="session")
def nurse1(admin):
    return DBNurse(
        id="bf1".rjust(24, "0"),
        email="nurse1@test.ts",
        firstName="nurse1",
        lastName="with more patients",
        fiscalCode="RXVPBL61A30F155H",
        phone="+393492736702",
        createdBy=admin.id,
        newPassword=SHARED_PASSWORD,
    )


@pytest.fixture(scope="session")
def nurse2(admin):
    return DBNurse(
        id="bf2".rjust(24, "0"),
        firstName="nurse2",
        email="nurse2@test.ts",
        lastName="without patients",
        fiscalCode="HSUMCL21E41L574I",
        phone="+393452739789",
        createdBy=admin.id,
        newPassword=SHARED_PASSWORD,
    )


@pytest.fixture(scope="session")
def nurse3(admin):
    return DBNurse(
        id="bf3".rjust(24, "0"),
        firstName="nurse3",
        email="nurse3@test.ts",
        lastName="with one patient",
        fiscalCode="DSLBGG86C56E876Q",
        phone="+393452739799",
        createdBy=admin.id,
        newPassword=SHARED_PASSWORD,
    )


@pytest.fixture(scope="session")
def doctor1(admin):
    return DBDoctor(
        id="bd1".rjust(24, "0"),
        email="doctor1@test.ts",
        firstName="doctor1",
        lastName="test",
        fiscalCode="GZMCRN36B24D693J",
        phone="+393462934789",
        createdBy=admin.id,
        newPassword=SHARED_PASSWORD,
    )


@pytest.fixture(scope="session")
def doctor2(admin):
    return DBDoctor(
        id="bd2".rjust(24, "0"),
        email="doctor2@test.ts",
        firstName="doctor2",
        lastName="test",
        fiscalCode="DCNDWJ81R16H098N",
        phone="+393464934781",
        createdBy=admin.id,
        reportableExamModalities=[],
        newPassword=SHARED_PASSWORD,
    )


@pytest.fixture(scope="session")
def patient1(admin):
    return DBPatient(
        id="ba1".rjust(24, "0"),
        firstName="patient1",
        lastName="with one nurse",
        fiscalCode="FRLDVD38P01E955H",
        email="patient1@test.ts",
        createdBy=admin.id,
        newPassword=SHARED_PASSWORD,
    )


@pytest.fixture(scope="session")
def patient2(admin):
    return DBPatient(
        id="ba2".rjust(24, "0"),
        firstName="patient2",
        lastName="without nurse",
        fiscalCode="TXSJSB91H43F207S",
        email="patient2@test.ts",
        createdBy=admin.id,
        newPassword=SHARED_PASSWORD,
    )


@pytest.fixture(scope="session")
def patient3(admin):
    return DBPatient(
        id="ba3".rjust(24, "0"),
        firstName="patient3",
        lastName="with morse nurse",
        fiscalCode="VSDFKG45T49B690X",
        email="patient3@test.ts",
        createdBy=admin.id,
        newPassword=SHARED_PASSWORD,
    )


@pytest.fixture(scope="session")
def permissions(admin, patient1, patient3, nurse1, nurse3, doctor1):
    return [
        DBPermission(
            patientId=patient1.id,
            targetId=nurse1.id,
            createdBy=admin.id,
            effectiveDate=datetime.now(timezone.utc),
            id="d1".rjust(24, "0"),
        ),
        DBPermission(
            patientId=patient1.id,
            targetId=doctor1.id,
            createdBy=admin.id,
            effectiveDate=datetime.now(timezone.utc),
            id="d2".rjust(24, "0"),
        ),
        DBPermission(
            patientId=patient1.id,
            targetId=nurse3.id,
            createdBy=admin.id,
            effectiveDate=datetime.now(timezone.utc),
            id="d3".rjust(24, "0"),
        ),
        DBPermission(
            patientId=patient3.id,
            targetId=nurse3.id,
            createdBy=admin.id,
            effectiveDate=datetime.now(timezone.utc),
            id="d4".rjust(24, "0"),
        ),
    ]


@pytest.fixture(scope="session")
def patients(patient1, patient2, patient3):
    return [patient1, patient2, patient3]


@pytest.fixture(scope="session")
def nurses(nurse1, nurse2, nurse3):
    return [nurse1, nurse2, nurse3]
