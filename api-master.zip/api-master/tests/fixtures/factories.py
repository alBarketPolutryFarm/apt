from abc import ABC
from typing import Any, Dict, Type, TypeVar

import pytest
from polyfactory.factories.pydantic_factory import ModelFactory
from polyfactory.pytest_plugin import register_fixture
from pydantic import BaseModel, TypeAdapter

from ss_api.models.report import NewMedicalExaminationReport
from ss_api.utils.typing import NotFutureDate

T = TypeVar("T", bound=BaseModel)


class BaseModelFactory(ModelFactory[T], ABC):
    __random_seed__ = 4
    __is_base_factory__ = True

    @classmethod
    def get_provider_map(cls) -> Dict[Type, Any]:
        providers_map = super().get_provider_map()

        return {
            NotFutureDate: lambda: TypeAdapter(NotFutureDate).validate_python("2012-01-24"),
            **providers_map,
        }


@register_fixture
class NewMedicalExaminationReportFactory(BaseModelFactory[NewMedicalExaminationReport]):
    __model__ = NewMedicalExaminationReport


@pytest.fixture
def new_medical_examination_report(new_medical_examination_report_factory):
    return new_medical_examination_report_factory.build()
