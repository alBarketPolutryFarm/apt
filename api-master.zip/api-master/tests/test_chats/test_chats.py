from datetime import datetime

import pytest
from httpx import AsyncClient
from starlette import status

from ss_api.models.chat import ServiceChat, UsersChat
from ss_api.models.chat.chat import DBBroadcastChat
from ss_api.models.chat.chat.type import ChatType
from ss_api.models.chat.message import NewChatMessageBookingRequest, NewChatMessageText

pytestmark = pytest.mark.asyncio


async def test_chats(client: AsyncClient, auth_nurse1, auth_patient1, patient1, nurse1):
    response = await client.get("/chats", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK
    assert len([c for c in response.json() if c["type"] != ChatType.broadcastChat]) == 0
    assert len([c for c in response.json() if c["type"] == ChatType.broadcastChat]) == 1

    response = await client.get(f"/chats/{patient1.id}", headers=auth_nurse1)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    response = await client.get(f"/chats/{patient1.id}/messages", headers=auth_nurse1)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    new_message = NewChatMessageText(message="test")
    response = await client.post(
        f"/chats/{patient1.id}/messages", headers=auth_nurse1, json=new_message.model_dump(mode="json")
    )
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get(f"/chats/{patient1.id}/messages", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 1

    response = await client.get(f"/chats/{patient1.id}", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK
    chat = UsersChat(**response.json())

    response = await client.get(f"/chats/{chat.id}", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/chats/{chat.id}", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/chats/{nurse1.id}/messages", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 1

    response = await client.get(f"/chats/{chat.id}/messages", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 1


async def test_service_chats(client: AsyncClient, auth_admin, auth_patient1, patient1):
    response = await client.get("/chats", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    chats_number = len(response.json())

    response = await client.get(f"/chats/{'0' * 24}", headers=auth_patient1)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    response = await client.get(f"/chats/{patient1.id}", headers=auth_admin)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    new_message = NewChatMessageText(message="test")
    response = await client.post(
        f"/chats/{'0' * 24}/messages", headers=auth_patient1, json=new_message.model_dump(mode="json")
    )
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get(f"/chats/{'0' * 24}", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    chat = ServiceChat(**response.json())

    response = await client.get(f"/chats/{chat.id}", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/chats/{patient1.id}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/chats/{chat.id}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get("/chats", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == chats_number + 1

    response = await client.get(f"/chats/{chat.id}/messages", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 1

    response = await client.get(f"/chats/{chat.id}/messages", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 1

    new_message2 = NewChatMessageText(message="test")
    response = await client.post(
        f"/chats/{chat.id}/messages", headers=auth_admin, json=new_message2.model_dump(mode="json")
    )
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get(f"/chats/{chat.id}/messages", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 2

    response = await client.get(f"/chats/{chat.id}/messages", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 2

    new_message3 = NewChatMessageBookingRequest(at=datetime.fromisoformat("2023-10-23T12:45"), description="test")
    response = await client.post(
        f"/chats/{chat.id}/messages", headers=auth_patient1, json=new_message3.model_dump(mode="json")
    )
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get(f"/chats/{chat.id}/messages", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 3

    response = await client.get(f"/chats/{chat.id}/messages", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 3


async def test_broadcast_chat(client: AsyncClient, auth_admin, auth_patient1, auth_doctor1):
    chat = await DBBroadcastChat.find().first_or_none()
    assert chat is not None

    for a in [auth_admin, auth_patient1, auth_doctor1]:
        response = await client.get("/chats", headers=a)
        assert response.status_code == status.HTTP_200_OK
        assert len([c for c in response.json() if c["type"] == ChatType.broadcastChat]) == 1

        response = await client.get(f"/chats/{chat.id}", headers=a)
        assert response.status_code == status.HTTP_200_OK
        assert response.json()["_id"] == str(chat.id)

        response = await client.get(f"/chats/{chat.id}/messages", headers=a)
        assert response.status_code == status.HTTP_200_OK
        assert len(response.json()) == 0

    response = await client.get(f"/chats/{'0'*24}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["_id"] == str(chat.id)

    new_message = NewChatMessageText(message="test")

    for a in [auth_patient1, auth_doctor1]:
        response = await client.post(f"/chats/{chat.id}/messages", headers=a, json=new_message.model_dump(mode="json"))
        assert response.status_code == status.HTTP_403_FORBIDDEN

    response = await client.post(
        f"/chats/{chat.id}/messages", headers=auth_admin, json=new_message.model_dump(mode="json")
    )
    assert response.status_code == status.HTTP_201_CREATED

    for a in [auth_admin, auth_patient1, auth_doctor1]:
        response = await client.get("/chats", headers=a)
        assert response.status_code == status.HTTP_200_OK
        assert len([c for c in response.json() if c["type"] == ChatType.broadcastChat]) == 1

        response = await client.get(f"/chats/{chat.id}/messages", headers=a)
        assert response.status_code == status.HTTP_200_OK
        assert len(response.json()) == 1
