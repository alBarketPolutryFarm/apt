import pytest

pytestmark = pytest.mark.asyncio


# @pytest.fixture
# def sign_up_patient(random_user_data):
#     return PatientSingUp(
#         **{
#             **random_user_data,
#             "email": "auto.patient@ss.dev",
#             "birthDate": date.fromisoformat("1990-04-25"),
#         }
#     )


# async def test_patient_auth(client: AsyncClient, sign_up_patient):
#     response = await client.post("/auth/sign-up", json=sign_up_patient.model_dump(mode="json"))
#     # assert response.status_code == status.HTTP_200_OK

#     patient_db = await DBPatient.find(Eq("email", sign_up_patient.email)).first_or_none()
#     assert patient_db is not None
#     password = Password.random()
#     patient_db.update_password(password)
#     await patient_db.save()

#     response = await client.post(
#         "/auth/sign-in", json=SingInBody(username=patient_db.email, password=password).model_dump(mode="json")
#     )
#     assert response.status_code == status.HTTP_200_OK
#     token_response = TokenResponse.model_validate(response.json())
#     auth_patient = {"Authorization": f"Bearer {token_response.token}"}

#     new_password = Password.random()
#     response = await client.post(
#         "/user/change-password",
#         json=ChangePasswordPayload(currentPassword=password, newPassword=new_password).model_dump(mode="json"),
#         headers=auth_patient,
#     )
#     assert response.status_code == status.HTTP_200_OK

#     response = await client.post(
#         "/auth/sign-in", json=SingInBody(username=patient_db.email, password=password).model_dump(mode="json")
#     )
#     assert response.status_code == status.HTTP_401_UNAUTHORIZED

#     response = await client.post(
#         "/auth/sign-in", json=SingInBody(username=patient_db.email, password=new_password).model_dump(mode="json")
#     )
#     assert response.status_code == status.HTTP_200_OK

#     response = await client.get("/user", headers=auth_patient)
#     assert response.status_code == status.HTTP_200_OK


# async def test_get_patients_as_admin(client: AsyncClient, auth_admin):
#     response = await client.get("/patients", headers=auth_admin)

#     assert response.status_code == status.HTTP_200_OK
#     assert len(response.json()) >= 1


# async def test_get_patients_as_nurse(client: AsyncClient, auth_nurse1):
#     response = await client.get("/patients", headers=auth_nurse1)

#     assert response.status_code == status.HTTP_200_OK
#     assert len(response.json()) >= 1


# async def test_get_patients_as_nurse_no_permission(client: AsyncClient, auth_nurse2):
#     response = await client.get("/patients", headers=auth_nurse2)

#     assert response.status_code == status.HTTP_200_OK
#     assert len(response.json()) == 0


# async def test_get_patient_as_admin(client: AsyncClient, auth_admin, patient1):
#     response = await client.get(f"/patients/{patient1.id}", headers=auth_admin)

#     assert response.status_code == status.HTTP_200_OK


# async def test_get_patient_as_nurse(client: AsyncClient, auth_nurse1, patient1):
#     response = await client.get(f"/patients/{patient1.id}", headers=auth_nurse1)

#     assert response.status_code == status.HTTP_200_OK


# async def test_get_patient_as_nurse_no_permission(client: AsyncClient, auth_nurse2, patient1):
#     response = await client.get(f"/patients/{patient1.id}", headers=auth_nurse2)

#     assert response.status_code == status.HTTP_404_NOT_FOUND
