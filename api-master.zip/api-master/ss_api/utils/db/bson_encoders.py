from datetime import date, datetime, time

from pydantic_core import Url

bson_encoders = {date: (lambda x: (datetime.combine(x, time.min) if type(x) is date else x)), time: str, Url: str}
