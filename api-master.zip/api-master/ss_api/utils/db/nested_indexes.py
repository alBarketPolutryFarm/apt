from typing import List

from pymongo import IndexModel


def nested_indexes(indexes: List[IndexModel], prefix: str) -> List[IndexModel]:
    new_indexes = []
    for ix in indexes:
        fields = list(map(lambda s: (prefix + s[0], s[1]), ix.document["key"].items()))
        new_indexes.append(IndexModel(fields, **ix.document))

    return new_indexes
