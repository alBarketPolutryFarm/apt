import logging
from logging import getLogger

from .logger import Logger


def setup_default_logger() -> None:
    logging.setLoggerClass(Logger)

    for logger_name in ["uvicorn", "uvicorn.error", "uvicorn.access", "uvicorn.asgi"]:
        old_logger = getLogger(logger_name)
        old_logger.disabled = True
