import locale
from io import BytesIO

from beanie import PydanticObjectId

from ss_api.models.index.base import DBIndexMeasureBase
from ss_api.models.measures.base import DBMeasureBase
from ss_api.models.medical_record.medical_record import DBMedicalRecord
from ss_api.models.monitoring_plan.monitoring_plan import DBMonitoringPlan
from ss_api.models.pai.pai import DBPAI
from ss_api.models.report.base import DBReportBase
from ss_api.models.treatment_plan.treatment_plan import DBTreatmentPlan
from ss_api.models.users import DBUserBase
from ss_api.templates import jinja_env
from ss_api.utils.communications.mail import send_mail
from ss_api.utils.pdf_turtle import PDFTurtle
from ss_api.utils.pdf_turtle.models import Margins
from ss_api.utils.pdf_turtle.models import Options as op

locale.setlocale(locale.LC_TIME, "it_IT.UTF-8")


def format_date(date):
    if date:
        return date.strftime("%d %B %Y").capitalize()
    return ""


def format_datetime(dt):
    if dt:
        return dt.strftime("%d %B %Y ore %H:%M").capitalize()
    return ""


async def get_operator_name(operator_id):
    operator = await DBUserBase.find_query(id=PydanticObjectId(operator_id)).to_list()
    if len(operator) > 0:
        operator = operator[0]
    else:
        operator = None
    if operator:
        return f"{operator.firstName} {operator.lastName}"
    return "Unknown Operator " + str(operator_id)


def format_dbmeasure_value(type, obj):
    if type == "bloodPressure":
        return f"{obj.systolic}/{obj.diastolic} mmHg"
    elif type == "glycaemia":
        return f"{obj.value} mg/dl"
    elif type == "oxygenSaturation":
        return f"{obj.value}%"
    elif type == "pain":
        return f"{obj.value}/10"
    elif type == "pulse":
        return f"{obj.value} bpm"
    elif type == "respiratoryRate":
        return f"{obj.value} bpm"
    elif type == "temperature":
        return f"{obj.value} °C"
    elif type == "weight":
        return f"{obj.value} kg"
    elif type == "waterBalance":
        return f"{obj.value} ml"
    else:
        return None


def convert_to_datetime(timedata):
    if len(timedata) == 0:
        return None
    elif len(timedata) == 1:
        timedata = timedata[0]
    else:
        timedata = timedata

    time_str = timedata.time
    weekdayNo = timedata.weekday
    weekday = ""
    if weekdayNo == 0:
        weekday = "Lunedì"
    elif weekdayNo == 1:
        weekday = "Martedì"
    elif weekdayNo == 2:
        weekday = "Mercoledì"
    elif weekdayNo == 3:
        weekday = "Giovedì"
    elif weekdayNo == 4:
        weekday = "Venerdì"
    elif weekdayNo == 5:
        weekday = "Sabato"
    elif weekdayNo == 6:
        weekday = "Domenica"

    return f"{weekday} ore {time_str.strftime('%H:%M:%S')}"


def combine_alarm_msg_for_BP(p):
    alarm_message = []

    if hasattr(p.bloodPressure, "limitMinSystolic") and p.bloodPressure.limitMinSystolic:
        alarm_message.append(f"Min Systolic: {p.bloodPressure.limitMinSystolic}")

    if hasattr(p.bloodPressure, "limitMaxSystolic") and p.bloodPressure.limitMaxSystolic:
        alarm_message.append(f"Max Systolic: {p.bloodPressure.limitMaxSystolic}")

    if hasattr(p.bloodPressure, "limitMinDiastolic") and p.bloodPressure.limitMinDiastolic:
        alarm_message.append(f"Min Diastolic: {p.bloodPressure.limitMinDiastolic}")

    if hasattr(p.bloodPressure, "limitMaxDiastolic") and p.bloodPressure.limitMaxDiastolic:
        alarm_message.append(f"Max Diastolic: {p.bloodPressure.limitMaxDiastolic}")

    alarm = "\n".join(alarm_message)
    return alarm


async def get_all_data_for_ehr_report(patient):
    report_data = {}

    report_data["name"] = patient.firstName
    report_data["surname"] = patient.lastName
    report_data["birthplace"] = str(patient.birthPlace)
    report_data["birthdate"] = patient.birthDate.strftime("%Y-%m-%d") if patient.birthDate else ""
    report_data["gender"] = patient.gender.value if patient.gender else ""
    report_data["phone"] = str(patient.phone)
    report_data["doctor"] = str(patient.doctor)
    report_data["caregiver"] = str(patient.caregiver)
    report_data["email"] = patient.email
    report_data["fiscal_code"] = str(patient.fiscalCode)

    medical_record = await DBMedicalRecord.find_one({"patientId": patient.id})
    if medical_record:
        print("Medical record found")
    # report_data["pathological_history"] = medical_record.pathologicalHistory
    # report_data["physiological_history"] = medical_record.physiologicalHistory
    # report_data["family_history"] = medical_record.familyHistory

    # Perfectly Done
    measurements = await DBMeasureBase.find({"patientId": PydanticObjectId(patient.id)}, with_children=True).to_list()
    report_data["measurements"] = [
        {
            "parameter": m.metadata.type.value,
            "datetime": format_datetime(m.timestamp),
            "value": format_dbmeasure_value(m.metadata.type.value, m),
        }
        for m in measurements
    ]

    monitoring_plan = (
        await DBMonitoringPlan.find({"patientId": patient.id}).sort((DBMonitoringPlan.createdAt, -1)).to_list()
    )
    report_data["monitoring_plan"] = []

    for p in monitoring_plan:
        # Blood Pressure
        if p.bloodPressure:
            report_data["monitoring_plan"].append(
                {
                    "datetime": format_datetime(p.createdAt),
                    "parameter_type": "Blood Pressure",
                    "schedule": convert_to_datetime(p.bloodPressure.schedule),
                    "alarm": (combine_alarm_msg_for_BP(p)),
                    "operator": await get_operator_name(p.createdBy),
                }
            )

        # Weight
        if p.weight:
            report_data["monitoring_plan"].append(
                {
                    "datetime": format_datetime(p.createdAt),
                    "parameter_type": "Weight",
                    "schedule": convert_to_datetime(p.weight.schedule),
                    "alarm": (f"Min: {p.weight.limitMin}\n" f"Max: {p.weight.limitMax}"),
                    "operator": await get_operator_name(p.createdBy),
                }
            )

        # Temperature
        if p.temperature:
            report_data["monitoring_plan"].append(
                {
                    "datetime": format_datetime(p.createdAt),
                    "parameter_type": "Temperature",
                    "schedule": convert_to_datetime(p.temperature.schedule),
                    "alarm": (f"Min: {p.temperature.limitMin}\n" f"Max: {p.temperature.limitMax}"),
                    "operator": await get_operator_name(p.createdBy),
                }
            )

        # Pain
        if p.pain:
            report_data["monitoring_plan"].append(
                {
                    "datetime": format_datetime(p.createdAt),
                    "parameter_type": "Pain",
                    "schedule": convert_to_datetime(p.pain.schedule),
                    "alarm": f"Max: {p.pain.limitMax}",
                    "operator": await get_operator_name(p.createdBy),
                }
            )

        # Respiratory Rate
        if p.respiratoryRate:
            report_data["monitoring_plan"].append(
                {
                    "datetime": format_datetime(p.createdAt),
                    "parameter_type": "Respiratory Rate",
                    "schedule": convert_to_datetime(p.respiratoryRate.schedule),
                    "alarm": (f"Min: {p.respiratoryRate.limitMin}\n" f"Max: {p.respiratoryRate.limitMax}"),
                    "operator": await get_operator_name(p.createdBy),
                }
            )

        # Pulse
        if p.pulse:
            report_data["monitoring_plan"].append(
                {
                    "datetime": format_datetime(p.createdAt),
                    "parameter_type": "Pulse",
                    "schedule": convert_to_datetime(p.pulse.schedule),
                    "alarm": (f"Min: {p.pulse.limitMin}\n" f"Max: {p.pulse.limitMax}"),
                    "operator": await get_operator_name(p.createdBy),
                }
            )

        # Glycaemia
        if p.glycaemia:
            report_data["monitoring_plan"].append(
                {
                    "datetime": format_datetime(p.createdAt),
                    "parameter_type": "Glycaemia",
                    "schedule": convert_to_datetime(p.glycaemia.schedule),
                    "alarm": (f"Min: {p.glycaemia.limitMin}\n" f"Max: {p.glycaemia.limitMax}"),
                    "operator": await get_operator_name(p.createdBy),
                }
            )

        # Oxygen Saturation
        if p.oxygenSaturation:
            report_data["monitoring_plan"].append(
                {
                    "datetime": format_datetime(p.createdAt),
                    "parameter_type": "Oxygen Saturation",
                    "schedule": convert_to_datetime(p.oxygenSaturation.schedule),
                    "alarm": f"Min: {p.oxygenSaturation.limitMin}",
                    "operator": await get_operator_name(p.createdBy),
                }
            )

        # Water Balance
        if p.waterBalance:
            report_data["monitoring_plan"].append(
                {
                    "datetime": format_datetime(p.createdAt),
                    "parameter_type": "Water Balance",
                    "schedule": convert_to_datetime(p.waterBalance.schedule),
                    "alarm": (f"Min: {p.waterBalance.limitMin}\n" f"Max: {p.waterBalance.limitMax}"),
                    "operator": await get_operator_name(p.createdBy),
                }
            )

    # print("PAI Data")
    pai = await DBPAI.find_one({"patientId": patient.id})
    # print(pai)
    # print("\n\n##################\n\n")
    if pai:
        report_data["pai_data_start"] = format_datetime(pai.createdAt)
        report_data["pai_data_end"] = format_datetime(pai.completedAt) if pai.completedAt else ""
        report_data["pai_diagnosis"] = pai.diagnosis
        report_data["pai_goal"] = pai.goal
        report_data["pai_details"] = [
            {
                "datetime": format_datetime(h.at),
                "description": h.description,
                "structure": h.hostStructure,
                "condition": h.condition.value,
                "operator": await get_operator_name(h.createdBy),
            }
            for h in pai.history
        ]

    assessment_scales = await DBIndexMeasureBase.find(
        {"patientId": PydanticObjectId(patient.id)}, with_children=True
    ).to_list()
    report_data["assessment_scales"] = [
        {
            "datetime": format_datetime(a.timestamp),
            "scale_type": a.metadata.type.value,
            "value": a.value,
            "operator": format_datetime(a.nextCheck),
        }
        for a in assessment_scales
    ]

    reports = await DBReportBase.find({"patientId": patient.id}, with_children=True).to_list()
    report_data["reports"] = [
        {
            "datetime": format_datetime(r.createdAt),
            "description": r.description,
            "operator": await get_operator_name(r.createdBy),
        }
        for r in reports
    ]

    treatment_plan = await DBTreatmentPlan.find_one({"patientId": patient.id})
    if treatment_plan:
        report_data["treatment_plan_modify_date"] = format_datetime(treatment_plan.createdAt)
        report_data["treatment_plan_description"] = treatment_plan.notes
        report_data["treatment_plan_operator"] = await get_operator_name(treatment_plan.createdBy)
        report_data["treatment_plan_details"] = [
            {
                "name": t.description,
                "active_ingredient": t.activeIngredient,
                "dosage": t.dosage,
                "administration": t.administrationRoute,
                "note": t.notes,
                "administration_datetime": (
                    [s.time.strftime("%H:%M") for s in t.schedule]
                    if isinstance(t.schedule, list)
                    else format_datetime(t.schedule.firstOccurence)
                ),
            }
            for t in treatment_plan.treatments
        ]

    # try:
    #     with open("ehr_report_data.json", "w", encoding="utf-8") as f:
    #         json.dump(report_data, f, default=str, ensure_ascii=False, indent=2)
    # except Exception as e:
    #     print(f"Error writing to ehr_report_data.json: {e}")

    return report_data


async def send_ehr_email(recipient_email: str, pdf_content: bytes):
    try:
        send_mail(recipient_email, "Your Electronic Health Record", None, attachment=pdf_content)
        print(f"EHR report sent successfully to {recipient_email}")
    except Exception as e:
        print(f"Error sending EHR report to {recipient_email}: {e}")


async def generate_ehr_report(patient):
    report_data = await get_all_data_for_ehr_report(patient)

    template = jinja_env.get_template("reports/ehr_template.html")
    html_content = template.render(report_data=report_data)
    # with open("ehr_report.html", "w") as f:
    #     f.write(html_content)

    try:
        pdf_generator = PDFTurtle(
            html=html_content,
            options=op(margins=Margins(bottom=20, left=10, right=10, top=40, excludeBuiltinStyles=True)),
        )

        pdf_buffer = BytesIO()
        await pdf_generator.save_to_file(pdf_buffer)
        pdf_content = pdf_buffer.getvalue()

    except Exception as e:
        print(f"Error generating PDF: {e}")
        return

    # with open("ehr_report.pdf", "wb") as f:
    #     f.write(pdf_content)

    return pdf_content
