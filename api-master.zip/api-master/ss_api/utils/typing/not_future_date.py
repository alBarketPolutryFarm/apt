from datetime import date
from typing import TYPE_CHECKING, Any, Self

from pydantic import GetCoreSchemaHandler
from pydantic_core.core_schema import (
    CoreSchema,
    date_schema,
    no_info_after_validator_function,
)

from .exceptions import DateInTheFutureError

if TYPE_CHECKING:
    NotFutureDate = date

else:

    class NotFutureDate(date):
        @classmethod
        def __get_pydantic_core_schema__(cls, source: type[Any], handler: GetCoreSchemaHandler) -> CoreSchema:
            return no_info_after_validator_function(cls.validate, date_schema(strict=False))

        @classmethod
        def validate(cls, value: date) -> Self:
            if value > date.today():
                raise DateInTheFutureError()

            return value
