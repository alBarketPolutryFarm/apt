from pydantic_extra_types.phone_numbers import PhoneNumber as _PhoneNumber


class PhoneNumber(_PhoneNumber):
    phone_format: str = "E164"
