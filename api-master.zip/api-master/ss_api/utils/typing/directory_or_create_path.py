from pathlib import Path
from typing import Annotated

from pydantic import AfterValidator, DirectoryPath, Field
from pydantic_core import PydanticCustomError


def _after_validator(path: Path) -> DirectoryPath:
    if not path.exists():
        path.mkdir(parents=True)
    elif not path.is_dir():
        raise PydanticCustomError("path_not_directory", "Path does point to a file")
    return path


DirectoryOrCreatePath = Annotated[
    DirectoryPath | Path,
    AfterValidator(_after_validator),
    Field(description="Path to directory, if it does not exist create it"),
]
