from typing import Annotated

from beanie import PydanticObjectId
from pydantic import AliasChoices, Field, WithJsonSchema

Id = Annotated[
    PydanticObjectId,
    Field(
        alias="_id",
        validation_alias=AliasChoices("_id", "id"),
    ),
    WithJsonSchema(
        {
            "type": "string",
            "title": "Id",
            "example": "5eb7cf5a86d9755df3a6c593",
            "pattern": r"^[a-f0-9]{24}$",
            "description": "MongoDB document ObjectID",
        }
    ),
]

IdOptional = Annotated[Id, Field(default_factory=lambda: PydanticObjectId())]
