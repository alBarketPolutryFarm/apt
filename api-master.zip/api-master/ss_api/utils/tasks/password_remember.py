import asyncio
from datetime import datetime, timedelta

from beanie.odm.operators.find.comparison import LT

from ss_api.models.users import DBUserBase
from ss_api.templates import jinja_env
from ss_api.utils.communications.mail import send_mail_async
from ss_api.utils.settings import get_settings
from ss_api.utils.tasks.periodic_job import PeriodicJob


# TODO : Improve this Logic First
async def OperatorPasswordReminder() -> None:
    now = datetime.now()
    ninety_days_ago = now - timedelta(days=1)

    users = await DBUserBase.find((LT(DBUserBase.lastPasswordChange, ninety_days_ago))).to_list()

    print(f"Found {len(users)} users to remind about password change")

    for user in users:
        template = jinja_env.get_template("./email/operator_password_reminder.html")
        body = template.render(operator=user, settings=get_settings())

        loop = asyncio.get_event_loop()
        loop.create_task(
            send_mail_async(
                subject="Servizio Salute | Promemoria cambio password",
                body=body,
                email=user.email,
            )
        )

        user.lastPasswordUpdateReminder = now
        await user.save()


def init_password_reminder_tasks():
    PeriodicJob(job=OperatorPasswordReminder, interval=timedelta(days=1)).start()
