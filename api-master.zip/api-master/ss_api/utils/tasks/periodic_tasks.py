import json
from base64 import b64encode
from datetime import timedelta
from logging import getLogger
from random import randrange

from beanie.odm.operators.find.comparison import NE, Eq
from firebase_admin import messaging

from ...models.report import DBReportBase
from ...models.report.signature import DBSignedReportBase, SignatureStatus
from ..open_api.exceptions import OpenAPIException
from ..orthanc.fetch_exams import fetch_exams
from ..settings import get_settings
from .periodic_job import PeriodicJob


def send_data_push(topic: str, data: dict) -> None:
    message = messaging.Message(
        data={"payload": b64encode(json.dumps(data).encode("utf-8")).decode("utf-8")},
        topic=topic,
        android=messaging.AndroidConfig(priority="high"),
        fcm_options=messaging.FCMOptions(),
    )

    messaging.send(message)


def send_treatments_push():
    getLogger(__package__).info("> send treatments push")
    send_data_push("treatments", {"type": "treatmentNotificationSync"})


def send_monitoring_plans_push():
    getLogger(__name__).info("> send monitoring_plans push")
    send_data_push("monitoring_plans", {"type": "monitoringPlanNotificationSync"})


async def check_report_signatures_status():
    getLogger(__name__).info("> check report signatures status")
    query = DBReportBase.find(NE(DBSignedReportBase.signature, None)).find(
        Eq(DBSignedReportBase.signature.status, SignatureStatus.waiting)
    )
    reports = await query.to_list()

    for r in reports:
        try:
            getLogger(__name__).info(f"> check report signatures status for {r.id}")
            await r.update_signature_status()
        except OpenAPIException:
            pass


def init_periodic_tasks() -> None:
    settings = get_settings()
    if settings.firebase_credentials_path:
        PeriodicJob(send_treatments_push, timedelta(hours=6), timedelta(seconds=randrange(60 * 1, 60 * 30))).start()
        PeriodicJob(
            send_monitoring_plans_push, timedelta(hours=8), timedelta(seconds=randrange(60 * 1, 60 * 30))
        ).start()

    else:
        getLogger(__name__).error("> firebase not initialized, skip push task scheduling")

    if settings.orthanc:
        PeriodicJob(fetch_exams, timedelta(hours=2), timedelta(seconds=randrange(60 * 1, 60 * 30))).start()

    else:
        getLogger(__name__).error("> orthanc connection not initialized, skip fetch exams scheduling")

    if settings.open_api:
        PeriodicJob(
            check_report_signatures_status, timedelta(hours=1), timedelta(seconds=randrange(60 * 1, 60 * 30))
        ).start()

    else:
        getLogger(__name__).error("> open api not initialized, skip check report signatures status scheduling")
