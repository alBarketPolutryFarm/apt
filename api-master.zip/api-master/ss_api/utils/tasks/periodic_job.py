import asyncio
from datetime import timedelta
from logging import getLogger
from typing import Callable


class PeriodicJob:
    def __init__(self, job: Callable, interval: timedelta, initial_delay: timedelta = timedelta(seconds=0)):
        self.job = job
        self.interval = interval
        self.initial_delay = initial_delay

        self.__name__ = job.__name__

        self._logger = getLogger(__package__)

    async def run(self) -> None:
        await asyncio.sleep(self.initial_delay.total_seconds())
        while True:
            self._logger.info(f"Run periodic job '{self.__name__}' iteration")
            try:
                job = self.job()
                if asyncio.iscoroutine(job):
                    await job
            except Exception as e:
                self._logger.error(f"Periodic job '{self.__name__}' raises an exception", extra={"exception": str(e)})
            await asyncio.sleep(self.interval.total_seconds())

    def start(self):
        self._logger.info(f"Periodic job '{self.__name__}' scheduled every {self.interval}")
        asyncio.create_task(self.run())
