from fastapi import FastAPI
from fastapi_responses import custom_openapi

from ss_api.utils.logging import RequestsLoggerMiddleware
from ss_api.utils.middleware.operation_id_from_path import use_operation_id_from_path
from ss_api.utils.middleware.versioned_routes import use_versioned_routes


def init_api(app: FastAPI) -> FastAPI:
    from ss_api.routes import include_routers

    app.openapi = custom_openapi(app)
    include_routers(app)
    use_versioned_routes(app)
    use_operation_id_from_path(app)

    app.add_middleware(RequestsLoggerMiddleware)

    return app
