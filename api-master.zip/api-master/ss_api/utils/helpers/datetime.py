from datetime import date, datetime, time, timedelta, timezone
from typing import Iterator, Tuple


def week_start(day: date) -> date:
    return day - timedelta(days=day.weekday())


def get_days(start_date: date, end_date: date) -> Iterator[date]:
    span = end_date - start_date
    for i in range(span.days + 1):
        yield start_date + timedelta(days=i)


def get_day_bounds(
    day: datetime | date, bound_time: time = time(hour=0, tzinfo=timezone.utc)
) -> Tuple[datetime, datetime]:
    _day = datetime.combine(day, time(hour=12, tzinfo=timezone.utc)) if isinstance(day, date) else day

    day_start = _day.combine(_day.date(), bound_time)
    if day_start > _day:
        day_start = day_start - timedelta(days=1)

    return day_start, day_start + timedelta(days=1)
