from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request


class RootPathPrefixStrip(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        root_path = request.app.root_path
        path = request.scope["path"]
        if path.startswith(root_path):
            new_path = request.scope["path"].replace(root_path, "", 1)
            request.scope["path"] = new_path
            request.scope["raw_path"] = new_path.encode("utf-8")
            request._url = request.url.replace(path=new_path)

        response = await call_next(request)
        return response
