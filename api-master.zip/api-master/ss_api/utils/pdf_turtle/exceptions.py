from httpx import ConnectError

from ss_api.utils.exceptions.remote_service import ExternalServiceConnectError
from ss_api.utils.settings.exceptions import NotInitializedSettingsError


class PDFTurtleException(Exception):
    pass


class PDFTurtleNotInitializedError(PDFTurtleException, NotInitializedSettingsError):
    pass


class PDFTurtleConnectError(PDFTurtleException, ExternalServiceConnectError, ConnectError):
    def __init__(self, message: str, **kwargs) -> None:
        super().__init__(message or "Unable to connect to pdf turtle server", **kwargs)
