class ErrorWrapper:
    def __init__(self, exc: Exception | str, loc: tuple[str | int, ...], type: str = ""):
        self.loc = loc
        self.msg = str(exc)
        self.type = type
