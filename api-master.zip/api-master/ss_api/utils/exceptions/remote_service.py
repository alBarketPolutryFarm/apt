class ExternalServiceConnectError(Exception):
    def __init__(self, message):
        super().__init__(message or "Unable to connect to external service")
