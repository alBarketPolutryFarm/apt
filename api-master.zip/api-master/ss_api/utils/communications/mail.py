import asyncio
import logging
import ssl
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from functools import partial
from smtplib import SMTP, SMTP_SSL, SMTPAuthenticationError, SMTPServerDisconnected

from ss_api.utils.settings import get_settings

from .exceptions import (
    SMTPServerAuthenticationError,
    SMTPServerConnectionError,
    SMTPServerException,
    SMTPServerNotInitializedError,
    SMTPServerTimeoutError,
)

_logger = logging.getLogger(__package__)


def send_mail(email, subject, body, attachment=None):
    _logger.debug(f"Sending email '{subject}' to '{email}'")

    settings = get_settings()

    if settings.smtp is None:
        _logger.error("Unable to send email: Missing SMTP configuration")
        raise SMTPServerNotInitializedError()

    if attachment:
        message = MIMEMultipart()
        _logger.debug("Creating multipart message with attachment")
    else:
        message = MIMEText(body, "html")
        _logger.debug("Creating plain text message without attachment")

    message["Subject"] = subject
    message["From"] = settings.smtp.sender
    message["To"] = email
    try:
        if attachment:
            message.attach(
                MIMEText(
                    body,
                    "html",
                )
            )
            for file in attachment:
                print("File : ", file["file_name"])
                pdf_part = MIMEApplication(file["content"], _subtype="pdf")
                pdf_part.add_header("Content-Disposition", "attachment", filename=file["file_name"])
                message.attach(pdf_part)
                _logger.debug(f"Attached PDF with size: {len(file['content'])} bytes")
    except Exception as e:
        print("Error in attachment : ", str(e))
        # pdf_part = MIMEApplication(attachment, _subtype="pdf")
        # pdf_part.add_header("Content-Disposition", "attachment", filename="ehr_report.pdf")
        # message.attach(pdf_part)
        # _logger.debug(f"Attached PDF with size: {len(attachment)} bytes")

    context = ssl.create_default_context()
    if settings.mode == "development":
        _logger.debug("Development mode: disabling SSL certificate verification")
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE

    try:
        _logger.debug(f"Connecting to the email server: {settings.smtp.host}:{settings.smtp.port}")
        try:
            with SMTP(settings.smtp.host, settings.smtp.port, timeout=60) as smtp:
                smtp.starttls(context=context)
                smtp.login(settings.smtp.username, settings.smtp.password)
                smtp.send_message(message)
                _logger.debug("Email sent successfully with STARTTLS")
                return
        except Exception:
            _logger.error("Error in SSL connection")
            with SMTP_SSL(settings.smtp.host, settings.smtp.port, context=context, timeout=60) as smtp:
                _logger.debug("Logging in to the email server...")
                smtp.login(settings.smtp.username, settings.smtp.password)
                _logger.debug("Sending email...")
                smtp.send_message(message)
                _logger.debug("Email sent successfully with SSL")
                return

    except SMTPServerDisconnected as e:
        _logger.error(f"Error in connection to mail server: {str(e)}")
        raise SMTPServerConnectionError(str(e))
    except SMTPAuthenticationError as e:
        _logger.error(f"Error in authentication to mail server: {str(e)}")
        raise SMTPServerAuthenticationError(str(e))
    except TimeoutError as e:
        _logger.error(f"Server timeout: {str(e)}")
        raise SMTPServerTimeoutError(str(e))
    except Exception as e:
        _logger.error(f"Generic error while sending email: {str(e)}")
        raise SMTPServerException(f"Failed to send email: {str(e)}")


async def send_mail_async(email, subject, body, attachment=None):
    loop = asyncio.get_running_loop()
    if attachment:
        await loop.run_in_executor(None, partial(send_mail, email, subject, body, attachment))
    else:
        await loop.run_in_executor(None, partial(send_mail, email, subject, body))
