from pydantic import HttpUrl

from ..open_api_module import OpenAPIModule
from .models import NewSignatureRequest, SignatureRequestResponse


class DigitalSignature(OpenAPIModule):
    _base_url_production: HttpUrl = "https://ws.firmadigitale.com"
    _base_url_test: HttpUrl = "https://test.ws.firmadigitale.com"

    async def request_pdf_signature(self, request: NewSignatureRequest) -> SignatureRequestResponse:
        async with self._client as client:
            response = await client.post("/firma_elettronica/base", json=request.model_dump(mode="json"))
            return SignatureRequestResponse(**response.json())

    async def get_signature_request_information(self, request_id: str) -> SignatureRequestResponse:
        async with self._client as client:
            response = await client.get(f"/firma_elettronica/{request_id}")
            return SignatureRequestResponse(**response.json())
