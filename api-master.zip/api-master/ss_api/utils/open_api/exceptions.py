from ss_api.utils.settings.exceptions import NotInitializedSettingsError


class OpenAPIException(Exception):
    pass


class OpenAPINotInitializedError(OpenAPIException, NotInitializedSettingsError):
    pass


class OpenAPIUnauthorized(OpenAPIException):
    pass


class OpenAPIRemoteError(OpenAPIException):
    pass


class OpenAPIFundsExhausted(OpenAPIException):
    pass


class OpenAPINotFound(OpenAPIException):
    pass


class OpenAPITimeout(OpenAPIException):
    pass
