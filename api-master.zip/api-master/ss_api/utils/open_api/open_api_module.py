from abc import ABC
from contextlib import asynccontextmanager

from httpx import AsyncClient
from pydantic import HttpUrl

from ss_api.utils.settings.settings import OpenAPISettings, get_settings

from .client import OpenAPIAsyncClient
from .exceptions import OpenAPINotInitializedError


class OpenAPIModule(ABC):
    _base_url_production: HttpUrl
    _base_url_test: HttpUrl

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._settings.token}"}

    @property
    @asynccontextmanager
    async def _client(self) -> AsyncClient:
        client = OpenAPIAsyncClient(base_url=self._base_url, headers=self._headers)
        try:
            yield client
        finally:
            await client.aclose()

    @property
    def _settings(self) -> OpenAPISettings:
        settings = get_settings()
        if not settings.open_api:
            raise OpenAPINotInitializedError

        return settings.open_api

    @property
    def _base_url(self) -> HttpUrl:
        return self._base_url_production if self._mode == "production" else self._base_url_test

    @property
    def _mode(self):
        settings = get_settings()
        return settings.mode
