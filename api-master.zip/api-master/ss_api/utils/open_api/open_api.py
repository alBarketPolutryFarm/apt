from .digital_signature import DigitalSignature


class OpenAPI:
    digital_signature: DigitalSignature = DigitalSignature()
