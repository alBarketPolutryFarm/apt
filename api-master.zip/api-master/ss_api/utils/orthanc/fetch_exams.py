from datetime import datetime, timedelta
from logging import getLogger

from beanie.odm.operators.find.comparison import Eq

from ss_api.models.cache.fetched_exam import DBFetchedExam
from ss_api.models.report import DBExamReport, DBExamReportRequest

from ...models.enum.exam_modality import ExamModality
from ...models.report.exam_report import DBExam
from ...models.users import DBPatient
from .orthanc import get_orthanc


async def handle_new_study(study_id: str) -> DBExamReportRequest | None:
    logger = getLogger(__package__)

    if await DBFetchedExam.find_one(Eq(DBFetchedExam.studyId, study_id)).exists():
        return None
    if (
        await DBExamReportRequest.find_one(Eq(DBExamReportRequest.exam.studyId, study_id)).exists()
        or await DBExamReport.find_one(Eq(DBExamReport.exam.studyId, study_id)).exists()
    ):
        await DBFetchedExam(studyId=study_id).create()
        return None

    orthanc = get_orthanc()
    study = orthanc.get_studies_id(study_id)

    fiscal_code = study["PatientMainDicomTags"]["PatientID"]
    patient = await DBPatient.find(Eq(DBPatient.fiscalCode, fiscal_code.upper())).first_or_none()

    modalities = []
    for series_id in study["Series"]:
        series = orthanc.get_series_id(series_id)
        modality = series["MainDicomTags"]["Modality"]
        if modality in iter(ExamModality):
            modalities.append(series["MainDicomTags"]["Modality"])

    exam_report_request = DBExamReportRequest(
        patientId=patient.id if patient is not None else None, exam=DBExam(studyId=study["ID"], modalities=modalities)
    )

    await exam_report_request.create()
    await DBFetchedExam(studyId=study_id).create()

    logger.info(f"New exam found with study id '{study_id}'")

    return exam_report_request


async def fetch_exams(since: datetime | None = None):
    if since is None:
        since = datetime.now() - timedelta(days=3)

    orthanc = get_orthanc()
    response = orthanc.get_changes(params={"since": since.isoformat()})

    new_studies = filter(lambda change: change["ChangeType"] == "NewStudy", response["Changes"])
    new_studies_id = map(lambda change: change["ID"], new_studies)

    for study_id in new_studies_id:
        await handle_new_study(study_id)
