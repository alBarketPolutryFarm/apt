from functools import cache
from typing import Dict, List, Union

import httpx
from httpx import ConnectError
from pyorthanc import Orthanc as _Orthanc

from ss_api.utils.settings import get_settings

from .exceptions import OrthancConnectionError, OrthancNotInitializedError


class Orthanc(_Orthanc):
    def __init__(self):
        settings = get_settings()
        if settings.orthanc is None:
            raise OrthancNotInitializedError

        super().__init__(
            str(settings.orthanc.api_url).rstrip("/"),
            username=settings.orthanc.username,
            password=settings.orthanc.password,
        )

    def _get(self, *args, **kwargs) -> Union[Dict, List, str, bytes, int, httpx.Response]:
        try:
            return super()._get(*args, **kwargs)
        except ConnectError as e:
            raise OrthancConnectionError from e

    def _post(self, *args, **kwargs) -> Union[Dict, List, str, bytes, int, httpx.Response]:
        try:
            return super()._post(*args, **kwargs)
        except ConnectError as e:
            raise OrthancConnectionError from e


@cache
def get_orthanc() -> Orthanc:
    return Orthanc()
