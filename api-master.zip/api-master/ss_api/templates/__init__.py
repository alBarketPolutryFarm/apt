from pathlib import Path

from jinja2 import ChainableUndefined, Environment, FileSystemLoader, select_autoescape

jinja_env = Environment(
    loader=FileSystemLoader(Path(__file__).parent), autoescape=select_autoescape(), undefined=ChainableUndefined
)
