from typing import List

import accept_types
from beanie import PydanticObjectId
from fastapi import APIRouter, HTTPException, Path
from fastapi.params import Header
from starlette.responses import HTMLResponse

from ss_api.models.agreement.agreement import (
    DBAgreement,
    FulfilledAgreement,
    NewAgreement,
)
from ss_api.models.agreement.agreement_signing import NewAgreementSigning
from ss_api.models.agreement.agreement_type import AgreementType
from ss_api.models.agreement.exceptions import (
    AgreementAlreadySigned,
    MissingAgreementSigningOptions,
)
from ss_api.utils.auth import AuthAdmin, AuthUser, AuthUserOptional
from ss_api.utils.responses import Success

router = APIRouter(prefix="/agreements", tags=["agreements"])


@router.get("", response_model=List[FulfilledAgreement], tags=["admins"], response_model_exclude_none=True)
async def get_agreements_list(user: AuthUserOptional) -> List[FulfilledAgreement]:
    return await DBAgreement.query(user=user).to_list()


@router.post("", response_model=Success, tags=["admins"])
async def create_new_agreement(agreement: NewAgreement, admin: AuthAdmin) -> Success:
    await DBAgreement(**agreement.model_dump(), createdBy=admin.id).create()
    return Success("Agreement has been created")


@router.get(
    "/{agreement_type}",
    response_model=FulfilledAgreement,
    responses={200: {"content": {"text/html": {}}}},
    openapi_extra={
        "parameters": [
            {
                "in": "path",
                "name": "agreement_type",
                "required": True,
                "schema": {"$ref": "#/components/schemas/AgreementType"},
            }
        ]
    },
    response_model_exclude_none=True,
)
@router.get(
    "/{agreement_id}",
    response_model=FulfilledAgreement,
    responses={200: {"content": {"text/html": {}}}},
    openapi_extra={
        "parameters": [
            {
                "in": "path",
                "name": "agreement_id",
                "required": True,
                "schema": {"title": "Agreement Id", "type": "string"},
            }
        ]
    },
    response_model_exclude_none=True,
)
async def get_agreement(
    user: AuthUserOptional,
    agreement_id: PydanticObjectId | AgreementType = Path(include_in_schema=False),
    accept: str | None = Header(default=None, include_in_schema=False),
) -> FulfilledAgreement | HTMLResponse:
    results = await DBAgreement.query(
        user=user,
        **(
            {"agreement_id": agreement_id}
            if isinstance(agreement_id, PydanticObjectId)
            else {"agreement_type": agreement_id}
        )
    ).to_list()

    if len(results) == 0:
        if isinstance(agreement_id, AgreementType):
            raise HTTPException(status_code=204, detail="No agreement available")
        raise HTTPException(status_code=404, detail="Agreement not found")

    if accept_types.get_best_match(accept, ["text/html", "*/*"]) == "text/html":
        return HTMLResponse(results[0].content)

    return results[0]


@router.post("/{agreement_id}/sign", response_model=Success)
async def sign_agreement(
    agreement_id: PydanticObjectId,
    signing: NewAgreementSigning,
    user: AuthUser,
) -> Success:
    try:
        agreement = (await DBAgreement.query(user=user, agreement_id=agreement_id).to_list())[0]

    except KeyError:
        raise HTTPException(status_code=404, detail="Agreement not found")

    try:
        await agreement.sign(user=user, options=signing.options)

    except AgreementAlreadySigned:
        raise HTTPException(status_code=424, detail="The agreement has already been signed")

    except MissingAgreementSigningOptions:
        raise HTTPException(status_code=422, detail="Missing some agreement options")

    return Success("Agreement has been signed")
