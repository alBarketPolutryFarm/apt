from typing import List, Optional

from beanie import PydanticObjectId
from fastapi import APIRouter, HTTPException
from starlette import status

from ss_api.models.chat.chat import DBChat
from ss_api.models.chat.chat.base import DBChatBase
from ss_api.models.chat.chat.service_chat import DBServiceChat
from ss_api.models.chat.chat.users_chat import DBUsersChat
from ss_api.models.users import DBUser
from ss_api.models.users.admin import DBAdmin
from ss_api.models.users.base import DBUserBase, UserStatus
from ss_api.models.users.nurse import DBNurse
from ss_api.models.users.operator import DBOperator
from ss_api.models.users.type import UserType
from ss_api.utils.auth import AuthUser
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Created

router = APIRouter(prefix="/chat", tags=["control"])


@router.get("/permit_list", response_model=List[DBUser])
async def get_chattable_persons(user: AuthUser, pagination: QueryPagination, q: Optional[str] = None) -> List[DBUser]:

    if user.__user_type__ in {UserType.superadmin, UserType.admin}:
        query = DBUserBase.find(
            DBUserBase.status == UserStatus.ACTIVE,
            with_children=True,
        )
        query = pagination(query)
        result = await query.to_list()
        result = [user for user in result if user.__user_type__ != UserType.patient]
        return result

    elif user.__user_type__ == UserType.operator:
        query = DBOperator.find(
            DBUserBase.status == UserStatus.ACTIVE,
            DBUserBase.createdBy == user.createdBy,
            DBUserBase.id != user.id,
            with_children=True,
        )
        query = pagination(query)
        result = await query.to_list()
        return result

    elif user.__user_type__ == UserType.patient:
        nurses_query = DBNurse.find_query(by=user)
        nurses = await nurses_query.to_list()
        admins_query = DBAdmin.find_all()
        admins = await admins_query.to_list()

        all_chattable = nurses + admins
        offset = pagination.offset
        limit = pagination.limit

        if limit is not None:
            result = all_chattable[offset : offset + limit]
        else:
            result = all_chattable[offset:]
        return result
    else:
        raise HTTPException(status_code=403, detail="Unauthorized")


@router.post("/create", status_code=201, response_model=Created)
async def create_chat(user: AuthUser, target: Optional[PydanticObjectId] = None) -> Created:
    if user.__user_type__ == UserType.admin and target is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="`target` is required for admins",
        )

    if target is None:
        raise HTTPException(status_code=500, detail="Pls Select the Person to chat with")
    else:
        target_user = await DBUserBase.get(target, with_children=True)
        if target_user is None:
            raise HTTPException(status_code=404, detail="Target user not found")

    if user.id == target_user.id:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Cannot chat with yourself")

    existing_chat = await DBChatBase.find_one({"membersId": {"$all": [user.id, target_user.id]}}, fetch_links=True)
    if existing_chat:
        return Created(existing_chat.id, message="Chat already exists")

    if user.__user_type__ == UserType.patient:
        if target_user.__user_type__ not in {UserType.admin, UserType.nurse, UserType.doctor}:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Patients can only initiate chats with admins, nurses or doctors",
            )

    if target_user.__user_type__ == UserType.patient:
        if user.__user_type__ not in {UserType.admin, UserType.nurse, UserType.doctor, UserType.superadmin}:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only admins, nurses or doctor can initiate chats with patients",
            )

    match user.__user_type__:
        case UserType.patient | UserType.admin | UserType.nurse | UserType.doctor | UserType.superadmin:
            chat: DBChat
            if target_user.__user_type__ == UserType.admin or target_user.__user_type__ == UserType.superadmin:
                chat = DBServiceChat(createdBy=user.id, membersId=[target_user.id])
            else:
                chat = DBUsersChat(createdBy=user.id, membersId=[user.id, target_user.id])

            await chat.save()
            return Created(chat.id, message="Chat created")

        case UserType.operator:
            if target_user.__user_type__ == UserType.operator:
                chat = DBUsersChat(createdBy=user.id, membersId=[user.id, target_user.id])
                await chat.save()
                return Created(chat.id, message="Chat created")
            else:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Operators can only chat with other operators",
                )
        case _:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Unauthorized")
