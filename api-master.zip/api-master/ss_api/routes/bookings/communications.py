from typing import TYPE_CHECKING

from ss_api.templates import jinja_env
from ss_api.utils.communications import send_mail

if TYPE_CHECKING:
    from ss_api.models.booking import DBBooking
    from ss_api.models.users import DBUserBase


def send_email_booking_created(target: "DBUserBase", booking: "DBBooking", provider: "DBUserBase") -> None:
    template = jinja_env.get_template("./email/booking/created.html")
    body = template.render(
        target=target,
        provider=provider,
        booking=booking,
    )

    send_mail(
        subject="Servizio Salute | Appuntamento creato",
        body=body,
        email=target.email,
    )


def send_email_for_provider_booking_created(target: "DBUserBase", booking: "DBBooking", provider: "DBUserBase") -> None:
    template = jinja_env.get_template("./email/booking/created_for_provider.html")
    body = template.render(
        target=target,
        provider=provider,
        booking=booking,
    )

    send_mail(
        subject="Servizio Salute | Appuntamento creato",
        body=body,
        email=provider.email,
    )


def send_email_booking_deleted(target: "DBUserBase", booking: "DBBooking", provider: "DBUserBase") -> None:
    template = jinja_env.get_template("./email/booking/deleted.html")
    body = template.render(
        target=target,
        provider=provider,
        booking=booking,
    )

    send_mail(
        subject="Servizio Salute | Appuntamento cancellato",
        body=body,
        email=target.email,
    )


def send_email_for_provider_booking_deleted(target: "DBUserBase", booking: "DBBooking", provider: "DBUserBase") -> None:
    template = jinja_env.get_template("./email/booking/deleted.html")
    body = template.render(
        target=target,
        provider=provider,
        booking=booking,
    )

    send_mail(
        subject="Servizio Salute | Appuntamento cancellato",
        body=body,
        email=target.email,
    )
