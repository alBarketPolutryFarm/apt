from fastapi import APIRouter

from .sign_in import router as sign_in_router
from .sign_up import router as sign_up_router
from .token import router as token_router

router = APIRouter(prefix="/auth", tags=["auth"])

router.include_router(sign_up_router)
router.include_router(sign_in_router)
router.include_router(token_router)
