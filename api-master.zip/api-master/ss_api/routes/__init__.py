from fastapi import FastAPI

from . import admins, agreements, alarms
from . import app as app_api
from . import (
    auth,
    bookings,
    callbacks,
    caregivers,
    chat,
    chats,
    dashboard,
    diets,
    doctors,
    exams,
    files,
    indexes,
    measures,
    medical_record,
    monitoring_plans,
    nurses,
    operators,
    pai,
    patients,
    reports,
    screenings,
    system,
    treatment_plans,
    user,
    users,
)


def include_routers(app: FastAPI) -> FastAPI:
    app.include_router(auth.router)
    app.include_router(user.router)
    app.include_router(medical_record.router)
    app.include_router(reports.router)
    app.include_router(pai.router)
    app.include_router(indexes.router)
    app.include_router(treatment_plans.router)
    app.include_router(monitoring_plans.router)
    app.include_router(measures.router)
    app.include_router(diets.router)
    app.include_router(patients.router)
    app.include_router(admins.router)
    app.include_router(nurses.router)
    app.include_router(doctors.router)
    app.include_router(operators.router)
    app.include_router(caregivers.router)
    app.include_router(agreements.router)
    app.include_router(exams.router)
    app.include_router(files.router)
    app.include_router(alarms.router)
    app.include_router(bookings.router)
    app.include_router(chats.router)
    app.include_router(users.router)
    app.include_router(app_api.router)
    app.include_router(callbacks.router)
    app.include_router(system.router)
    app.include_router(screenings.router)
    app.include_router(chat.router)
    app.include_router(dashboard.router)
    return app
