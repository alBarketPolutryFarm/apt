from datetime import datetime, timedelta, timezone

from fastapi import APIRouter

from ss_api.models.diet import DBDiet
from ss_api.models.diet.diet_adherence import DBDietAdherence, NewDietAdherence
from ss_api.models.diet.diet_schedule_entry import DietScheduleEntry
from ss_api.utils.auth import AuthPatient
from ss_api.utils.query_string.date_range import query_date_range
from ss_api.utils.responses import Success

router = APIRouter(prefix="/schedule")


@router.get(
    "", response_model=list[DietScheduleEntry], response_model_exclude_unset=True, response_model_exclude_none=True
)
async def get_schedule(
    patient: AuthPatient,
    date_range=query_date_range(
        default_factory_start_date=lambda: datetime.now(timezone.utc),
        default_factory_end_date=lambda: datetime.now(timezone.utc) + timedelta(days=7),
    ),
) -> list[DietScheduleEntry]:
    return await DBDiet.get_complete_schedule(patient=patient, start_date=date_range.start, end_date=date_range.end)


@router.post("/adherence", response_model=Success, status_code=201)
async def insert_adherence(
    diet_adherence: NewDietAdherence,
    patient: AuthPatient,
) -> Success:
    # TODO: check if the meal is in the schedule
    await DBDietAdherence(**diet_adherence.model_dump(), patientId=patient.id).insert()
    return Success()
