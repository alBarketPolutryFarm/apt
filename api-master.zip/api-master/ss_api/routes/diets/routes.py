from typing import List

from beanie.odm.operators.find.comparison import Eq
from fastapi import APIRouter
from pymongo import DESCENDING
from starlette.responses import Response

from ss_api.models.diet.diet import DBDiet, Diet
from ss_api.models.diet.diet_out_meal import DBDietOutMeal, DietOutMeal, NewDietOutMeal
from ss_api.utils.auth import AuthPatient
from ss_api.utils.db import query_sort
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/diets", tags=["diets"])


@router.get("", response_model=List[Diet])
async def get_diets_list(
    pagination: QueryPagination,
    patient: AuthPatient,
    date_range=query_date_range(),
) -> List[DBDiet]:
    query = DBDiet.find(DBDiet.patientId == patient.id)
    query = filter_by_date_range(query, date_range)
    query = query_sort(query, "effectiveDate", DESCENDING)
    query = pagination(query)
    return await query.to_list()


@router.post("/out-meals", response_model=Success, status_code=201)
async def insert_adherence(
    diet_out_meal: NewDietOutMeal,
    patient: AuthPatient,
) -> Success:
    await DBDietOutMeal(**diet_out_meal.model_dump(), patientId=patient.id).insert()
    return Success()


@router.get("/out-meals", response_model=List[DietOutMeal])
async def get_side_effects(
    pagination: QueryPagination,
    patient: AuthPatient,
    date_range=query_date_range(),
) -> List[DBDietOutMeal]:
    query = DBDietOutMeal.find(Eq(DBDietOutMeal.patientId, patient.id))
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    return await query.to_list()


@router.get(
    "/current",
    response_model=Diet,
    responses={204: {"description": "No active diet at the moment"}},
)
async def get_current_diet(
    patient: AuthPatient,
) -> Diet | Response:
    if (current := await DBDiet.find_period().find(DBDiet.patientId == patient.id).first_or_none()) is None:
        Response(status_code=204)
    return current
