from . import schedule
from .routes import router

router.include_router(schedule.router)
