from fastapi import APIRouter

from ss_api.utils.responses import Success

router = APIRouter(prefix="/health")


@router.get("", response_model=Success)
async def get_health() -> Success:
    return Success("OK")
