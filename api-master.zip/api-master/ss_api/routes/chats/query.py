from typing import Annotated

from beanie import PydanticObjectId
from fastapi import Depends, HTTPException, Path

from ss_api.models.chat import DBChat, DBChatBase, DBServiceChat, DBUsersChat
from ss_api.models.chat.chat import DBBroadcastChat
from ss_api.models.users import DBPatient, DBUserBase, UserType
from ss_api.utils.auth import AuthUser


def query_chat(create_if_not_exist: bool = False) -> DBChat:
    async def _get_chat(
        chat_id: Annotated[
            PydanticObjectId,
            Path(
                title="Chat id or user id",
                description=f"""To refer to a chat with a single user, user id can be used also.
                            Special value \"{'0' * 24}\" referes to the service chat for user
                            and broadcast one for the admins""",
            ),
        ],
        user: AuthUser,
    ) -> DBChat:
        if chat_id == PydanticObjectId("0" * 24):
            if user.__user_type__ == UserType.admin or user.__user_type__ == UserType.superadmin:
                return await DBBroadcastChat.find().first_or_none()

            chats = await DBServiceChat.find_query(by=user).to_list()
            if len(chats) != 0:
                return chats[0]

            if create_if_not_exist:
                chat = DBServiceChat(createdBy=user.id, membersId=[user.id])
                await chat.save()
                return chat

            raise HTTPException(status_code=404, detail="Chat not found")

        chat = await DBBroadcastChat.find_query(id=chat_id).first_or_none()
        if chat is not None:
            return chat

        if user.__user_type__ == UserType.admin or user.__user_type__ == UserType.superadmin:
            chats = await DBChatBase.find_query(id=chat_id).to_list()
            if len(chats) != 0:
                return chats[0]

            chats = await DBServiceChat.find_query(id=chat_id).to_list()
            if len(chats) != 0:
                return chats[0]

            chats = await DBServiceChat.find_query(target=chat_id).to_list()
            if len(chats) != 0:
                return chats[0]

            patients = await DBPatient.find_query(id=chat_id).to_list()
            if len(patients) != 0 and create_if_not_exist:
                chat = DBServiceChat(createdBy=user.id, membersId=[patients[0].id])
                await chat.save()
                return chat

            raise HTTPException(status_code=404, detail="Chat not found")

        chats = await DBChatBase.find_query(by=user, id=chat_id).to_list()
        if len(chats) != 0:
            return chats[0]

        targets = await DBUserBase.find_query(by=user, id=chat_id).to_list()
        if len(targets) != 0:
            chats = await DBChatBase.find_query(by=user, target=targets[0], only_private=True).to_list()
            if len(chats) != 0:
                return chats[0]

            if create_if_not_exist:
                chat = DBUsersChat(createdBy=user.id, membersId=[user.id, targets[0].id])
                await chat.save()
                return chat

        raise HTTPException(status_code=404, detail="Chat not found")

    return Depends(_get_chat)


QueryChat = Annotated[DBChat, query_chat()]
QueryChatOrCreate = Annotated[DBChat, query_chat(create_if_not_exist=True)]
