from datetime import datetime, timedelta, timezone
from typing import List

from fastapi import APIRouter, BackgroundTasks, HTTPException
from pymongo import ASCENDING

from ss_api.models.chat import (
    ChatMessage,
    DBChatMessage,
    DBChatMessageBase,
    NewChatMessage,
)
from ss_api.models.chat.chat.type import ChatType
from ss_api.models.users import UserType
from ss_api.routes.chats.query import QueryChat, QueryChatOrCreate
from ss_api.utils.auth import AuthUser
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/{chat_id}/messages")


@router.get("", response_model=List[ChatMessage])
async def get_messages(
    pagination: QueryPagination,
    chat: QueryChat,
    _: AuthUser,
    date_range=query_date_range(default_factory_start_date=lambda: datetime.now(timezone.utc) - timedelta(hours=6)),
) -> List[DBChatMessage]:
    query = DBChatMessageBase.find_query(chat=chat, order=ASCENDING)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    return await query.to_list()


@router.post("", response_model=Success, status_code=201)
async def send_chat_message(
    new_message: NewChatMessage, chat: QueryChatOrCreate, user: AuthUser, background_tasks: BackgroundTasks
) -> Success:
    isChatPermitted = user.type == UserType.admin or user.type == UserType.superadmin
    if chat.type == ChatType.broadcastChat and not isChatPermitted:
        raise HTTPException(status_code=403, detail="Send message in broadcast chat is forbidden")

    await new_message.__db_model__(**new_message.model_dump(), chatId=chat.id, createdBy=user.id).create(
        background_tasks=background_tasks
    )

    return Success("Message has been sent")
