import asyncio
from datetime import timedelta
from urllib.parse import urljoin

from fastapi import APIRouter, BackgroundTasks, Request
from fastapi.responses import HTMLResponse
from jose import ExpiredSignatureError, JWTError
from pydantic import BaseModel, EmailStr, HttpUrl

from ss_api.utils.communications.mail import send_mail_async
from ss_api.utils.responses import Success

from ...models.users import DBUserBase
from ...templates import jinja_env
from ...utils.settings import get_settings
from ...utils.typing import JWT, FiscalCode

router = APIRouter(prefix="/forgot-password")


async def _send_forgot_password_check_email(user: DBUserBase, link: HttpUrl):
    template = jinja_env.get_template("./forgot_password/email_check.html")
    body = template.render(link=link)
    loop = asyncio.get_event_loop()
    loop.create_task(
        send_mail_async(
            subject="Servizio Salute | Rigenera la password smarrita",
            body=body,
            email=user.email,
        )
    )


class ForgotPasswordPayload(BaseModel):
    username: EmailStr | FiscalCode


@router.post("", response_model=Success)
async def start_forgot_password_process(
    body: ForgotPasswordPayload, background_tasks: BackgroundTasks, request: Request
) -> Success:
    if isinstance(body.username, FiscalCode):
        user = await DBUserBase.find(DBUserBase.fiscalCode == body.username, with_children=True).first_or_none()
    else:
        user = await DBUserBase.find(DBUserBase.email == body.username, with_children=True).first_or_none()

    if user is not None:
        settings = get_settings()
        token = JWT.create(user=user, expires_delta=timedelta(minutes=20))
        link = HttpUrl(urljoin(str(settings.base_url), f"{request.url.path}?token={token}"))
        background_tasks.add_task(_send_forgot_password_check_email, user=user, link=link)

    return Success("Email has been sent")


@router.get(
    "",
    response_class=HTMLResponse,
    openapi_extra={
        "parameters": [
            {"required": True, "schema": {"title": "Token", "type": "string"}, "name": "token", "in": "query"}
        ]
    },
)
async def verify_forgot_password(request: Request, background_tasks: BackgroundTasks) -> Success | str:
    token_str = request.query_params.get("token")
    if token_str is None:
        return jinja_env.get_template("./forgot_password/check_invalid.html").render()

    try:
        token = JWT(token_str)

    except ExpiredSignatureError:
        return jinja_env.get_template("./forgot_password/check_expired.html").render()

    except JWTError:
        return jinja_env.get_template("./forgot_password/check_invalid.html").render()

    user = await DBUserBase.get(token.sub, with_children=True)
    if user is None:
        return jinja_env.get_template("./forgot_password/check_invalid.html").render()

    if user.lastPasswordChange is not None and token.iat < user.lastPasswordChange:
        return jinja_env.get_template("./forgot_password/check_expired.html").render()

    await user.regenerate_password(background_tasks=background_tasks)

    email_rendered = jinja_env.get_template("./forgot_password/check_success.html").render()

    return email_rendered
