from datetime import datetime, timedelta, timezone
from typing import List

from beanie.odm.operators.find.comparison import GT, LT, Eq
from fastapi import APIRouter

from ss_api.models.treatment_plan import DBTreatmentSideEffect
from ss_api.models.treatment_plan.treatment_side_effect import (
    NewTreatmentSideEffect,
    TreatmentSideEffect,
)
from ss_api.utils.auth import AuthPatient
from ss_api.utils.query_string.date_range import query_date_range
from ss_api.utils.responses import Success

router = APIRouter(prefix="/side-effects")


@router.get("", response_model=List[TreatmentSideEffect], response_model_exclude_none=True)
async def get_side_effects(
    patient: AuthPatient,
    date_range=query_date_range(
        default_factory_start_date=lambda: datetime.now(timezone.utc) - timedelta(days=1),
        default_factory_end_date=lambda: datetime.now(timezone.utc) + timedelta(days=1),
    ),
) -> List[DBTreatmentSideEffect]:
    return await DBTreatmentSideEffect.find(
        Eq(DBTreatmentSideEffect.patientId, patient.id),
        GT(DBTreatmentSideEffect.at, date_range.start),
        LT(DBTreatmentSideEffect.at, date_range.end),
    ).to_list()


@router.post("", response_model=Success, status_code=201)
async def intake_treatment(side_effect: NewTreatmentSideEffect, patient: AuthPatient) -> Success:
    await DBTreatmentSideEffect(**side_effect.model_dump(), patientId=patient.id).insert()
    return Success()
