from typing import List

from fastapi import APIRouter
from pymongo import DESCENDING

from ss_api.models.treatment_plan.treatment_plan import DBTreatmentPlan, TreatmentPlan
from ss_api.utils.auth import AuthPatient
from ss_api.utils.db import query_sort

router = APIRouter(prefix="/treatment-plans", tags=["treatment plans"])


@router.get("", response_model=List[TreatmentPlan])
async def get_treatment_plans_list(patient: AuthPatient) -> List[DBTreatmentPlan]:
    query = DBTreatmentPlan.find(DBTreatmentPlan.patientId == patient.id)
    query = query_sort(query, "effectiveDate", DESCENDING)
    return await query.to_list()
