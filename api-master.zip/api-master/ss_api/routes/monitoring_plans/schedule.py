from datetime import datetime, timedelta

from fastapi import APIRouter
from pytz import UTC

from ss_api.models.monitoring_plan.monitoring_plan import DBMonitoringPlan
from ss_api.models.monitoring_plan.monitoring_plan_schedule import (
    MonitoringPlanSchedule,
)
from ss_api.utils.auth import AuthPatient
from ss_api.utils.headers import HeaderTimeZone
from ss_api.utils.query_string.date_range import query_date_range

router = APIRouter(prefix="/schedule")


@router.get("", response_model=MonitoringPlanSchedule, response_model_exclude_none=True)
async def get_schedule(
    patient: AuthPatient,
    timezone: HeaderTimeZone,
    date_range=query_date_range(
        default_factory_start_date=lambda: datetime.now(UTC),
        default_factory_end_date=lambda: datetime.now(UTC) + timedelta(days=7),
    ),
) -> MonitoringPlanSchedule:
    return await DBMonitoringPlan.get_complete_schedule(
        patient=patient, start_date=date_range.start, end_date=date_range.end, timezone=timezone
    )
