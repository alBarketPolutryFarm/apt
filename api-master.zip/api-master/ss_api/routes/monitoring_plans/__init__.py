from . import current, schedule, week_schedule
from .routes import router

router.include_router(schedule.router)
router.include_router(current.router)
router.include_router(week_schedule.router)
