from typing import List

from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException
from pymongo.errors import DuplicateKeyError
from starlette.background import BackgroundTasks
from typing_extensions import Annotated

from ss_api.models.users import DBAdmin
from ss_api.models.users.admin import Admin, DBSuperAdmin, NewAdmin, UpdateAdmin
from ss_api.models.users.base import UserStatus
from ss_api.models.users.limits.admin_creation_limit import (
    AdminLimitsBase,
    DBAdminLimits,
    NewAdminLimits,
    UpdateAdminLimits,
)
from ss_api.utils.auth import AuthAdmin
from ss_api.utils.responses import Success
from ss_api.utils.user.auth_helpers import get_superadmin

router = APIRouter(prefix="/admins", tags=["admins"])
AuthSuperAdmin = Annotated[DBSuperAdmin, Depends(get_superadmin)]


@router.get("", response_model=List[Admin])
async def list_admins(superadmin: AuthSuperAdmin) -> List[DBAdmin]:
    admins = await DBAdmin.find_all().to_list()
    admin_list = []
    for admin in admins:
        admin_dict = admin.dict()
        if admin.limits:
            admin_dict["limits"] = await admin.limits.fetch()
        admin_list.append(Admin(**admin_dict))
    return admin_list


@router.post("", response_model=Success)
async def create_admin(
    new_admin: NewAdmin, superadmin: AuthSuperAdmin, background_tasks: BackgroundTasks
):  # Require SuperAdmin
    try:
        await DBAdmin(
            **new_admin.model_dump(),
            password=None,
            createdBy=superadmin.id,
        ).create(background_tasks=background_tasks, fiscalCodeCheck=False)
        # Remove the Check for fiscalCode on Production
    except DuplicateKeyError as e:
        field = list(e.details.get("keyValue").keys())[0]
        if field == "email":
            raise HTTPException(status_code=409, detail="Email already used")
        else:
            raise HTTPException(status_code=409, detail="Conflict in db")

    return Success(message="Admin was added")


@router.get("/{admin_id}", response_model=Admin)
async def get_admin(admin_id: PydanticObjectId, admin: AuthAdmin):
    return await DBAdmin.get(admin_id, createdBy=admin.id)


@router.patch("/{admin_id}", response_model=Success)
async def update_admin(
    admin_id: PydanticObjectId,
    updated_admin: UpdateAdmin,
    superadmin: AuthSuperAdmin,
):
    admin = await DBAdmin.get(admin_id)
    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")

    admin_data = updated_admin.model_dump(exclude_unset=True)
    for key, value in admin_data.items():
        setattr(admin, key, value)

    await admin.save()
    return Success(message="Admin updated successfully")


@router.put("/{admin_id}/suspend", response_model=Success)
async def suspend_admin(admin_id: PydanticObjectId, superadmin: AuthSuperAdmin):
    admin = await DBAdmin.get(admin_id)
    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")

    if admin.status == UserStatus.SUSPENDED:
        raise HTTPException(status_code=400, detail="Admin is already suspended")

    await DBAdmin.suspend_user(admin_id)
    return Success(message="Admin suspended successfully")


@router.put("/{admin_id}/activate", response_model=Success)
async def activate_admin(admin_id: PydanticObjectId, superadmin: AuthSuperAdmin):
    admin = await DBAdmin.get(admin_id)
    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")

    if admin.status == UserStatus.ACTIVE:
        raise HTTPException(status_code=400, detail="Admin is already active")

    await DBAdmin.activate_user(admin_id)
    return Success(message="Admin activated successfully")


@router.post("/{admin_id}/limits", response_model=Success, status_code=201)
async def create_admin_limits(
    admin_id: PydanticObjectId,
    limits: NewAdminLimits,
    _: AuthSuperAdmin,
) -> Success:
    if await DBAdmin.get(admin_id) is None:
        raise HTTPException(status_code=404, detail="Admin not found")

    new_limits = DBAdminLimits(adminId=admin_id, **limits.model_dump())
    await new_limits.create()
    return Success(message="Admin limits created successfully")


@router.get("/{admin_id}/limits", response_model=AdminLimitsBase)
async def get_admin_limits(admin_id: PydanticObjectId, _: AuthSuperAdmin) -> DBAdminLimits:
    limits = await DBAdminLimits.find_one(DBAdminLimits.adminId == admin_id)
    if not limits:
        limits = DBAdminLimits(adminId=admin_id)
        await limits.create()
        return limits
    return limits


@router.patch("/{admin_id}/limits", response_model=Success)
async def update_admin_limits(
    admin_id: PydanticObjectId,
    updated_limits: UpdateAdminLimits,
    _: AuthSuperAdmin,
) -> Success:
    limits = await DBAdminLimits.find_one(DBAdminLimits.adminId == admin_id)
    if not limits:
        raise HTTPException(status_code=404, detail="Admin limits not found")

    limits_data = updated_limits.model_dump(exclude_unset=True)
    for key, value in limits_data.items():
        setattr(limits, key, value)

    await limits.save()
    return Success(message="Admin limits updated successfully")


@router.delete("/{admin_id}/limits", response_model=Success)
async def delete_admin_limits(admin_id: PydanticObjectId, _: AuthSuperAdmin) -> Success:
    limits = await DBAdminLimits.find_one(DBAdminLimits.adminId == admin_id)
    if not limits:
        raise HTTPException(status_code=404, detail="Admin limits not found")

    await limits.delete()
    return Success(message="Admin limits deleted successfully")
