from typing import List

from fastapi import APIRouter, HTTPException
from pydantic import ValidationError
from pymongo.errors import DuplicateKeyError
from starlette.background import BackgroundTasks

from ss_api.models.base import EditLog
from ss_api.models.users import DBNurse, DBOperator, Operator
from ss_api.models.users.base import UserType
from ss_api.models.users.operator import NewOperator
from ss_api.models.utils.patch import PatchBody
from ss_api.utils.auth import AuthAdmin
from ss_api.utils.depends import QueryOperator
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success
from ss_api.utils.user.auth_helpers import _enforce_admin_user_creation_limit

router = APIRouter(prefix="/operators", tags=["operators"])


@router.get("", response_model=List[Operator])
async def list_operators(pagination: QueryPagination, _: AuthAdmin) -> List[DBOperator]:
    query = DBOperator.find_all()
    query = pagination(query)
    return await query.to_list()


@router.post("", response_model=Success)
async def create_operator(operator: NewOperator, background_tasks: BackgroundTasks, admin: AuthAdmin) -> Success:

    if admin.__user_type__ == UserType.admin:
        await _enforce_admin_user_creation_limit(admin)

    try:
        if admin.__user_type__ == "superadmin":
            await DBOperator(**operator.model_dump(), createdBy=admin.id).create(
                background_tasks=background_tasks, fiscalCodeCheck=False
            )
        else:
            await DBOperator(**operator.model_dump(), createdBy=admin.id).create(background_tasks=background_tasks)
    except DuplicateKeyError as e:
        field = list(e.details.get("keyValue").keys())[0]
        if field == "email":
            raise HTTPException(status_code=409, detail="Email already used")
        else:
            raise HTTPException(status_code=409, detail="Conflict in db")

    return Success(message="Nurse was added")


@router.get("/{operator_id}", response_model=Operator)
async def get_operator(operator: QueryOperator, _: AuthAdmin) -> DBNurse:
    return operator


@router.patch("/{operator_id}", response_model=Success)
async def update_operator(patch: PatchBody, operator: QueryOperator, admin: AuthAdmin) -> Success:
    try:
        operator = operator.patch(*patch)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    operator.insert_edit_log(EditLog(by=admin.id))

    await operator.save()

    return Success()


@router.delete("/{operator_id}", status_code=501, response_description="Not implemented")
async def remove_operator(operator: QueryOperator, _: AuthAdmin):
    pass
