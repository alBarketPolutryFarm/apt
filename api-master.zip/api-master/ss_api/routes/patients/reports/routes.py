from typing import List

from accept_types import accept_types
from fastapi import APIRouter, HTTPException, Response
from pymongo import DESCENDING
from starlette.responses import FileResponse

from ss_api.models.base.edits_log import EditLog
from ss_api.models.file import DBFileTemp, FileEncoded
from ss_api.models.file.exceptions import FileAlreadyClaimed
from ss_api.models.report import (
    DBExternalReport,
    DBMedicalExaminationReport,
    DBReport,
    DBReportBase,
    NewReport,
    Report,
    ReportType,
)
from ss_api.models.report.responses import StartSignatureProcessSuccess
from ss_api.models.report.signature import DBSignedReportBase, SignatureStatus
from ss_api.models.users import UserType
from ss_api.models.users.patient import DBPatient
from ss_api.models.utils.patch import Patch
from ss_api.utils.auth import AuthAdminDoctorNurse, AuthDoctor, AuthUser
from ss_api.utils.db import query_sort
from ss_api.utils.depends import QueryPatient
from ss_api.utils.headers import HeaderAccept
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Created, Success

from .depends import QueryReport

router = APIRouter(prefix="/reports", tags=["reports"])


@router.post("", status_code=201, response_model=Created)
async def insert_report(
    user: AuthAdminDoctorNurse,
    report: NewReport,
    patient: QueryPatient,
) -> Success:
    match report.type:
        case ReportType.external:
            try:
                file = await DBFileTemp.get(report.file)
                if file is None:
                    raise FileNotFoundError
                await file.claim()
                file = await DBFileTemp.get(report.file)
                db_report = DBExternalReport(
                    **{**report.model_dump(), "patientId": patient.id, "createdBy": user.id, "file": file}
                )
                await db_report.save()
            except FileAlreadyClaimed:
                raise HTTPException(status_code=422, detail="File already claimed")
            except FileNotFoundError:
                raise HTTPException(status_code=424, detail="File has not yet been uploaded")

        case ReportType.medical_examination:
            if user.__user_type__ != UserType.doctor:
                raise HTTPException(status_code=403, detail="You cannot create a new medical examination report")

            db_report = DBMedicalExaminationReport(**report.model_dump(), patientId=patient.id, createdBy=user.id)
            await db_report.save()

        case _:
            raise NotImplementedError

    try:
        patient.insert_edit_log(
            EditLog(by=user.id, description=f"Nuovo rapporto {str(report.type).split('.')[1]} inserito")
        )
        await patient.save()
    except Exception as e:
        print(f"Error in inserting edit log: {e}")
    return Created(db_report.id, "Report has been inserted")


@router.get("", response_model=List[Report])
async def get_reports(
    user: AuthUser,
    patient: QueryPatient,
    pagination: QueryPagination,
    date_range=query_date_range(),
) -> List[DBReportBase]:
    query = DBReportBase.find_query(by=user, patientId=patient.id)
    query = query_sort(query, "date", DESCENDING)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    reports = await query.to_list()
    return reports


@router.get("/{report_id}", response_model=Report)
async def get_report(
    _: AuthUser,
    report: QueryReport,
) -> DBReport:
    return report


@router.patch("/{report_id}")
async def patch_report(report: QueryReport, patch: Patch) -> Success:
    if not isinstance(report, DBSignedReportBase):
        raise HTTPException(status_code=403, detail="Only signable report can be edited")

    if report.signature is not None and report.signature.status == SignatureStatus.completed:
        raise HTTPException(status_code=403, detail="Report already signed cannot be edited")

    if report.signature is not None and report.signature.status == SignatureStatus.waiting:
        raise HTTPException(status_code=403, detail="Report with a running signing process cannot be edited")

    await report.patch(*patch).save()

    return Success("Report has been updated")


@router.post("/{report_id}/signature", description="Require to start the signature process")
async def require_report_signature(report: QueryReport, Doc: AuthDoctor) -> StartSignatureProcessSuccess:

    if Doc.signatureLimit.available <= 0:
        raise HTTPException(status_code=403, detail="You have reached the signature limit")

    if not isinstance(report, DBSignedReportBase):
        raise HTTPException(status_code=403, detail="The report does not required signature")

    if report.signature is not None and report.signature.status == SignatureStatus.completed:
        raise HTTPException(status_code=403, detail="Report already signed")

    if report.signature is not None and report.signature.status == SignatureStatus.waiting:
        raise HTTPException(status_code=409, detail="A signature process is already underway")

    await report.create_signature_request()
    print("Everything is fine at Signature Report to Use at Line 136 in routes.py")

    await report.save()
    print("Everything is fine at Report Save to Use at Line 139 in routes.py")

    return StartSignatureProcessSuccess("A new signature process has been started", signature=report.signature)


@router.get("/{report_id}/file", response_model=FileEncoded, responses={200: {"content": {"application/pdf": {}}}})
async def get_report_file(
    user: AuthUser,
    report: QueryReport,
    accept: HeaderAccept,
) -> FileEncoded | FileResponse:

    if report.file is None:
        raise FileNotFoundError

    try:
        patient = await DBPatient.find(DBPatient.id == report.patientId).first_or_none()
        patient.insert_edit_log(
            EditLog(
                by=user.id,
                description=f"Controllato il file {report.file.filename} con descrizione {report.description}",
            )
        )
        await patient.save()
    except Exception as e:
        print(e)

    if accept_types.get_best_match(accept, ["application/pdf", "application/json"]) == "application/pdf":
        return FileResponse(
            path=report.file.absolute_path, media_type=report.file.contentType, filename=report.file.filename
        )
    return report.file.encoded


@router.get("/{report_id}/exam", response_model=FileEncoded, responses={200: {"content": {"application/zip": {}}}})
async def get_report_exam(
    report: QueryReport,
    accept: HeaderAccept,
    _: AuthUser,
) -> FileEncoded | Response:
    if accept_types.get_best_match(accept, ["application/zip", "application/json"]) == "application/zip":
        return Response(content=report.exam.get_file(), media_type="application/zip", status_code=200)

    return report.exam.get_encoded_file()
