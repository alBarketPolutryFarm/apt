from typing import List

from beanie.odm.operators.find.comparison import Eq
from fastapi import APIRouter
from pymongo import DESCENDING

from ss_api.models.treatment_plan import DBTreatmentSideEffect
from ss_api.models.treatment_plan.treatment_side_effect import TreatmentSideEffect
from ss_api.utils.auth import AuthUser
from ss_api.utils.db import query_sort
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination

router = APIRouter(prefix="/side-effects")


@router.get("", response_model=List[TreatmentSideEffect], response_model_exclude_none=True)
async def get_side_effects(
    patient: QueryPatient,
    pagination: QueryPagination,
    _: AuthUser,
    date_range=query_date_range(),
) -> List[DBTreatmentSideEffect]:
    query = DBTreatmentSideEffect.find(Eq(DBTreatmentSideEffect.patientId, patient.id))
    query = query_sort(query, "at", DESCENDING)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    return await query.to_list()
