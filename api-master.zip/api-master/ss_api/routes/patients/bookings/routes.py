from datetime import datetime, timezone
from typing import List

from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException

from ss_api.models.booking import Booking, DBBooking
from ss_api.utils.auth import AuthUser
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination

router = APIRouter(prefix="/bookings", tags=["bookings"])


@router.get("", response_model=List[Booking])
async def get_patient_bookings(
    _: AuthUser,
    patient: QueryPatient,
    pagination: QueryPagination,
    date_range=query_date_range(default_factory_start_date=lambda: datetime.now(timezone.utc)),
) -> List[DBBooking]:
    query = DBBooking.find_query(user=patient)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)

    return await query.to_list()


def query_booking() -> DBBooking:
    async def _get_booking(user: AuthUser, booking_id: PydanticObjectId, patient: QueryPatient) -> DBBooking:
        try:
            booking = (await DBBooking.find_query(user=user, id=booking_id).to_list())[0]
        except IndexError:
            raise HTTPException(status_code=404, detail="Booking not found")

        if booking.targetId != patient.id:
            raise HTTPException(status_code=404, detail="Booking not found")

        return booking

    return Depends(_get_booking)


@router.get("/{booking_id}", response_model=Booking)
async def get_patient_booking(
    _: AuthUser,
    booking=query_booking(),
) -> DBBooking:
    return booking
