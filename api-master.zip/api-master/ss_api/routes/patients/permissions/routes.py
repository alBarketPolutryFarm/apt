from typing import List

from fastapi import APIRouter, HTTPException
from pydantic import ValidationError

from ss_api.models.permissions.permissions import (
    DBPermission,
    NewPermission,
    Permission,
    RevokePermission,
)
from ss_api.models.revocation import Revocation, RevocationReason
from ss_api.utils.auth import AuthAdmin
from ss_api.utils.auth.auth import AuthNotPatient, AuthUser
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/permissions", tags=["permissions"])


@router.post("", status_code=201, response_model=Success)
async def create_permission(permission: NewPermission, patient: QueryPatient, admin: AuthAdmin) -> Success:
    try:
        await DBPermission(**permission.model_dump(), patientId=patient.id, createdBy=admin.id).create()
    except ValidationError as e:
        raise HTTPException(status_code=404, detail=str(e))

    return Success("Permission was created")


@router.get("", response_model=List[Permission])
async def get_permissions(
    patient: QueryPatient,
    pagination: QueryPagination,
    _: AuthUser,
    date_range=query_date_range(),
) -> List[DBPermission]:
    query = DBPermission.find_query(patient=patient, active_only=False, only_unique=False)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    return await query.to_list()


@router.get("/current", response_model=List[Permission])
async def get_current_permissions(
    patient: QueryPatient,
    pagination: QueryPagination,
    _: AuthNotPatient,
    date_range=query_date_range(),
) -> List[DBPermission]:
    query = DBPermission.find_query(patient=patient, active_only=True, only_unique=False)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    return await query.to_list()


@router.delete("", response_model=Success)
async def revoke_permissions(revoke_permission: RevokePermission, patient: QueryPatient, user: AuthAdmin) -> Success:
    query = DBPermission.find_query(
        patient=patient, active_only=True, target=revoke_permission.targetId, only_unique=False
    )
    permissions = await query.to_list()

    if len(permissions) == 0:
        raise HTTPException(status_code=404, detail="No permissions was found")

    for a in permissions:
        await a.revoke(Revocation(by=user.id, dueTo=RevocationReason.manual))

    return Success("Permissions have been revoked")
