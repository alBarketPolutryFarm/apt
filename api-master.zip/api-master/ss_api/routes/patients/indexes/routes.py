from typing import List

from fastapi import APIRouter
from pymongo import DESCENDING

from ss_api.models.base.edits_log import EditLog
from ss_api.models.index import (
    DBIndexMeasureBase,
    DBIndexMeasuresSummary,
    IndexMeasure,
    IndexMeasuresSummary,
    IndexMeasureType,
    NewIndexMeasure,
)
from ss_api.models.users.patient import DBPatient
from ss_api.utils.auth import AuthDoctorNurse, AuthUser
from ss_api.utils.db import query_sort
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.date_range import query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/indexes", tags=["indexes"])


@router.post("", status_code=201, response_model=Success)
async def insert_index_measure(
    measures: List[NewIndexMeasure],
    patient: QueryPatient,
    _: AuthDoctorNurse,
) -> Success:
    for m in measures:
        m = m.get_db_model()(**m.model_dump(), patientId=patient.id)
        await m.insert()
    try:
        newpatient = await DBPatient.find(DBPatient.id == patient.id).first_or_none()
        newpatient.insert_edit_log(EditLog(by=_.id, description="Nuova index measurement creata"))
        await newpatient.save()
    except Exception as e:
        print(e)
    return Success("Index measures have been inserted")


@router.get("/summary", response_model=IndexMeasuresSummary, response_model_exclude_none=True)
async def get_index_measures_summary(patient: QueryPatient, _: AuthUser) -> DBIndexMeasuresSummary:
    return await DBIndexMeasuresSummary.compute(patient)


@router.get("/{index_type}", response_model=List[IndexMeasure])
async def get_index_measures(
    patient: QueryPatient,
    pagination: QueryPagination,
    _: AuthUser,
    index_type: IndexMeasureType | None = None,
    date_range=query_date_range(),
) -> List[DBIndexMeasureBase]:
    query = DBIndexMeasureBase.find({"patientId": patient.id, "metadata.type": index_type}, with_children=True)

    if date_range.start is not None:
        query = query.find({"timestamp": {"$gte": date_range.start}})

    if date_range.end is not None:
        query = query.find({"timestamp": {"$lte": date_range.end}})

    query = query_sort(query, "timestamp", DESCENDING)
    query = pagination(query)

    return await query.to_list()
