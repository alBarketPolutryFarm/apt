from datetime import datetime, timezone
from typing import Annotated, List

from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException
from pymongo import DESCENDING

from ss_api.models.base.edits_log import EditLog
from ss_api.models.pai.pai import (
    DBPAI,
    PAI,
    CompletionReason,
    NewPAI,
    NewPAIHistoryEntry,
    PAIHistoryEntry,
    PAIStatus,
)
from ss_api.models.users.base import DBUserBase
from ss_api.models.users.patient import DBPatient
from ss_api.utils.auth import AuthUser
from ss_api.utils.auth.auth import AuthStaff
from ss_api.utils.db import query_sort
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/pai", tags=["pai"])


@router.post("", status_code=201, response_model=Success)
async def create_new_pai(pai: NewPAI, patient: QueryPatient, user: AuthUser) -> Success:
    if user.type == "admin" or user.type == "superadmin":
        raise HTTPException(status_code=403, detail="Unauthorized User")

    pai_data = pai.model_dump()
    pai_data["createdByName"] = f"{user.firstName} {user.lastName}"
    await DBPAI(**pai_data, patientId=patient.id, createdBy=user.id).create()
    try:
        patient = await DBPatient.get(pai.patientId)
        patient.insert_edit_log(EditLog(by=user.id, description="PAI set as completed"))
        await patient.save()
    except Exception as e:
        print(f"Error in inserting edit log: {e}")
    return Success("PAI has been created")


@router.get("", response_model=List[PAI])
async def get_pai_list(
    patient: QueryPatient,
    pagination: QueryPagination,
    _: AuthUser,
    status: PAIStatus | None = None,
) -> List[DBPAI]:
    query = DBPAI.find_query(patientId=patient.id, status=status)
    query = query_sort(query, "lastUpdate", DESCENDING)
    query = pagination(query)
    return await query.to_list()


def query_pai() -> DBPAI:
    async def _get_pai(pai_id: PydanticObjectId, patient: QueryPatient) -> DBPAI:
        try:
            return (await DBPAI.find({"_id": pai_id}).find(DBPAI.patientId == patient.id).to_list())[0]
        except IndexError:
            raise HTTPException(status_code=404, detail="PAI not found")

    return Depends(_get_pai)


QueryPAI = Annotated[DBPAI, query_pai()]


@router.get("/{pai_id}", response_model=PAI)
async def get_pai(
    pai: QueryPAI,
    _: AuthStaff,
) -> DBPAI:
    for entry in pai.history:
        creator = await DBUserBase.get(entry.createdByUserId)
        entry.creatorUsername = f"{creator.firstName} {creator.lastName}"
    print(pai.history)
    return pai


@router.post("/{pai_id}/history", response_model=Success)
async def add_pia_history_entry(
    history_entry: NewPAIHistoryEntry,
    pai: QueryPAI,
    staff: AuthStaff,
) -> Success:
    pai.history.append(
        PAIHistoryEntry(
            id=PydanticObjectId(),
            **history_entry.model_dump(),
            createdBy=staff.id,
            createdByName=f"{staff.firstName} {staff.lastName}",
        )
    )
    await pai.save()
    return Success()


@router.post("/{pai_id}/completed", response_model=Success)
async def set_pai_as_completed(
    reason: CompletionReason,
    pai: QueryPAI,
    staff_member: AuthStaff,
) -> Success:
    pai.completedAt = datetime.now(tz=timezone.utc)
    pai.closedBy = staff_member.id
    pai.reason = reason.reason
    await pai.save()

    try:
        patient = await DBPatient.get(pai.patientId)
        patient.insert_edit_log(EditLog(by=staff_member.id, description="PAI set as completed"))
        await patient.save()
    except Exception as e:
        print(f"Error in inserting edit log: {e}")
    return Success("PAI set as completed")
