from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ss_api.utils.settings import get_settings

from ...utils.orthanc.fetch_exams import handle_new_study
from ...utils.responses import Success
from ...utils.typing.secret import Secret
from .auth import api_auth


def _get_orthanc_token() -> str:
    settings = get_settings()
    if settings.orthanc:
        return settings.orthanc.token
    return Secret.random(128)  # random token to prevent use of the callback api


router = APIRouter(
    prefix="/exams",
    tags=["exams"],
    dependencies=[api_auth(_get_orthanc_token)],
)


class NotifyNewExamPayload(BaseModel):
    id: str


@router.post("", response_model=Success)
async def notify_new_exam(payload: NotifyNewExamPayload) -> Success:
    if await handle_new_study(payload.id) is None:
        raise HTTPException(status_code=409, detail="Exam has already been registered")

    return Success()
