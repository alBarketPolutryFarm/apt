from fastapi import APIRouter, BackgroundTasks

from ss_api.models.report import DBExamReport, DBMedicalExaminationReport, DBReportBase
from ss_api.utils.open_api.digital_signature.models import (
    SignatureRequestCallbackPayload,
    SignatureRequestStatus,
)
from ss_api.utils.responses import Success

router = APIRouter(prefix="/reports", tags=["reports"])


@router.post("/signature-request-update")
async def report_sign_callback(update: SignatureRequestCallbackPayload, background_tasks: BackgroundTasks) -> Success:
    if update.data.status != SignatureRequestStatus.finished:
        return Success()

    report = await DBReportBase.find({"signature._id": update.data.id}, with_children=True).first_or_none()
    if report is None:
        return Success()

    if not isinstance(report, (DBMedicalExaminationReport, DBExamReport)):
        return Success()

    if report.signature is None:
        return Success()

    await report.update_signature_status(background_tasks=background_tasks, force=True)

    return Success()
