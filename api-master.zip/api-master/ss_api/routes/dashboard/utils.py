from datetime import datetime, timedelta
from typing import Any, Dict, List

from bson import ObjectId

from ...models.alarm.base import DBAlarmBase
from ...models.chat.message.base import DBChatMessage
from ...models.pai.pai import DBPAI
from ...models.report.base import DBReportBase
from ...models.users.base import DBUserBase


async def get_monthly_metric_value(admin_id: str, metric_name: str, start_date: datetime, end_date: datetime) -> int:
    """Get monthly metric value for a specific admin."""
    base_query = {"createdAt": {"$gte": start_date, "$lt": end_date}}
    if admin_id:
        base_query["createdBy"] = ObjectId(admin_id)

    if metric_name == "active_assistants":
        query = {**base_query, "type": "assistant", "status": "active"}
        return await DBChatMessage.count_documents(query)

    elif metric_name == "active_users":
        query = {**base_query, "status": "active"}
        if admin_id:
            query["creator"] = ObjectId(admin_id)
        return await DBUserBase.count_documents(query)

    elif metric_name == "managed_alerts":
        return await DBAlarmBase.count_documents(base_query)

    elif metric_name in ["created_care_plans", "completed_care_plans", "active_care_plans"]:
        query = base_query.copy()
        if metric_name == "completed_care_plans":
            query["status"] = "completed"
        elif metric_name == "active_care_plans":
            query["status"] = "active"
        return await DBPAI.count_documents(query)

    elif metric_name in ["deaths", "hospitalizations", "recoveries", "administrative_closures", "infections"]:
        completion_reason_map = {
            "deaths": "death",
            "hospitalizations": "hospitalization",
            "recoveries": "recovery",
            "administrative_closures": "administrative",
            "infections": "infection",
        }
        query = {**base_query, "completionReason": completion_reason_map[metric_name]}
        return await DBPAI.count_documents(query)

    elif metric_name == "generated_reports":
        return await DBReportBase.count_documents(base_query)

    return 0


async def get_monthly_metric_value_all_admins(metric_name: str, start_date: datetime, end_date: datetime) -> int:
    """Get monthly metric value aggregated across all admins."""
    return await get_monthly_metric_value(None, metric_name, start_date, end_date)


async def get_metric_data_for_download(
    user_type: str, metric_name: str, user_id: str | None = None
) -> List[Dict[str, Any]]:
    """Get metric data formatted for CSV download."""
    end_date = datetime.now()
    start_date = end_date.replace(year=end_date.year - 1)  # Last 12 months

    data = []
    current_date = start_date

    while current_date <= end_date:
        next_month = (current_date.replace(day=1) + timedelta(days=32)).replace(day=1)

        if user_type == "superadmin":
            value = await get_monthly_metric_value_all_admins(metric_name, current_date, next_month)
        else:
            value = await get_monthly_metric_value(user_id, metric_name, current_date, next_month)

        data.append({"month": current_date.strftime("%Y-%m"), "value": value, "admin_id": user_id})

        current_date = next_month

    return data
