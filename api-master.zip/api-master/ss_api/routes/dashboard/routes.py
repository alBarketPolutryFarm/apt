import tempfile
from datetime import datetime, timedelta
from typing import List, Union

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse

from ss_api.models.alarm.base import DBAlarmBase
from ss_api.models.dashboard.models import (
    AdminMetrics,
    MetricDownloadResponse,
    MetricTrend,
    MonthlyTrend,
    SuperAdminMetrics,
)
from ss_api.models.pai.pai import DBPAI
from ss_api.models.report.base import DBReportBase
from ss_api.models.users.admin import DBAdmin, DBSuperAdmin
from ss_api.models.users.base import DBUserBase, UserStatus
from ss_api.models.users.type import UserType
from ss_api.utils.auth import AuthAdmin, NeedAuth

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/", response_model=Union[AdminMetrics, SuperAdminMetrics])
async def get_dashboard_metrics(current_user: AuthAdmin):
    if current_user.type == UserType.admin:
        admin_metrics = AdminMetrics(
            type=UserType.admin,
            admin_id=str(current_user.id),
            name=current_user.firstName,
            active_users=len(
                await DBUserBase.find({"createdBy": current_user.id, "status": "active"}, with_children=True).to_list(
                    None
                )
            ),
            active_assistants=len(
                await DBUserBase.find(
                    {"createdBy": current_user.id, "status": "active", "_class_id": {"$ne": "DBUserBase.DBPatient"}},
                    with_children=True,
                ).to_list(None)
            ),
            managed_alerts=len(
                await DBAlarmBase.find(
                    {
                        "$or": [
                            {"handling.by": current_user.id},
                            {
                                "handling.by": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {
                                                "createdBy": current_user.id,
                                                "_class_id": {"$ne": "DBUserBase.DBPatient"},
                                            },
                                            with_children=True,
                                        ).to_list(None)
                                    ]
                                }
                            },
                        ]
                    },
                    with_children=True,
                ).to_list(None)
            ),
            created_care_plans=len(
                await DBPAI.find(
                    {
                        "$or": [
                            {"createdBy": current_user.id},
                            {
                                "createdBy": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {"createdBy": current_user.id}, with_children=True
                                        ).to_list(None)
                                    ]
                                }
                            },
                        ]
                    },
                    with_children=True,
                ).to_list(None)
            ),
            completed_care_plans=len(
                await DBPAI.find(
                    {
                        "$or": [
                            {
                                "createdBy": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {"createdBy": current_user.id}, with_children=True
                                        ).to_list(None)
                                    ]
                                }
                            },
                        ],
                        "closedBy": {"$ne": None},
                    },
                    with_children=True,
                ).to_list(None)
            ),
            active_care_plans=len(
                await DBPAI.find(
                    {
                        "$or": [
                            {"createdBy": current_user.id, "status": "active"},
                            {
                                "createdBy": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {"createdBy": current_user.id}, with_children=True
                                        ).to_list(None)
                                    ]
                                },
                                "closedBy": None,
                            },
                        ]
                    },
                    with_children=True,
                ).to_list(None)
            ),
            deaths=len(
                await DBPAI.find(
                    {
                        "$or": [
                            {"createdBy": current_user.id, "reason": "Decesso"},
                            {
                                "createdBy": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {"createdBy": current_user.id}, with_children=True
                                        ).to_list(None)
                                    ]
                                },
                                "reason": "Decesso",
                            },
                        ]
                    },
                    with_children=True,
                ).to_list(None)
            ),
            hospitalizations=len(
                await DBPAI.find(
                    {
                        "$or": [
                            {"createdBy": current_user.id, "reason": "Ricovero"},
                            {
                                "createdBy": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {"createdBy": current_user.id}, with_children=True
                                        ).to_list(None)
                                    ]
                                },
                                "reason": "Ricovero",
                            },
                        ]
                    },
                    with_children=True,
                ).to_list(None)
            ),
            recoveries=len(
                await DBPAI.find(
                    {
                        "$or": [
                            {"createdBy": current_user.id, "reason": "Guarigione"},
                            {
                                "createdBy": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {"createdBy": current_user.id}, with_children=True
                                        ).to_list(None)
                                    ]
                                },
                                "reason": "Guarigione",
                            },
                        ]
                    },
                    with_children=True,
                ).to_list(None)
            ),
            administrative_closures=len(
                await DBPAI.find(
                    {
                        "$or": [
                            {"createdBy": current_user.id, "reason": "Chiusura amministrativa"},
                            {
                                "createdBy": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {"createdBy": current_user.id}, with_children=True
                                        ).to_list(None)
                                    ]
                                },
                                "reason": "Chiusura amministrativa",
                            },
                        ]
                    },
                    with_children=True,
                ).to_list(None)
            ),
            infections=len(
                await DBPAI.find(
                    {
                        "$or": [
                            {"createdBy": current_user.id, "reason": "Infezione correlata all'assistenza"},
                            {
                                "createdBy": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {"createdBy": current_user.id}, with_children=True
                                        ).to_list(None)
                                    ]
                                },
                                "reason": "Infezione correlata all'assistenza",
                            },
                        ]
                    },
                    with_children=True,
                ).to_list(None)
            ),
            generated_reports=len(
                await DBReportBase.find(
                    {
                        "$or": [
                            {"createdBy": current_user.id},
                            {
                                "createdBy": {
                                    "$in": [
                                        user.id
                                        for user in await DBUserBase.find(
                                            {"createdBy": current_user.id}, with_children=True
                                        ).to_list(None)
                                    ]
                                }
                            },
                        ]
                    },
                    with_children=True,
                ).to_list(None)
            ),
            trends=await get_monthly_trends(str(current_user.id)),
        )
        return admin_metrics
    elif current_user.type == UserType.superadmin:
        # Handle superadmin case
        admins = await DBAdmin.find_all().to_list()
        admins = [admin for admin in admins if admin.type == UserType.admin and admin.status == UserStatus.ACTIVE]
        admins_data = []

        for admin in admins:
            admin_metrics = AdminMetrics(
                type=UserType.admin,
                admin_id=str(admin.id),
                name=admin.firstName,
                active_users=len(
                    await DBUserBase.find({"createdBy": admin.id, "status": "active"}, with_children=True).to_list(None)
                ),
                active_assistants=len(
                    await DBUserBase.find(
                        {"createdBy": admin.id, "status": "active", "_class_id": {"$ne": "DBUserBase.DBPatient"}},
                        with_children=True,
                    ).to_list(None)
                ),
                managed_alerts=len(
                    await DBAlarmBase.find(
                        {
                            "$or": [
                                {"handling.by": admin.id},
                                {
                                    "handling.by": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id, "_class_id": {"$ne": "DBUserBase.DBPatient"}},
                                                with_children=True,
                                            ).to_list(None)
                                        ]
                                    }
                                },
                            ]
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                created_care_plans=len(
                    await DBPAI.find(
                        {
                            "$or": [
                                {"createdBy": admin.id},
                                {
                                    "createdBy": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id}, with_children=True
                                            ).to_list(None)
                                        ]
                                    }
                                },
                            ]
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                completed_care_plans=len(
                    await DBPAI.find(
                        {
                            "$or": [
                                {
                                    "createdBy": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id}, with_children=True
                                            ).to_list(None)
                                        ]
                                    }
                                },
                            ],
                            "closedBy": {"$ne": None},
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                active_care_plans=len(
                    await DBPAI.find(
                        {
                            "$or": [
                                {"createdBy": admin.id, "status": "active"},
                                {
                                    "createdBy": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id}, with_children=True
                                            ).to_list(None)
                                        ]
                                    },
                                    "closedBy": None,
                                },
                            ]
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                deaths=len(
                    await DBPAI.find(
                        {
                            "$or": [
                                {"createdBy": admin.id, "reason": "Decesso"},
                                {
                                    "createdBy": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id}, with_children=True
                                            ).to_list(None)
                                        ]
                                    },
                                    "reason": "Decesso",
                                },
                            ]
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                hospitalizations=len(
                    await DBPAI.find(
                        {
                            "$or": [
                                {"createdBy": admin.id, "reason": "Ricovero"},
                                {
                                    "createdBy": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id}, with_children=True
                                            ).to_list(None)
                                        ]
                                    },
                                    "reason": "Ricovero",
                                },
                            ]
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                recoveries=len(
                    await DBPAI.find(
                        {
                            "$or": [
                                {"createdBy": admin.id, "reason": "Guarigione"},
                                {
                                    "createdBy": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id}, with_children=True
                                            ).to_list(None)
                                        ]
                                    },
                                    "reason": "Guarigione",
                                },
                            ]
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                administrative_closures=len(
                    await DBPAI.find(
                        {
                            "$or": [
                                {"createdBy": admin.id, "reason": "Chiusura amministrativa"},
                                {
                                    "createdBy": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id}, with_children=True
                                            ).to_list(None)
                                        ]
                                    },
                                    "reason": "Chiusura amministrativa",
                                },
                            ]
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                infections=len(
                    await DBPAI.find(
                        {
                            "$or": [
                                {"createdBy": admin.id, "reason": "Infezione correlata all'assistenza"},
                                {
                                    "createdBy": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id}, with_children=True
                                            ).to_list(None)
                                        ]
                                    },
                                    "reason": "Infezione correlata all'assistenza",
                                },
                            ]
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                generated_reports=len(
                    await DBReportBase.find(
                        {
                            "$or": [
                                {"createdBy": admin.id},
                                {
                                    "createdBy": {
                                        "$in": [
                                            user.id
                                            for user in await DBUserBase.find(
                                                {"createdBy": admin.id}, with_children=True
                                            ).to_list(None)
                                        ]
                                    }
                                },
                            ]
                        },
                        with_children=True,
                    ).to_list(None)
                ),
                trends=await get_monthly_trends(str(admin.id)),
            )
            admins_data.append(admin_metrics)

        superadmin_metrics = SuperAdminMetrics(
            type=UserType.superadmin,
            total_registered_admins=len(admins),
            admins_data=admins_data,
        )

        return superadmin_metrics
    else:
        raise HTTPException(status_code=403, detail="Not authorized")


@router.get("/download/{metric_name}", response_model=List[MetricDownloadResponse])
async def download_metric_data(metric_name: str, current_user: DBUserBase = Depends(NeedAuth())):
    if metric_name not in AdminMetrics.__fields__:
        raise HTTPException(status_code=400, detail="Invalid metric name")

    # Get data based on user type
    if isinstance(current_user, DBSuperAdmin):
        data = await get_metric_data_for_download(metric_name)
    elif isinstance(current_user, DBAdmin):
        data = await get_metric_data_for_download(metric_name, current_user.id)
    else:
        raise HTTPException(status_code=403, detail="Not authorized")

    # Create CSV file
    df = pd.DataFrame(data)
    filename = f"{metric_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".csv") as temp_file:
        df.to_csv(temp_file.name, index=False)
        return FileResponse(path=temp_file.name, filename=filename, media_type="text/csv")


async def get_monthly_trends(admin_id: str | None = None) -> List[MetricTrend]:
    """Get monthly trends for metrics."""
    trends = []
    end_date = datetime.now()
    start_date = end_date - timedelta(days=365)  # Last 12 months

    for metric_name in AdminMetrics.__fields__:
        if metric_name in ["type", "admin_id"]:
            continue

        monthly_data = []
        current_date = start_date

        while current_date <= end_date:
            next_month = (current_date.replace(day=1) + timedelta(days=32)).replace(day=1)
            value = await get_metric_value(metric_name, current_date, next_month, admin_id)
            monthly_data.append(MonthlyTrend(month=current_date, value=value))
            current_date = next_month
        trends.append(MetricTrend(metric_name=metric_name, trend_data=monthly_data))

    return trends


async def get_metric_value(
    metric_name: str, start_date: datetime, end_date: datetime, admin_id: str | None = None
) -> int:
    """Get value for a specific metric in a date range."""
    if not admin_id:
        return 0

    if metric_name == "active_assistants":
        return len(
            await DBUserBase.find(
                {
                    "createdBy": admin_id,
                    "status": "active",
                    "_class_id": {"$ne": "DBUserBase.DBPatient"},
                    "createdAt": {"$gte": start_date, "$lt": end_date},
                },
                with_children=True,
            ).to_list(None)
        )
    elif metric_name == "active_users":
        return len(
            await DBUserBase.find(
                {"createdBy": admin_id, "status": "active", "createdAt": {"$gte": start_date, "$lt": end_date}},
                with_children=True,
            ).to_list(None)
        )
    elif metric_name == "managed_alerts":
        users = await DBUserBase.find(
            {"createdBy": admin_id, "_class_id": {"$ne": "DBUserBase.DBPatient"}}, with_children=True
        ).to_list(None)
        user_ids = [user.id for user in users]
        user_ids.append(admin_id)

        return len(
            await DBAlarmBase.find(
                {"handling.by": {"$in": user_ids}, "createdAt": {"$gte": start_date, "$lt": end_date}},
                with_children=True,
            ).to_list(None)
        )
    elif metric_name in ["created_care_plans", "completed_care_plans", "active_care_plans"]:
        users = await DBUserBase.find({"createdBy": admin_id}, with_children=True).to_list(None)
        user_ids = [user.id for user in users]
        user_ids.append(admin_id)

        query = {"createdBy": {"$in": user_ids}, "createdAt": {"$gte": start_date, "$lt": end_date}}

        if metric_name == "completed_care_plans":
            query["closedBy"] = {"$ne": None}
        elif metric_name == "active_care_plans":
            query["closedBy"] = None

        return len(await DBPAI.find(query, with_children=True).to_list(None))
    elif metric_name in ["deaths", "hospitalizations", "recoveries", "administrative_closures", "infections"]:
        users = await DBUserBase.find({"createdBy": admin_id}, with_children=True).to_list(None)
        user_ids = [user.id for user in users]
        user_ids.append(admin_id)

        completion_reason_map = {
            "deaths": "Decesso",
            "hospitalizations": "Ricovero",
            "recoveries": "Guarigione",
            "administrative_closures": "Chiusura amministrativa",
            "infections": "Infezione correlata all'assistenza",
        }

        return len(
            await DBPAI.find(
                {
                    "createdBy": {"$in": user_ids},
                    "reason": completion_reason_map[metric_name],
                    "createdAt": {"$gte": start_date, "$lt": end_date},
                },
                with_children=True,
            ).to_list(None)
        )
    elif metric_name == "generated_reports":
        users = await DBUserBase.find({"createdBy": admin_id}, with_children=True).to_list(None)
        user_ids = [user.id for user in users]
        user_ids.append(admin_id)

        return len(
            await DBReportBase.find(
                {"createdBy": {"$in": user_ids}, "createdAt": {"$gte": start_date, "$lt": end_date}}, with_children=True
            ).to_list(None)
        )

    return 0


async def get_metric_data_for_download(metric_name: str, admin_id: str | None = None) -> List[MetricDownloadResponse]:
    """Get metric data formatted for CSV download."""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=365)  # Last 12 months

    data = []
    current_date = start_date

    while current_date <= end_date:
        next_month = (current_date.replace(day=1) + timedelta(days=32)).replace(day=1)
        value = await get_metric_value(metric_name, current_date, next_month, admin_id)

        data.append(MetricDownloadResponse(month=current_date.strftime("%Y-%m"), value=value, admin_id=admin_id))

        current_date = next_month

    return data
