from fastapi import APIRouter
from firebase_admin import messaging
from pydantic import BaseModel

from ss_api.utils.auth import AuthUser
from ss_api.utils.responses import Success

router = APIRouter(prefix="/fcm")


class RegisterFCM(BaseModel):
    token: str


@router.post("/register", response_model=Success)
async def register_fcm(body: RegisterFCM, _: AuthUser) -> Success:
    messaging.subscribe_to_topic(body.token, "treatments")
    messaging.subscribe_to_topic(body.token, "monitoring_plans")

    return Success()
