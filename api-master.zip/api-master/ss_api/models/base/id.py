from pydantic import BaseModel

from ss_api.utils.typing import Id, IdOptional


class IdBase(BaseModel):
    id: Id


class IdOptionalBase(BaseModel):
    id: IdOptional
