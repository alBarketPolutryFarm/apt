from datetime import datetime, timezone
from typing import Annotated, Any

from beanie import Indexed, PydanticObjectId
from beanie.odm.queries.aggregation import AggregationQuery
from pydantic import BaseModel, Field, model_validator

from ss_api.models.utils.db import DBQuery
from ss_api.utils.query_string.date_range import DateRangeData, FilterableByDataRange


class CreationAnonymousBase(BaseModel, FilterableByDataRange):
    createdAt: Annotated[Indexed(datetime), Field(description="Datetime of document creation")]  # type: ignore

    @model_validator(mode="before")
    @classmethod
    def set_created_at(cls, data: Any) -> Any:
        if isinstance(data, dict) and "createdAt" not in data:
            data["createdAt"] = datetime.now(timezone.utc)
        return data

    @staticmethod
    def __filter_by_data_range__(query: DBQuery, date_range: DateRangeData) -> DBQuery:
        if isinstance(query, AggregationQuery):
            if date_range.start is not None:
                query.aggregation_pipeline.append({"$match": {"createdAt": {"$gt": date_range.start}}})
            if date_range.end is not None:
                query.aggregation_pipeline.append({"$match": {"createdAt": {"$lt": date_range.end}}})
            return query

        else:
            if date_range.start is not None:
                query = query.find({"createdAt": {"$gt": date_range.start}})
            if date_range.end is not None:
                query = query.find({"createdAt": {"$lt": date_range.end}})
            return query


CreationBy = Annotated[PydanticObjectId, Field(description="Id of user who created the document")]


class CreationOptionallyAnonymousBase(CreationAnonymousBase):
    createdBy: CreationBy | None = None


class CreationBase(CreationOptionallyAnonymousBase):
    createdBy: CreationBy
