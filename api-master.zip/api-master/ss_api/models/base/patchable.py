from beanie.odm.documents import DocType
from fastapi.exceptions import RequestValidationError
from jsonpointer import JsonPointerException
from pydantic import BaseModel

from ss_api.models.utils.patch import PatchOperation, apply_patch
from ss_api.utils.exceptions import ErrorWrapper


class PatchableBase(BaseModel):
    __update_model__ = BaseModel

    def patch(self: DocType, *operations: PatchOperation) -> DocType:
        try:
            patch_dict = apply_patch(self, list(operations))
            self.__update_model__(**patch_dict)  # check schema
            patched = self.__class__(**patch_dict)
            return patched

        except JsonPointerException as e:
            raise RequestValidationError(errors=[ErrorWrapper(e, loc=("",))], model=PatchOperation)
