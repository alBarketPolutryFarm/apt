from datetime import datetime, timezone
from typing import Annotated, Type

from beanie import Document
from beanie.odm.documents import DocType
from beanie.odm.operators.find.comparison import GT, LT, Eq
from beanie.odm.operators.find.logical import Or
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from pydantic import BaseModel, Field
from pymongo import IndexModel

from ss_api.models.utils.db import DBQuery
from ss_api.utils.query_string.date_range import DateRangeData


class ValidityPeriodBase(BaseModel):
    effectiveDate: datetime
    expirationDate: datetime | None = None

    class Settings:
        indexes = [IndexModel("effectiveDate"), IndexModel("datetime")]

    @classmethod
    def find_period(
        cls: Type[DocType],
        date_a: datetime | None = None,
        date_b: datetime | None = None,
        /,
        query: FindMany[DocType] | None = None,
    ) -> FindMany[DocType]:
        if isinstance(cls, Document):
            raise NotImplementedError

        if date_a is None and date_b is None:
            _upper_bound = _lower_bound = datetime.now(timezone.utc)
        elif date_a is not None and date_b is None:
            _upper_bound = _lower_bound = date_a
        elif date_a is not None and date_b is not None:
            _lower_bound = date_a
            _upper_bound = date_b
        else:
            raise NotImplementedError

        if query is None:
            query = cls.find()

        query = query.find(Or(Eq(cls.expirationDate, None), GT(cls.expirationDate, _lower_bound)))
        query = query.find(LT(cls.effectiveDate, _upper_bound))

        return query

    @staticmethod
    def __filter_by_data_range__(query: DBQuery, date_range: DateRangeData) -> DBQuery:
        if isinstance(query, AggregationQuery):
            if date_range.start is not None:
                query.aggregation_pipeline.append(
                    {"$match": {"$or": [{"expirationDate": None}, {"expirationDate": {"$gt": date_range.start}}]}}
                )
            if date_range.end is not None:
                query.aggregation_pipeline.append({"$match": {"effectiveDate": {"$lt": date_range.end}}})
            return query

        else:
            if date_range.start is not None:
                query = query.find({"$or": [{"expirationDate": None}, {"expirationDate": {"$gt": date_range.start}}]})
            if date_range.end is not None:
                query = query.find({"effectiveDate": {"$lt": date_range.end}})
            return query


class NewValidityPeriodBase(ValidityPeriodBase):
    effectiveDate: Annotated[datetime, Field(default_factory=lambda: datetime.now(timezone.utc))]
