from abc import ABC
from datetime import date
from typing import Annotated, Any, Optional, Type

from beanie import Document, PydanticObjectId
from beanie.odm.documents import DocType
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from pydantic import BaseModel, Field, computed_field, model_validator
from pymongo import IndexModel

from ss_api.models.base.creation import CreationBase
from ss_api.models.base.id import IdBase
from ss_api.models.file import DBFile, File
from ss_api.utils.db import bson_encoders
from ss_api.utils.typing import NotFutureDate

from ..permissions import DBPermission
from ..users import DBUserBase, UserType
from .signature import SignatureStatus
from .type import ReportType


class UpdateReportBase(BaseModel, ABC):
    description: str | None = None


class NewReportBase(BaseModel, ABC):
    type: ReportType
    date: Annotated[NotFutureDate, Field(default_factory=lambda: date.today())]
    description: str

    @model_validator(mode="before")
    @classmethod
    def set_type(cls, data: Any):
        if isinstance(data, dict) and "type" not in data:
            data["type"] = cls.__report_type__
        return data


class ReportBase(IdBase, CreationBase, ABC):
    type: ReportType
    file: File
    patientId: PydanticObjectId
    date: date
    description: str


class DBReportBase(Document, CreationBase, ABC):
    file: DBFile | None = None
    patientId: PydanticObjectId
    date: date
    description: str

    class Settings:
        name = "reports"
        is_root = True
        bson_encoders = bson_encoders
        indexes = [IndexModel("patientId"), IndexModel("date")]

    @computed_field  # type: ignore[misc]
    @property
    def type(self) -> ReportType:
        return self.__report_type__

    @classmethod
    def find_query(
        cls: Type[DocType],
        by: Optional[DBUserBase] = None,
        id: PydanticObjectId | None = None,
        patientId: PydanticObjectId | None = None,
    ) -> FindMany[DocType] | AggregationQuery[DocType]:
        query = {}
        if id is not None:
            query["_id"] = id
        if patientId is not None:
            query["patientId"] = patientId

        if by is not None and by.__user_type__ == UserType.patient:
            query = {
                **query,
                "patientId": by.id,
                "$or": [{"signature.status": SignatureStatus.completed}, {"signature": {"$exists": False}}],
            }
            return cls.find(query, with_children=True)

        if by is None or by.__user_type__ == UserType.admin:
            if id is None:
                return cls.find(query, with_children=True)
            return cls.find(query, with_children=True)

        if patientId is None or by is None:
            raise NotImplementedError

        query = DBPermission.find_query(patient=patientId, target=by.id)
        query.aggregation_pipeline.extend(  # type: ignore
            [
                {
                    "$lookup": {
                        "from": cls.Settings.name,
                        "localField": "patientId",
                        "foreignField": "patientId",
                        "as": "tmp",
                    }
                },
                {"$unwind": {"path": "$tmp"}},
                {"$replaceRoot": {"newRoot": {"$mergeObjects": ["$tmp"]}}},
                *(
                    [{"$match": {"_class_id": f"{DBReportBase.__name__}.{cls.__name__}"}}]
                    if cls.__name__ != DBReportBase.__name__
                    else []
                ),
                {
                    "$match": {
                        "$or": [
                            {"signature.status": "completed"},
                            {"signature": {"$exists": False}},
                            {"createdBy": by.id},
                        ]
                    },
                },
                *([{"$match": {"_id": id}}] if id is not None else []),
            ]
        )
        query.projection_model = cls  # type: ignore
        return query
