from base64 import b64encode
from typing import List

from pymongo import IndexModel

from ss_api.models.base.creation import CreationAnonymousBase
from ss_api.models.base.id import IdBase, IdOptionalBase
from ss_api.models.enum.exam_modality import ExamModality
from ss_api.models.file import FileEncoded
from ss_api.utils.orthanc import Orthanc


class ExamBase(CreationAnonymousBase):
    studyId: str
    modalities: List[ExamModality]

    def get_file(self) -> bytes:
        orthanc = Orthanc()
        return orthanc.get_studies_id_archive(self.studyId)

    def get_encoded_file(self) -> FileEncoded:
        return FileEncoded(
            content=b64encode(self.get_file()).decode("utf-8"),
            filename=f"{self.createdAt.strftime('%Y-%m-%d')}-{self.id}.zip",
            mediaType="application/zip",
        )


class Exam(IdBase, ExamBase):
    pass


class DBExam(IdOptionalBase, ExamBase):
    class Settings:
        indexes = [IndexModel("studyId", unique=True), IndexModel("modalities")]
