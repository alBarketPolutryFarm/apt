from pydantic import BaseModel


class PlannedIntervention(BaseModel):
    description: str
    specialists: str | None = None
    frequency: str | None = None
