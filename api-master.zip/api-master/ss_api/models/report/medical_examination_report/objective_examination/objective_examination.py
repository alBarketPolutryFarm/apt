from pydantic import BaseModel, field_validator

from .adbomen import Abdomen
from .cardiovascular_system import CardiovascularSystem
from .detail import Detail
from .nervous_system import NervousSystem
from .reproductive_system import ReproductiveSystem
from .respiratory_system import RespiratorySystem


class ObjectiveExamination(BaseModel):
    general: str | None = None
    other: str | None = None

    detail: Detail | None = None
    respiratorySystem: RespiratorySystem | None = None
    abdomen: Abdomen | None = None
    nervousSystem: NervousSystem | None = None
    reproductiveSystem: ReproductiveSystem | None = None
    cardiovascularSystem: CardiovascularSystem | None = None

    @field_validator(
        "detail", "respiratorySystem", "abdomen", "nervousSystem", "reproductiveSystem", "cardiovascularSystem"
    )
    @classmethod
    def light_up(cls, v):
        if v is not None:
            if len(v.dict(exclude_none=True).keys()) == 0:
                return None
        return v
