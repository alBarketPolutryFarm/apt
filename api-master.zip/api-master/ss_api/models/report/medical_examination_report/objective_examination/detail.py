from pydantic import BaseModel


class Detail(BaseModel):
    head: str | None = None
    eyes: str | None = None
    neck: str | None = None
    monthThroat: str | None = None
    noseEars: str | None = None
