from pydantic import BaseModel


class RespiratorySystem(BaseModel):
    inspection: str | None = None
    palpation: str | None = None
    percussion: str | None = None
    auscultation: str | None = None
