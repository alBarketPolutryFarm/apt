from enum import Enum
from typing import Annotated, Any, Dict, List

from fastapi import Body, Depends
from jsonpatch import apply_patch as _apply_patch
from pydantic import BaseModel


class PatchOperationType(str, Enum):
    _add: str = "add"
    _remove: str = "remove"
    _replace: str = "replace"


class PatchOperation(BaseModel):
    op: PatchOperationType
    path: str
    value: Any | None = None


Patch = List[PatchOperation]


async def get_path_body(update: Patch = Body(description="Patch body compliant with RFC6902")) -> Patch:
    return update


def patch_body() -> Patch:
    return Depends(get_path_body)


PatchBody = Annotated[Patch, Depends(get_path_body)]


def apply_patch(data: BaseModel, patch: Patch) -> Dict:
    return _apply_patch(data.model_dump(), list(map(lambda x: x.model_dump(), patch)))
