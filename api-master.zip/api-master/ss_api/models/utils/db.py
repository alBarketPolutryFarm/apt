from typing import TypeVar

from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany

DBQuery = TypeVar("DBQuery", FindMany, AggregationQuery)
