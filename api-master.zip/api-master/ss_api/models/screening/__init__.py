from .screening import DBScreening, NewScreening, Screening

__document_models__ = [DBScreening]
