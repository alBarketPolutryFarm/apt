from datetime import datetime, timedelta
from typing import Annotated

from beanie import Document, Granularity, PydanticObjectId, TimeSeriesConfig
from pydantic import BaseModel, Field
from pymongo import IndexModel

from ss_api.models.base.id import IdBase


class TreatmentIntakeBase(BaseModel):
    scheduleId: PydanticObjectId
    at: datetime | None
    isTaken: bool
    notes: str | None = None


class NewTreatmentIntake(TreatmentIntakeBase):
    at: Annotated[datetime | None, Field(default_factory=datetime.utcnow)]
    isTaken: bool = True


class TreatmentIntake(IdBase, TreatmentIntakeBase):
    patientId: PydanticObjectId
    at: datetime


class DBTreatmentIntake(Document, TreatmentIntake):
    class Settings:
        name = "treatments_intakes"

        timeseries = TimeSeriesConfig(
            time_field="at",
            granularity=Granularity.minutes,
            expire_after_seconds=timedelta(days=365).total_seconds(),
        )
        indexes = [IndexModel("patientId"), IndexModel("at")]
