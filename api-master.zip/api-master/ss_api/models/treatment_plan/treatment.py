from datetime import datetime, time, timedelta
from typing import List

from pydantic import BaseModel

from ss_api.models.base.id import IdBase, IdOptionalBase
from ss_api.models.enum import Weekday


class NewTreatmentSchedule(BaseModel):
    time: time
    weekday: Weekday


class TreatmentSchedule(IdBase, NewTreatmentSchedule):
    pass


class DBTreatmentSchedule(IdOptionalBase, TreatmentSchedule):
    pass


class TreatmentPeriodicSchedule(BaseModel):
    period: timedelta
    firstOccurence: datetime
    endPeriod: datetime | None = None


class NewTreatment(BaseModel):
    description: str
    activeIngredient: str | None = None
    dosage: str | None = None
    administrationRoute: str | None = None
    notes: str | None = None

    schedule: List[NewTreatmentSchedule] | TreatmentPeriodicSchedule


class Treatment(IdBase, NewTreatment):
    schedule: List[TreatmentSchedule] | TreatmentPeriodicSchedule


class DBTreatment(IdOptionalBase, Treatment):
    schedule: List[DBTreatmentSchedule] | TreatmentPeriodicSchedule
