from __future__ import annotations

from typing import Annotated, List

from pydantic import BaseModel, Field

from ss_api.models.base.id import IdBase
from ss_api.models.enum import Weekday
from ss_api.models.treatment_plan.treatment import Treatment
from ss_api.utils.typing import NaiveTime


class TreatmentPlanWeekScheduleEntry(IdBase, BaseModel):
    time: NaiveTime
    weekday: Weekday
    description: Annotated[str, Field(deprecated=True)]
    notes: str | None = None
    treatment: Treatment


TreatmentPlanWeekSchedule = List[TreatmentPlanWeekScheduleEntry]
