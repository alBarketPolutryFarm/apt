from __future__ import annotations

from datetime import datetime, timedelta
from itertools import product
from math import ceil
from typing import List, Tuple

from beanie import Document, Insert, PydanticObjectId, before_event
from beanie.odm.operators.find.comparison import GT, LT, Eq
from beanie.odm.operators.find.logical import Or
from pydantic import BaseModel
from pymongo import ASCENDING, IndexModel
from pytz import UTC
from pytz.tzinfo import BaseTzInfo

from ss_api.models.base.creation import CreationBase
from ss_api.models.base.validity_period import NewValidityPeriodBase, ValidityPeriodBase
from ss_api.models.revocation import Revocation, RevocationReason
from ss_api.models.users import DBPatient
from ss_api.utils.db import bson_encoders, query_sort
from ss_api.utils.helpers.datetime import week_start

from ..base import IdBase
from .treatment import DBTreatment, NewTreatment, Treatment, TreatmentPeriodicSchedule
from .treatment_plan_schedule import (
    TreatmentPlanScheduleEntry,
    TreatmentPlanScheduleEntryRaw,
)
from .treatment_plan_week_schedule import (
    TreatmentPlanWeekSchedule,
    TreatmentPlanWeekScheduleEntry,
)


class TreatmentPlanBase(ValidityPeriodBase, BaseModel):
    treatments: List[Treatment]
    reportId: PydanticObjectId

    notes: str | None = None


class TreatmentPlan(TreatmentPlanBase, CreationBase):
    revocation: Revocation | None = None


class NewTreatmentPlanBase(BaseModel):
    treatments: List[NewTreatment]

    notes: str | None = None


class NewTreatmentPlan(NewValidityPeriodBase, NewTreatmentPlanBase, TreatmentPlanBase):
    pass


class DBTreatmentPlan(Document, TreatmentPlan, IdBase):
    treatments: List[DBTreatment]
    patientId: PydanticObjectId

    class Settings:
        name = "treatment_plans"

        bson_encoders = bson_encoders

        indexes = [IndexModel("patientId")]

    @before_event(Insert)
    async def revoke_current(self):
        patient = await DBPatient.get(self.patientId)
        if (current_treatment := await self.get_current(patient)) is not None:
            await current_treatment.revoke(
                Revocation(dueTo=RevocationReason.outdated, effectiveFrom=self.effectiveDate, by=self.id)
            )

    @classmethod
    async def get_current(cls, patient: DBPatient) -> DBTreatmentPlan | None:
        return await cls.find_one(
            cls.patientId == patient.id,
            Or(Eq(cls.expirationDate, None), GT(cls.expirationDate, datetime.utcnow())),
            cls.effectiveDate < datetime.utcnow(),
        )

    async def revoke(self, revocation: Revocation) -> None:
        self.revocation = revocation
        self.expirationDate = self.revocation.effectiveFrom
        await self.save()

    @property
    def validity_interval(self) -> Tuple[datetime, datetime | None]:
        return self.effectiveDate, self.expirationDate

    @property
    def week_schedule(self) -> TreatmentPlanWeekSchedule:
        return sorted(
            [
                TreatmentPlanWeekScheduleEntry(
                    **{
                        **schedule.model_dump(),
                        **treatment.model_dump(),
                        "treatment": treatment.model_dump(),
                        "_id": schedule.id,
                    }
                )
                for treatment in self.treatments
                if isinstance(treatment.schedule, list)
                for schedule in treatment.schedule
            ],
            key=lambda s: (s.weekday, s.time),
        )

    async def get_schedule(
        self, /, start_date: datetime | None = None, end_date: datetime | None = None, timezone: BaseTzInfo = UTC
    ) -> List[TreatmentPlanScheduleEntry]:
        _start_date = self.effectiveDate if start_date is None or start_date < self.effectiveDate else start_date

        if end_date is not None and self.expirationDate is not None:
            _end_date = self.expirationDate if end_date > self.expirationDate else end_date
        elif self.expirationDate is None and end_date is not None:
            _end_date = end_date
        elif self.expirationDate is not None and end_date is None:
            _end_date = self.expirationDate
        else:
            raise ValueError("'end_date' must be provided or 'expirationDate' must be set")

        week_start_date = week_start(_start_date.date())
        week_schedule = self.week_schedule
        weeks = range(ceil((_end_date - _start_date).days / 7 + 1))

        weeks_start_date = map(lambda w: week_start_date + timedelta(days=7 * w), weeks)

        schedule_weeks = product(weeks_start_date, week_schedule)

        schedule_unfiltered = map(
            lambda s: TreatmentPlanScheduleEntryRaw(
                **{
                    **s[1].model_dump(),
                    "at": timezone.localize(datetime.combine(date=s[0] + timedelta(days=s[1].weekday), time=s[1].time)),
                    "_id": s[1].id,
                }
            ),
            schedule_weeks,
        )

        schedule_raw = filter(lambda s: _start_date < s.at < _end_date, schedule_unfiltered)

        schedule = [await TreatmentPlanScheduleEntry.from_raw(t) for t in schedule_raw]

        schedule_periodic = []

        for treatment in self.treatments:
            if isinstance(treatment.schedule, TreatmentPeriodicSchedule):
                period = treatment.schedule.period
                first_occurrence = treatment.schedule.firstOccurence
                end_period = treatment.schedule.endPeriod

                current_occurrence = first_occurrence
                while end_period is not None and current_occurrence <= _end_date and current_occurrence <= end_period:
                    if current_occurrence >= _start_date:
                        treatment_data = {
                            "treatment": treatment,
                            "description": treatment.description,
                            "notes": treatment.notes,
                            "at": current_occurrence,
                            "notBefore": current_occurrence - timedelta(hours=1),
                            "notAfter": current_occurrence + timedelta(hours=3),
                            "_id": treatment.id,
                        }
                        entry = TreatmentPlanScheduleEntryRaw(**treatment_data)
                        schedule_periodic.append(entry)
                    current_occurrence += period

        schedule_raw = filter(lambda s: _start_date < s.at < _end_date, schedule_periodic)
        schedule_periodic = [await TreatmentPlanScheduleEntry.from_raw(t) for t in schedule_raw]

        return schedule + schedule_periodic

    @classmethod
    async def get_complete_schedule(
        cls, /, patient: DBPatient, start_date: datetime, end_date: datetime, timezone: BaseTzInfo
    ) -> List[TreatmentPlanScheduleEntry]:
        query = cls.find(
            cls.patientId == patient.id,
            Or(Eq(cls.expirationDate, None), GT(cls.expirationDate, start_date)),
            LT(cls.effectiveDate, end_date),
        )
        query = query_sort(query, "effectiveDate", ASCENDING)
        plans = await query.to_list()

        schedule = [await p.get_schedule(start_date=start_date, end_date=end_date, timezone=timezone) for p in plans]

        return [p for s in schedule for p in s]
