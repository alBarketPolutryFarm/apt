from __future__ import annotations

from typing import List, Type

from beanie import Document, Insert, PydanticObjectId, before_event
from beanie.odm.documents import DocType
from beanie.odm.operators.find.comparison import Eq
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from bson import ObjectId
from pydantic import BaseModel

from ss_api.models.agreement.agreement_type import AgreementType
from ss_api.models.base.creation import CreationBase
from ss_api.models.base.revocable import RevocableBase
from ss_api.models.base.validity_period import NewValidityPeriodBase, ValidityPeriodBase
from ss_api.models.users import DBUserBase, UserType

from ..base.id import IdBase, IdOptionalBase
from ..revocation import Revocation, RevocationReason
from .agreement_signing import (
    AgreementSigning,
    DBAgreementSigning,
    NewAgreementSigningOption,
)
from .exceptions import AgreementAlreadySigned, MissingAgreementSigningOptions


class NewAgreementOption(BaseModel):
    required: bool = False
    description: str


class AgreementOption(IdOptionalBase):
    required: bool
    description: str


class AgreementBase(RevocableBase, ValidityPeriodBase):
    type: AgreementType
    description: str
    content: str
    targets: List[UserType] | None = None


class Agreement(CreationBase, IdBase, AgreementBase):
    options: List[AgreementOption]


class NewAgreement(NewValidityPeriodBase, AgreementBase):
    options: List[NewAgreementOption]


class FulfilledAgreement(Agreement):
    signing: AgreementSigning | None = None

    async def sign(self, user: DBUserBase, options: List[NewAgreementSigningOption]):
        if self.signing is not None:
            raise AgreementAlreadySigned

        agreement_options = {o.id: o.required for o in self.options}
        agreement_agree = {o.id: o.agree for o in options}
        if any(
            [
                agreement_agree.get(id) is None or (required and not agreement_agree.get(id))
                for id, required in agreement_options.items()
            ]
        ):
            raise MissingAgreementSigningOptions

        await DBAgreementSigning(agreementId=self.id, userId=user.id, options=options).create()


class DBAgreement(Document, Agreement):
    class Settings:
        name = "agreements"

    @classmethod
    def query(
        cls: Type[DocType],
        user: DBUserBase | None = None,
        agreement_type: AgreementType | None = None,
        agreement_id: PydanticObjectId = None,
        only_current: bool = True,
    ) -> FindMany[FulfilledAgreement] | AggregationQuery[FulfilledAgreement]:
        query = DBAgreement.find_period() if only_current else DBAgreement.find()

        if agreement_id is not None:
            query = query.find(Eq(cls.id, agreement_id))

        if agreement_type is not None:
            query = query.find(Eq(DBAgreement.type, agreement_type))

        user_type = "patient" if user is None else user.__user_type__
        if user_type != UserType.admin:
            query = query.aggregate(
                [
                    {"$match": {"targets": {"$in": [None, user_type]}}},
                    {"$sort": {"createdAt": -1}},
                    {"$group": {"_id": "$type", "tmp": {"$first": "$$ROOT"}}},
                    {"$unwind": {"path": "$tmp"}},
                    {"$replaceRoot": {"newRoot": {"$mergeObjects": ["$tmp"]}}},
                    *(
                        []
                        if user is None
                        else [
                            {
                                "$lookup": {
                                    "from": "agreement_signings",
                                    "localField": "_id",
                                    "foreignField": "agreementId",
                                    "as": "signings",
                                    "pipeline": [{"$match": {"userId": ObjectId(user.id)}}],
                                }
                            },
                            {"$addFields": {"signing": {"$first": "$signings"}}},
                            {"$project": {"signings": 0}},
                        ]
                    ),
                ],
                projection_model=FulfilledAgreement,
            )

        return query

    def find_revocable(self) -> FindMany:
        return super().find_revocable().find(Eq(DBAgreement.type, self.type))

    @before_event(Insert)
    async def revoke_old(self):
        for e in await self.find_revocable().to_list():
            await e.revoke(Revocation(dueTo=RevocationReason.outdated, by=self.createdBy))
