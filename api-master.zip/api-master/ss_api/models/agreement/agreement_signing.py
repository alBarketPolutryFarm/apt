from __future__ import annotations

from datetime import datetime, timezone
from typing import List

from beanie import Document, PydanticObjectId
from pydantic import BaseModel
from pymongo import IndexModel

from ss_api.models.base.id import IdBase


class NewAgreementSigningOption(IdBase, BaseModel):
    agree: bool


class AgreementSigningOption(NewAgreementSigningOption):
    pass


class NewAgreementSigning(BaseModel):
    options: List[NewAgreementSigningOption]


class AgreementSigning(IdBase, NewAgreementSigning):
    agreementId: PydanticObjectId
    userId: PydanticObjectId
    at: datetime
    options: List[NewAgreementSigningOption]

    def __init__(self, **kwargs):
        super().__init__(**{"at": datetime.now(timezone.utc), **kwargs})


class DBAgreementSigning(Document, AgreementSigning):
    class Settings:
        name = "agreement_signings"
        indexes = [IndexModel("agreementId"), IndexModel("userId")]
