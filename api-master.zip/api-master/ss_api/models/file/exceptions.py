class FileException(Exception):
    pass


class FileAlreadyClaimed(FileException):
    pass
