from pydantic import BaseModel


class FileEncoded(BaseModel):
    content: str
    mediaType: str
    filename: str
