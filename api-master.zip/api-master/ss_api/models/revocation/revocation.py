from datetime import datetime
from enum import Enum

from beanie import PydanticObjectId
from pydantic import BaseModel, Field


class RevocationReason(str, Enum):
    outdated = "outdated"
    manual = "manual"


class Revocation(BaseModel):
    by: PydanticObjectId
    effectiveFrom: datetime = Field(default_factory=datetime.utcnow)
    dueTo: RevocationReason | None = None
    date: datetime = Field(default_factory=datetime.utcnow)
    notes: str | None = None
