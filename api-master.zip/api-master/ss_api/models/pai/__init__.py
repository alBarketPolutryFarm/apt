from .pai import DBPAI

__document_models__ = [DBPAI]
