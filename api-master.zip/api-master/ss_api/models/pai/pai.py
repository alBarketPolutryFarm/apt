from __future__ import annotations

import asyncio
from datetime import date, datetime, timezone
from enum import Enum
from typing import List, Type

from beanie import Document, PydanticObjectId, ValidateOnSave, after_event, before_event
from beanie.odm.documents import DocType
from beanie.odm.operators.find.comparison import NE, Eq
from beanie.odm.queries.find import FindMany
from pydantic import BaseModel, Field, FutureDate
from pymongo import IndexModel

from ss_api.models.base import IdBase
from ss_api.models.base.creation import CreationBase
from ss_api.models.users.patient import DBPatient
from ss_api.templates import jinja_env
from ss_api.utils.communications.mail import send_mail_async
from ss_api.utils.db import bson_encoders


class CompletionReason(BaseModel):
    reason: str


class PAIStatus(str, Enum):
    ACTIVE = "active"
    COMPLETED = "completed"


class PAICondition(str, Enum):
    IMPROVED = "improved"
    STATIONARY = "stationary"
    DETERIORATED = "deteriorated"


class NewPAIHistoryEntry(BaseModel):
    description: str
    condition: PAICondition
    hostStructure: str
    nextCheck: FutureDate | None = None


class PAIHistoryEntry(NewPAIHistoryEntry, IdBase):
    at: datetime
    nextCheck: date | None
    createdBy: PydanticObjectId
    createdByName: str | None = None

    def __init__(self, **kwargs):
        if kwargs.get("at") is None:
            kwargs["at"] = datetime.now(tz=timezone.utc)
        super().__init__(**kwargs)


class PAIBase(BaseModel):
    diagnosis: str
    goal: str


class NewPAI(PAIBase):
    pass


class PAI(CreationBase, IdBase, PAIBase):
    patientId: PydanticObjectId
    history: List[PAIHistoryEntry]
    completedAt: datetime | None = None
    closedBy: PydanticObjectId | None = None
    reason: str | None = None
    lastUpdate: datetime
    createdByName: str | None = None


class DBPAI(Document, PAI):
    history: List[PAIHistoryEntry] = Field([])
    lastUpdate: datetime | None = None  # type: ignore

    class Settings:
        name = "pai"
        indexes = [IndexModel("patientId")]
        bson_encoders = bson_encoders

    def __init__(self, *args, **kwargs):
        if "goal" not in kwargs:
            kwargs["goal"] = ""
        super().__init__(*args, **kwargs)

    @before_event(ValidateOnSave)
    def update_last_update(self):
        self.lastUpdate = datetime.now(tz=timezone.utc)

    @classmethod
    def find_query(
        cls: Type[DocType], patientId: PydanticObjectId, status: PAIStatus | None = None
    ) -> FindMany[DocType]:
        query = cls.find(cls.patientId == patientId)

        match status:
            case PAIStatus.ACTIVE:
                query = query.find(Eq(cls.completedAt, None))
            case PAIStatus.COMPLETED:
                query = query.find(NE(cls.completedAt, None))

        return query

    @after_event(ValidateOnSave)
    async def send_pai_update_notification(self):
        patient = await DBPatient.get(self.patientId)
        if patient:
            await self._send_pai_update_email(patient)

    async def _send_pai_update_email(self, patient: DBPatient):
        try:
            template = jinja_env.get_template("./email/pai_updated.html")
            body = template.render(patient=patient, pai=self)
            # with open("email/pai_updated.html", "w") as f:
            #     f.write(body)
            loop = asyncio.get_event_loop()
            loop.create_task(
                send_mail_async(
                    subject="Servizio Salute | Il tuo PAI è stato aggiornato",
                    body=body,
                    email=patient.email,
                )
            )
        except Exception as e:
            print(e)
