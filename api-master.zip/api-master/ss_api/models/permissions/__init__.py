from ss_api.models.permissions.permissions import DBPermission

__document_models__ = [DBPermission]
