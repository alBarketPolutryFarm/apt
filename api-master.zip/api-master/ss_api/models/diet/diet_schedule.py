from __future__ import annotations

from pydantic import BaseModel

from .diet_day import DBDietDay, DietDay, NewDietDay


class NewDietSchedule(BaseModel):
    monday: NewDietDay
    tuesday: NewDietDay
    wednesday: NewDietDay
    thursday: NewDietDay
    friday: NewDietDay
    saturday: NewDietDay
    sunday: NewDietDay


class DietSchedule(BaseModel):
    monday: DietDay
    tuesday: DietDay
    wednesday: DietDay
    thursday: DietDay
    friday: DietDay
    saturday: DietDay
    sunday: DietDay


class DBDietSchedule(BaseModel):
    monday: DBDietDay
    tuesday: DBDietDay
    wednesday: DBDietDay
    thursday: DBDietDay
    friday: DBDietDay
    saturday: DBDietDay
    sunday: DBDietDay
