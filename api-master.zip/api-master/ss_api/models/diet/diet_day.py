from pydantic import BaseModel

from ..base import IdBase, IdOptionalBase
from .diet_meal import DBDietMeal, DietMeal, NewDietMeal


class NewDietDay(BaseModel):
    breakfast: NewDietMeal
    morningSnack: NewDietMeal
    lunch: NewDietMeal
    afternoonSnack: NewDietMeal
    dinner: NewDietMeal


class DietDay(IdBase):
    breakfast: DietMeal
    morningSnack: DietMeal
    lunch: DietMeal
    afternoonSnack: DietMeal
    dinner: DietMeal


class DBDietDay(IdOptionalBase):
    breakfast: DBDietMeal
    morningSnack: DBDietMeal
    lunch: DBDietMeal
    afternoonSnack: DBDietMeal
    dinner: DBDietMeal
