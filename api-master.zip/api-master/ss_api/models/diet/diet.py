from __future__ import annotations

from datetime import datetime
from typing import List, Tuple

from beanie import Document, Insert, PydanticObjectId, before_event
from pydantic import BaseModel
from pymongo import ASCENDING, IndexModel

from ss_api.models.base import IdBase
from ss_api.models.base.creation import CreationBase
from ss_api.models.base.validity_period import NewValidityPeriodBase, ValidityPeriodBase
from ss_api.models.revocation import Revocation, RevocationReason
from ss_api.models.users.patient import DBPatient
from ss_api.utils.db import query_sort
from ss_api.utils.helpers.datetime import get_days

from .diet_schedule import DBDietSchedule, DietSchedule, NewDietSchedule
from .diet_schedule_entry import DietScheduleEntry, DietScheduleEntryRaw


class DietBase(ValidityPeriodBase, BaseModel):
    reportId: PydanticObjectId
    notes: str | None = None


class Diet(DietBase, CreationBase):
    revocation: Revocation | None = None
    diet: DietSchedule


class NewDietBase(BaseModel):
    diet: NewDietSchedule

    notes: str | None = None


class NewDiet(NewValidityPeriodBase, DietBase, NewDietBase):
    pass


class DBDiet(Document, Diet, IdBase):
    patientId: PydanticObjectId
    diet: DBDietSchedule

    class Settings:
        name = "diets"
        indexes = [IndexModel("patientId")]

    @before_event(Insert)
    async def revoke_current(self):
        patient = await DBPatient.get(self.patientId)
        if (
            current_treatment := await self.find_period().find(DBDiet.patientId == patient.id).first_or_none()
        ) is not None:
            await current_treatment.revoke(
                Revocation(dueTo=RevocationReason.outdated, effectiveFrom=self.effectiveDate, by=self.id)
            )

    async def revoke(self, revocation: Revocation) -> None:
        self.revocation = revocation
        self.expirationDate = self.revocation.effectiveFrom
        await self.save()

    @property
    def validity_interval(self) -> Tuple[datetime, datetime | None]:
        return self.effectiveDate, self.expirationDate

    async def get_schedule(
        self, /, start_date: datetime | None = None, end_date: datetime | None = None
    ) -> list[DietScheduleEntry]:
        _start_date = self.effectiveDate if start_date is None or start_date < self.effectiveDate else start_date

        if end_date is not None and self.expirationDate is not None:
            _end_date = self.expirationDate if end_date > self.expirationDate else end_date
        elif self.expirationDate is None and end_date is not None:
            _end_date = end_date
        elif self.expirationDate is not None and end_date is None:
            _end_date = self.expirationDate
        else:
            raise ValueError("'end_date' must be provided or 'expirationDate' must be set")

        days = get_days(_start_date.date(), _end_date.date())

        schedule_raw = map(
            lambda d: DietScheduleEntryRaw(at=d, **getattr(self.diet, d.strftime("%A").lower()).model_dump()), days
        )

        schedule = [await DietScheduleEntry.from_raw(t) for t in schedule_raw]

        return schedule

    @classmethod
    async def get_complete_schedule(
        cls, /, patient: DBPatient, start_date: datetime, end_date: datetime
    ) -> List[DietScheduleEntry]:
        query = cls.find_period(start_date, end_date)
        query = query.find(cls.patientId == patient.id)
        query = query_sort(query, "effectiveDate", ASCENDING)
        diets = await query.to_list()

        schedule = [await d.get_schedule(start_date=start_date, end_date=end_date) for d in diets]

        return [p for s in schedule for p in s]
