from datetime import datetime, timedelta
from typing import Annotated

from beanie import Document, Granularity, PydanticObjectId, TimeSeriesConfig
from pydantic import BaseModel, Field
from pymongo import IndexModel

from ss_api.models.base.id import IdBase


class DietAdherenceBase(BaseModel):
    mealId: PydanticObjectId
    at: datetime | None
    adherence: float = Field(ge=0, le=1, description="The adherence expressed as percentage")


class NewDietAdherence(DietAdherenceBase):
    at: Annotated[datetime | None, Field(default_factory=datetime.utcnow)]


class DietAdherence(IdBase, DietAdherenceBase):
    patientId: PydanticObjectId
    at: datetime


class DBDietAdherence(Document, DietAdherence):
    class Settings:
        name = "diet_adherence"

        timeseries = TimeSeriesConfig(
            time_field="at",
            granularity=Granularity.minutes,
            expire_after_seconds=timedelta(days=365).total_seconds(),
        )
        indexes = [IndexModel("patientId"), IndexModel("at")]
