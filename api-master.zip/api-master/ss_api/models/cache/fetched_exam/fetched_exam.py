from datetime import UTC, datetime, timedelta
from typing import Annotated

from beanie import Document
from pydantic import Field
from pymongo import IndexModel


class DBFetchedExam(Document):
    timestamp: Annotated[datetime, Field(default_factory=lambda: datetime.now(tz=UTC))]
    studyId: str

    class Settings:
        name = "cache@fetched_exams"
        indexes = [
            IndexModel("studyId"),
            IndexModel("timestamp", expireAfterSeconds=timedelta(days=30).total_seconds()),
        ]
