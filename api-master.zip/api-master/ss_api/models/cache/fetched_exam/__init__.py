from .fetched_exam import DBFetchedExam

__document_models__ = [DBFetchedExam]
