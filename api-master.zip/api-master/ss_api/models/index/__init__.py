from .barthel import BarthelIndexMeasure, DBBarthelIndexMeasure, NewBarthelIndexMeasure
from .base import DBIndexMeasureBase
from .braden import BradenIndexMeasure, DBBradenIndexMeasure, NewBradenIndexMeasure
from .brass import BrassIndexMeasure, DBBrassIndexMeasure, NewBrassIndexMeasure
from .conley import ConleyIndexMeasure, DBConleyIndexMeasure, NewConleyIndexMeasure
from .must import DBMustIndexMeasure, MustIndexMeasure, NewMustIndexMeasure
from .npi import DBNPIIndexMeasure, NewNPIIndexMeasure, NPIIndexMeasure
from .summary import DBIndexMeasuresSummary, IndexMeasuresSummary
from .type import IndexMeasureType

__document_models__ = [
    DBIndexMeasureBase,
    DBBarthelIndexMeasure,
    DBBradenIndexMeasure,
    DBBrassIndexMeasure,
    DBConleyIndexMeasure,
    DBMustIndexMeasure,
    DBNPIIndexMeasure,
]

DBIndexMeasure = (
    DBBarthelIndexMeasure
    | DBBradenIndexMeasure
    | DBBrassIndexMeasure
    | DBConleyIndexMeasure
    | DBMustIndexMeasure
    | DBNPIIndexMeasure
)

IndexMeasure = (
    BarthelIndexMeasure
    | BradenIndexMeasure
    | BrassIndexMeasure
    | ConleyIndexMeasure
    | MustIndexMeasure
    | NPIIndexMeasure
)

NewIndexMeasure = (
    NewBarthelIndexMeasure
    | NewBradenIndexMeasure
    | NewBrassIndexMeasure
    | NewConleyIndexMeasure
    | NewMustIndexMeasure
    | NewNPIIndexMeasure
)
