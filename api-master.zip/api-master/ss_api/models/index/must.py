from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import (
    DBIndexMeasureBase,
    IndexMeasureBase,
    IndexMeasureMetadataBase,
    NewIndexMeasureBase,
    _IndexMeasureBase,
)
from .type import IndexMeasureType


class MustIndexMeasureMetadata(IndexMeasureMetadataBase):
    type: Literal[IndexMeasureType.must]


class NewMustIndexMeasureMetadata(MustIndexMeasureMetadata):
    pass


class _MustIndexMeasureBase(_IndexMeasureBase):
    metadata: MustIndexMeasureMetadata

    value: int = Field(ge=0)


class DBMustIndexMeasure(_MustIndexMeasureBase, DBIndexMeasureBase):
    pass


class MustIndexMeasure(_MustIndexMeasureBase, IndexMeasureBase):
    pass


class NewMustIndexMeasure(NewIndexMeasureBase, _MustIndexMeasureBase):
    metadata: NewMustIndexMeasureMetadata
    __db_model__ = DBMustIndexMeasure
