from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import (
    DBIndexMeasureBase,
    IndexMeasureBase,
    IndexMeasureMetadataBase,
    NewIndexMeasureBase,
    _IndexMeasureBase,
)
from .type import IndexMeasureType


class ConleyIndexMeasureMetadata(IndexMeasureMetadataBase):
    type: Literal[IndexMeasureType.conley]


class NewConleyIndexMeasureMetadata(ConleyIndexMeasureMetadata):
    pass


class _ConleyIndexMeasureBase(_IndexMeasureBase):
    metadata: ConleyIndexMeasureMetadata

    value: int = Field(ge=0, le=12)


class DBConleyIndexMeasure(_ConleyIndexMeasureBase, DBIndexMeasureBase):
    pass


class ConleyIndexMeasure(_ConleyIndexMeasureBase, IndexMeasureBase):
    pass


class NewConleyIndexMeasure(NewIndexMeasureBase, _ConleyIndexMeasureBase):
    metadata: NewConleyIndexMeasureMetadata
    __db_model__ = DBConleyIndexMeasure
