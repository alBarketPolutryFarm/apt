from __future__ import annotations

from abc import ABC
from datetime import date, datetime, timedelta, timezone
from typing import Annotated, Self, Type

from beanie import Document, Granularity, PydanticObjectId, TimeSeriesConfig
from beanie.odm.operators.find.comparison import Eq
from pydantic import BaseModel, Field, FutureDate, PastDatetime
from pymongo import DESCENDING, IndexModel

from ss_api.models.base.id import IdBase
from ss_api.models.users import DBPatient
from ss_api.utils.db import bson_encoders, query_sort

from .type import IndexMeasureType


class IndexMeasureMetadataBase(BaseModel, ABC):
    type: IndexMeasureType


class _IndexMeasureBase(BaseModel, ABC):
    metadata: IndexMeasureMetadataBase
    timestamp: datetime
    notes: str | None = None
    nextCheck: date | None = None


class DBIndexMeasureBase(Document, _IndexMeasureBase, ABC):
    patientId: PydanticObjectId

    class Settings:
        is_root = True
        name = "index_measures"
        indexes = [IndexModel("patientId")]
        bson_encoders = bson_encoders

        timeseries = TimeSeriesConfig(
            time_field="timestamp",
            meta_field="metadata",
            granularity=Granularity.hours,
            expire_after_seconds=timedelta(days=3 * 365).total_seconds(),
        )

    @classmethod
    async def get_last(cls: Type[Self], patient: DBPatient | PydanticObjectId) -> Self:
        query = cls.find(Eq("patientId", (patient.id if isinstance(patient, DBPatient) else patient)))
        query = query_sort(query, "timestamp", DESCENDING)
        return await query.first_or_none()


class IndexMeasureBase(IdBase, _IndexMeasureBase, ABC):
    pass


class NewIndexMeasureBase(_IndexMeasureBase, ABC):
    __db_model__: Type[DBIndexMeasureBase]

    timestamp: Annotated[PastDatetime, Field(default_factory=lambda: datetime.now(tz=timezone.utc))]
    nextCheck: FutureDate | None = None

    @classmethod
    def get_db_model(cls) -> Type[DBIndexMeasureBase]:
        return cls.__db_model__
