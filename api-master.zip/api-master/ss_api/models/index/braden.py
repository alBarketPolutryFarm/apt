from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import (
    DBIndexMeasureBase,
    IndexMeasureBase,
    IndexMeasureMetadataBase,
    NewIndexMeasureBase,
    _IndexMeasureBase,
)
from .type import IndexMeasureType


class BradenIndexMeasureMetadata(IndexMeasureMetadataBase):
    type: Literal[IndexMeasureType.braden]


class NewBradenIndexMeasureMetadata(BradenIndexMeasureMetadata):
    pass


class _BradenIndexMeasureBase(_IndexMeasureBase):
    metadata: BradenIndexMeasureMetadata

    value: int = Field(ge=0, le=23)


class DBBradenIndexMeasure(_BradenIndexMeasureBase, DBIndexMeasureBase):
    pass


class BradenIndexMeasure(_BradenIndexMeasureBase, IndexMeasureBase):
    pass


class NewBradenIndexMeasure(NewIndexMeasureBase, _BradenIndexMeasureBase):
    metadata: NewBradenIndexMeasureMetadata
    __db_model__ = DBBradenIndexMeasure
