from enum import Enum


class IndexMeasureType(str, Enum):
    barthel = "barthel"
    braden = "braden"
    brass = "brass"
    conley = "conley"
    must = "must"
    npi = "npi"
