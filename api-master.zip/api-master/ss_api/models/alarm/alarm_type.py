from enum import Enum


class AlarmType(str, Enum):
    measure_out_bounds = "measureOutBounds"
