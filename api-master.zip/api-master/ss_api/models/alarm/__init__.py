from .base import DBAlarmBase
from .measure_out_bounds import DBMeasureOutOfBoundsAlarm, MeasureOutOfBoundsAlarm

__document_models__ = [DBAlarmBase, DBMeasureOutOfBoundsAlarm]

Alarm = MeasureOutOfBoundsAlarm
DBAlarm = DBMeasureOutOfBoundsAlarm
