# admin.py
from typing import Literal

from beanie import Link

from ss_api.models.users.limits.admin_creation_limit import DBAdminLimits

from ..base import EditsLogBase, PatchableBase
from .base import DBUserBase, NewUser, UpdateUser, UserBase
from .type import UserType


class UpdateAdmin(UpdateUser):
    __user_type__ = UserType.admin


class NewAdmin(NewUser, UpdateAdmin):
    pass


class Admin(NewAdmin, UserBase, EditsLogBase):
    type: Literal[UserType.admin]


class DBAdmin(NewAdmin, DBUserBase, EditsLogBase, PatchableBase):
    __update_model__ = UpdateAdmin
    limits: Link[DBAdminLimits] | None = None
    __sign_up_email_template__ = "email/admin_created.html"
    __sign_up_email_subject__ = "Admin creato"


class UpdateSuperAdmin(UpdateUser):
    __user_type__ = UserType.superadmin


class NewSuperAdmin(NewUser, UpdateSuperAdmin):
    pass


class SuperAdmin(NewSuperAdmin, UserBase, EditsLogBase):
    type: Literal[UserType.superadmin]


class DBSuperAdmin(NewSuperAdmin, DBUserBase, EditsLogBase, PatchableBase):
    __update_model__ = UpdateSuperAdmin
