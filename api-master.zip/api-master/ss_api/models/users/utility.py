# utility.py
from ss_api.models.users import (
    DBAdmin,
    DBCaregiver,
    DBDoctor,
    DBNurse,
    DBOperator,
    DBPatient,
    DBSuperAdmin,
    UserType,
)


def user_type_to_class_id(type: UserType) -> str:
    match type:
        case UserType.superadmin:
            return DBSuperAdmin._class_id
        case UserType.admin:
            return DBAdmin._class_id
        case UserType.operator:
            return DBOperator._class_id
        case UserType.patient:
            return DBPatient._class_id
        case UserType.doctor:
            return DBDoctor._class_id
        case UserType.nurse:
            return DBNurse._class_id
        case UserType.caregiver:
            return DBCaregiver._class_id

    raise NotImplementedError
