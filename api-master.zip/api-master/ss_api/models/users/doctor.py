from typing import Annotated, Any, List, Literal

from beanie import ValidateOnSave, before_event
from pydantic import Field, computed_field
from pymongo import IndexModel

from ss_api.models.base import CreationBase, EditsLogBase, PatchableBase
from ss_api.utils.typing import FiscalCode, PhoneNumber

from ..enum.exam_modality import ExamModality
from .base import DBUserBase, NewUser, UpdateUser, UserBase
from .limits import (
    DBPatientCreationLimit,
    DBSignatureLimit,
    NewPatientCreationLimit,
    NewSignatureLimit,
    PatientCreationLimit,
    SignatureLimit,
    UpdatePatientCreationLimit,
)
from .type import UserType


class UpdateDoctor(UpdateUser):
    __user_type__ = UserType.doctor

    reportableExamModalities: List[ExamModality] | None = None

    patientCreationLimit: UpdatePatientCreationLimit | None = None
    signatureLimit: SignatureLimit | None = None

    @computed_field  # type: ignore[misc]
    @property
    def fullName(self) -> str:
        return f"Dott. {self.firstName} {self.lastName}"


class NewDoctor(NewUser, UpdateDoctor):
    fiscalCode: FiscalCode
    phone: PhoneNumber
    reportableExamModalities: List[ExamModality] = []

    patientCreationLimit: NewPatientCreationLimit = NewPatientCreationLimit()
    signatureLimit: NewSignatureLimit = NewSignatureLimit()


class Doctor(NewDoctor, CreationBase, UserBase, EditsLogBase):
    type: Literal[UserType.doctor]
    reportableExamModalities: List[ExamModality]

    patientCreationLimit: PatientCreationLimit
    signatureLimit: SignatureLimit


class DBDoctor(NewDoctor, DBUserBase, EditsLogBase, PatchableBase):
    __update_model__ = UpdateDoctor
    __sign_up_email_template__ = "email/doctor_created.html"
    __sign_up_email_subject__ = "Dottore creato"

    reportableExamModalities: List[ExamModality] = []

    patientCreationLimit: Annotated[DBPatientCreationLimit, Field(default_factory=lambda: DBPatientCreationLimit())]
    signatureLimit: Annotated[DBSignatureLimit, Field(default_factory=lambda: DBSignatureLimit())]

    def __init__(self, **kwargs: Any):
        # if "patientCreationLimit" not in kwargs:
        #     kwargs["patientCreationLimit"] = NewPatientCreationLimit()
        # if "signatureLimit" not in kwargs:
        #     kwargs["signatureLimit"] = NewSignatureLimit()

        super().__init__(**{"type": UserType.doctor, **kwargs})

        self.patientCreationLimit._user = self
        self.signatureLimit._user = self

    @before_event(ValidateOnSave)
    async def sync_limits(self) -> None:
        await self.patientCreationLimit.sync()
        await self.signatureLimit.sync()

    class Settings(DBUserBase.Settings):
        indexes = [
            IndexModel(
                "reportableExamModalities", partialFilterExpression={"reportableExamModalities": {"$exists": True}}
            )
        ]
