from typing import Annotated

from pydantic import Field

from .base import (
    DBNumericLimit,
    NewNumericLimit,
    NumericLimit,
    ResetInterval,
    UpdateNumericLimit,
)


class UpdatePatientCreationLimit(UpdateNumericLimit):
    resetValue: Annotated[int, Field(ge=0)] | None = None


class NewPatientCreationLimit(UpdatePatientCreationLimit, NewNumericLimit):
    resetInterval: ResetInterval = "month"
    resetValue: Annotated[int, Field(ge=0)] | None = 20
    available: Annotated[int, Field(ge=0)] | None = 20


class PatientCreationLimit(NewPatientCreationLimit, NumericLimit):  # type: ignore
    available: Annotated[int, Field(ge=0)]
    resetValue: Annotated[int, Field(ge=0)]
    resetInterval: ResetInterval


class DBPatientCreationLimit(NewPatientCreationLimit, DBNumericLimit):  # type: ignore
    async def reset(self) -> None:
        self.available = 20
        await super().reset()

    def __init__(self, **kwargs):
        if "resetValue" not in kwargs:
            kwargs["resetValue"] = 20

        super().__init__(**kwargs)
