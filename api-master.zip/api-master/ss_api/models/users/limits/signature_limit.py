from math import ceil
from typing import Annotated

from pydantic import Field

from ss_api.models.permissions import DBPermission
from ss_api.utils.db import query_count

from .base import (
    DBNumericLimit,
    NewNumericLimit,
    NumericLimit,
    ResetInterval,
    UpdateNumericLimit,
)


class UpdateSignatureLimit(UpdateNumericLimit):
    resetValue: Annotated[int, Field(ge=0)] | None = None
    resetPatientsScaleFactor: Annotated[float, Field(ge=0)] | None = None


class NewSignatureLimit(UpdateSignatureLimit, NewNumericLimit):
    resetInterval: ResetInterval = "month"
    resetValue: Annotated[int, Field(ge=0)] = 0
    resetPatientsScaleFactor: Annotated[float, Field(ge=0)] = 0.25
    available: Annotated[int, Field(ge=0)] = 0


class SignatureLimit(NewSignatureLimit, NumericLimit):  # type: ignore
    available: Annotated[int, Field(ge=0)]
    resetValue: Annotated[int, Field(ge=0)]
    resetPatientsScaleFactor: Annotated[float, Field(ge=0)]
    resetInterval: ResetInterval


class DBSignatureLimit(NewSignatureLimit, DBNumericLimit):  # type: ignore
    async def reset(self) -> None:
        self.available = self.resetValue + ceil(
            (await query_count(DBPermission.find_query(target=self._user))) * self.resetPatientsScaleFactor
        )
        await super().reset()
