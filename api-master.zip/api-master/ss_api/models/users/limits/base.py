from abc import abstractmethod
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Annotated, Literal, Type

from pydantic import BaseModel, Field, PrivateAttr, computed_field
from pytz import UTC

from ss_api.models.base import UpdatableBase
from ss_api.models.users.limits.exceptions import LimitExceededError

if TYPE_CHECKING:
    from ss_api.models.users import DBDoctor, DBNurse, DBOperator

    DBUser = Type[DBOperator | DBNurse | DBDoctor]

ResetInterval = Literal["day", "week", "month", "year"]


class UpdateNumericLimit(BaseModel):
    available: Annotated[int, Field(ge=0)] | None = None


class NewNumericLimit(UpdateNumericLimit):
    available: Annotated[int, Field(ge=0)] | None = 0


class NumericLimit(NewNumericLimit):
    available: Annotated[int, Field(ge=0)]
    lastReset: datetime

    def __init__(self, **kwargs):
        if "lastReset" not in kwargs:
            kwargs["lastReset"] = datetime.min.replace(tzinfo=UTC)
        super().__init__(**kwargs)

    @computed_field  # type: ignore[misc]
    @property
    def next_reset(self) -> datetime:
        return self.lastReset + self.reset_delta

    @computed_field  # type: ignore[misc]
    @property
    def reset_delta(self) -> timedelta:
        match self.resetInterval:
            case "month":
                return timedelta(days=30)
            case _:
                raise NotImplementedError()


class DBNumericLimit(NumericLimit, UpdatableBase):
    resetInterval: ResetInterval

    _user: Annotated["DBUser", PrivateAttr()]

    @abstractmethod
    async def reset(self) -> None:
        self.lastReset = datetime.now(tz=UTC)

    async def sync(self) -> bool:
        if datetime.now(tz=UTC) < self.next_reset:
            return False

        await self.reset()
        return True

    async def use(self, save=True) -> None:
        await self.sync()

        if self.available <= 0:
            raise LimitExceededError()

        self.available -= 1

        if save:
            await self._user.save()
