# __init__.py
from .admin import Admin, DBAdmin, DBSuperAdmin, NewAdmin, NewSuperAdmin, SuperAdmin
from .base import DBUserBase
from .caregiver import Caregiver, DBCaregiver, NewCaregiver
from .doctor import DBDoctor, Doctor, NewDoctor
from .nurse import DBNurse, NewNurse, Nurse
from .operator import DBOperator, NewOperator, Operator
from .patient import DBPatient, NewPatient, Patient
from .type import UserType

__document_models__ = [DBUserBase, DBAdmin, DBSuperAdmin, DBNurse, DBPatient, DBDoctor, DBOperator, DBCaregiver]

NewUser = NewPatient | NewNurse | NewAdmin | NewSuperAdmin | NewOperator | NewDoctor | NewCaregiver
User = Patient | Nurse | Admin | SuperAdmin | Operator | Doctor | Caregiver
DBUser = DBAdmin | DBSuperAdmin | DBNurse | DBPatient | DBDoctor | DBOperator | DBCaregiver
