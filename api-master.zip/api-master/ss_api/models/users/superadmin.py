from typing import Literal

from ..base import EditsLogBase, PatchableBase
from .base import DBUserBase, NewUser, UpdateUser, UserBase
from .type import UserType


class UpdateSuperAdmin(UpdateUser):
    __user_type__ = UserType.superadmin


class NewSuperAdmin(NewUser, UpdateSuperAdmin):
    pass


class Admin(NewSuperAdmin, UserBase, EditsLogBase):
    type: Literal[UserType.superadmin]


class DBSuperAdmin(NewSuperAdmin, DBUserBase, EditsLogBase, PatchableBase):
    __update_model__ = UpdateSuperAdmin
