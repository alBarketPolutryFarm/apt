from enum import Enum


class MeasureType(str, Enum):
    bloodPressure = "bloodPressure"
    weight = "weight"
    temperature = "temperature"
    pain = "pain"
    respiratoryRate = "respiratoryRate"
    pulse = "pulse"
    glycaemia = "glycaemia"
    oxygenSaturation = "oxygenSaturation"
    waterBalance = "waterBalance"
