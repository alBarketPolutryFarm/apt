from abc import ABC
from datetime import date, datetime, time, timedelta, timezone
from enum import Enum
from typing import Literal

from beanie.odm.documents import DocType
from pydantic import Field

from .base import (
    DBMeasureBase,
    GetMeasureBase,
    MeasureBase,
    MeasureMetadataBase,
    NewMeasureBase,
)
from .type import MeasureType


class WaterBalanceUnit(str, Enum):
    ML = "ml"


class WaterBalanceMetadata(MeasureMetadataBase):
    type: Literal[MeasureType.waterBalance]
    unit: WaterBalanceUnit


class NewWaterBalanceMetadata(WaterBalanceMetadata):
    unit: WaterBalanceUnit = WaterBalanceUnit.ML


class _WaterBalanceBase(MeasureBase, ABC):
    metadata: WaterBalanceMetadata

    value: int = Field()


class DBWaterBalance(_WaterBalanceBase, DBMeasureBase):
    total: int = 0

    async def insert(self: DocType, **kwargs) -> DocType:
        if (last := await self.get_last(self.patientId)) is not None:
            # the total have to be reset at 7:00AM
            reset_date = datetime.combine(date.today(), time(hour=7), tzinfo=timezone.utc)
            if datetime.now(tz=timezone.utc) < reset_date:
                reset_date = reset_date - timedelta(days=1)
            if last.timestamp > reset_date:
                self.total = last.total + self.value
        return await super().insert(**kwargs)


class WaterBalance(_WaterBalanceBase, GetMeasureBase):
    total: int


class NewWaterBalance(NewMeasureBase, _WaterBalanceBase):
    metadata: NewWaterBalanceMetadata
    __db_model__ = DBWaterBalance
