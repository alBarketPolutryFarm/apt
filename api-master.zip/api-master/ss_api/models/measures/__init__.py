from .base import DBMeasureBase
from .blood_pressure import BloodPressure, DBBloodPressure, NewBloodPressure
from .glycaemia import DBGlycaemia, Glycaemia, NewGlycaemia
from .oxygen_saturation import DBOxygenSaturation, NewOxygenSaturation, OxygenSaturation
from .pain import DBPain, NewPain, Pain
from .pulse import DBPulse, NewPulse, Pulse
from .respiratory_rate import DBRespiratoryRate, NewRespiratoryRate, RespiratoryRate
from .summary import MeasuresSummary
from .temperature import DBTemperature, NewTemperature, Temperature
from .type import MeasureType
from .water_balance import DBWaterBalance, NewWaterBalance, WaterBalance
from .weight import DBWeight, NewWeight, Weight

__document_models__ = [
    DBMeasureBase,
    DBBloodPressure,
    DBWeight,
    DBGlycaemia,
    DBOxygenSaturation,
    DBTemperature,
    DBPain,
    DBPulse,
    DBRespiratoryRate,
    DBWaterBalance,
]

DBMeasure = (
    DBTemperature
    | DBWeight
    | DBBloodPressure
    | DBGlycaemia
    | DBOxygenSaturation
    | DBPain
    | DBPulse
    | DBRespiratoryRate
    | DBWaterBalance
)

Measure = (
    Temperature | Weight | BloodPressure | Glycaemia | OxygenSaturation | Pain | Pulse | RespiratoryRate | WaterBalance
)

NewMeasure = (
    NewTemperature
    | NewWeight
    | NewBloodPressure
    | NewGlycaemia
    | NewOxygenSaturation
    | NewPain
    | NewPulse
    | NewRespiratoryRate
    | NewWaterBalance
)
