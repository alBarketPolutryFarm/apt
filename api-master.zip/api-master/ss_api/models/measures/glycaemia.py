from __future__ import annotations

from abc import ABC
from enum import Enum
from typing import Literal

from pydantic import Field

from .base import (
    DBMeasureBase,
    GetMeasureBase,
    MeasureBase,
    MeasureMetadataBase,
    NewMeasureBase,
)
from .type import MeasureType


class GlycaemiaUnit(str, Enum):
    MG_PER_DL = "mg/dl"
    MMOL_PER_L = "mmol/l"


class GlycaemiaMetadata(MeasureMetadataBase):
    type: Literal[MeasureType.glycaemia]
    unit: GlycaemiaUnit


class NewGlycaemiaMetadata(GlycaemiaMetadata):
    unit: GlycaemiaUnit = GlycaemiaUnit.MG_PER_DL


class _GlycaemiaBase(MeasureBase, ABC):
    metadata: GlycaemiaMetadata

    value: int = Field(ge=0)


class DBGlycaemia(_GlycaemiaBase, DBMeasureBase):
    pass


class Glycaemia(_GlycaemiaBase, GetMeasureBase):
    pass


class NewGlycaemia(NewMeasureBase, _GlycaemiaBase):
    metadata: NewGlycaemiaMetadata
    __db_model__ = DBGlycaemia
