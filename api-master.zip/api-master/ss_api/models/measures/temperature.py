from abc import ABC
from enum import Enum
from typing import Literal

from pydantic import Field

from .base import (
    DBMeasureBase,
    GetMeasureBase,
    MeasureBase,
    MeasureMetadataBase,
    NewMeasureBase,
)
from .type import MeasureType


class TemperatureUnit(str, Enum):
    CELSIUS = "°C"
    FAHRENHEIT = "°F"


class TemperatureMetadata(MeasureMetadataBase):
    type: Literal[MeasureType.temperature]
    unit: TemperatureUnit


class NewTemperatureMetadata(TemperatureMetadata):
    unit: TemperatureUnit = TemperatureUnit.CELSIUS


class _TemperatureBase(MeasureBase, ABC):
    metadata: TemperatureMetadata

    value: float = Field(ge=0)


class DBTemperature(_TemperatureBase, DBMeasureBase):
    pass


class Temperature(_TemperatureBase, GetMeasureBase):
    pass


class NewTemperature(NewMeasureBase, _TemperatureBase):
    metadata: NewTemperatureMetadata
    __db_model__ = DBTemperature
