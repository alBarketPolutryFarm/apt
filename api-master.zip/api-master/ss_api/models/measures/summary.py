from __future__ import annotations

from pydantic import BaseModel

from ss_api.models.users import DBPatient

from .blood_pressure import BloodPressure, DBBloodPressure
from .glycaemia import DBGlycaemia, Glycaemia
from .oxygen_saturation import DBOxygenSaturation, OxygenSaturation
from .pain import DBPain, Pain
from .pulse import DBPulse, Pulse
from .respiratory_rate import DBRespiratoryRate, RespiratoryRate
from .temperature import DBTemperature, Temperature
from .water_balance import DBWaterBalance, WaterBalance
from .weight import DBWeight, Weight


class DBMeasuresSummary(BaseModel):
    bloodPressure: DBBloodPressure | None = None
    weight: DBWeight | None = None
    temperature: DBTemperature | None = None
    pain: DBPain | None = None
    respiratoryRate: DBRespiratoryRate | None = None
    pulse: DBPulse | None = None
    glycaemia: DBGlycaemia | None = None
    oxygenSaturation: DBOxygenSaturation | None = None
    waterBalance: DBWaterBalance | None = None

    @classmethod
    async def compute(cls, patient: DBPatient) -> DBMeasuresSummary:
        return cls(
            bloodPressure=await DBBloodPressure.get_last(patient),
            weight=await DBWeight.get_last(patient),
            temperature=await DBTemperature.get_last(patient),
            pain=await DBPain.get_last(patient),
            respiratoryRate=await DBRespiratoryRate.get_last(patient),
            pulse=await DBPulse.get_last(patient),
            glycaemia=await DBGlycaemia.get_last(patient),
            oxygenSaturation=await DBOxygenSaturation.get_last(patient),
            waterBalance=await DBWaterBalance.get_last(patient),
        )


class MeasuresSummary(BaseModel):
    bloodPressure: BloodPressure | None = None
    weight: Weight | None = None
    temperature: Temperature | None = None
    pain: Pain | None = None
    respiratoryRate: RespiratoryRate | None = None
    pulse: Pulse | None = None
    glycaemia: Glycaemia | None = None
    oxygenSaturation: OxygenSaturation | None = None
    waterBalance: WaterBalance | None = None
