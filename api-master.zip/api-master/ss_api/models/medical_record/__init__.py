from .medical_record import DBMedicalRecord

__document_models__ = [DBMedicalRecord]
