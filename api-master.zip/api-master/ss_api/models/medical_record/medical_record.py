from __future__ import annotations

from enum import Enum
from typing import List

from beanie import Document, PydanticObjectId
from pydantic import BaseModel
from pymongo import IndexModel

from ss_api.models.base.edits_log import EditsLogBase
from ss_api.models.base.id import IdBase
from ss_api.models.base.patchable import PatchableBase
from ss_api.models.blood_type import BloodType
from ss_api.utils.db import bson_encoders
from ss_api.utils.typing import NotFutureDate


class Surgery(BaseModel):
    date: NotFutureDate
    cause: str
    sideEffects: str | None = None


class Injury(BaseModel):
    date: NotFutureDate
    description: str


class Comorbidity(BaseModel):
    congenitalMalformations: str | None = None
    exanthematousDiseases: str | None = None
    venerealDiseases: str | None = None
    infectiousDiseases: str | None = None
    respiratoryDiseases: str | None = None
    digestiveDiseases: str | None = None
    cardiovascularDiseases: str | None = None
    nervousPsycheDiseases: str | None = None
    genitourinaryDiseases: str | None = None
    osteoarticularDiseases: str | None = None
    bloodDiseases: str | None = None
    skinDiseases: str | None = None
    metabolicDiseases: str | None = None
    otherDiseases: str | None = None


class Vaccination(BaseModel):
    type: str
    date: NotFutureDate


class Menarche(str, Enum):
    NORMAL = "normal"
    PREMATURE = "premature"
    LATE = "late"
    ABSENT = "absent"


class Menopause(str, Enum):
    NORMAL = "normal"
    PREMATURE = "premature"
    LATE = "late"
    CAUSED = "caused"
    ABSENT = "absent"


class Andropause(str, Enum):
    NORMAL = "normal"
    PREMATURE = "premature"
    LATE = "late"
    ABSENT = "absent"


class Nutrition(str, Enum):
    NORMAL = "normal"
    INSUFFICIENT = "insufficient"
    OVEREATING = "overeating"


class Alcohol(str, Enum):
    TEETOTALER = "teetotaler"
    MEDIUM_DRINKER = "mediumDrinker"
    HEAVY_DRINKER = "heavyDrinker"


class Coffe(str, Enum):
    NEVER = "never"
    MEDIUM_DRINKER = "mediumDrinker"
    HEAVY_DRINKER = "heavyDrinker"


class Sleep(str, Enum):
    NORMAL = "normal"
    SLEEPLESS = "sleepless"
    EXCESSIVE = "excessive"


class PhysicalActivity(str, Enum):
    NEVER = "never"
    MODERATE = "moderate"
    INTENSE = "intense"


class SexLife(str, Enum):
    NORMAL = "normal"
    LOW = "low"
    NEVER = "never"


class Bowel(str, Enum):
    NORMAL = "normal"
    DIARRHEA = "diarrhea"
    CONSTIPATED = "constipated"
    TENESMUS = "tenesmus"


class Diuresis(str, Enum):
    NORMAL = "normal"
    OLIGURIA = "oliguria"
    POLYURIA = "polyuria"
    DYSURIA = "dysuria"
    POLLAKIURA = "pollakiuria"


class Appetite(str, Enum):
    NORMAL = "normal"
    INCREASED = "increased"
    REDUCED = "reduced"


class Thirst(str, Enum):
    NORMAL = "normal"
    INCREASED = "increased"
    REDUCED = "reduced"


class MedicalRecordBase(BaseModel):
    bloodType: BloodType | None = None

    height: float | None = None
    weight: float | None = None
    bmi: float | None = None

    familyHistory: str | None = None

    surgeries: List[Surgery] | None = None
    injuries: List[Injury] | None = None
    prostheses: str | None = None

    comorbidity: Comorbidity | None = None

    riskFactors: str | None = None
    allergiesIntolerances: str | None = None

    vaccinations: List[Vaccination] | None = None

    notes: str | None = None

    menarche: Menarche | None = None
    lastMenstruation: NotFutureDate | None = None
    pregnanciesNumber: int | None = None
    menopause: Menopause | None = None
    andropause: Andropause | None = None

    nutrition: Nutrition | None = None
    alcohol: Alcohol | None = None
    coffe: Coffe | None = None
    sleep: Sleep | None = None
    physicalActivity: PhysicalActivity | None = None
    sexLife: SexLife | None = None
    bowel: Bowel | None = None
    diuresis: Diuresis | None = None
    appetite: Appetite | None = None
    thirst: Thirst | None = None
    drugs: str | None = None


class MedicalRecord(IdBase, EditsLogBase, MedicalRecordBase):
    patientId: PydanticObjectId


class UpdateMedicalRecord(MedicalRecordBase):
    pass


class DBMedicalRecord(Document, MedicalRecord, PatchableBase):
    __update_model__ = UpdateMedicalRecord

    class Settings:
        name = "medical_records"
        bson_encoders = bson_encoders
        indexes = [IndexModel("patientId")]
