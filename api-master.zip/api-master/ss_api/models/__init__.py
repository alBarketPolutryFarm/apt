from typing import List

from beanie.odm.documents import DocType

from ss_api.models import (
    agreement,
    alarm,
    booking,
    cache,
    chat,
    diet,
    file,
    index,
    measures,
    medical_record,
    monitoring_plan,
    pai,
    permissions,
    report,
    screening,
    task,
    treatment_plan,
    users,
)
from ss_api.models.otp import OTP
from ss_api.models.users.limits.admin_creation_limit import DBAdminLimits

__timeseries_models__ = [*treatment_plan.__timeseries_models__, *diet.__timeseries_models__]

__document_models__: List[DocType] = [
    *file.__document_models__,
    *users.__document_models__,
    *measures.__document_models__,
    *pai.__document_models__,
    *report.__document_models__,
    *treatment_plan.__document_models__,
    *diet.__document_models__,
    *agreement.__document_models__,
    *medical_record.__document_models__,
    *permissions.__document_models__,
    *monitoring_plan.__document_models__,
    *alarm.__document_models__,
    *booking.__document_models__,
    *chat.__document_models__,
    *index.__document_models__,
    *task.__document_models__,
    *cache.__document_models__,
    *screening.__document_models__,
    DBAdminLimits,
    OTP,
]
