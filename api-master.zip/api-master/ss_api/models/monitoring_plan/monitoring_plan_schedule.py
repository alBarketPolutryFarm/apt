from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, List, Self

from beanie.odm.operators.find.comparison import GT, LT, Eq
from pydantic import BaseModel

from ss_api.models.base.id import IdBase
from ss_api.models.measures import DBMeasureBase, Measure
from ss_api.models.measures.type import MeasureType


class MonitoringPlanScheduleEntryRaw(IdBase, BaseModel):
    measureType: MeasureType
    notes: str | None = None

    at: datetime
    notBefore: datetime
    notAfter: datetime

    def __init__(self, at: datetime, **data: Any):
        if data.get("notBefore") is None:
            data["notBefore"] = at - timedelta(minutes=30)
        if data.get("notAfter") is None:
            data["notAfter"] = at + timedelta(hours=2)

        super().__init__(**data, at=at)

    async def get_measures(self) -> List[DBMeasureBase]:
        return await DBMeasureBase.find(
            Eq(DBMeasureBase.metadata.type, self.measureType),
            GT(DBMeasureBase.timestamp, self.notBefore),
            LT(DBMeasureBase.timestamp, self.notAfter),
            with_children=True,
        ).to_list()


class MonitoringPlanScheduleEntry(MonitoringPlanScheduleEntryRaw):
    measures: List[Measure]

    @classmethod
    async def from_raw(cls, raw: MonitoringPlanScheduleEntryRaw) -> Self:
        measures = await raw.get_measures()
        return cls(**raw.model_dump(), measures=[m.model_dump() for m in measures])


MonitoringPlanSchedule = List[MonitoringPlanScheduleEntry]
