from typing import List

from ss_api.models.enum import Weekday
from ss_api.models.measures.type import MeasureType

from .monitored_measure.schedule import MonitoredMeasureSchedule


class MonitoringPlanWeekScheduleEntry(MonitoredMeasureSchedule):
    measureType: MeasureType
    weekday: Weekday


MonitoringPlanWeekSchedule = List[MonitoringPlanWeekScheduleEntry]
