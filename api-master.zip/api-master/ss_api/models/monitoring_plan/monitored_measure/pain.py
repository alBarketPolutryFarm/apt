from pydantic import BaseModel

from .base import DBMonitoredMeasureBase, MonitoredMeasureBase, NewMonitoredMeasureBase


class MonitoredPainMeasureBase(BaseModel):
    limitMax: int | None = None


class NewMonitoredPainMeasure(MonitoredPainMeasureBase, NewMonitoredMeasureBase):
    pass


class MonitoredPainMeasure(MonitoredPainMeasureBase, MonitoredMeasureBase):
    pass


class DBMonitoredPainMeasure(MonitoredPainMeasureBase, DBMonitoredMeasureBase):
    pass
