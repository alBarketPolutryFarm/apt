import itertools
from abc import ABC
from typing import List

from pydantic import BaseModel

from ss_api.models.base import IdBase, IdOptionalBase

from .schedule import (
    DBMonitoredMeasureSchedule,
    MonitoredMeasureSchedule,
    NewMonitoredMeasureSchedule,
)


class MonitoredMeasureCommonBase(BaseModel, ABC):
    notes: str | None = None

    @property
    def week_schedule(self) -> List[MonitoredMeasureSchedule]:
        return list(
            itertools.chain(
                *[
                    (
                        [MonitoredMeasureSchedule(**{**x.model_dump(), "weekday": i}) for i in range(7)]
                        if x.weekday is None
                        else [x]
                    )
                    for x in self.schedule
                ]
            )
        )


class NewMonitoredMeasureBase(MonitoredMeasureCommonBase, ABC):
    schedule: List[NewMonitoredMeasureSchedule]


class MonitoredMeasureBase(IdBase, MonitoredMeasureCommonBase, ABC):
    schedule: List[MonitoredMeasureSchedule]


class DBMonitoredMeasureBase(IdOptionalBase, MonitoredMeasureCommonBase, ABC):
    schedule: List[DBMonitoredMeasureSchedule]
