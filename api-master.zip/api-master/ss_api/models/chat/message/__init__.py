from .base import DBChatMessage as DBChatMessageBase
from .booking_request import (
    ChatMessageBookingRequest,
    DBChatMessageBookingRequest,
    NewChatMessageBookingRequest,
)
from .text import ChatMessageText, DBChatMessageText, NewChatMessageText
from .type import ChatMessageType

__document_models__ = [DBChatMessageBase, DBChatMessageText, DBChatMessageBookingRequest]

NewChatMessage = NewChatMessageText | NewChatMessageBookingRequest
ChatMessage = ChatMessageText | ChatMessageBookingRequest
DBChatMessage = DBChatMessageText | DBChatMessageBookingRequest
