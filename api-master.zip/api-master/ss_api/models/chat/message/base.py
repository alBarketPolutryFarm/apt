import asyncio
from abc import ABC
from datetime import UTC, datetime, timedelta
from typing import Any, Dict, Optional, Self, Type

from beanie import Document, PydanticObjectId
from beanie.odm.documents import DocType
from beanie.odm.queries.find import FindMany
from fastapi import BackgroundTasks
from pydantic import BaseModel, computed_field, model_validator
from pymongo import ASCENDING, DESCENDING, IndexModel
from pymongo.client_session import ClientSession

from ss_api.models.base.creation import CreationBase
from ss_api.models.base.id import IdBase
from ss_api.models.users import DBUserBase
from ss_api.templates import jinja_env
from ss_api.utils.communications.mail import send_mail_async

from ..chat import DBChat, DBChatBase
from ..chat.type import ChatType
from .type import ChatMessageType


class ChatMessageBase(BaseModel, ABC):
    __message_type__: ChatMessageType


class NewChatMessage(ChatMessageBase, ABC):
    __db_model__: DocType

    type: ChatMessageType

    @model_validator(mode="before")
    @classmethod
    def set_type(cls, v: Any):
        return {"type": cls.__message_type__, **v}


class ChatMessage(IdBase, CreationBase, ChatMessageBase, ABC):
    type: ChatMessageType
    chatId: PydanticObjectId


class DBChatMessage(Document, CreationBase, ChatMessageBase, ABC):
    chatId: PydanticObjectId

    async def get_chat(self) -> DBChat:
        return await DBChatBase.get(self.chatId, with_children=True)

    @computed_field  # type: ignore[misc]
    @property
    def type(self) -> ChatMessageType:
        return self.__message_type__

    class Settings:
        name = "chat_messages"
        is_root = True
        indexes = [IndexModel("chatId")]

    def dict(self, /, **kwargs) -> Dict[str, Any]:
        return {"type": self.__message_type__, **super().model_dump(**kwargs)}

    @classmethod
    def find_query(
        cls: Type[DocType],
        chat: DBChat | None = None,
        by: DBUserBase | None = None,
        id: PydanticObjectId | None = None,
        order: Optional[DESCENDING | ASCENDING] = None,
    ) -> FindMany[DocType]:
        query = cls.find(with_children=True)

        if chat is not None:
            query = query.find(cls.chatId == chat.id)

        if by is not None:
            query = query.find(cls.createdBy == by.id)

        if id is not None:
            query = query.find({"_id": id})

        if order is not None:
            query = query.sort((cls.createdAt, order))

        return query

    async def create(
        self, session: Optional[ClientSession] | None = None, background_tasks: BackgroundTasks | None = None
    ) -> Self:
        await super().create(session)

        if background_tasks is not None:
            chat = await self.get_chat()

            if chat.type != ChatType.broadcastChat:
                for user_id in [m for m in chat.membersId if m != self.createdBy]:
                    background_tasks.add_task(self._send_notify_email, user_id=user_id)

        return self

    async def _send_notify_email(self, user_id: PydanticObjectId) -> None:
        user = await DBUserBase.get(user_id, with_children=True)

        if user is None:
            return

        if user.lastChatMessageNotification is not None and user.lastChatMessageNotification + timedelta(
            minutes=30
        ) > datetime.now(tz=UTC):
            return

        template = jinja_env.get_template("./email/new_chat_message.html")
        body = template.render(user=self)

        loop = asyncio.get_event_loop()
        loop.create_task(
            send_mail_async(
                subject="Servizio Salute | Nuovo messaggio in chat",
                body=body,
                email=user.email,
            )
        )
        user.lastChatMessageNotification = datetime.now(tz=UTC)
        await user.save()
