from datetime import datetime
from typing import Literal

from .base import ChatMessage, ChatMessageBase, DBChatMessage, NewChatMessage
from .type import ChatMessageType


class ChatMessageBookingRequestBase(ChatMessageBase):
    __message_type__ = ChatMessageType.booking_request

    at: datetime
    description: str


class ChatMessageBookingRequest(ChatMessage, ChatMessageBookingRequestBase):
    type: Literal[ChatMessageType.booking_request]


class DBChatMessageBookingRequest(DBChatMessage, ChatMessageBookingRequestBase):
    pass


class NewChatMessageBookingRequest(NewChatMessage, ChatMessageBookingRequestBase):
    __db_model__ = DBChatMessageBookingRequest

    type: Literal[ChatMessageType.booking_request]
