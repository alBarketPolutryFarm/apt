from . import chat, message
from .chat import (
    Chat,
    DBChat,
    DBChatBase,
    DBServiceChat,
    DBUsersChat,
    ServiceChat,
    UsersChat,
)
from .message import ChatMessage, DBChatMessage, DBChatMessageBase, NewChatMessage

__document_models__ = [*chat.__document_models__, *message.__document_models__]
