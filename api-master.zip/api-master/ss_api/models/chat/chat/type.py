from enum import StrEnum


class ChatType(StrEnum):
    usersChat = "usersChat"
    serviceChat = "serviceChat"
    broadcastChat = "broadcastChat"
    operatorChat = "operatorChat"
    adminChat = "adminChat"
