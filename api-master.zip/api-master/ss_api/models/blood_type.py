from enum import Enum


class BloodType(str, Enum):
    _0P = "0+"
    _0N = "0-"
    _AP = "A+"
    _AN = "A-"
    _BP = "B+"
    _BN = "B-"
    _ABP = "AB+"
    _ABN = "AB-"
