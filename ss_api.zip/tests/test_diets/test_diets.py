import pytest
from beanie import PydanticObjectId
from httpx import AsyncClient
from starlette import status

from ss_api.models.diet import NewDiet
from ss_api.models.diet.diet_day import NewDietDay
from ss_api.models.diet.diet_meal import NewDietMeal
from ss_api.models.diet.diet_schedule import NewDietSchedule
from ss_api.models.enum import Weekday
from ss_api.models.report import ExternalReport, NewExternalReport

pytestmark = pytest.mark.asyncio


@pytest.fixture(scope="module")
def new_diet1():
    new_diet_day = NewDietDay(**{f"{p}": NewDietMeal(description="test") for p in NewDietDay.model_fields.keys()})
    return NewDiet(
        reportId=PydanticObjectId(),
        diet=NewDietSchedule(**{f"{w}": new_diet_day.model_copy() for w in Weekday.__members__.keys()}),
    )


async def test_set_diet_by_nurse(client: AsyncClient, patient1, auth_nurse1, upload_pdf_file, new_diet1):
    response = await client.post("/files", headers=auth_nurse1, files=upload_pdf_file)
    assert response.status_code == status.HTTP_201_CREATED, response.json()
    file_id = response.json()["_id"]

    response = await client.post(
        f"/patients/{patient1.id}/reports",
        headers=auth_nurse1,
        json=NewExternalReport(description="test report", file=file_id).model_dump(mode="json"),
    )
    assert response.status_code == status.HTTP_201_CREATED, response.json()

    response = await client.get(f"/patients/{patient1.id}/reports", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK, response.json()
    assert len(response.json()) > 0
    report = ExternalReport(**response.json()[0])

    response = await client.post(
        f"/patients/{patient1.id}/diets",
        headers=auth_nurse1,
        json=new_diet1.model_copy(update={"reportId": report.id}).model_dump(mode="json"),
    )
    assert response.status_code == status.HTTP_201_CREATED, response.json()

    # TODO: add some check on the inserted diet
