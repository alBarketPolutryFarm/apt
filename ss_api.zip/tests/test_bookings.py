from datetime import datetime, timedelta

import pytest
import pytest_asyncio
from httpx import AsyncClient
from starlette import status

from ss_api.models.booking import DBBooking, NewBooking

pytestmark = pytest.mark.asyncio


@pytest.fixture(scope="module")
def booking1(nurse1, patient1):
    return NewBooking(
        description="test1", at=datetime.now() + timedelta(days=1), providerId=nurse1.id, targetId=patient1.id
    )


@pytest.fixture(scope="module")
def booking2(nurse1, patient1):
    return DBBooking(
        id="b123".rjust(24, "0"),
        targetId=patient1.id,
        description="test2",
        providerId=nurse1.id,
        at=datetime.now() + timedelta(days=2),
        createdBy=nurse1.id,
        isRemote=True,
    )


@pytest_asyncio.fixture(scope="module", autouse=True)
async def init_db_booking2(booking2):
    await DBBooking(**booking2.model_dump()).create()


async def test_create_booking(
    client: AsyncClient, auth_admin, auth_nurse1, auth_patient1, auth_nurse2, patient1, booking1
):
    response = await client.get(f"/patients/{patient1.id}/bookings", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK
    nurse_bookings_count = len(response.json())

    response = await client.get("/bookings", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    patient_bookings_count = len(response.json())

    response = await client.post("/bookings", headers=auth_admin, json=booking1.model_dump(mode="json"))
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get(f"/patients/{patient1.id}/bookings", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == nurse_bookings_count + 1

    response = await client.get("/bookings", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == patient_bookings_count + 1

    response = await client.get(f"/patients/{patient1.id}/bookings", headers=auth_nurse2)
    assert response.status_code == status.HTTP_404_NOT_FOUND


async def test_get_booking(client: AsyncClient, auth_patient1, auth_nurse1, auth_nurse2, auth_admin, booking2):
    response = await client.get(f"/bookings/{booking2.id}", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK, response.json()

    response = await client.get(f"/bookings/{booking2.id}", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/patients/{booking2.targetId}/bookings/{booking2.id}", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/patients/{booking2.targetId}/bookings/{booking2.id}", headers=auth_nurse2)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    response = await client.get(f"/bookings/{booking2.id}", headers=auth_nurse2)
    assert response.status_code == status.HTTP_404_NOT_FOUND


async def test_delete_booking(client: AsyncClient, auth_nurse1, auth_admin, booking2):
    response = await client.get(f"/patients/{booking2.targetId}/bookings/{booking2.id}", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK

    response = await client.delete(f"/bookings/{booking2.id}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/patients/{booking2.targetId}/bookings/{booking2.id}", headers=auth_nurse1)
    assert response.status_code == status.HTTP_404_NOT_FOUND
