import pytest
from beanie.odm.operators.find.comparison import Eq
from httpx import AsyncClient
from starlette import status

from ss_api.models.permissions.permissions import NewPermission, RevokePermission
from ss_api.models.users.nurse import DBNurse, NewNurse
from tests.fixtures import make_random_user_data

pytestmark = pytest.mark.asyncio


@pytest.fixture(scope="module")
def new_nurse():
    return NewNurse(**make_random_user_data())


async def test_nurses(client: AsyncClient, auth_admin, auth_patient1, patient1, nurses, new_nurse, make_auth):
    response = await client.get("/nurses", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    patient_nurses_count = len(response.json())
    assert 1 <= patient_nurses_count < len(nurses)

    response = await client.get("/nurses", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    admin_nurses_count = len(response.json())
    assert admin_nurses_count >= len(nurses)

    response = await client.post("/nurses", headers=auth_admin, json=new_nurse.model_dump(mode="json"))
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get("/nurses", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert patient_nurses_count == len(response.json())

    response = await client.get("/nurses", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    assert admin_nurses_count + 1 == len(response.json())
    admin_nurses_count = len(response.json())

    nurse_db = await DBNurse.find(Eq("email", new_nurse.email)).first_or_none()
    assert nurse_db is not None
    auth_new_nurse = make_auth(nurse_db)

    response = await client.get(f"/nurses/{nurse_db.id}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/nurses/{nurse_db.id}", headers=auth_patient1)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    response = await client.get("/patients", headers=auth_new_nurse)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 0

    response = await client.get(f"/patients/{patient1.id}", headers=auth_new_nurse)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    response = await client.post(
        f"/patients/{patient1.id}/permissions",
        headers=auth_admin,
        json=NewPermission(targetId=nurse_db.id).model_dump(mode="json"),
    )
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get(f"/nurses/{nurse_db.id}", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get("/nurses", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert patient_nurses_count + 1 == len(response.json())

    response = await client.get("/patients", headers=auth_new_nurse)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 1

    response = await client.get(f"/patients/{patient1.id}", headers=auth_new_nurse)
    assert response.status_code == status.HTTP_200_OK

    response = await client.request(
        "DELETE",
        f"/patients/{patient1.id}/permissions",
        headers=auth_admin,
        json=RevokePermission(targetId=nurse_db.id).model_dump(mode="json"),
    )
    assert response.status_code == status.HTTP_200_OK

    response = await client.get("/patients", headers=auth_new_nurse)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 0

    response = await client.get(f"/patients/{patient1.id}", headers=auth_new_nurse)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    response = await client.get(f"/nurses/{nurse_db.id}", headers=auth_patient1)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    response = await client.get("/nurses", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert patient_nurses_count == len(response.json())
