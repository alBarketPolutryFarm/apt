import pytest
import pytest_asyncio
from httpx import AsyncClient
from starlette import status

from ss_api.models.permissions.permissions import NewPermission
from ss_api.models.users import NewPatient
from ss_api.models.users.doctor import DBDoctor, NewDoctor
from tests.fixtures import make_random_user_data

pytestmark = pytest.mark.asyncio


@pytest.fixture(scope="module")
def doctor():
    return NewDoctor(**{**make_random_user_data(), "firstName": "doctor", "lastName": "auto test"})


@pytest.fixture(scope="module")
def doctor_patient():
    return NewPatient(**make_random_user_data())


async def test_create_doctor(client: AsyncClient, auth_patient1, auth_nurse1, auth_admin, doctor, patient1):
    response = await client.get("/doctors", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    doctors_count = len(response.json())
    doctors_ids = list(map(lambda d: d["_id"], response.json()))

    response = await client.get("/doctors", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    patient_doctors_count = len(response.json())

    response = await client.post("/doctors", headers=auth_admin, json=doctor.model_dump(mode="json", exclude_none=True))
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get("/doctors", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    assert doctors_count + 1 == len(response.json())

    doctor_id_filtered = list(filter(lambda id: id not in doctors_ids, map(lambda d: d["_id"], response.json())))
    assert len(doctor_id_filtered) == 1
    doctor_id = doctor_id_filtered[0]

    response = await client.get("/doctors", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK
    assert patient_doctors_count == len(response.json())

    response = await client.get(f"/doctors/{doctor_id}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/doctors/{doctor_id}", headers=auth_patient1)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    response = await client.get(f"/doctors/{doctor_id}", headers=auth_nurse1)
    assert response.status_code == status.HTTP_404_NOT_FOUND

    response = await client.post(
        f"/patients/{patient1.id}/permissions",
        headers=auth_admin,
        json=NewPermission(targetId=doctor_id).model_dump(mode="json"),
    )
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get(f"/doctors/{doctor_id}", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK


async def test_doctor_create_patient(client: AsyncClient, auth_doctor2, doctor_patient):
    response = await client.get("/patients", headers=auth_doctor2)
    assert response.status_code == status.HTTP_200_OK
    patient_count = len(response.json())

    response = await client.post(
        "/patients", headers=auth_doctor2, json=doctor_patient.model_dump(mode="json", exclude_none=True)
    )
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get("/patients", headers=auth_doctor2)
    assert response.status_code == status.HTTP_200_OK
    assert patient_count + 1 == len(response.json())


@pytest.fixture(scope="module")
def patient_limited():
    return NewPatient(**make_random_user_data())


@pytest.fixture(scope="module")
def doctor_limited(admin):
    return DBDoctor(
        id="d42".rjust(24, "0"),
        **NewDoctor(**make_random_user_data()).model_dump(),
        createdBy=admin.id,
    )


@pytest.fixture(scope="module")
def auth_doctor_limited(doctor_limited, make_auth):
    return make_auth(doctor_limited)


@pytest_asyncio.fixture(scope="module", autouse=True)
async def create_doctor(create_document, doctor_limited):
    await create_document(doctor_limited)


async def test_doctor_create_patient_limited(
    client: AsyncClient, auth_doctor_limited, auth_admin, doctor_patient, doctor_limited, patient_limited
):
    response = await client.get("/patients", headers=auth_doctor_limited)
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/doctors/{doctor_limited.id}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK

    response = await client.patch(
        f"/doctors/{doctor_limited.id}",
        headers=auth_admin,
        json=[{"op": "replace", "path": "/patientCreationLimit/available", "value": 0}],
    )
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/doctors/{doctor_limited.id}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["patientCreationLimit"]["available"] == 0

    response = await client.post(
        "/patients", headers=auth_doctor_limited, json=patient_limited.model_dump(mode="json", exclude_none=True)
    )
    assert response.status_code == status.HTTP_429_TOO_MANY_REQUESTS

    response = await client.patch(
        f"/doctors/{doctor_limited.id}",
        headers=auth_admin,
        json=[{"op": "replace", "path": "/patientCreationLimit/available", "value": 5}],
    )
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/doctors/{doctor_limited.id}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["patientCreationLimit"]["available"] == 5

    response = await client.post(
        "/patients", headers=auth_doctor_limited, json=patient_limited.model_dump(mode="json", exclude_none=True)
    )
    assert response.status_code == status.HTTP_201_CREATED
