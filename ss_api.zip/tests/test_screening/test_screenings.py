from datetime import datetime, timedelta

import pytest
from httpx import AsyncClient
from starlette import status

from ss_api.models.screening import NewScreening

pytestmark = pytest.mark.asyncio


async def test_screening(client: AsyncClient, auth_nurse1, auth_admin, auth_patient1):
    new_screening1 = NewScreening(
        title="Title Screening1",
        description="Description Screening1",
        body="<h1>Tes</h1><h4>test2</h4>",
        startAt=datetime.now(),
        endAt=datetime.now() + timedelta(days=30),
    )

    response = await client.post("/screenings", headers=auth_admin, json=new_screening1.model_dump(mode="json"))
    assert response.status_code == status.HTTP_201_CREATED

    response = await client.get("/screenings", headers=auth_nurse1)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 1

    _id = response.json()[0]["_id"]

    response = await client.get(f"/screenings/{_id}", headers=auth_patient1)
    assert response.status_code == status.HTTP_200_OK

    response = await client.patch(
        f"/screenings/{_id}",
        headers=auth_admin,
        json=[{"op": "replace", "path": "/title", "value": "Titolo2"}],
    )
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/screenings/{_id}", headers=auth_patient1)
    assert response.json()["title"] == "Titolo2"

    response = await client.patch(
        f"/screenings/{_id}",
        headers=auth_nurse1,
        json=[{"op": "replace", "path": "/title", "value": "Titolo3"}],
    )
    assert response.status_code == status.HTTP_403_FORBIDDEN

    response = await client.patch(
        f"/screenings/{_id}",
        headers=auth_admin,
        json=[
            {
                "op": "replace",
                "path": "/body",
                "value": '<h1>Tes</h1><script>document.getElementById("demo").innerHTML = "Hello '
                'JavaScript!"</script><h4>test2</h4>',
            }
        ],
    )
    assert response.status_code == status.HTTP_200_OK

    response = await client.get(f"/screenings/{_id}", headers=auth_patient1)
    assert response.json()["body"] == "<h1>Tes</h1><h4>test2</h4>"

    response = await client.delete(f"/screenings/{_id}", headers=auth_admin)
    assert response.status_code == status.HTTP_200_OK
