from typing import AsyncGenerator

import pytest_asyncio
from asgi_lifespan import LifespanManager
from fastapi import FastAPI
from httpx import AsyncClient


@pytest_asyncio.fixture(scope="session")
async def client(app: FastAPI) -> AsyncGenerator:
    async with LifespanManager(app, startup_timeout=100):
        async with AsyncClient(app=app, base_url="http://test") as client:
            yield client
