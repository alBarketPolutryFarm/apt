import pytest

from ss_api.utils.settings import get_settings


@pytest.fixture
def pdf_file():
    return b"0"


@pytest.fixture
def upload_pdf_file(pdf_file):
    return {"file": ("report.pdf", pdf_file, "application/pdf")}


@pytest.fixture
def settings():
    return get_settings()
