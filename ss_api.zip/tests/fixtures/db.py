from functools import reduce

import pytest_asyncio
from beanie.odm.documents import DocType
from pymongo.errors import DuplicateKeyError

from ss_api.models import __document_models__
from ss_api.utils.db.init_db import init_db_connection as _init_db_connection


@pytest_asyncio.fixture(scope="session", autouse=True)
async def init_db_connection():
    await _init_db_connection(clean_start=False)


@pytest_asyncio.fixture(scope="session")
def create_document():
    async def _create_document(*document: DocType):
        for d in document:
            try:
                await d.create()
            except DuplicateKeyError:
                pass

    return _create_document


@pytest_asyncio.fixture(scope="session", autouse=True)
async def init_db(
    init_db_connection,
    create_document,
    patient1,
    patient2,
    patient3,
    nurse1,
    nurse2,
    nurse3,
    doctor1,
    doctor2,
    admin,
    permissions,
):
    unique_documents = reduce(lambda t, d: {f"{d.get_collection_name()}": d, **t}, __document_models__, dict()).values()

    for d in unique_documents:
        c = d.get_motor_collection()
        if "timeseries" in d.Settings.__dict__:
            await c.drop()
        else:
            await c.delete_many({})

    await _init_db_connection(clean_start=False)

    await create_document(
        admin,
        nurse1,
        nurse2,
        nurse3,
        doctor1,
        doctor2,
        patient1,
        patient2,
        patient3,
    )

    await create_document(*permissions)
