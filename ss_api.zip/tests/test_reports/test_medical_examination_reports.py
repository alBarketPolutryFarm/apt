from datetime import date, timedelta
from random import randint

import pytest

pytestmark = pytest.mark.asyncio


@pytest.fixture(scope="module")
def random_date():
    return date.today() - timedelta(days=randint(0, int(1e4)))


@pytest.fixture()
def new_medical_examination_report_full(new_medical_examination_report_factory):
    report = new_medical_examination_report_factory.build()
    while report.diet is None or report.treatmentPlan is None or report.monitoringPlan is None:
        report_update = new_medical_examination_report_factory.build()
        if report.diet is None:
            report.diet = report_update.diet
        if report.treatmentPlan is None:
            report.treatmentPlan = report_update.treatmentPlan
        if report.monitoringPlan is None:
            report.monitoringPlan = report_update.monitoringPlan
    return report


# async def test_render_medical_examination_report(patient1, doctor1, new_medical_examination_report_factory, settings):
#     if settings.pdf_turtle is None:
#         pytest.skip("pdf_turtle is not configured")

#     for _ in range(10):
#         new_medical_examination_report = new_medical_examination_report_factory.build()
#         report_db = DBMedicalExaminationReport(
#             **new_medical_examination_report.model_dump(), patientId=patient1.id, createdBy=doctor1.id
#         )
#         await report_db.generate_pdf()


# async def test_create_medical_examination_report(
#     client: AsyncClient,
#     patient1,
#     doctor1,
#     auth_doctor1,
#     new_medical_examination_report_full,
#     auth_patient1,
#     auth_nurse1,
#     auth_doctor2,
#     auth_admin,
# ):
#     response = await client.patch(
#         f"/doctors/{doctor1.id}",
#         headers=auth_admin,
#         json=[{"op": "replace", "path": "/signatureLimit/available", "value": 100}],
#     )
#     assert response.status_code == status.HTTP_200_OK

#     response = await client.post(
#         f"/patients/{patient1.id}/reports",
#         headers=auth_doctor1,
#         json=new_medical_examination_report_full.model_dump(mode="json"),
#     )
#     assert response.status_code == status.HTTP_201_CREATED, response.json()

#     report_id = response.json()["resourceId"]

#     response = await client.get(f"/patients/{patient1.id}/reports/{report_id}", headers=auth_doctor1)
#     assert response.status_code == status.HTTP_200_OK, response.json()

#     report = MedicalExaminationReport(**response.json())

#     # none except the creator (and admin) can see the report until is signed
#     response = await client.get(f"/reports/{report.id}", headers=auth_patient1)
#     assert response.status_code == status.HTTP_404_NOT_FOUND, response.json()
#     response = await client.get(f"/patients/{patient1.id}/reports/{report.id}", headers=auth_nurse1)
#     assert response.status_code == status.HTTP_404_NOT_FOUND, response.json()
#     response = await client.get(f"/patients/{patient1.id}/reports/{report.id}", headers=auth_doctor2)
#     assert response.status_code == status.HTTP_404_NOT_FOUND, response.json()
#     response = await client.get(f"/patients/{patient1.id}/reports/{report.id}", headers=auth_admin)
#     assert response.status_code == status.HTTP_200_OK, response.json()

#     response = await client.post(f"/patients/{patient1.id}/reports/{report.id}/signature", headers=auth_doctor2)
#     assert response.status_code == status.HTTP_404_NOT_FOUND, response.json()
#     response = await client.post(f"/patients/{patient1.id}/reports/{report.id}/signature", headers=auth_doctor1)
#     assert response.status_code == status.HTTP_200_OK, response.json()

#     response = await client.get(f"/patients/{patient1.id}/reports/{report.id}", headers=auth_doctor1)
#     assert response.status_code == status.HTTP_200_OK, response.json()
#     report = MedicalExaminationReport(**response.json())
#     assert report.signature is not None, response.json()

#     # report_db = await DBMedicalExaminationReport.get(report.id)
#     # report_db.signature.status = SignatureStatus.completed
#     # await report_db.save()

#     response = await client.get(f"/patients/{patient1.id}/reports/{report.id}", headers=auth_doctor1)
#     assert response.status_code == status.HTTP_200_OK, response.json()
#     assert response.json()["signature"]["status"] == SignatureStatus.completed
#     response = await client.get(f"/reports/{report.id}", headers=auth_patient1)
#     assert response.status_code == status.HTTP_200_OK, response.json()
#     response = await client.get(f"/patients/{patient1.id}/reports/{report.id}", headers=auth_nurse1)
#     assert response.status_code == status.HTTP_200_OK, response.json()
#     response = await client.get(f"/patients/{patient1.id}/reports/{report.id}", headers=auth_doctor2)
#     assert response.status_code == status.HTTP_404_NOT_FOUND, response.json()
#     response = await client.get(f"/patients/{patient1.id}/reports/{report.id}", headers=auth_admin)
#     assert response.status_code == status.HTTP_200_OK, response.json()
