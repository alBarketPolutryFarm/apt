# Servizio Salute API

This project exposes the backend API for Servizio Salute website and APP.
This project use [FastAPI](https://fastapi.tiangolo.com/).

## OpenAPI specification

When the app is running (in debug mode `API_DEBUG=true`) you can see the OAS at the address `/`.

## Configuration

For the configuration the app use [`SettingBase`](https://pydantic-docs.helpmanual.io/usage/settings/) approach provided by `Pydantic`.
All the settings in [`/api/utils/settings.py`](/ss_api/utils/settings.py) can be overwritten with `env`.

Commands to run The Projects

pip3 install poetry
poetry build --format wheel
poetry install
rm -rf dist
poetry run pre-commit run -a
poetry run pytest #For PYTEST
docker run -p 8000:8000 --name pdf-turtle --rm -d lucasgaitzsch/pdf-turtle
python3 -m ss_api
