from typing import Any

from beanie import PydanticObjectId
from pydantic import BaseModel


class Success(BaseModel):
    message: str

    def __init__(self, message: str = "Success", **data: Any):
        super().__init__(message=message, **data)


class Created(Success):
    resourceId: PydanticObjectId

    def __init__(self, resourceId: PydanticObjectId, message: str = "Created", **data: Any):
        super().__init__(resourceId=resourceId, message=message, **data)
