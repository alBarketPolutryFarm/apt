from typing import Annotated, TypeVar

from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from fastapi import Depends, Query
from pydantic import BaseModel

T = TypeVar("T", FindMany, AggregationQuery)


class PaginationData(BaseModel):
    limit: int | None = None
    offset: int = 0

    def __call__(self, query: T) -> T:
        if isinstance(query, AggregationQuery):
            query.aggregation_pipeline.append({"$skip": self.offset})
            if self.limit is not None:
                query.aggregation_pipeline.append({"$limit": self.limit})

        else:
            query = query.skip(self.offset)
            if self.limit is not None:
                query = query.limit(self.limit)

        return query


class QueryInfo(BaseModel):
    count: int


class Pagination:
    def __call__(self, limit: int | None = None, offset: int = Query(0, ge=0)) -> PaginationData:
        return PaginationData(limit=limit, offset=offset)


def query_pagination() -> PaginationData:
    return Depends(Pagination())


QueryPagination = Annotated[PaginationData, Depends(Pagination())]


def apply_pagination(query: T, pagination: PaginationData) -> T:
    if isinstance(query, AggregationQuery):
        query.aggregation_pipeline.append({"$skip": pagination.offset})
        if pagination.limit is not None:
            query.aggregation_pipeline.append({"$limit": pagination.limit})

    else:
        query = query.skip(pagination.offset)
        if pagination.limit is not None:
            query = query.limit(pagination.limit)

    return query
