from abc import ABC
from datetime import datetime
from typing import Callable

from beanie.odm.queries.aggregation import AggregationQuery
from fastapi import Depends, Query
from pydantic import BaseModel

from ss_api.models.utils.db import DBQuery


class DateRangeData(BaseModel):
    start: datetime | None = None
    end: datetime | None = None


class DateRange:
    def __init__(
        self,
        default_factory_start_date: Callable[[], datetime] | None = None,
        default_factory_end_date: Callable[[], datetime] | None = None,
    ):
        self.default_factory_start_date = default_factory_start_date
        self.default_factory_end_date = default_factory_end_date

    def __call__(
        self,
        start_date: datetime | None = Query(default=None, alias="startDate"),
        end_date: datetime | None = Query(default=None, alias="endDate"),
    ) -> DateRangeData:
        return DateRangeData(
            start=(
                self.default_factory_start_date()
                if start_date is None and self.default_factory_start_date is not None
                else start_date
            ),
            end=(
                self.default_factory_end_date()
                if end_date is None and self.default_factory_end_date is not None
                else end_date
            ),
        )


def query_date_range(**kwargs) -> DateRangeData:
    return Depends(DateRange(**kwargs))


class FilterableByDataRange(ABC):
    @staticmethod
    def __filter_by_data_range__(query: DBQuery, date_range: DateRangeData) -> DBQuery:
        raise NotImplementedError


def filter_by_date_range(query: DBQuery, date_range: DateRangeData) -> DBQuery:
    model = query.projection_model or query.document_model

    if issubclass(model, FilterableByDataRange):
        return model.__filter_by_data_range__(query, date_range)

    for field in ["at", "date", "timestamp"]:
        if hasattr(model, field):
            if isinstance(query, AggregationQuery):
                if date_range.start is not None:
                    query.aggregation_pipeline.append({"$match": {field: {"$gt": date_range.start}}})
                if date_range.end is not None:
                    query.aggregation_pipeline.append({"$match": {field: {"$lt": date_range.end}}})
                return query

            else:
                if date_range.start is not None:
                    query = query.find({field: {"$gt": date_range.start}})
                if date_range.end is not None:
                    query = query.find({field: {"$lt": date_range.end}})
                return query

    raise NotImplementedError
