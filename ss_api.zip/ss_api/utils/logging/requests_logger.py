import logging
from http import HTTPStatus
from logging import getLogger
from time import time

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

from ss_api import __package__


class RequestsLoggerMiddleware(BaseHTTPMiddleware):
    def __init__(self, app):
        super().__init__(app)
        self.logger = getLogger(f"{__package__}.requests")

    async def dispatch(self, request: Request, call_next):
        url = f"{request.url.path}?{request.query_params}" if request.query_params else request.url.path
        start_time = time()
        response = await call_next(request)
        process_time = int((time() - start_time) * 1000)
        host = getattr(getattr(request, "client", None), "host", None)
        port = getattr(getattr(request, "client", None), "port", None)
        try:
            status_phrase = HTTPStatus(response.status_code).phrase
        except ValueError:
            status_phrase = ""

        extra = {
            "http_request_method": request.method,
            "http_request_url": url,
            "http_response_status": response.status_code,
            "http_response_status_phrase": status_phrase,
            "http_response_process_time": process_time,
        }

        self.logger.log(
            logging.ERROR if response.status_code >= 500 else logging.INFO,
            f'{host}:{port} - "{request.method} {url}" {response.status_code} {status_phrase} {process_time}ms',
            extra=extra,
        )
        return response
