import logging
from functools import lru_cache
from logging import Formatter as _Formatter
from logging import Logger as _Logger
from sys import stdout

from graypy import GELFTCPHandler
from termcolor import colored

from ss_api import __package__, __version__
from ss_api.utils.settings.settings import get_settings


class Formatter(_Formatter):
    _format = "%(asctime)sZ [%(levelname)s] %(name)s: %(message)s"

    @lru_cache
    def get_format(self, level: int) -> str:
        match level:
            case logging.DEBUG:
                return colored(f"{self._format} (%(filename)s:%(lineno)d)", "grey")
            case logging.INFO:
                return colored(self._format, "white")
            case logging.WARNING:
                return colored(self._format, "yellow")
            case logging.ERROR:
                return colored(self._format, "red")
            case logging.CRITICAL:
                return colored(self._format, "red", attrs=["bold"])
            case _:
                return colored(self._format, "white")

    def format(self, record) -> str:
        log_fmt = self.get_format(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


class Logger(_Logger):
    extra = {"package": __package__, "package_version": __version__}

    def __init__(self, name: str, level: int = logging.INFO) -> None:
        super().__init__(name, level)
        self.propagate = False

        console_handler = logging.StreamHandler(stream=stdout)
        console_handler.setFormatter(Formatter())
        self.addHandler(console_handler)

        settings = get_settings()
        if settings and settings.graylog:
            graylog_handler = GELFTCPHandler(settings.graylog.host, settings.graylog.port, level_names=True)

            self.addHandler(graylog_handler)

        self.extra["mode"] = settings.mode

    def _log(self, level, msg, *args, extra=None, **kwargs):
        if extra is None:
            extra = {}

        return super()._log(level, msg, *args, extra={**self.extra, **extra}, **kwargs)
