from typing import Annotated, Literal, Tuple

from fastapi import Depends, HTTPException
from fastapi.params import Depends as _Depends
from fastapi.security import APIKeyCookie, HTTPBearer
from jose import ExpiredSignatureError, JWTError

from ss_api.models.users import (
    DBAdmin,
    DBCaregiver,
    DBDoctor,
    DBNurse,
    DBOperator,
    DBPatient,
    DBSuperAdmin,
    DBUser,
    DBUserBase,
)
from ss_api.utils.typing import JWT

bearerAuth = HTTPBearer(auto_error=False, bearerFormat="JWT")
cookieAuth = APIKeyCookie(auto_error=False, name="Authorization")

UserType = Literal["admin", "nurse", "doctor", "patient", "operator", "superadmin"]


class NeedAuth(_Depends):
    required_roles: Tuple[UserType, ...] | None
    auto_error: bool = True

    def __init__(
        self,
        *required_roles: UserType,
        auto_error: bool = True,
    ):
        super().__init__(dependency=self, use_cache=True)
        self.required_roles = required_roles if len(required_roles) != 0 else None
        self.auto_error = auto_error

    async def __call__(
        self, authorization_bearer=Depends(bearerAuth), authorization_cookie=Depends(cookieAuth)
    ) -> DBUser | None:
        token_raw = authorization_bearer.credentials if authorization_bearer is not None else authorization_cookie
        if token_raw is None:
            self._raise(HTTPException(status_code=401, detail="Token not provided"))
            return None

        try:
            JWT.validate(token_raw)
            token = JWT(token_raw)

        except ExpiredSignatureError:
            self._raise(HTTPException(status_code=401, detail="Token expired"))
            return None

        except JWTError:
            self._raise(HTTPException(status_code=401, detail="Invalid token"))
            return None

        if (user := await DBUserBase.get(token.sub, with_children=True)) is None:
            self._raise(HTTPException(status_code=401, detail="Invalid authentication"))
            return None

        if self.required_roles is not None:
            if not any(map(lambda x: user.__user_type__ == x, self.required_roles)):
                self._raise(HTTPException(status_code=403, detail="Unauthorized user"))
                return None

        return user

    def _raise(self, e: Exception) -> None:
        if self.auto_error:
            raise e


AuthInternal = Annotated[
    DBSuperAdmin | DBAdmin | DBNurse | DBDoctor | DBOperator,
    NeedAuth(
        DBAdmin.__user_type__,
        DBSuperAdmin.__user_type__,
        DBNurse.__user_type__,
        DBDoctor.__user_type__,
        DBOperator.__user_type__,
    ),
]

AuthNotPatient = Annotated[
    DBAdmin | DBNurse | DBDoctor | DBOperator | DBCaregiver | DBSuperAdmin,
    NeedAuth(
        DBAdmin.__user_type__,
        DBSuperAdmin.__user_type__,
        DBNurse.__user_type__,
        DBDoctor.__user_type__,
        DBOperator.__user_type__,
        DBCaregiver.__user_type__,
    ),
]

AuthAdminDoctorNurse = Annotated[
    DBSuperAdmin,
    DBAdmin | DBNurse | DBDoctor,
    NeedAuth(DBSuperAdmin.__user_type__, DBAdmin.__user_type__, DBNurse.__user_type__, DBDoctor.__user_type__),
]

AuthAdminOperator = Annotated[
    DBSuperAdmin,
    DBAdmin | DBOperator,
    NeedAuth(DBSuperAdmin.__user_type__, DBAdmin.__user_type__, DBOperator.__user_type__),
]

AuthAdminDoctor = Annotated[
    DBAdmin | DBSuperAdmin | DBDoctor,
    NeedAuth(DBSuperAdmin.__user_type__, DBAdmin.__user_type__, DBDoctor.__user_type__),
]
AuthAdminNurse = Annotated[
    DBAdmin | DBSuperAdmin | DBNurse, NeedAuth(DBSuperAdmin.__user_type__, DBAdmin.__user_type__, DBNurse.__user_type__)
]
AuthAdminPatient = Annotated[
    DBAdmin | DBSuperAdmin | DBPatient,
    NeedAuth(DBSuperAdmin.__user_type__, DBAdmin.__user_type__, DBPatient.__user_type__),
]
AuthDoctorNurse = Annotated[DBDoctor | DBNurse, NeedAuth(DBDoctor.__user_type__, DBNurse.__user_type__)]

AuthAdmin = Annotated[DBAdmin, DBSuperAdmin, NeedAuth(DBAdmin.__user_type__, DBSuperAdmin.__user_type__)]
AuthSuperAdmin = Annotated[DBSuperAdmin, NeedAuth(DBSuperAdmin.__user_type__)]

AuthNurse = Annotated[DBNurse, NeedAuth(DBNurse.__user_type__)]
AuthDoctor = Annotated[DBDoctor, NeedAuth(DBDoctor.__user_type__)]
AuthOperator = Annotated[DBOperator, NeedAuth(DBOperator.__user_type__)]
AuthCaregiver = Annotated[DBCaregiver, NeedAuth(DBCaregiver.__user_type__)]

AuthPatient = Annotated[DBPatient, NeedAuth(DBPatient.__user_type__)]

AuthUser = Annotated[DBUser, NeedAuth()]
AuthStaff = Annotated[
    DBUser, NeedAuth(DBOperator.__user_type__, DBNurse.__user_type__, DBDoctor.__user_type__, DBCaregiver.__user_type__)
]

AuthUserOptional = Annotated[DBUser, NeedAuth(auto_error=False)]
