import asyncio

from ss_api.models.users.base import DBUserBase
from ss_api.templates import jinja_env
from ss_api.utils.communications.mail import send_mail_async


async def _send_login_notification_email(user: DBUserBase):
    try:
        template = jinja_env.get_template("./email/login_notification.html")
        body = template.render(user=user)
        loop = asyncio.get_event_loop()
        loop.create_task(send_mail_async(subject="Servizio Salute | Notifica di accesso", body=body, email=user.email))
    except Exception as e:
        print(f"Failed to send login notification email: {e}")
