from typing import Annotated, Type, TypeVar, Union

from beanie import PydanticObjectId
from fastapi import Depends, HTTPException, Path

from ss_api.models.users import (
    DBCaregiver,
    DBDoctor,
    DBNurse,
    DBOperator,
    DBPatient,
    DBUser,
    DBUserBase,
)
from ss_api.models.users.base import UserStatus
from ss_api.utils.auth import AuthUser

T = TypeVar("T", bound=DBUserBase)


def make_query_user_path(user_model: Type[T], path: str) -> Union[T, dict]:
    async def _get_user(user_id: Annotated[PydanticObjectId, Path(alias=path)], by: AuthUser) -> Union[T, any]:
        try:
            user_result = await user_model.find_query(by=by, id=user_id).to_list()
            if by.type == "operator" and not user_result:
                query = DBOperator.find(
                    DBUserBase.status == UserStatus.ACTIVE, DBUserBase.id == user_id, with_children=True
                )
                user_result = await query.to_list()
            if not user_result:
                raise HTTPException(status_code=404, detail="User not found")
            return user_result[0]
        except Exception:
            if path == "user_id":
                data = await DBUserBase.find_one(DBUserBase.id == user_id, with_children=True)
                return {"firstName": data.firstName, "lastName": data.lastName}
            raise HTTPException(status_code=404, detail="User not found")

    return Depends(_get_user)


QueryNurse = Annotated[DBNurse, make_query_user_path(DBNurse, "nurse_id")]
QueryOperator = Annotated[DBOperator, make_query_user_path(DBOperator, "operator_id")]
QueryCaregiver = Annotated[DBCaregiver, make_query_user_path(DBCaregiver, "caregiver_id")]
QueryDoctor = Annotated[DBDoctor, make_query_user_path(DBDoctor, "doctor_id")]
QueryPatient = Annotated[DBPatient, make_query_user_path(DBPatient, "patient_id")]
QueryUser = Annotated[DBUser, make_query_user_path(DBUserBase, "user_id")]
