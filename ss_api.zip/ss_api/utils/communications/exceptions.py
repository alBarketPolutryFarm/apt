from smtplib import SMTPAuthenticationError

from ss_api.utils.exceptions.remote_service import ExternalServiceConnectError
from ss_api.utils.settings.exceptions import NotInitializedSettingsError


class SMTPServerException(Exception):
    pass


class SMTPServerNotInitializedError(SMTPServerException, NotInitializedSettingsError):
    pass


class SMTPServerConnectionError(SMTPServerException, ExternalServiceConnectError):
    pass


class SMTPServerAuthenticationError(SMTPServerException, SMTPAuthenticationError, ExternalServiceConnectError):
    pass


class SMTPServerTimeoutError(SMTPServerException, TimeoutError, ExternalServiceConnectError):
    pass
