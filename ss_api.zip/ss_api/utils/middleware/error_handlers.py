from logging import getLogger

from fastapi import FastAPI, Request
from fastapi.exception_handlers import (
    http_exception_handler,
    request_validation_exception_handler,
)
from fastapi.exceptions import HTTPException, RequestValidationError
from starlette.middleware.base import BaseHTTPMiddleware

from ss_api.utils.exceptions.remote_service import ExternalServiceConnectError
from ss_api.utils.open_api.exceptions import (
    OpenAPIException,
    OpenAPINotInitializedError,
)
from ss_api.utils.orthanc.exceptions import OrthancNotInitializedError
from ss_api.utils.settings.exceptions import NotInitializedSettingsError


def init_error_handlers(app: FastAPI):
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        return await request_validation_exception_handler(request=request, exc=exc)

    @app.exception_handler(FileNotFoundError)
    async def file_not_found_exception_handler(request: Request, exc: FileNotFoundError):
        return await http_exception_handler(
            request, HTTPException(status_code=410, detail="File is not longer available")
        )

    @app.exception_handler(OrthancNotInitializedError)
    async def orthanc_not_initialized_exception_handler(request: Request, exc: OrthancNotInitializedError):
        return await http_exception_handler(
            request, HTTPException(status_code=503, detail="Orthanc server has not been initialized")
        )

    @app.exception_handler(OpenAPINotInitializedError)
    async def open_api_not_initialized_exception_handler(request: Request, exc: OpenAPINotInitializedError):
        return await http_exception_handler(
            request,
            HTTPException(status_code=503, detail="Signing service unavailable because it has not been initialized"),
        )

    @app.exception_handler(OpenAPIException)
    async def open_api_unavailable_exception_handler(request: Request, exc: OpenAPIException):
        return await http_exception_handler(
            request,
            HTTPException(
                status_code=503, detail="External signing service temporarily unavailable because to external reasons"
            ),
        )

    @app.exception_handler(NotInitializedSettingsError)
    async def not_initialized_settings_exception_handler(request: Request, exc: NotInitializedSettingsError):
        return await http_exception_handler(
            request, HTTPException(status_code=503, detail="Service unavailable because it has not been initialized")
        )

    @app.exception_handler(ExternalServiceConnectError)
    async def external_service_connect_error_exception_handler(request: Request, exc: ExternalServiceConnectError):
        return await http_exception_handler(
            request, HTTPException(status_code=503, detail="Service unavailable due to remote connection error")
        )

    app.add_middleware(GenericExceptionHandlerMiddleware)


class GenericExceptionHandlerMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        try:
            return await call_next(request)
        except Exception as exc:
            getLogger(__package__).error(f"Unhandled exception: {exc}", exc_info=True, extra={"exception": exc})
            return await http_exception_handler(request, HTTPException(status_code=500, detail="Internal server error"))
