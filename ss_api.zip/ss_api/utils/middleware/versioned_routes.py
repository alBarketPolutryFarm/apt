from typing import Callable

from fastapi import FastAPI
from fastapi.routing import APIRoute
from fastapi.types import DecoratedCallable
from starlette.routing import compile_path


def use_versioned_routes(
    app: FastAPI,
    default_version: int | None = None,
    prefix_format: str = "/v{version}",
) -> FastAPI:
    for route in app.routes:
        if isinstance(route, APIRoute):
            if hasattr(route.endpoint, "__version__"):
                route.path = f"{prefix_format.format(version=route.endpoint.__version__)}{route.path}"
                route.path_regex, route.path_format, route.param_convertors = compile_path(route.path)
            elif default_version is not None:
                route.path = f"{prefix_format.format(version=default_version)}{route.path}"
                route.path_regex, route.path_format, route.param_convertors = compile_path(route.path)

    return app


class RouteVersion:
    def __init__(self, version: int):
        self.version = version

    def __call__(self, func: Callable) -> DecoratedCallable:
        func.__version__ = self.version  # type: ignore
        return func
