import re

from fastapi import FastAPI
from fastapi.routing import APIRoute


def use_operation_id_from_path(app: FastAPI) -> FastAPI:
    by_id_regex = re.compile(r"{[^}]*id[^{]*}")

    def compute_operation_id(route: APIRoute) -> str:
        path = by_id_regex.sub("by_id", route.path)
        operation_id = re.sub("/", "_", f"{next(iter(route.methods))}{path}")
        return operation_id

    for route in app.routes:
        if isinstance(route, APIRoute):
            route.operation_id = compute_operation_id(route)

    return app
