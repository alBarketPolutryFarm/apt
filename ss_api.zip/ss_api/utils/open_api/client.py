from httpx import AsyncClient, ReadTimeout, Response
from httpx._types import URLTypes
from starlette import status

from .exceptions import (
    OpenAPIFundsExhausted,
    OpenAPINotFound,
    OpenAPIRemoteError,
    OpenAPITimeout,
    OpenAPIUnauthorized,
)


class OpenAPIAsyncClient(AsyncClient):
    @staticmethod
    def _handle_response(response: Response) -> Response:
        if response.status_code == status.HTTP_401_UNAUTHORIZED:
            raise OpenAPIUnauthorized
        if response.status_code == status.HTTP_402_PAYMENT_REQUIRED:
            raise OpenAPIFundsExhausted
        if response.status_code == status.HTTP_404_NOT_FOUND:
            raise OpenAPINotFound
        if response.status_code == status.HTTP_200_OK:
            return response
        raise OpenAPIRemoteError

    async def post(self, url: URLTypes, **kwargs) -> Response:
        try:
            response = await super().post(url, **kwargs)
            return self._handle_response(response)
        except ReadTimeout:
            raise OpenAPITimeout

    async def get(self, url: URLTypes, **kwargs) -> Response:
        try:
            response = await super().get(url, **kwargs)
            return self._handle_response(response)
        except ReadTimeout:
            raise OpenAPITimeout
