from datetime import datetime
from enum import Enum
from typing import Dict, List

from beanie import PydanticObjectId
from pydantic import BaseModel, EmailStr, HttpUrl

from ss_api.utils.typing import PhoneNumber


class SignatureRequestCallback(BaseModel):
    field: str = "data"
    url: HttpUrl
    headers: Dict[str, str] | None = None


class SignatureRequestPosition(BaseModel):
    page: int
    position: str | None = None


class SignatureRequestMember(BaseModel):
    firstname: str
    lastname: str
    email: EmailStr
    phone: PhoneNumber
    sign_link: str

    signs: List[SignatureRequestPosition] | None = None


class NewSignatureRequestMember(BaseModel):
    firstname: str
    lastname: str
    email: EmailStr
    phone: PhoneNumber

    signs: List[SignatureRequestPosition] | None = None


class NewSignatureRequest(BaseModel):
    title: str | None = None
    description: str | None = None
    ui: str | None = None
    filename: str
    content: str

    members: List[NewSignatureRequestMember]

    callback: SignatureRequestCallback | None = None


class SignatureRequestStatus(str, Enum):
    created = "created"
    started = "started"
    finished = "finished"
    refused = "refused"
    expired = "expired"
    request_failed = "request failed"
    file_validation_failed = "file validation failed"
    error = "error"
    awaiting_members_confirmation = "awaiting members confirmation"


class SignatureRequestResponseData(BaseModel):
    id: PydanticObjectId
    filename: str
    title: str | None = None
    description: str | None = None
    status: SignatureRequestStatus
    download_link: str | None = None
    updated_at: datetime | None = None

    members: List[SignatureRequestMember]

    callback: SignatureRequestCallback | None = None


class SignatureRequestCallbackPayload(BaseModel):
    data: SignatureRequestResponseData


class SignatureRequestResponse(SignatureRequestCallbackPayload):
    success: bool
    message: str
    error: str | None = None
