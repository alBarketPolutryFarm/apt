from typing import Any, Callable, Self

from codicefiscale import codicefiscale
from pydantic import GetJsonSchemaHandler
from pydantic.json_schema import JsonSchemaValue
from pydantic_core import CoreSchema
from pydantic_core.core_schema import no_info_after_validator_function, str_schema


class FiscalCode(str):
    @classmethod
    def __get_pydantic_core_schema__(cls, source: type[Any], handler: Callable[[Any], CoreSchema]) -> CoreSchema:
        return no_info_after_validator_function(
            cls.validate,
            str_schema(),
        )

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema: CoreSchema, handler: GetJsonSchemaHandler) -> JsonSchemaValue:
        json_schema = handler(core_schema)
        json_schema.update(
            examples=["PZHGMR64D57F656S", "GCPPNC57C10L458Y"],
        )
        return json_schema

    @classmethod
    def validate(cls, v: Any) -> Self:
        if not isinstance(v, str):
            raise TypeError("string required")

        if not codicefiscale.is_valid(v):
            raise ValueError("Invalid fiscal code")

        return cls(v.upper())

    def __repr__(self):
        return f"FiscalCode({super().__repr__()})"
