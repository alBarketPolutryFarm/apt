from datetime import datetime, timedelta, timezone
from functools import cached_property
from typing import TYPE_CHECKING, Any, Callable, Self  # type: ignore

from beanie import PydanticObjectId
from jose import jwt
from pydantic import GetJsonSchemaHandler
from pydantic.json_schema import JsonSchemaValue
from pydantic_core import CoreSchema
from pydantic_core.core_schema import no_info_after_validator_function, str_schema

if TYPE_CHECKING:
    from ss_api.models.users import DBUser


class JWT(str):
    @classmethod
    def __get_pydantic_core_schema__(cls, source: type[Any], handler: Callable[[Any], CoreSchema]) -> CoreSchema:
        return no_info_after_validator_function(
            cls.validate,
            str_schema(),
        )

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema: CoreSchema, handler: GetJsonSchemaHandler) -> JsonSchemaValue:
        json_schema = handler(core_schema)
        return json_schema

    @classmethod
    def validate(cls, v: Any) -> Self:
        if not isinstance(v, str):
            raise TypeError("string required")

        from ss_api.utils.settings import get_settings

        settings = get_settings()

        jwt.decode(
            v,
            settings.secrets.jwt,
            options={"require_exp": True, "require_iat": True, "require_sub": True},
        )

        return cls(v)

    def __repr__(self):
        return f"JWT({super().__repr__()})"

    @classmethod
    def create(cls, user: "DBUser", expires_delta: timedelta = timedelta(days=7)) -> Self:
        from ss_api.utils.settings import get_settings

        settings = get_settings()
        return cls(
            jwt.encode(
                {
                    "exp": datetime.now(tz=timezone.utc) + expires_delta,
                    "iat": datetime.now(tz=timezone.utc),
                    "sub": str(user.id),
                    "type": user.__user_type__,
                },
                settings.secrets.jwt,
            )
        )

    @cached_property
    def _decoded(self):
        from ss_api.utils.settings import get_settings

        settings = get_settings()

        return jwt.decode(
            self,
            settings.secrets.jwt,
            options={"require_exp": False, "require_iat": False, "require_sub": False},
        )

    @property
    def exp(self) -> datetime:
        return datetime.fromtimestamp(self._decoded.get("exp"), tz=timezone.utc)

    @property
    def iat(self) -> datetime:
        return datetime.fromtimestamp(self._decoded.get("iat"), tz=timezone.utc)

    @property
    def sub(self) -> PydanticObjectId:
        return PydanticObjectId(self._decoded.get("sub"))
