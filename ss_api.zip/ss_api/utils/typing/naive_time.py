from datetime import time
from typing import TYPE_CHECKING, Any, Self

from pydantic import GetCoreSchemaHandler
from pydantic_core import CoreSchema
from pydantic_core.core_schema import no_info_after_validator_function, time_schema

if TYPE_CHECKING:
    NaiveTime = time

else:

    class NaiveTime(time):
        @classmethod
        def __get_pydantic_core_schema__(cls, source: type[Any], handler: GetCoreSchemaHandler) -> CoreSchema:
            return no_info_after_validator_function(cls.validate, time_schema(strict=False))

        @classmethod
        def validate(cls, value: time) -> Self:
            return value.replace(tzinfo=None)
