from __future__ import annotations

from secrets import choice
from string import ascii_letters, digits
from typing import Any, Callable, Self

from pydantic_core import CoreSchema
from pydantic_core.core_schema import no_info_after_validator_function, str_schema
from starlette.datastructures import Secret as _Secret


class Secret(_Secret, str):
    @classmethod
    def __get_pydantic_core_schema__(cls, source: type[Any], handler: Callable[[Any], CoreSchema]) -> CoreSchema:
        return no_info_after_validator_function(cls.validate, str_schema())

    @classmethod
    def validate(cls, v: str) -> Self:
        if isinstance(v, cls):
            return v

        return cls(str(v))

    @classmethod
    def random(cls, size: int = 16) -> Self:
        pool = ascii_letters + digits
        return cls("".join(choice(pool) for _ in range(size)))
