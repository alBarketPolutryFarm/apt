from typing import Any, Callable, Self

from pydantic import GetJsonSchemaHandler, TypeAdapter, ValidationError
from pydantic.json_schema import JsonSchemaValue
from pydantic_core import CoreSchema
from pydantic_core.core_schema import no_info_after_validator_function, str_schema

from ss_api.utils.typing.secret import Secret


class Password(Secret):
    MIN_LENGHT = 12

    @classmethod
    def __get_pydantic_core_schema__(cls, source: type[Any], handler: Callable[[Any], CoreSchema]) -> CoreSchema:
        return no_info_after_validator_function(
            cls.validate,
            str_schema(
                min_length=Password.MIN_LENGHT, pattern=r"(?=.*[a-z])(?=.*[A-Z])(?=.*\d)", regex_engine="python-re"
            ),
        )

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema: CoreSchema, handler: GetJsonSchemaHandler) -> JsonSchemaValue:
        json_schema = handler(core_schema)
        json_schema.update(
            description=f"""Password must be at least {cls.MIN_LENGHT} chars,
                           it must contain at least one uppercase char,
                           one lowercase char and one digit""",
            examples=["k2NDPeK4ZKiFjJx6", "U2zUb4FG7fEqWtDz"],
        )
        return json_schema

    @classmethod
    def random(cls, size: int = 16) -> Self:
        if size < Password.MIN_LENGHT:
            raise ValidationError(f"Password must be at least {cls.MIN_LENGHT} characters")

        type_adapter = TypeAdapter(cls)
        while True:
            try:
                return type_adapter.validate_python(super().random(size))
            except ValidationError:
                pass
