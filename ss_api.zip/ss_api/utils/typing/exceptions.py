from pydantic.v1 import PydanticValueError


class DateInTheFutureError(PydanticValueError):
    code = "date.in_the_future"
    msg_template = "date is in the future"
