from .orthanc import Orthanc, get_orthanc
