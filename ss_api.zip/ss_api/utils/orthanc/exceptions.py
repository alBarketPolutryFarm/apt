from ss_api.utils.settings.exceptions import NotInitializedSettingsError


class OrthancException(Exception):
    pass


class OrthancConnectionError(OrthancException):
    pass


class OrthancNotInitializedError(OrthancException, NotInitializedSettingsError):
    pass
