from typing import Annotated

from fastapi import Depends, Header


def header_accept(accept: str | None = Header(None, include_in_schema=False, alias="accept")) -> str | None:
    return accept


HeaderAccept = Annotated[str | None, Depends(header_accept)]
