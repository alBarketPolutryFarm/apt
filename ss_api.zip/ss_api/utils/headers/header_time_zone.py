from typing import Annotated

import pytz
from fastapi import Depends, Header
from pytz.exceptions import UnknownTimeZoneError


def header_timezone(tz: str = Header("UTC", alias="TimeZone")) -> pytz.BaseTzInfo:
    try:
        return pytz.timezone(tz)
    except UnknownTimeZoneError:
        return pytz.timezone("UTC")


HeaderTimeZone = Annotated[pytz.BaseTzInfo, Depends(header_timezone)]
