from beanie.odm.documents import DocType
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany


async def query_count(query: FindMany[DocType] | AggregationQuery[DocType]) -> int:
    if isinstance(query, AggregationQuery):
        query.aggregation_pipeline.append({"$count": "count"})
        query.projection_model = None
        result = await query.to_list()
        return result[0]["count"] if len(result) != 0 else 0

    return await query.count()
