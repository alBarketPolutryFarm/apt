from typing import TypeVar

from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from pymongo import ASCENDING, DESCENDING

DBQuery = TypeVar("DBQuery", FindMany, AggregationQuery)


def query_sort(query: DBQuery, field: str, direction: DESCENDING | ASCENDING = DESCENDING) -> DBQuery:
    if isinstance(query, AggregationQuery):
        query.aggregation_pipeline.append({"$sort": {f"{field}": direction}})
        return query

    return query.sort((field, direction))
