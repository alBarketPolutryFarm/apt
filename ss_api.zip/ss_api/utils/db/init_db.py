from beanie import init_beanie
from bson import DEFAULT_CODEC_OPTIONS
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.errors import DuplicateKeyError, OperationFailure

from ss_api.models import __document_models__, __timeseries_models__
from ss_api.models.chat.chat import DBBroadcastChat
from ss_api.models.users import DBSuperAdmin
from ss_api.utils.settings import get_settings


async def drop_fiscal_code_1_index():
    """Drops the index named 'fiscalCode_1' from the 'users' collection. For Deployed Variants Only"""
    settings = get_settings()
    client = AsyncIOMotorClient(settings.mongo_uri)
    database = client.get_default_database()
    users_collection = database["users"]

    try:
        await users_collection.drop_index("fiscalCode_1")
        print("Index 'fiscalCode_1' dropped successfully from 'users' collection.")
    except Exception as e:
        print(f"Error dropping index: {e}")


async def init_db_connection(clean_start: bool = False):
    settings = get_settings()

    client = AsyncIOMotorClient(settings.mongo_uri)

    try:
        await drop_fiscal_code_1_index()
    except Exception as e:
        print(f"Error dropping index: {e}")

    database = client.get_default_database(codec_options=DEFAULT_CODEC_OPTIONS.with_options(tz_aware=True))

    if clean_start:
        for c in await database.list_collection_names():
            try:
                await database.drop_collection(c)
            except OperationFailure:
                pass

    # Double initialization is required due to a race condition issue
    # on initialization of timeseries with multiple models(UnionDoc)
    # With a single initialization we can not assume that
    # timeseries will be created instead of a regular collection
    # With this approach we first initialize the timeseries than all the models
    await init_beanie(database=database, document_models=__timeseries_models__)
    await init_beanie(database=database, document_models=[*__timeseries_models__, *__document_models__])


async def create_first_super_admin(email: str, password: str) -> bool:
    try:
        await DBSuperAdmin(
            firstName="super",
            lastName="admin",
            fiscalCode="SPRDNA84R14A460L",
            email=email,
            newPassword=password,
        ).create(fiscalCodeCheck=False)
    except DuplicateKeyError:
        return False
    return True


async def check_and_create_first_super_admin(email: str, password: str) -> bool:
    # if await DBSuperAdmin.count() == 0:
    #     print("> Creating first super admin")
    try:
        await create_first_super_admin(email=email, password=password)
        return True
    except Exception as e:
        print(e)
    return False


async def create_broadcast_chat() -> bool:
    if await DBBroadcastChat.count() == 0:
        await DBBroadcastChat().create()
        return True
    return False
