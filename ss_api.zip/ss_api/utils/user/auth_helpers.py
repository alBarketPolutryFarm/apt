from fastapi import Depends, HTTPException, status

from ss_api.models.users.base import DBUserBase
from ss_api.models.users.limits.admin_creation_limit import DBAdminLimits
from ss_api.utils.auth.auth import AuthAdmin, NeedAuth


async def get_superadmin(user: DBUserBase = Depends(NeedAuth())):
    if user.__user_type__ != "superadmin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Unauthorized")
    return user


async def _enforce_admin_user_creation_limit(admin: AuthAdmin):
    limits = await DBAdminLimits.find_one({"adminId": admin.id})

    if limits is None:
        limits = DBAdminLimits(
            adminId=admin.id, userCreationLimit=2, docuSignLimit=1, assistantCreationLimit=2
        )  # Default limit
        await limits.save()

    if limits.userCreationLimit <= 0:
        raise HTTPException(status_code=429, detail="User creation limit exceeded for this admin.")

    limits.userCreationLimit -= 1
    await limits.save()


async def _enforce_admin_patient_creation_limit(admin: AuthAdmin):
    limits = await DBAdminLimits.find_one({"adminId": admin.id})

    if limits is None:
        limits = DBAdminLimits(
            adminId=admin.id, userCreationLimit=2, docuSignLimit=1, assistantCreationLimit=2
        )  # Default limit
        await limits.save()

    if limits.assistantCreationLimit <= 0:
        raise HTTPException(status_code=429, detail="User creation limit exceeded for this admin.")

    limits.assistantCreationLimit -= 1
    await limits.save()
