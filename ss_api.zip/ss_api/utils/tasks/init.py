from .periodic_tasks import init_periodic_tasks
from .scheduled_tasks import init_scheduled_tasks


def init_background_tasks():
    init_scheduled_tasks()
    init_periodic_tasks()
