from datetime import timedelta
from random import randrange

from ss_api.models.task import Task

from .periodic_job import PeriodicJob


async def check_pending_scheduled_tasks():
    while task := await Task.get_first_pending():
        await task.perform()


def init_scheduled_tasks() -> None:
    PeriodicJob(
        check_pending_scheduled_tasks, timedelta(hours=1), initial_delay=timedelta(seconds=randrange(60 * 1, 60 * 30))
    ).start()
