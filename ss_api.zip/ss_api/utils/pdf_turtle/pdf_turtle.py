from contextlib import asynccontextmanager
from typing import BinaryIO

from httpx import AsyncClient, ConnectError
from pydantic import BaseModel, HttpUrl

from ..settings import get_settings
from .exceptions import PDFTurtleConnectError, PDFTurtleNotInitializedError
from .models import Options


class PDFTurtle(BaseModel):
    html: str
    headerHtml: str | None = None
    footerHtml: str | None = None
    options: Options | None = None

    @property
    def _base_url(self) -> HttpUrl:
        settings = get_settings()
        if not settings.pdf_turtle:
            raise PDFTurtleNotInitializedError("missing `pdf_turtle` configuration")
        return settings.pdf_turtle.api_url

    @property
    @asynccontextmanager
    async def _client(self) -> AsyncClient:
        client = AsyncClient(base_url=str(self._base_url))
        try:
            yield client
        finally:
            await client.aclose()

    @asynccontextmanager
    async def generate_pdf(self):
        async with AsyncClient(base_url=str(self._base_url)) as client:
            response = None
            try:
                response = await client.send(
                    client.build_request(
                        "POST",
                        "/api/pdf/from/html/render",
                        json=self.model_dump(mode="json", exclude_none=True),
                    ),
                    stream=True,
                )
                yield response
            except ConnectError as e:
                raise PDFTurtleConnectError from e
            finally:
                if response is not None:
                    await response.aclose()

    async def save_to_file(self, file: BinaryIO):
        async with self.generate_pdf() as response:
            async for chunk in response.aiter_bytes():
                file.write(chunk)
