from typing import Annotated, Literal

from pydantic import BaseModel, Field


class PageSize(BaseModel):
    height: Annotated[int | None, Field(description="The height of the page in mm")] = 297
    width: Annotated[int | None, Field(description="The width of the page in mm")] = 210


class Margins(BaseModel):
    bottom: Annotated[int | None, Field(description="The bottom margin in mm")] = 20
    left: Annotated[int | None, Field(description="The left margin in mm")] = 25
    right: Annotated[int | None, Field(description="The right margin in mm")] = 25
    top: Annotated[int | None, Field(description="The top margin in mm")] = 25


class Options(BaseModel):
    excludeBuiltinStyles: bool | None = False
    landscape: bool | None = False
    margins: Margins | None = None
    pageFormat: Literal["A0", "A1", "A2", "A3", "A4", "A5", "A6", "Letter", "Legal"] | None = "A4"
    pageSize: PageSize | None = None
