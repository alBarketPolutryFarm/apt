class NotInitializedSettingsError(Exception):
    pass
