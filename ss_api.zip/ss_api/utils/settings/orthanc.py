from pydantic import BaseModel, HttpUrl

from ss_api.utils.typing.secret import Secret


class OrthancSettings(BaseModel):
    username: str
    password: Secret

    api_url: HttpUrl

    token: Secret
