from functools import cache
from pathlib import Path
from typing import Annotated, Literal

from pydantic import BaseModel, EmailStr, Field, FilePath, HttpUrl
from pydantic_settings import BaseSettings, SettingsConfigDict

import ss_api
from ss_api.utils.typing.secret import Secret

from ..typing import DirectoryOrCreatePath
from .orthanc import OrthancSettings

ENV_PREFIX = f"{ss_api.__package__.upper()}__"


class SecretsSettings(BaseModel):
    jwt: Annotated[Secret, Field(default_factory=lambda: Secret.random(64))]
    url: Annotated[Secret, Field(default_factory=lambda: Secret.random(64))]


class SMTPSettings(BaseModel):
    host: str
    port: int = 587
    username: str = ""
    password: Secret = Secret("")
    sender: EmailStr = "no-reply@serviziosalute.com"


class AdminSettings(BaseModel):
    email: EmailStr
    password: Secret


class OpenAPISettings(BaseModel):
    token: Secret


class PdfTurtleSettings(BaseModel):
    api_url: HttpUrl


class GraylogSettings(BaseModel):
    type: Literal["tcp"] = "tcp"
    host: str
    port: Annotated[int | None, Field(default=None)]


class ExternalServices(BaseModel):
    desk_dashboard_url: HttpUrl | None = None


class Settings(BaseSettings):
    debug: bool = False
    cors: bool = False
    mongo_uri: Secret
    base_url: HttpUrl
    storage_path: DirectoryOrCreatePath
    secrets: SecretsSettings = SecretsSettings()
    smtp: SMTPSettings | None = None
    admin: AdminSettings | None = None
    open_api: OpenAPISettings | None = None
    orthanc: OrthancSettings | None = None
    firebase_credentials_path: FilePath | None = None
    pdf_turtle: PdfTurtleSettings | None = None
    graylog: GraylogSettings | None = None
    external_services: ExternalServices = ExternalServices()
    mode: Literal["production", "development"] = "development"

    model_config = SettingsConfigDict(env_prefix=ENV_PREFIX, env_nested_delimiter="__", extra="ignore")


@cache
def get_settings() -> Settings:
    return Settings(_env_file=Path.cwd() / ".env", _env_file_encoding="utf-8")
