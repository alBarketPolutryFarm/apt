from ss_api.models.cache import fetched_exam

__document_models__ = [*fetched_exam.__document_models__]
