from typing import Literal

from beanie import PydanticObjectId

from .base import DBReportBase, NewReportBase, ReportBase
from .type import ReportType


class NewExternalReport(NewReportBase):
    __report_type__ = ReportType.external
    type: Literal[ReportType.external]
    file: PydanticObjectId


class ExternalReport(ReportBase):
    __report_type__ = ReportType.external
    type: Literal[ReportType.external]


class DBExternalReport(DBReportBase):
    __report_type__ = ReportType.external
