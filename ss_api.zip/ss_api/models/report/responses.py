from ss_api.utils.responses import Success

from .signature import Signature


class StartSignatureProcessSuccess(Success):
    signature: Signature
