from .base import DBReportBase
from .exam_report import DBExamReport, DBExamReportRequest, ExamReport, NewExamReport
from .external_report import DBExternalReport, ExternalReport, NewExternalReport
from .medical_examination_report import (
    DBMedicalExaminationReport,
    MedicalExaminationReport,
    NewMedicalExaminationReport,
)
from .type import ReportType

__document_models__ = [DBReportBase, DBExamReport, DBMedicalExaminationReport, DBExternalReport, DBExamReportRequest]

Report = MedicalExaminationReport | ExamReport | ExternalReport
NewReport = NewMedicalExaminationReport | NewExamReport | NewExternalReport
DBReport = DBMedicalExaminationReport | DBExamReport | DBExternalReport
