from abc import ABC
from typing import Literal

from pydantic import BaseModel

from ..base import DBReportBase, NewReportBase, ReportBase, UpdateReportBase
from ..signature import DBSignedReportBase, SignedReportBase
from ..type import ReportType
from .exam import DBExam, Exam


class ExamReportBase(BaseModel, ABC):
    __report_type__ = ReportType.exam


class UpdateExamReport(UpdateReportBase, ExamReportBase):
    conclusion: str | None = None


class NewExamReport(NewReportBase, ExamReportBase):
    type: Literal[ReportType.exam]

    conclusion: str


class ExamReport(ReportBase, ExamReportBase, SignedReportBase):
    type: Literal[ReportType.exam]

    exam: Exam

    conclusion: str


class DBExamReport(DBReportBase, ExamReportBase, DBSignedReportBase):
    __update_model__ = UpdateExamReport
    __pdf_template__ = "reports/exam_report.html"

    exam: DBExam

    conclusion: str
