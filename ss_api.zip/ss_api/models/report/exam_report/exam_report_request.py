from typing import Self

from beanie import Document, Link, PydanticObjectId
from beanie.odm.operators.find.comparison import NE, Eq, In
from beanie.odm.operators.find.logical import Or
from beanie.odm.queries.find import FindMany
from pydantic import BaseModel

from ss_api.models.base import (
    CreationAnonymousBase,
    IdBase,
    IdOptionalBase,
    PatchableBase,
)
from ss_api.utils.db import nested_indexes

from ...users import DBUser, UserType
from .exam import DBExam, Exam
from .exam_report import DBExamReport, ExamReport


class UpdateExamReportRequest(BaseModel):
    patientId: PydanticObjectId | None = None
    report: ExamReport | None = None


class ExamReportRequest(IdBase, CreationAnonymousBase, UpdateExamReportRequest):
    patientId: PydanticObjectId | None = None
    exam: Exam
    report: ExamReport | None = None


class DBExamReportRequest(Document, IdOptionalBase, CreationAnonymousBase, PatchableBase):
    __update_model__ = UpdateExamReportRequest

    patientId: PydanticObjectId | None = None

    exam: DBExam
    report: Link[DBExamReport] | None = None

    class Settings:
        name = "exam_report_requests"
        indexes = [*nested_indexes(DBExam.Settings.indexes, "exam.")]

    @classmethod
    def find_query(
        cls,
        *,
        by: DBUser | None,
        id: PydanticObjectId | None = None,
        patientId: PydanticObjectId | None = None,
        **kwargs
    ) -> FindMany[Self]:
        query = cls.find(**kwargs)

        if id is not None:
            query = query.find(Eq(cls.id, id))

        if by is not None:
            if by.__user_type__ != UserType.admin:
                query = query.find(NE(cls.patientId, None))
                query = query.find(Or(Eq(cls.report, None), Eq("report.createdBy", by.id)))
            if by.__user_type__ == UserType.doctor:
                query = query.find(In(cls.exam.modalities, by.reportableExamModalities))

        if patientId is not None:
            query = query.find(Eq(cls.patientId, patientId))

        query = query.find(fetch_links=True)

        return query
