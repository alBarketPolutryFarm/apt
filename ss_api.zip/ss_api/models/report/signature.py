from abc import ABC
from datetime import datetime, timedelta, timezone
from enum import StrEnum
from typing import Annotated

from beanie import PydanticObjectId, Save, before_event
from beanie.odm.documents import DocType
from fastapi import BackgroundTasks
from pydantic import BaseModel, HttpUrl, PrivateAttr

from ss_api.models.base import CreationBase, IdBase, IdOptionalBase, PatchableBase
from ss_api.models.diet import DBDiet
from ss_api.models.file import DBFile, File
from ss_api.models.monitoring_plan import DBMonitoringPlan
from ss_api.models.treatment_plan import DBTreatmentPlan
from ss_api.models.users import DBPatient, DBUserBase, UserType
from ss_api.models.utils.patch import PatchOperation
from ss_api.templates import jinja_env
from ss_api.utils.communications import send_mail
from ss_api.utils.open_api import OpenAPI
from ss_api.utils.open_api.digital_signature import NewSignatureRequest
from ss_api.utils.open_api.digital_signature.models import (
    NewSignatureRequestMember,
    SignatureRequestCallback,
    SignatureRequestStatus,
)
from ss_api.utils.pdf_turtle import PDFTurtle
from ss_api.utils.pdf_turtle.models import Margins, Options
from ss_api.utils.settings import get_settings

open_api = OpenAPI()


class SignatureStatus(StrEnum):
    waiting = "waiting"
    failed = "failed"
    completed = "completed"


class Signature(IdBase, BaseModel):
    status: SignatureStatus
    link: HttpUrl | str
    updatedAt: datetime | None = None


class SignedReportBase(CreationBase, ABC):
    signature: Signature | None = None
    file: File


class DBSignedReportBase(CreationBase, IdOptionalBase, PatchableBase, ABC):
    __pdf_template__: str
    signature: Signature | None = None
    file: DBFile | None = None

    _pdf_must_be_regenerated: Annotated[bool, PrivateAttr()] = False

    @before_event(Save)
    async def auto_generate_pdf(self) -> None:
        if self.file is None or self._pdf_must_be_regenerated:
            await self.generate_pdf()

    async def generate_pdf(self) -> None:
        if self.id is None:
            self.id = PydanticObjectId()

        specialist = await DBUserBase.get(self.createdBy, with_children=True)
        if specialist.__user_type__ != UserType.doctor:
            raise NotImplementedError()

        if self.file is None:
            self.file = await DBFile.new(
                ownerId=self.patientId,
                filename="report.pdf",
                contentType="application/pdf",
                createdBy=self.createdBy,
            )
        else:
            self.file.createdAt = datetime.now(timezone.utc)

        patient = await DBPatient.get(self.patientId)

        template = jinja_env.get_template(self.__pdf_template__)
        html = template.render(r=self, p=patient, s=specialist)
        pdf_generator = PDFTurtle(
            html=html,
            options=Options(margins=Margins(bottom=20, left=10, right=10, top=40, excludeBuiltinStyles=True)),
        )

        with self.file.open(mode="wb") as file:
            await pdf_generator.save_to_file(file)

    async def create_signature_request(self):
        if self.file is None:
            await self.generate_pdf()
        print("Everything is fine at PDF Generation at Line 96 Signature.py")

        specialist = await DBUserBase.get(self.createdBy, with_children=True)
        if specialist.__user_type__ != UserType.doctor:
            raise NotImplementedError()

        await specialist.signatureLimit.use()
        print("Everything is fine at Signature Limite Use at Line 102 Signature.py")
        request = NewSignatureRequest(
            title=f"Referto {self.date.strftime('%d/%m/%Y')}",
            content=self.file.base64,
            filename="report.pdf",
            members=[
                NewSignatureRequestMember(
                    firstname=specialist.firstName,
                    lastname=specialist.lastName,
                    email=specialist.email,
                    phone=specialist.phone,
                )
            ],
            callback=SignatureRequestCallback(
                url=f"{get_settings().base_url}callbacks/reports/signature-request-update"
            ),
        )
        print("Everything is fine at DBSignedReportBase Line 119 Signature.py")
        response = await open_api.digital_signature.request_pdf_signature(request)

        self.signature = Signature(
            id=response.data.id, status=SignatureStatus.waiting, link=response.data.members[0].sign_link
        )

    async def update_signature_status(
        self, background_tasks: BackgroundTasks | None = None, force: bool = False
    ) -> None:
        from ss_api.models.report import (
            DBExamReport,
            DBExamReportRequest,
            DBMedicalExaminationReport,
        )

        if self.signature is None:
            return

        if (
            not force
            and self.signature.updatedAt is not None
            and datetime.now(timezone.utc) - self.signature.updatedAt < timedelta(seconds=30)
        ):
            return

        open_api = OpenAPI()

        response = await open_api.digital_signature.get_signature_request_information(self.signature.id)

        self.signature.updatedAt = datetime.now(timezone.utc)

        if response.data.status in [
            SignatureRequestStatus.refused,
            SignatureRequestStatus.expired,
            SignatureRequestStatus.request_failed,
            SignatureRequestStatus.error,
        ]:
            self.signature.status = SignatureStatus.failed

        elif response.data.status == SignatureRequestStatus.finished:
            self.signature.status = SignatureStatus.completed

            if isinstance(self, DBMedicalExaminationReport):
                if self.diet is not None:
                    diet = DBDiet(
                        **self.diet.model_dump(),
                        createdBy=self.createdBy,
                        patientId=self.patientId,
                        effectiveDate=self.signature.updatedAt,
                        reportId=self.id,
                    )
                    await diet.revoke_current()
                    await diet.create()
                if self.monitoringPlan is not None:
                    monitoring_plan = DBMonitoringPlan(
                        **self.monitoringPlan.model_dump(),
                        createdBy=self.createdBy,
                        patientId=self.patientId,
                        effectiveDate=self.signature.updatedAt,
                        reportId=self.id,
                    )
                    await monitoring_plan.revoke_current()
                    await monitoring_plan.create()
                if self.treatmentPlan is not None:
                    treatment_plan = DBTreatmentPlan(
                        **self.treatmentPlan.model_dump(),
                        createdBy=self.createdBy,
                        patientId=self.patientId,
                        effectiveDate=self.signature.updatedAt,
                        reportId=self.id,
                    )
                    await treatment_plan.revoke_current()
                    await treatment_plan.create()

            elif isinstance(self, DBExamReport):
                request = await DBExamReportRequest.find({"report.$id": self.id}).first_or_none()
                if request is not None:
                    await request.delete()

            patient = await DBPatient.get(self.patientId, with_children=True)
            if background_tasks:
                background_tasks.add_task(self._send_notify_email, patient=patient)
            else:
                self._send_notify_email(patient=patient)

        await self.save()

    def patch(self: DocType, *operations: PatchOperation) -> DocType:
        report = super().patch(*operations)
        report.signature = None
        report._pdf_must_be_regenerated = True
        return report

    def _send_notify_email(self, patient: DBPatient) -> None:
        template = jinja_env.get_template("./email/new_report.html")
        body = template.render(user=patient)

        send_mail(
            subject="Servizio Salute | Nuovo referto",
            body=body,
            email=patient.email,
        )
