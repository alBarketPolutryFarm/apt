from enum import Enum


class ReportType(str, Enum):
    medical_examination = "medicalExamination"
    external = "external"
    exam = "exam"
