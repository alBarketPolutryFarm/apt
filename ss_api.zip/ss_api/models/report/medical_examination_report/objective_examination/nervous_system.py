from pydantic import BaseModel


class NervousSystem(BaseModel):
    reflexes: str | None = None
    motility: str | None = None
    sensitivity: str | None = None
    gait: str | None = None
