from pydantic import BaseModel


class CardiovascularSystem(BaseModel):
    inspection: str | None = None
    palpation: str | None = None
    percussion: str | None = None
    auscultation: str | None = None
    peripheralVessels: str | None = None
