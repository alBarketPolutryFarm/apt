from abc import ABC
from typing import List, Literal

from pydantic import BaseModel, field_validator

from ss_api.models.diet.diet import NewDietBase
from ss_api.models.monitoring_plan.monitoring_plan import NewMonitoringPlanBase
from ss_api.models.treatment_plan.treatment_plan import NewTreatmentPlanBase

from ..base import DBReportBase, NewReportBase, ReportBase, UpdateReportBase
from ..signature import DBSignedReportBase, SignedReportBase
from ..type import ReportType
from .diagnosis import Diagnosis
from .objective_examination import ObjectiveExamination
from .planned_intervention import PlannedIntervention


class MedicalExaminationReportBase(BaseModel, ABC):
    __report_type__ = ReportType.medical_examination

    objectiveExamination: ObjectiveExamination | None = None
    diagnosis: Diagnosis | None = None
    plannedInterventions: List[PlannedIntervention] | None = None

    monitoringPlan: NewMonitoringPlanBase | None = None
    diet: NewDietBase | None = None
    treatmentPlan: NewTreatmentPlanBase | None = None

    diagnosticExaminations: str | None = None
    conclusion: str | None = None

    @field_validator("objectiveExamination", "diagnosis", "plannedInterventions")
    @classmethod
    def light_up(cls, v):
        if v is not None:
            if isinstance(v, list):
                if len(v) == 0:
                    return None
            elif len(v.model_dump(exclude_none=True).keys()) == 0:
                return None
        return v


class UpdateMedicalExaminationReportBase(UpdateReportBase, MedicalExaminationReportBase):
    remotely: bool | None = None


class NewMedicalExaminationReport(NewReportBase, MedicalExaminationReportBase):
    type: Literal[ReportType.medical_examination]

    remotely: bool = False


class MedicalExaminationReport(ReportBase, MedicalExaminationReportBase, SignedReportBase):
    type: Literal[ReportType.medical_examination]

    remotely: bool


class DBMedicalExaminationReport(DBReportBase, MedicalExaminationReportBase, DBSignedReportBase):
    __update_model__ = UpdateMedicalExaminationReportBase
    __pdf_template__ = "reports/medical_examination_report.html"

    remotely: bool = False
