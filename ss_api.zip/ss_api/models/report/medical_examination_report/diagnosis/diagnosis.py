from pydantic import BaseModel


class Diagnosis(BaseModel):
    pathology: str | None = None
    secondaryPathologies: str | None = None
