from .treatment_intake import DBTreatmentIntake, NewTreatmentIntake, TreatmentIntake
from .treatment_plan import (
    DBTreatmentPlan,
    NewTreatmentPlan,
    NewTreatmentPlanBase,
    TreatmentPlan,
)
from .treatment_side_effect import (
    DBTreatmentSideEffect,
    NewTreatmentSideEffect,
    TreatmentSideEffect,
)

__timeseries_models__ = [DBTreatmentIntake, DBTreatmentSideEffect]
__document_models__ = [DBTreatmentPlan]
