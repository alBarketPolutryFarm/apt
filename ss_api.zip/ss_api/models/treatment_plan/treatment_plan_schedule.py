from __future__ import annotations

from datetime import datetime, timedelta
from typing import Annotated, Any, List

from beanie.odm.operators.find.comparison import GT, LT
from pydantic import BaseModel, Field

from ss_api.models.base.id import IdBase

from .treatment import Treatment
from .treatment_intake import DBTreatmentIntake, TreatmentIntake


class TreatmentPlanScheduleEntryRaw(IdBase, BaseModel):
    treatment: Treatment
    description: Annotated[str, Field(deprecated=True)]
    notes: str | None = None

    at: datetime
    notBefore: datetime
    notAfter: datetime

    def __init__(self, at: datetime, **data: Any):
        if data.get("notBefore") is None:
            data["notBefore"] = at - timedelta(hours=1)
        if data.get("notAfter") is None:
            data["notAfter"] = at + timedelta(hours=3)

        super().__init__(**data, at=at)

    async def get_intake_entry(self) -> DBTreatmentIntake:
        return await DBTreatmentIntake.find(
            DBTreatmentIntake.scheduleId == self.id,
            GT(DBTreatmentIntake.at, self.notBefore - timedelta(days=1)),
            LT(DBTreatmentIntake.at, self.notAfter + timedelta(days=3)),
        ).first_or_none()


class TreatmentPlanScheduleEntry(TreatmentPlanScheduleEntryRaw):
    intake: TreatmentIntake | None = None

    @classmethod
    async def from_raw(cls, raw: TreatmentPlanScheduleEntryRaw) -> TreatmentPlanScheduleEntry:
        return cls(**{**raw.model_dump(), "_id": raw.id}, intake=await raw.get_intake_entry())


TreatmentPlanSchedule = List[TreatmentPlanScheduleEntry]
