from datetime import datetime, timedelta
from typing import Annotated

from beanie import Document, Granularity, PydanticObjectId, TimeSeriesConfig
from pydantic import BaseModel, Field
from pymongo import IndexModel

from ss_api.models.base.id import IdBase


class TreatmentSideEffectBase(BaseModel):
    at: datetime | None
    description: str


class NewTreatmentSideEffect(TreatmentSideEffectBase):
    at: Annotated[datetime | None, Field(default_factory=datetime.utcnow)]


class TreatmentSideEffect(IdBase, TreatmentSideEffectBase):
    patientId: PydanticObjectId
    at: datetime


class DBTreatmentSideEffect(Document, TreatmentSideEffect):
    class Settings:
        name = "treatments_side_effects"

        timeseries = TimeSeriesConfig(
            time_field="at",
            granularity=Granularity.minutes,
            expire_after_seconds=timedelta(days=365).total_seconds(),
        )
        indexes = [IndexModel("patientId"), IndexModel("at")]
