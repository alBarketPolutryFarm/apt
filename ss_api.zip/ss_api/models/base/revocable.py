from datetime import datetime
from typing import TypeVar, Union

from beanie import Document
from beanie.odm.queries.find import FindMany
from pydantic import BaseModel

from ss_api.models.base.validity_period import ValidityPeriodBase
from ss_api.models.revocation import Revocation

T = TypeVar("T", bound=Union[Document, ValidityPeriodBase])


class RevocableBase(ValidityPeriodBase, BaseModel):
    revocation: Revocation | None = None

    async def revoke(self: T, revocation: Revocation) -> None:
        self.revocation = revocation
        if isinstance(self, ValidityPeriodBase):
            self.expirationDate = revocation.effectiveFrom
        await self.save()

    def find_revocable(self) -> FindMany:
        return self.find_period(self.effectiveDate, self.expirationDate or datetime.max)
