from datetime import datetime, timezone
from typing import Any, List

from beanie import PydanticObjectId
from pydantic import BaseModel


class EditLog(BaseModel):
    at: datetime
    by: PydanticObjectId
    description: str | None = None

    def __init__(self, **data: Any):
        if data.get("at") is None:
            data["at"] = datetime.now(timezone.utc)
        super().__init__(**data)


class EditsLogBase(BaseModel):
    editsLog: List[EditLog]

    def __init__(self, **data: Any):
        if data.get("editsLog") is None:
            data["editsLog"] = []
        super().__init__(**data)

    def insert_edit_log(self, edit_log: EditLog):
        if self.editsLog is None:
            self.editsLog = []

        self.editsLog.insert(0, edit_log)
