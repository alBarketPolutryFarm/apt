from datetime import datetime
from typing import Annotated

from beanie import Update, before_event
from pydantic import BaseModel, Field
from pytz import UTC


class UpdatableBase(BaseModel):
    lastUpdate: Annotated[datetime, Field(default_factory=lambda: datetime.now(UTC))]

    @before_event(Update)
    def update_date(self):
        self.lastUpdate = datetime.now()
