from datetime import datetime
from typing import Self  # type: ignore

import nh3
from beanie import Document, PydanticObjectId
from beanie.odm.enums import SortDirection
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from pydantic import BaseModel, field_validator
from pymongo import IndexModel

from ss_api.models.base import PatchableBase
from ss_api.models.base.creation import CreationBase
from ss_api.models.base.id import IdBase
from ss_api.models.utils.db import DBQuery
from ss_api.utils.query_string import DateRangeData


class NewScreening(BaseModel):
    title: str
    description: str | None = None
    body: str
    startAt: datetime
    endAt: datetime


class UpdateScreening(BaseModel):
    title: str
    description: str | None = None
    body: str
    startAt: datetime
    endAt: datetime


class Screening(IdBase, CreationBase, NewScreening):
    pass


class DBScreening(Document, Screening, PatchableBase):
    __update_model__ = UpdateScreening

    class Settings:
        name = "screenings"
        indexes = [IndexModel("startAt"), IndexModel("endAt")]

    @field_validator("body", mode="before")
    def sanitize_body(cls, v):
        if isinstance(v, str):
            tags = {
                "a",
                "abbr",
                "acronym",
                "b",
                "blockquote",
                "code",
                "em",
                "i",
                "li",
                "ol",
                "strong",
                "ul",
                "p",
                "br",
                "span",
                "div",
                "img",
                "h1",
                "h2",
                "h3",
                "h4",
                "h5",
                "h6",
                "pre",
                "table",
                "thead",
                "tbody",
                "tr",
                "td",
                "th",
                "font",
                "u",
                "strike",
            }
            attributes = {
                "a": {"href", "title", "target"},
                "abbr": {"title"},
                "acronym": {"title"},
                "img": {"src", "alt", "title"},
                "span": {"style"},
                "div": {"style", "align"},
                "p": {"style", "align"},
                "h1": {"style", "align"},
                "h2": {"style", "align"},
                "h3": {"style", "align"},
                "h4": {"style", "align"},
                "h5": {"style", "align"},
                "h6": {"style", "align"},
                "table": {"border", "cellspacing", "cellpadding"},
                "td": {"colspan", "rowspan"},
                "th": {"colspan", "rowspan"},
                "font": {"size"},
            }

            return nh3.clean(v, tags=tags, attributes=attributes)
        return v

    @classmethod
    def find_query(
        cls,
        id: PydanticObjectId | None = None,
        sort: SortDirection | None = SortDirection.DESCENDING,
    ) -> FindMany[Self]:
        query = cls.find()

        if id is not None:
            query = query.find({"_id": id})

        if sort is not None:
            query = query.sort(("at", sort))

        return query

    @staticmethod
    def __filter_by_data_range__(query: DBQuery, date_range: DateRangeData) -> DBQuery:
        filter_conditions = []

        if date_range.start is not None:
            filter_conditions.append({"endAt": {"$gte": date_range.start}})

        if date_range.end is not None:
            filter_conditions.append({"startAt": {"$lte": date_range.end}})

        if isinstance(query, AggregationQuery):
            if filter_conditions:
                query.aggregation_pipeline.append({"$match": {"$and": filter_conditions}})
            return query
        else:
            if filter_conditions:
                query = query.find({"$and": filter_conditions})
            return query
