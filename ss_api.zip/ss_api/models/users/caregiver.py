from typing import Literal

from ss_api.models.base import CreationBase, EditsLogBase, PatchableBase
from ss_api.utils.typing import FiscalCode, PhoneNumber

from .base import DBUserBase, NewUser, UpdateUser, UserBase
from .type import UserType


class UpdateCaregiver(UpdateUser):
    __user_type__ = UserType.caregiver


class NewCaregiver(NewUser, UpdateCaregiver):
    fiscalCode: FiscalCode
    phone: PhoneNumber


class Caregiver(NewCaregiver, CreationBase, UserBase, EditsLogBase):
    type: Literal[UserType.caregiver]


class DBCaregiver(NewCaregiver, DBUserBase, EditsLogBase, PatchableBase):
    __update_model__ = UpdateCaregiver
    __sign_up_email_template__ = "email/caregiver_created.html"
    __sign_up_email_subject__ = "Caregiver creato"
