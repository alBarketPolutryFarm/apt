from enum import Enum
from typing import Literal

from ss_api.models.base import CreationBase, EditsLogBase, PatchableBase
from ss_api.utils.typing import FiscalCode, PhoneNumber

from .base import DBUserBase, NewUser, UpdateUser, UserBase
from .type import UserType


class OperatorType(str, Enum):
    physiotherapist = "physiotherapist"
    nutritionist = "nutritionist"
    psychologist = "psychologist"
    obstetrician = "obstetrician"
    socialWorker = "socialWorker"
    educator = "educator"
    childhoodEducator = "childhoodEducator"
    sociologist = "sociologist"
    pharmacist = "pharmacist"
    labTechnician = "labTechnician"
    other = "other"


class UpdateOperator(UpdateUser):
    __user_type__ = UserType.operator

    operatorType: OperatorType | None = None


class NewOperator(NewUser, UpdateOperator):
    fiscalCode: FiscalCode
    phone: PhoneNumber

    operatorType: OperatorType | None = OperatorType.other


class Operator(NewOperator, CreationBase, UserBase, EditsLogBase):
    type: Literal[UserType.operator]

    operatorType: OperatorType


class DBOperator(NewOperator, DBUserBase, EditsLogBase, PatchableBase):
    __update_model__ = UpdateOperator
    __sign_up_email_template__ = "email/operator_created.html"
    __sign_up_email_subject__ = "Operatore creato"
