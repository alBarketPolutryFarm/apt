from typing import Literal

from ss_api.models.base import CreationBase, EditsLogBase, PatchableBase
from ss_api.utils.typing import PhoneNumber

from ...utils.typing import FiscalCode
from .base import DBUserBase, NewUser, UpdateUser, UserBase
from .type import UserType


class UpdateNurse(UpdateUser):
    __user_type__ = UserType.nurse


class NewNurse(NewUser, UpdateNurse):
    fiscalCode: FiscalCode
    phone: PhoneNumber


class Nurse(NewNurse, CreationBase, UserBase, EditsLogBase):
    type: Literal[UserType.nurse]


class DBNurse(NewNurse, DBUserBase, EditsLogBase, PatchableBase):
    __update_model__ = UpdateNurse
    __sign_up_email_template__ = "email/nurse_created.html"
    __sign_up_email_subject__ = "Infermiere creato"
