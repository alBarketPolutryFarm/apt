from enum import StrEnum


class UserType(StrEnum):
    superadmin = "superadmin"
    admin = "admin"
    nurse = "nurse"
    patient = "patient"
    operator = "operator"
    doctor = "doctor"
    caregiver = "caregiver"
