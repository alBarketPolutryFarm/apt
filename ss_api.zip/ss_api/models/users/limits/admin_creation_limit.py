from beanie import Document, Insert, PydanticObjectId, before_event
from pydantic import BaseModel, Field
from pymongo.errors import DuplicateKeyError


class AdminLimitsBase(BaseModel):
    userCreationLimit: int = Field(1, ge=0, description="Maximum number of users an admin can create")
    assistantCreationLimit: int = Field(1, ge=0, description="Maximum number of Assistiti an admin can create")
    docuSignLimit: int = Field(1, ge=0, description="Monthly DocuSign signature limit for the admin")


class DBAdminLimits(Document, AdminLimitsBase):
    adminId: PydanticObjectId

    class Settings:
        name = "admin_limits"

    @before_event(Insert)
    async def check_limit_exists(self):
        if await DBAdminLimits.find_one(DBAdminLimits.adminId == self.adminId) is not None:
            raise DuplicateKeyError({"adminId": self.adminId}, code=11000, msg="Limits already exists for this admin")


class NewAdminLimits(AdminLimitsBase):
    pass


class UpdateAdminLimits(AdminLimitsBase):
    pass
