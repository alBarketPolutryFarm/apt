class LimitExceededError(Exception):
    pass
