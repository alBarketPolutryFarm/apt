from beanie import Document, Insert, PydanticObjectId, before_event
from pydantic import BaseModel, Field
from pymongo.errors import DuplicateKeyError


class DoctorDocuSignLimitsBase(BaseModel):
    limit: int = Field(ge=0, description="Monthly DocuSign signature limit for the doctor")
    # @validator('expiration_date', pre=True, always=True)
    # def set_expiration_date(cls, value):
    #     if value is None:
    #         return (datetime.now().replace(day=1) + timedelta(days=32)).replace(day=1).date() - timedelta(days=1)
    #     return value


class DBDoctorDocuSignLimits(Document, DoctorDocuSignLimitsBase):
    doctorId: PydanticObjectId

    class Settings:
        name = "doctor_docusign_limits"

    @before_event(Insert)
    async def check_limit_exists(self):
        if await DBDoctorDocuSignLimits.find_one(DBDoctorDocuSignLimits.doctorId == self.doctorId) is not None:
            raise DuplicateKeyError(
                {"doctorId": self.doctorId}, code=11000, msg="DocuSign limits already exists for this doctor"
            )


class NewDoctorDocuSignLimits(DoctorDocuSignLimitsBase):
    pass


class UpdateDoctorDocuSignLimits(DoctorDocuSignLimitsBase):
    pass
