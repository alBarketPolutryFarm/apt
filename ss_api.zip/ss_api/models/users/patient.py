from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import PastDate

from ss_api.models.base import EditsLogBase, PatchableBase
from ss_api.models.gender import Gender

from .base import DBUserBase, NewUser, UpdateUser, UserBase
from .type import UserType


class UpdatePatient(UpdateUser):
    __user_type__ = UserType.patient
    gender: Gender | None = None

    birthDate: PastDate | None = None
    birthPlace: str | None = None

    doctor: str | None = None
    caregiver: str | None = None


class NewPatient(NewUser, UpdatePatient):
    pass


class Patient(UserBase, EditsLogBase, NewPatient):
    type: Literal[UserType.patient]


class DBPatient(DBUserBase, NewPatient, EditsLogBase, PatchableBase):
    __update_model__ = UpdatePatient
    __sign_up_email_template__ = "email/patient_created.html"
    __sign_up_email_subject__ = "Paziente creato"

    def __init__(self, *args, **kwargs):
        if kwargs.get("birthDate") is not None and isinstance(kwargs.get("birthDate"), datetime):
            kwargs["birthDate"] = kwargs.get("birthDate").date()
        super().__init__(*args, **kwargs)
