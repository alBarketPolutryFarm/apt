import asyncio
import re
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Type

import bcrypt
import pymongo
from beanie import Document, PydanticObjectId
from beanie.odm.documents import DocType
from beanie.odm.operators.find.evaluation import Text
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from fastapi import BackgroundTasks
from pydantic import BaseModel, EmailStr, PastDatetime, computed_field, model_validator
from pymongo import IndexModel
from pymongo.client_session import ClientSession
from pymongo.errors import DuplicateKeyError

from ss_api.models.base import CreationOptionallyAnonymousBase
from ss_api.models.base.id import IdBase
from ss_api.utils.db import bson_encoders
from ss_api.utils.typing import FiscalCode, PhoneNumber
from ss_api.utils.typing.secret import Secret

from ...templates import jinja_env
from ...utils.communications.mail import send_mail, send_mail_async
from ..permissions import DBPermission
from .type import UserType

if TYPE_CHECKING:
    from . import DBUser


class ChatUser(BaseModel):
    _id: str
    first_name: str
    last_name: str
    type: str


class UserStatus(str, Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"


class UpdateUser(BaseModel):
    __user_type__: UserType
    firstName: str | None = None
    lastName: str | None = None
    phone: PhoneNumber | None = None
    fiscalCode: FiscalCode | None = None
    status: UserStatus | None = None

    @property
    def fullName(self) -> str:
        return f"{self.firstName} {self.lastName}"


class NewUser(UpdateUser):
    email: EmailStr
    firstName: str
    lastName: str
    fiscalCode: FiscalCode | None = None
    status: UserStatus = UserStatus.ACTIVE

    @model_validator(mode="before")
    @classmethod
    def email_or_fiscal_code_set(cls, values):
        if dict(values).get("email") is None and dict(values).get("fiscalCode") is None:
            raise ValueError("Email and fiscal code cannot both be undefined")

        return values


class UserBase(IdBase, CreationOptionallyAnonymousBase, NewUser):
    pass


class DBUserBase(Document, UserBase):
    __sign_up_email_template__: str
    __sign_up_email_subject__: str
    password: Secret | None = None
    lastPasswordChange: PastDatetime | None = None
    lastChatMessageNotification: PastDatetime | None = None
    status: UserStatus = UserStatus.ACTIVE
    last_login_attempt: datetime | None = None
    login_attempts: int = 0
    lastPasswordUpdateReminder: datetime | None = datetime.now(tz=timezone.utc)
    creator: PydanticObjectId | None = None

    class Settings:
        is_root = True
        name = "users"
        bson_encoders = bson_encoders
        indexes = [
            # Removed For Adding Multiple Users with Same Fiscal Code Via SuperAdmin , removed unique=True
            IndexModel("fiscalCode", partialFilterExpression={"fiscalCode": {"$type": "string"}}),
            IndexModel("email", unique=True),
            IndexModel(
                [
                    ("firstName", pymongo.TEXT),
                    ("lastName", pymongo.TEXT),
                    ("fiscalCode", pymongo.TEXT),
                    ("phone", pymongo.TEXT),
                ],
                name="text",
            ),
        ]

    @staticmethod
    def _hash_password(password: Secret | str) -> Secret:
        return Secret(bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8"))

    def __init__(self, *args, newPassword: Secret | str | None = None, **kwargs):
        if newPassword is not None:
            kwargs["password"] = self._hash_password(Secret(newPassword))

        super().__init__(*args, **kwargs)

    @computed_field  # type: ignore[misc]
    @property
    def type(self) -> str:
        return self.__user_type__

    def check_password(self, password: str) -> bool:
        return self.password is not None and bcrypt.checkpw(password.encode("utf-8"), self.password.encode("utf-8"))

    def update_password(self, password: str) -> None:
        self.password = Secret(bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(14)).decode("utf-8"))
        self.lastPasswordChange = datetime.now(tz=timezone.utc)

    async def _send_regenerated_password_email(self, plain_password: str):
        template = jinja_env.get_template("./forgot_password/email_regenerated.html")
        body = template.render(user=self, password=plain_password)

        loop = asyncio.get_event_loop()
        loop.create_task(
            send_mail_async(
                subject="Servizio Salute | Password rigenerata",
                body=body,
                email=self.email,
            )
        )

    @classmethod
    async def activate_user(cls, user_id: PydanticObjectId) -> None:
        await cls.find_one(cls.id == user_id).update({"$set": {"status": UserStatus.ACTIVE}})

    @classmethod
    async def suspend_user(cls, user_id: PydanticObjectId) -> None:
        await cls.find_one(cls.id == user_id).update({"$set": {"status": UserStatus.SUSPENDED}})

    def is_active(self) -> bool:
        return self.status == UserStatus.ACTIVE

    def is_suspended(self) -> bool:
        return self.status == UserStatus.SUSPENDED

    async def regenerate_password(self, background_tasks: BackgroundTasks | None = None) -> None:
        plain_password = Secret.random()
        self.update_password(plain_password)
        await self.save()

        if background_tasks is not None and plain_password is not None:
            background_tasks.add_task(self._send_regenerated_password_email, plain_password=plain_password)

    @classmethod
    def find_query(
        cls: Type[DocType],
        by: Optional["DBUser"] = None,
        id: PydanticObjectId | None = None,
        q: str | None = None,
        gender: str | None = None,
        target_ids: List[PydanticObjectId] | None = None,
        status: UserStatus | None = None,
        find_created_by: bool = False,
    ) -> FindMany[DocType] | AggregationQuery[DocType]:

        # TODO improve this workaround
        if find_created_by:
            if by is not None:
                return cls.find({"createdBy": by.id}, with_children=True)

        if by is not None and id is not None and by.id == id:
            return cls.find({"_id": id}, with_children=True)

        if by is None or by.__user_type__ == UserType.superadmin or by.__user_type__ == UserType.admin:
            if id is None:
                if q is not None or gender is not None or target_ids is not None:
                    query_find = cls.find()
                    pipeline: List[Dict[str, Any]] = []
                    match_stage = {"$match": {}}  # type: ignore
                    if q is not None:
                        match_stage["$match"]["$or"] = [
                            {"firstName": {"$regex": q, "$options": "i"}},
                            {"lastName": {"$regex": q, "$options": "i"}},
                            {"fiscalCode": {"$regex": q, "$options": "i"}},
                            {"email": {"$regex": q, "$options": "i"}},
                            {"phone": {"$regex": q, "$options": "i"}},
                        ]

                    if status is not None:
                        match_stage["$match"]["status"] = status

                    if gender is not None:
                        match_stage["$match"]["gender"] = gender

                    pipeline.append(match_stage)

                    if target_ids is not None:
                        match_stage["$match"]["_class_id"] = "DBUserBase.DBPatient"
                        # Fase $lookup per i permessi
                        pipeline.append(
                            {
                                "$lookup": {
                                    "from": "permissions",
                                    "let": {"patientId": "$_id"},
                                    "pipeline": [
                                        {
                                            "$match": {
                                                "$expr": {"$eq": ["$patientId", "$$patientId"]},
                                                "$or": [
                                                    {"expirationDate": {"$gt": datetime.utcnow()}},
                                                    {"expirationDate": None},
                                                ],
                                                "revocation": None,
                                                "targetId": {"$in": target_ids},
                                            }
                                        }
                                    ],
                                    "as": "validPermissions",
                                }
                            }
                        )

                        # Fase $match finale per filtrare i record con permessi validi
                        pipeline.append({"$match": {"validPermissions": {"$ne": []}}})

                    # Fase $project per proiettare i campi desiderati
                    pipeline.append(
                        {"$project": {"_id": 1, "firstName": 1, "lastName": 1, "email": 1, "phone": 1, "gender": 1}}
                    )

                    query = query_find.aggregate(pipeline, projection_model=cls)
                    query.projection_model = cls
                    return query
                else:
                    query = cls.find(with_children=True)
                    if q is not None:
                        # Controlla se 'q' è un'email
                        if re.match(r"^[^@]+@[^@]+\.[^@]+$", q):
                            return cls.find({"email": q}, with_children=True).limit(1)
                        query = query.find(Text(q))
                return query
            return cls.find({"_id": id}, with_children=True)

        if q is not None:
            q = q.strip().lower()
            if re.match(r"^[^@]+@[^@]+\.[^@]+$", q):  # Controlla se 'q' è un'email
                return cls.find({"email": q}, with_children=True).limit(1)
            else:
                q = re.sub(r"[^a-zA-Z\dàáâãäåèéêëìíîïòóôõöùúûü ]", "", q)
                q = re.sub(r" +", "|", q)
                q = re.sub(r"[aàáâãäå]", "[aàáâãäå]", q)
                q = re.sub(r"[eèéêë]", "[eèéêë]", q)
                q = re.sub(r"[iìíîï]", "[iìíîï]", q)
                q = re.sub(r"[oòóôõö]", "[oòóôõö]", q)
                q = re.sub(r"[uùúûü]", "[uùúûü]", q)

        query = DBPermission.find_query(
            **({"patient": by.id} if by.__user_type__ == UserType.patient else {"target": by.id})
        )
        query.aggregation_pipeline.extend(
            [
                {"$project": {"targetId": "$targetId" if by.__user_type__ == UserType.patient else "$patientId"}},
                {
                    "$group": {
                        "_id": "$targetId",
                        "targetId": {
                            "$first": "$targetId",
                        },
                    },
                },
                {
                    "$lookup": {
                        "from": cls.Settings.name,
                        "localField": "targetId",
                        "foreignField": "_id",
                        "as": "tmp",
                    }
                },
                {"$unwind": {"path": "$tmp"}},
                {"$replaceRoot": {"newRoot": {"$mergeObjects": ["$tmp"]}}},
                *(
                    [{"$match": {"_class_id": f"{DBUserBase.__name__}.{cls.__name__}"}}]
                    if cls.__name__ != DBUserBase.__name__
                    else []
                ),
                *([{"$match": {"_id": id}}] if id is not None else []),
                *(
                    [
                        {
                            "$match": {
                                "$or": [
                                    {"firstName": {"$regex": q, "$options": "i"}},
                                    {"lastName": {"$regex": q, "$options": "i"}},
                                    {"fiscalCode": {"$regex": q, "$options": "i"}},
                                    {"email": {"$regex": q, "$options": "i"}},
                                    {"phone": {"$regex": q, "$options": "i"}},
                                ]
                            }
                        }
                    ]
                    if q is not None
                    else []
                ),
            ]
        )
        query.projection_model = cls
        return query

    def _send_sing_up_email(self, plain_password: str):
        template = jinja_env.get_template(self.__sign_up_email_template__)
        body = template.render(user=self, password=plain_password)

        send_mail(
            subject=f"Servizio Salute | {self.__sign_up_email_subject__}",
            body=body,
            email=self.email,
        )

    async def create(
        self: DocType,
        session: Optional[ClientSession] | None = None,
        background_tasks: BackgroundTasks | None = None,
        fiscalCodeCheck: bool = True,
    ) -> DocType:
        plain_password: str | None = None
        if self.password is None:
            plain_password = Secret.random()
            self.password = self._hash_password(plain_password)

        if self.fiscalCode is None and self.__user_type__ == UserType.patient:
            print("Patient is Allowed without Fiscal Code")
            fiscalCodeCheck = False
        if fiscalCodeCheck:
            print("Fiscal Code Check Running")
            DupUserData = await DBUserBase.find(DBUserBase.fiscalCode == self.fiscalCode, with_children=True).to_list()
            if DupUserData is not None and len(DupUserData) > 0:
                raise DuplicateKeyError(
                    error={"message": "Duplicate key error", "code": 11000},
                    details={"keyValue": {"fiscalCode": self.fiscalCode}},
                    code=11000,
                )
        await super().create(session)

        if background_tasks is not None and plain_password is not None:
            background_tasks.add_task(self._send_sing_up_email, plain_password=plain_password)

        return self
