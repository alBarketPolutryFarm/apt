from typing import List

from beanie import Document

from .monitored_measure import DBMonitoredMeasure, MonitoredMeasure, NewMonitoredMeasure
from .monitoring_plan import (
    DBMonitoringPlan,
    MonitoringPlan,
    NewMonitoringPlan,
    NewMonitoringPlanBase,
)

__timeseries_models__: List[Document] = []
__document_models__ = [DBMonitoringPlan]
