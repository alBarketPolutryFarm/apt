from __future__ import annotations

from datetime import datetime, timedelta
from hashlib import sha256
from itertools import product
from math import ceil
from typing import List, Tuple

from beanie import Document, Insert, PydanticObjectId, before_event
from beanie.odm.operators.find.comparison import GT, LT, Eq
from beanie.odm.operators.find.logical import Or
from bson import ObjectId
from pydantic import BaseModel
from pymongo import ASCENDING, IndexModel
from pytz import UTC
from pytz.tzinfo import BaseTzInfo

from ss_api.models.base import IdBase
from ss_api.models.base.creation import CreationBase
from ss_api.models.base.validity_period import NewValidityPeriodBase, ValidityPeriodBase
from ss_api.models.measures import MeasureType
from ss_api.models.revocation import Revocation, RevocationReason
from ss_api.models.users import DBPatient
from ss_api.utils.db import bson_encoders, query_sort
from ss_api.utils.helpers.datetime import week_start

from .monitored_measure import (
    DBMonitoredBloodPressureMeasure,
    DBMonitoredGenericMeasure,
    DBMonitoredOxygenSaturationMeasure,
    DBMonitoredPainMeasure,
    MonitoredBloodPressureMeasure,
    MonitoredGenericMeasure,
    NewMonitoredBloodPressureMeasure,
    NewMonitoredGenericMeasure,
    NewMonitoredOxygenSaturationMeasure,
    NewMonitoredPainMeasure,
)
from .monitoring_plan_schedule import (
    MonitoringPlanScheduleEntry,
    MonitoringPlanScheduleEntryRaw,
)
from .monitoring_plan_week_schedule import (
    MonitoringPlanWeekSchedule,
    MonitoringPlanWeekScheduleEntry,
)


class MonitoringPlanBase(ValidityPeriodBase, BaseModel):
    bloodPressure: MonitoredBloodPressureMeasure | None = None
    weight: MonitoredGenericMeasure | None = None
    temperature: MonitoredGenericMeasure | None = None
    pain: MonitoredGenericMeasure | None = None
    respiratoryRate: MonitoredGenericMeasure | None = None
    pulse: MonitoredGenericMeasure | None = None
    glycaemia: MonitoredGenericMeasure | None = None
    oxygenSaturation: MonitoredGenericMeasure | None = None
    waterBalance: MonitoredGenericMeasure | None = None

    reportId: PydanticObjectId

    notes: str | None = None


class MonitoringPlan(IdBase, MonitoringPlanBase, CreationBase):
    revocation: Revocation | None = None


class NewMonitoringPlanBase(BaseModel):
    bloodPressure: NewMonitoredBloodPressureMeasure | None = None
    weight: NewMonitoredGenericMeasure | None = None
    temperature: NewMonitoredGenericMeasure | None = None
    pain: NewMonitoredPainMeasure | None = None
    respiratoryRate: NewMonitoredGenericMeasure | None = None
    pulse: NewMonitoredGenericMeasure | None = None
    glycaemia: NewMonitoredGenericMeasure | None = None
    oxygenSaturation: NewMonitoredOxygenSaturationMeasure | None = None
    waterBalance: NewMonitoredGenericMeasure | None = None
    notes: str | None = None


class NewMonitoringPlan(NewValidityPeriodBase, NewMonitoringPlanBase, MonitoringPlanBase):
    reportId: PydanticObjectId


class DBMonitoringPlan(Document, MonitoringPlan):
    patientId: PydanticObjectId
    reportId: PydanticObjectId

    bloodPressure: DBMonitoredBloodPressureMeasure | None = None
    weight: DBMonitoredGenericMeasure | None = None
    temperature: DBMonitoredGenericMeasure | None = None
    pain: DBMonitoredPainMeasure | None = None
    respiratoryRate: DBMonitoredGenericMeasure | None = None
    pulse: DBMonitoredGenericMeasure | None = None
    glycaemia: DBMonitoredGenericMeasure | None = None
    oxygenSaturation: DBMonitoredOxygenSaturationMeasure | None = None
    waterBalance: DBMonitoredGenericMeasure | None = None

    class Settings:
        name = "monitoring_plans"
        bson_encoders = bson_encoders
        indexes = [*MonitoringPlanBase.Settings.indexes, IndexModel("patientId")]

    @before_event(Insert)
    async def revoke_current(self):
        patient = await DBPatient.get(self.patientId)
        if (current := await self.get_current(patient)) is not None:
            await current.revoke(
                Revocation(dueTo=RevocationReason.outdated, effectiveFrom=self.effectiveDate, by=self.id)
            )

    @classmethod
    async def get_current(cls, patient: DBPatient) -> DBMonitoringPlan | None:
        return await cls.find_one(
            cls.patientId == patient.id,
            Or(Eq(cls.expirationDate, None), GT(cls.expirationDate, datetime.utcnow())),
            cls.effectiveDate < datetime.utcnow(),
        )

    async def revoke(self, revocation: Revocation) -> None:
        self.revocation = revocation
        self.expirationDate = self.revocation.effectiveFrom
        await self.save()

    @property
    def validity_interval(self) -> Tuple[datetime, datetime | None]:
        return self.effectiveDate, self.expirationDate

    @property
    def week_schedule(self) -> MonitoringPlanWeekSchedule:
        measure_objects = map(lambda x: (x, self.__getattribute__(x)), MeasureType)

        return sorted(
            [
                MonitoringPlanWeekScheduleEntry(
                    **{
                        **schedule.model_dump(),
                        "measureType": measure_type,
                        "_id": ObjectId(sha256(f"{schedule.weekday}{schedule.id}".encode("utf-8")).hexdigest()[0:24]),
                    }
                )
                for (measure_type, measure) in measure_objects
                if measure is not None
                for schedule in measure.week_schedule
            ],
            key=lambda s: (s.weekday, s.time),
        )

    async def get_schedule(
        self, /, start_date: datetime | None = None, end_date: datetime | None = None, timezone: BaseTzInfo = UTC
    ) -> List[MonitoringPlanScheduleEntry]:
        _start_date = self.effectiveDate if start_date is None or start_date < self.effectiveDate else start_date

        if end_date is not None and self.expirationDate is not None:
            _end_date = self.expirationDate if end_date > self.expirationDate else end_date
        elif self.expirationDate is None and end_date is not None:
            _end_date = end_date
        elif self.expirationDate is not None and end_date is None:
            _end_date = self.expirationDate
        else:
            raise ValueError("'end_date' must be provided or 'expirationDate' must be set")

        week_start_date = week_start(_start_date.date())
        week_schedule = self.week_schedule
        weeks = range(ceil((_end_date - _start_date).days / 7 + 1))

        weeks_start_date = map(lambda w: week_start_date + timedelta(days=7 * w), weeks)

        schedule_weeks = product(weeks_start_date, week_schedule)

        schedule_unfiltered = map(
            lambda s: MonitoringPlanScheduleEntryRaw(
                **{
                    **s[1].model_dump(),
                    "at": timezone.localize(datetime.combine(date=s[0] + timedelta(days=s[1].weekday), time=s[1].time)),
                }
            ),
            schedule_weeks,
        )

        schedule_raw = filter(lambda s: _start_date < s.at < _end_date, schedule_unfiltered)

        schedule = [await MonitoringPlanScheduleEntry.from_raw(t) for t in schedule_raw]

        return schedule

    @classmethod
    async def get_complete_schedule(
        cls, /, patient: DBPatient, start_date: datetime, end_date: datetime, timezone: BaseTzInfo
    ) -> List[MonitoringPlanScheduleEntry]:
        query = cls.find(
            cls.patientId == patient.id,
            Or(Eq(cls.expirationDate, None), GT(cls.expirationDate, start_date)),
            LT(cls.effectiveDate, end_date),
        )
        query = query_sort(query, "effectiveDate", ASCENDING)
        plans = await query.to_list()

        schedule = [await p.get_schedule(start_date=start_date, end_date=end_date, timezone=timezone) for p in plans]

        return [p for s in schedule for p in s]
