from pydantic import BaseModel

from .base import DBMonitoredMeasureBase, MonitoredMeasureBase, NewMonitoredMeasureBase


class MonitoredBloodPressureMeasureBase(BaseModel):
    limitMinSystolic: int | None = None
    limitMaxSystolic: int | None = None
    limitMinDiastolic: int | None = None
    limitMaxDiastolic: int | None = None


class NewMonitoredBloodPressureMeasure(MonitoredBloodPressureMeasureBase, NewMonitoredMeasureBase):
    pass


class MonitoredBloodPressureMeasure(
    MonitoredBloodPressureMeasureBase,
    MonitoredMeasureBase,
):
    pass


class DBMonitoredBloodPressureMeasure(MonitoredBloodPressureMeasureBase, DBMonitoredMeasureBase):
    pass
