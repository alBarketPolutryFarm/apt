from pydantic import BaseModel

from ss_api.models.base.id import IdBase, IdOptionalBase
from ss_api.models.enum import Weekday
from ss_api.utils.typing import NaiveTime


class NewMonitoredMeasureSchedule(BaseModel):
    time: NaiveTime
    weekday: Weekday | None = None


class MonitoredMeasureSchedule(IdBase, NewMonitoredMeasureSchedule):
    pass


class DBMonitoredMeasureSchedule(IdOptionalBase, MonitoredMeasureSchedule):
    pass
