from pydantic import BaseModel

from .base import DBMonitoredMeasureBase, MonitoredMeasureBase, NewMonitoredMeasureBase


class MonitoredGenericMeasureBase(BaseModel):
    limitMin: float | None = None
    limitMax: float | None = None


class NewMonitoredGenericMeasure(MonitoredGenericMeasureBase, NewMonitoredMeasureBase):
    pass


class MonitoredGenericMeasure(MonitoredGenericMeasureBase, MonitoredMeasureBase):
    pass


class DBMonitoredGenericMeasure(MonitoredGenericMeasureBase, DBMonitoredMeasureBase):
    pass
