from .blood_pressure import (
    DBMonitoredBloodPressureMeasure,
    MonitoredBloodPressureMeasure,
    NewMonitoredBloodPressureMeasure,
)
from .generic import (
    DBMonitoredGenericMeasure,
    MonitoredGenericMeasure,
    NewMonitoredGenericMeasure,
)
from .oxygen_saturation import (
    DBMonitoredOxygenSaturationMeasure,
    MonitoredOxygenSaturationMeasure,
    NewMonitoredOxygenSaturationMeasure,
)
from .pain import DBMonitoredPainMeasure, MonitoredPainMeasure, NewMonitoredPainMeasure

NewMonitoredMeasure = (
    NewMonitoredGenericMeasure
    | NewMonitoredOxygenSaturationMeasure
    | NewMonitoredPainMeasure
    | NewMonitoredBloodPressureMeasure
)

MonitoredMeasure = (
    MonitoredGenericMeasure | MonitoredOxygenSaturationMeasure | MonitoredPainMeasure | MonitoredBloodPressureMeasure
)

DBMonitoredMeasure = (
    DBMonitoredGenericMeasure
    | DBMonitoredOxygenSaturationMeasure
    | DBMonitoredPainMeasure
    | DBMonitoredBloodPressureMeasure
)
