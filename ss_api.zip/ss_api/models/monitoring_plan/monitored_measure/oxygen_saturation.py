from pydantic import BaseModel

from .base import DBMonitoredMeasureBase, MonitoredMeasureBase, NewMonitoredMeasureBase


class MonitoredOxygenSaturationMeasureBase(BaseModel):
    limitMin: int | None = None


class NewMonitoredOxygenSaturationMeasure(MonitoredOxygenSaturationMeasureBase, NewMonitoredMeasureBase):
    pass


class MonitoredOxygenSaturationMeasure(MonitoredOxygenSaturationMeasureBase, MonitoredMeasureBase):
    pass


class DBMonitoredOxygenSaturationMeasure(MonitoredOxygenSaturationMeasureBase, DBMonitoredMeasureBase):
    pass
