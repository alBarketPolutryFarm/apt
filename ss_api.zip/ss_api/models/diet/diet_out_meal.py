from datetime import datetime, timedelta, timezone

from beanie import Document, Granularity, PydanticObjectId, TimeSeriesConfig
from pydantic import BaseModel, Field
from pymongo import IndexModel

from ss_api.models.base.id import IdBase


class DietOutMealBase(BaseModel):
    description: str


class NewDietOutMeal(DietOutMealBase):
    at: datetime | None = Field(default_factory=lambda: datetime.now(timezone.utc))


class DietOutMeal(IdBase, DietOutMealBase):
    at: datetime


class DBDietOutMeal(Document, DietOutMeal):
    patientId: PydanticObjectId

    class Settings:
        name = "diet_out_meals"

        timeseries = TimeSeriesConfig(
            time_field="at",
            granularity=Granularity.minutes,
            expire_after_seconds=timedelta(days=365).total_seconds(),
        )
        indexes = [IndexModel("patientId")]
