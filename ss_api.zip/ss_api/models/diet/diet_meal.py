from pydantic import BaseModel

from ss_api.models.base.id import IdBase, IdOptionalBase


class NewDietMeal(BaseModel):
    description: str


class DietMeal(IdBase, NewDietMeal):
    pass


class DBDietMeal(IdOptionalBase, NewDietMeal):
    pass
