from .diet import DBDiet, Diet, NewDiet, NewDietBase
from .diet_adherence import DBDietAdherence, DietAdherence, NewDietAdherence
from .diet_out_meal import DBDietOutMeal, DietOutMeal, NewDietOutMeal

__timeseries_models__ = [DBDietAdherence, DBDietOutMeal]
__document_models__ = [DBDiet]
