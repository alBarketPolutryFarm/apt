from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone

from beanie.odm.operators.find.comparison import GT, LT
from pydantic import BaseModel

from ss_api.models.base.id import IdBase
from ss_api.models.diet.diet_adherence import DBDietAdherence, DietAdherence
from ss_api.models.diet.diet_meal import DietMeal
from ss_api.models.diet.diet_out_meal import DBDietOutMeal, DietOutMeal
from ss_api.utils.helpers.datetime import get_day_bounds


class DietScheduleMealEntryRaw(DietMeal):
    async def get_adherence(self, at: date = date.today()) -> DBDietAdherence | None:
        _at = datetime.combine(at, time(0, 0), timezone.utc)
        return await DBDietAdherence.find(
            DBDietAdherence.mealId == self.id,
            GT(DBDietAdherence.at, _at - timedelta(days=2)),
            LT(DBDietAdherence.at, _at + timedelta(days=3)),
        ).first_or_none()


class DietScheduleEntryRaw(IdBase, BaseModel):
    at: date

    breakfast: DietScheduleMealEntryRaw
    morningSnack: DietScheduleMealEntryRaw
    lunch: DietScheduleMealEntryRaw
    afternoonSnack: DietScheduleMealEntryRaw
    dinner: DietScheduleMealEntryRaw


class DietScheduleMealEntry(DietScheduleMealEntryRaw):
    adherence: DietAdherence | None

    @classmethod
    async def from_raw(cls, raw: DietScheduleMealEntryRaw, at: date = date.today()) -> DietScheduleMealEntry:
        return cls(**{**raw.model_dump(), "_id": raw.id}, adherence=await raw.get_adherence(at))


class DietScheduleEntry(DietScheduleEntryRaw):
    breakfast: DietScheduleMealEntry
    morningSnack: DietScheduleMealEntry
    lunch: DietScheduleMealEntry
    afternoonSnack: DietScheduleMealEntry
    dinner: DietScheduleMealEntry
    outMeals: list[DietOutMeal] | None = None

    @classmethod
    async def from_raw(cls, raw: DietScheduleEntryRaw) -> DietScheduleEntry:
        content = {
            **raw.model_dump(),
            "breakfast": (await DietScheduleMealEntry.from_raw(raw.breakfast, at=raw.at)).model_dump(),
            "morningSnack": (await DietScheduleMealEntry.from_raw(raw.morningSnack, at=raw.at)).model_dump(),
            "lunch": (await DietScheduleMealEntry.from_raw(raw.lunch, at=raw.at)).model_dump(),
            "afternoonSnack": (await DietScheduleMealEntry.from_raw(raw.afternoonSnack, at=raw.at)).model_dump(),
            "dinner": (await DietScheduleMealEntry.from_raw(raw.dinner, at=raw.at)).model_dump(),
        }

        day_start, day_end = get_day_bounds(raw.at, time(hour=3, tzinfo=timezone.utc))
        out_meals = await DBDietOutMeal.find(GT(DBDietOutMeal.at, day_start), LT(DBDietOutMeal.at, day_end)).to_list()
        if len(out_meals) != 0:
            content["outMeals"] = out_meals

        return cls(**content)
