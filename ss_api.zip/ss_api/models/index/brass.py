from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import (
    DBIndexMeasureBase,
    IndexMeasureBase,
    IndexMeasureMetadataBase,
    NewIndexMeasureBase,
    _IndexMeasureBase,
)
from .type import IndexMeasureType


class BrassIndexMeasureMetadata(IndexMeasureMetadataBase):
    type: Literal[IndexMeasureType.brass]


class NewBrassIndexMeasureMetadata(BrassIndexMeasureMetadata):
    pass


class _BrassIndexMeasureBase(_IndexMeasureBase):
    metadata: BrassIndexMeasureMetadata

    value: int = Field(ge=0)


class DBBrassIndexMeasure(_BrassIndexMeasureBase, DBIndexMeasureBase):
    pass


class BrassIndexMeasure(_BrassIndexMeasureBase, IndexMeasureBase):
    pass


class NewBrassIndexMeasure(NewIndexMeasureBase, _BrassIndexMeasureBase):
    metadata: NewBrassIndexMeasureMetadata
    __db_model__ = DBBrassIndexMeasure
