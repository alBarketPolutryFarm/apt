from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import (
    DBIndexMeasureBase,
    IndexMeasureBase,
    IndexMeasureMetadataBase,
    NewIndexMeasureBase,
    _IndexMeasureBase,
)
from .type import IndexMeasureType


class NPIIndexMeasureMetadata(IndexMeasureMetadataBase):
    type: Literal[IndexMeasureType.npi]


class NewNPIIndexMeasureMetadata(NPIIndexMeasureMetadata):
    pass


class _NPIIndexMeasureBase(_IndexMeasureBase):
    metadata: NPIIndexMeasureMetadata

    value: int = Field(ge=0, le=12)


class DBNPIIndexMeasure(_NPIIndexMeasureBase, DBIndexMeasureBase):
    pass


class NPIIndexMeasure(_NPIIndexMeasureBase, IndexMeasureBase):
    pass


class NewNPIIndexMeasure(NewIndexMeasureBase, _NPIIndexMeasureBase):
    metadata: NewNPIIndexMeasureMetadata
    __db_model__ = DBNPIIndexMeasure
