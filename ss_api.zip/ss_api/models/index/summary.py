from __future__ import annotations

from pydantic import BaseModel

from ss_api.models.index.barthel import BarthelIndexMeasure, DBBarthelIndexMeasure
from ss_api.models.index.braden import BradenIndexMeasure, DBBradenIndexMeasure
from ss_api.models.index.brass import BrassIndexMeasure, DBBrassIndexMeasure
from ss_api.models.index.conley import ConleyIndexMeasure, DBConleyIndexMeasure
from ss_api.models.index.must import DBMustIndexMeasure, MustIndexMeasure
from ss_api.models.index.npi import DBNPIIndexMeasure, NPIIndexMeasure
from ss_api.models.users import DBPatient


class DBIndexMeasuresSummary(BaseModel):
    barthel: DBBarthelIndexMeasure | None = None
    braden: DBBradenIndexMeasure | None = None
    brass: DBBrassIndexMeasure | None = None
    conley: DBConleyIndexMeasure | None = None
    must: DBMustIndexMeasure | None = None
    npi: DBNPIIndexMeasure | None = None

    @classmethod
    async def compute(cls, patient: DBPatient) -> DBIndexMeasuresSummary:
        return cls(
            barthel=await DBBarthelIndexMeasure.get_last(patient),
            braden=await DBBradenIndexMeasure.get_last(patient),
            brass=await DBBrassIndexMeasure.get_last(patient),
            conley=await DBConleyIndexMeasure.get_last(patient),
            must=await DBMustIndexMeasure.get_last(patient),
            npi=await DBNPIIndexMeasure.get_last(patient),
        )


class IndexMeasuresSummary(BaseModel):
    barthel: BarthelIndexMeasure | None = None
    braden: BradenIndexMeasure | None = None
    brass: BrassIndexMeasure | None = None
    conley: ConleyIndexMeasure | None = None
    must: MustIndexMeasure | None = None
    npi: NPIIndexMeasure | None = None
