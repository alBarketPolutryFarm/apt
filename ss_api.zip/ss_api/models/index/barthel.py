from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import (
    DBIndexMeasureBase,
    IndexMeasureBase,
    IndexMeasureMetadataBase,
    NewIndexMeasureBase,
    _IndexMeasureBase,
)
from .type import IndexMeasureType


class BarthelIndexMeasureMetadata(IndexMeasureMetadataBase):
    type: Literal[IndexMeasureType.barthel]


class NewBarthelIndexMeasureMetadata(BarthelIndexMeasureMetadata):
    pass


class _BarthelIndexMeasureBase(_IndexMeasureBase):
    metadata: BarthelIndexMeasureMetadata

    value: int = Field(ge=0, le=100)


class DBBarthelIndexMeasure(_BarthelIndexMeasureBase, DBIndexMeasureBase):
    pass


class BarthelIndexMeasure(_BarthelIndexMeasureBase, IndexMeasureBase):
    pass


class NewBarthelIndexMeasure(NewIndexMeasureBase, _BarthelIndexMeasureBase):
    metadata: NewBarthelIndexMeasureMetadata
    __db_model__ = DBBarthelIndexMeasure
