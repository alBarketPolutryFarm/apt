from enum import Enum


class Gender(str, Enum):
    female = "female"
    male = "male"
    other = "other"
    unknown = "unknown"
