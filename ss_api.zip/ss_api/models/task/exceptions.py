class TaskFail(Exception):
    pass
