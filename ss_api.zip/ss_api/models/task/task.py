from abc import abstractmethod
from datetime import UTC, datetime, time
from enum import Enum
from typing import Annotated, Self

from beanie import Document
from beanie.odm.operators.find.comparison import LT, Eq
from pydantic import Field
from pymongo import IndexModel

from ss_api.models.base import CreationOptionallyAnonymousBase, UpdatableBase
from ss_api.models.task.exceptions import TaskFail
from ss_api.utils.db import bson_encoders


class TaskStatus(str, Enum):
    scheduled = "scheduled"
    running = "running"
    done = "done"
    failed = "failed"


class Task(Document, CreationOptionallyAnonymousBase, UpdatableBase):
    at: datetime
    status: TaskStatus = TaskStatus.scheduled

    class Settings:
        is_root = True
        name = "tasks"
        bson_encoders = bson_encoders
        indexes = [IndexModel("at")]

    @abstractmethod
    async def do(self) -> None:
        pass

    async def perform(self):
        try:
            await self.before()
            await self.do()
            await self.after()
        except TaskFail:
            await self.failed()

    async def failed(self) -> None:
        self.status = TaskStatus.failed
        await self.save()

    async def before(self) -> None:
        self.status = TaskStatus.running
        await self.save()

    async def after(self) -> None:
        self.status = TaskStatus.done
        await self.save()

    @classmethod
    async def get_first_pending(cls) -> Self | None:
        return await (
            cls.find(with_children=True)
            .find(Eq(cls.status, TaskStatus.scheduled))
            .find(LT(cls.at, datetime.now(UTC)))
            .first_or_none()
        )


class PeriodicTask(Task):
    at: Annotated[datetime, Field(default_factory=lambda: datetime.combine(datetime.today().replace(day=1), time()))]

    @property
    @abstractmethod
    def next_schedule(self) -> datetime:
        pass

    async def after(self) -> None:
        self.at = self.next_schedule
        self.status = TaskStatus.scheduled
        await self.save()

    async def failed(self) -> None:
        self.status = TaskStatus.failed
        await self.save()
