from .task import PeriodicTask, Task

__document_models__ = [Task, PeriodicTask]
