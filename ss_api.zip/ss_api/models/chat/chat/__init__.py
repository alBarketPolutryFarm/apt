from .base import DBChatBase
from .broadcast_chat import BroadcastChat, DBBroadcastChat
from .service_chat import DBServiceChat, ServiceChat
from .users_chat import DBUsersChat, UsersChat

__document_models__ = [DBChatBase, DBUsersChat, DBServiceChat, DBBroadcastChat]

Chat = UsersChat | ServiceChat | BroadcastChat
DBChat = DBUsersChat | DBServiceChat | DBBroadcastChat
