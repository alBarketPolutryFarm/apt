from abc import ABC
from typing import Self, Type

from beanie import Document, PydanticObjectId
from beanie.odm.documents import DocType
from beanie.odm.operators.find.comparison import Eq, In
from beanie.odm.operators.find.logical import Or
from beanie.odm.queries.find import FindMany
from pydantic import computed_field, model_validator
from pymongo import IndexModel

from ss_api.models.base.creation import CreationAnonymousBase
from ss_api.models.base.id import IdBase
from ss_api.models.users import DBAdmin, DBUser
from ss_api.models.users.admin import DBSuperAdmin

from .type import ChatType


class CommonChatBase(CreationAnonymousBase, ABC):
    __chat_type__: ChatType


class ChatBase(IdBase, CommonChatBase, ABC):
    type: ChatType

    @model_validator(mode="before")
    @classmethod
    def set_type(cls, v: dict | Self):
        if isinstance(v, dict):
            return {"type": cls.__chat_type__, **v}
        return v


class DBChatBase(Document, CommonChatBase, ABC):
    @computed_field  # type: ignore[misc]
    @property
    def type(self) -> ChatType:
        return self.__chat_type__

    class Settings:
        name = "chats"
        indexes = [
            IndexModel("membersId", partialFilterExpression={"membersId": {"$type": "array"}}),
            IndexModel("_class_id"),
        ]
        is_root = True

    @classmethod
    def find_query(
        cls: Type[DocType],
        by: DBUser | None = None,
        id: PydanticObjectId | None = None,
        target: DBUser | PydanticObjectId | list[DBUser | PydanticObjectId] | None = None,
        only_private: bool = False,
    ) -> FindMany[DocType]:
        query = cls.find(with_children=True)

        if target is not None:
            _target = target if isinstance(target, list) else [target]
            for t in [p if isinstance(p, PydanticObjectId) else p.id for p in _target]:
                query = query.find(Eq("membersId", t))

        if only_private:
            query = query.find({"membersId": {"$size": 2}})

        # @DEPRECATED
        # if by is not None:

        #     if isinstance(by, DBAdmin):
        #         query = query.find(
        #             In("_class_id", [DBServiceChat._class_id, DBBroadcastChat._class_id]))
        #     else:
        #         query = query.find(Or(Eq("membersId", by.id), Eq(
        #             "_class_id", DBBroadcastChat._class_id)))

        if by is not None:
            from . import DBBroadcastChat, DBServiceChat

            if isinstance(by, (DBAdmin, DBSuperAdmin)):
                query = query.find(
                    Or(
                        In("membersId", [by.id]),
                        Eq("_class_id", DBServiceChat._class_id),
                        Eq("_class_id", DBBroadcastChat._class_id),
                    )
                )
            else:
                query = query.find(Or(Eq("membersId", by.id), Eq("_class_id", DBBroadcastChat._class_id)))

        if id is not None:
            query = query.find({"_id": id})

        return query
