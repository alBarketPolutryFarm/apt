from typing import Annotated, Literal

from beanie import PydanticObjectId
from pydantic import Field

from ...base import CreationBase
from .base import ChatBase, CommonChatBase, DBChatBase
from .type import ChatType


class UsersChatBase(CommonChatBase, CreationBase):
    __chat_type__ = ChatType.usersChat
    membersId: Annotated[list[PydanticObjectId], Field(min_length=2)]
    description: str | None = None


class UsersChat(ChatBase, UsersChatBase):
    type: Literal[ChatType.usersChat]


class DBUsersChat(DBChatBase, UsersChatBase):
    pass
