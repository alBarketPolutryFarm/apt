from abc import ABC
from typing import Literal

from .base import ChatBase, CommonChatBase, DBChatBase
from .type import ChatType


class BroadcastChatBase(CommonChatBase, ABC):
    __chat_type__ = ChatType.broadcastChat


class BroadcastChat(ChatBase, BroadcastChatBase):
    type: Literal[ChatType.broadcastChat]


class DBBroadcastChat(DBChatBase, BroadcastChatBase):
    pass
