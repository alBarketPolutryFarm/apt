from typing import Annotated, Literal

from beanie import PydanticObjectId
from pydantic import Field

from ...base import CreationBase
from .base import ChatBase, CommonChatBase, DBChatBase
from .type import ChatType


class ServiceChatBase(CreationBase, CommonChatBase):
    __chat_type__ = ChatType.serviceChat
    membersId: Annotated[list[PydanticObjectId], Field(min_length=1, max_length=1)]


class ServiceChat(ChatBase, ServiceChatBase):
    type: Literal[ChatType.serviceChat]


class DBServiceChat(DBChatBase, ServiceChatBase):
    pass
