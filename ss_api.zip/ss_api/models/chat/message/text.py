from typing import Literal

from .base import ChatMessage, ChatMessageBase, DBChatMessage, NewChatMessage
from .type import ChatMessageType


class ChatMessageTextBase(ChatMessageBase):
    __message_type__ = ChatMessageType.text

    message: str


class ChatMessageText(ChatMessage, ChatMessageTextBase):
    type: Literal[ChatMessageType.text]


class DBChatMessageText(DBChatMessage, ChatMessageTextBase):
    pass


class NewChatMessageText(NewChatMessage, ChatMessageTextBase):
    __db_model__ = DBChatMessageText

    type: Literal[ChatMessageType.text]
