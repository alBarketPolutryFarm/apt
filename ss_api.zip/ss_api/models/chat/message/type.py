from enum import StrEnum


class ChatMessageType(StrEnum):
    text = "text"
    booking_request = "bookingRequest"
