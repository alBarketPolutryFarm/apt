from __future__ import annotations

from typing import TYPE_CHECKING, Type

from beanie import Document, Insert, PydanticObjectId, before_event
from beanie.odm.documents import DocType
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from pydantic import BaseModel, ValidationError
from pymongo import DESCENDING, IndexModel

from ...utils.db import query_sort
from ..users.type import UserType

if TYPE_CHECKING:
    from ss_api.models.users import DBNurse, DBOperator, DBPatient, DBDoctor

from ss_api.models.base import (
    CreationBase,
    IdBase,
    NewValidityPeriodBase,
    ValidityPeriodBase,
)
from ss_api.models.base.revocable import RevocableBase


class PermissionBase(ValidityPeriodBase, BaseModel):
    targetId: PydanticObjectId


class RevokePermission(BaseModel):
    targetId: PydanticObjectId


class NewPermission(NewValidityPeriodBase, PermissionBase):
    pass


class Permission(IdBase, PermissionBase, RevocableBase, CreationBase):
    patientId: PydanticObjectId


class DBPermission(Document, PermissionBase, RevocableBase, CreationBase):
    patientId: PydanticObjectId

    class Settings:
        name = "permissions"
        indexes = [*Permission.Settings.indexes, IndexModel("patientId"), IndexModel("targetId")]

    @classmethod
    def find_query(
        cls: Type[DocType],
        /,
        patient: DBPatient | PydanticObjectId = None,
        target: DBOperator | DBNurse | DBDoctor | PydanticObjectId | None = None,
        active_only: bool = True,
        only_unique: bool = True,
    ) -> AggregationQuery[DocType]:
        query_find = cls.find_period() if active_only else cls.find_all()

        query = query_find.aggregate([], projection_model=cls)

        if patient is not None:
            query.aggregation_pipeline.append(
                {"$match": {"patientId": (patient if isinstance(patient, PydanticObjectId) else patient.id)}}
            )

        if target is not None:
            query.aggregation_pipeline.append(
                {"$match": {"targetId": (target if isinstance(target, PydanticObjectId) else target.id)}}
            )

        if only_unique:
            query.aggregation_pipeline.append(
                {
                    "$group": {
                        "_id": {"patientId": "$patientId", "targetId": "$targetId"},
                        "permission": {"$first": "$$ROOT"},
                    }
                }
            )
            query.aggregation_pipeline.append({"$replaceRoot": {"newRoot": "$permission"}})

        query = query_sort(query, "effectiveDate", DESCENDING)

        return query

    @classmethod
    async def get_current(
        cls: Type[DocType], patient: DBPatient | PydanticObjectId, target: DBOperator | DBNurse | DBDoctor
    ) -> DocType | None:
        query = cls.find_query(patient=patient, target=target, active_only=True)
        query = query_sort(query, "effectiveDate", DESCENDING)
        return await query.first_or_none()

    @before_event(Insert)
    async def check_before_insert(self):
        from ss_api.models.users import DBPatient, DBUserBase

        if await DBPatient.get(self.patientId) is None:
            raise ValidationError("Patient does not exist")

        if (t := await DBUserBase.get(self.targetId, with_children=True)) is None or (
            t.__user_type__ == UserType.patient or t.__user_type__ == UserType.admin
        ):
            raise ValidationError("Target does not exist")

    def find_revocable(self) -> FindMany:
        return (
            super()
            .find_revocable()
            .find(DBPermission.targetId == self.targetId, DBPermission.patientId == self.patientId)
        )
