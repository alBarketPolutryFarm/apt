from datetime import datetime
from typing import Self  # type: ignore

from beanie import Document, PydanticObjectId
from beanie.odm.enums import SortDirection
from beanie.odm.operators.find.logical import Or
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from pydantic import BaseModel, Field, model_validator
from pymongo import IndexModel

from ss_api.models.base.creation import CreationBase
from ss_api.models.base.id import IdBase
from ss_api.models.users import DBAdmin, DBSuperAdmin, DBUserBase
from ss_api.models.utils.db import DBQuery
from ss_api.utils.query_string import DateRangeData
from ss_api.utils.typing.secret import Secret


class NewBooking(BaseModel):
    providerId: PydanticObjectId
    targetId: PydanticObjectId
    description: str
    at: datetime
    isRemote: bool | None = Field(False)


class Booking(IdBase, CreationBase, NewBooking):
    isRemote: bool
    remoteLink: Secret | None = None


class DBBooking(Document, Booking):
    class Settings:
        name = "bookings"
        indexes = [IndexModel("at"), IndexModel("providerId"), IndexModel("targetId")]

    @model_validator(mode="before")
    @classmethod
    def create_remote_link(cls, values):
        if values.get("isRemote") is True and values.get("remoteLink") is None:
            values["remoteLink"] = Secret(f"https://meet.jit.si/servizio-salute-{Secret.random(64)}")

        return values

    @classmethod
    def find_query(
        cls,
        user: DBUserBase | None = None,
        id: PydanticObjectId | None = None,
        sort: SortDirection | None = SortDirection.DESCENDING,
    ) -> FindMany[Self]:
        query = cls.find()

        if id is not None:
            query = query.find({"_id": id})

        if not isinstance(user, (DBAdmin, DBSuperAdmin)):
            if user is not None:
                query = query.find(Or({"targetId": user.id}, {"providerId": user.id}))
            else:
                raise ValueError("User must be provided to query bookings")

        if sort is not None:
            query = query.sort(("at", sort))

        return query

    @staticmethod
    def __filter_by_data_range__(query: DBQuery, date_range: DateRangeData) -> DBQuery:
        if isinstance(query, AggregationQuery):
            if date_range.start is not None:
                query.aggregation_pipeline.append({"$match": {"at": {"$gt": date_range.start}}})
            if date_range.end is not None:
                query.aggregation_pipeline.append({"$match": {"at": {"$lt": date_range.end}}})
            return query

        else:
            if date_range.start is not None:
                query = query.find({"at": {"$gt": date_range.start}})
            if date_range.end is not None:
                query = query.find({"at": {"$lt": date_range.end}})
            return query
