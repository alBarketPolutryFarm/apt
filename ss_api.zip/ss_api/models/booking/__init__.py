from .booking import Booking, DBBooking, NewBooking

__document_models__ = [DBBooking]
