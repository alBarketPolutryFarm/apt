class AgreementSigningError(Exception):
    pass


class MissingAgreementSigningOptions(AgreementSigningError):
    pass


class AgreementAlreadySigned(AgreementSigningError):
    pass
