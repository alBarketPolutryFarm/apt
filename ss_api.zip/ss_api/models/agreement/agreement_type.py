from enum import Enum


class AgreementType(str, Enum):
    privacy = "privacy"
    tos = "tos"
