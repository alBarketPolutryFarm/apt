from .agreement import DBAgreement
from .agreement_signing import DBAgreementSigning

__document_models__ = [DBAgreement, DBAgreementSigning]
