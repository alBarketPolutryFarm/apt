from abc import ABC
from datetime import datetime, timezone
from typing import Any, Dict, Type

from beanie import Document, PydanticObjectId
from beanie.odm.documents import DocType
from beanie.odm.enums import SortDirection
from beanie.odm.operators.find.comparison import Eq
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.find import FindMany
from pydantic import BaseModel

from ss_api.models.base import CreationAnonymousBase
from ss_api.models.permissions import DBPermission
from ss_api.models.users import DBAdmin, DBUser
from ss_api.models.utils.db import DBQuery
from ss_api.utils.db import bson_encoders
from ss_api.utils.query_string import DateRangeData

from ..base.id import IdBase


class Handling(BaseModel):
    at: datetime
    by: PydanticObjectId

    def __init__(self, **data: Any):
        super().__init__(**{"at": datetime.now(tz=timezone.utc), **data})


class _AlarmBase(CreationAnonymousBase, BaseModel, ABC):
    __alarm_type__: str

    description: str
    patientId: PydanticObjectId
    handling: Handling | None = None


class AlarmBase(IdBase, _AlarmBase, ABC):
    pass


class DBAlarmBase(Document, _AlarmBase, ABC):
    class Settings:
        is_root = True
        name = "alarms"
        bson_encoders = bson_encoders

    def dict(self, /, **kwargs) -> Dict[str, Any]:
        return {"type": self.__alarm_type__, **super().dict(**kwargs)}

    @classmethod
    def find_query(
        cls: Type[DocType], user: DBUser | None = None, only_unhandled: bool = False
    ) -> FindMany[DocType] | AggregationQuery[DocType]:
        if user is not None and not isinstance(user, DBAdmin):
            query = DBPermission.find_query(target=user)
            query.aggregation_pipeline.extend(
                [
                    {
                        "$lookup": {
                            "from": "alarms",
                            "localField": "patientId",
                            "foreignField": "patientId",
                            "as": "alarms",
                        }
                    },
                    {"$unwind": {"path": "$alarms"}},
                    {"$replaceRoot": {"newRoot": {"$mergeObjects": ["$alarms"]}}},
                    *([{"$match": {"handling": None}}] if only_unhandled else []),
                    {"$sort": {"createdAt": -1}},
                ]
            )
            query.projection_model = cls
            return query
            # return DBPermission.find_query(target=user).aggregate(
            #     [
            #         {
            #             "$lookup": {
            #                 "from": "alarms",
            #                 "localField": "patientId",
            #                 "foreignField": "patientId",
            #                 "as": "alarms",
            #             }
            #         },
            #         {"$unwind": {"path": "$alarms"}},
            #         {"$replaceRoot": {"newRoot": {"$mergeObjects": ["$alarms"]}}},
            #         *([{"$match": {"handling": None}}] if only_unhandled else []),
            #         {"$sort": {"createdAt": -1}},
            #     ],
            #     projection_model=cls,
            # )

        query = cls.find(with_children=True)

        if only_unhandled:
            query = query.find(Eq(cls.handling, None))

        return query.sort(("createdAt", SortDirection.DESCENDING))

    @staticmethod
    def __filter_by_data_range__(query: DBQuery, date_range: DateRangeData) -> DBQuery:
        return CreationAnonymousBase.__filter_by_data_range__(query, date_range)
