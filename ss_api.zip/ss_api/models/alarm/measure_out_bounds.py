from typing import Literal

from pydantic import computed_field

from ..measures import Measure
from ..monitoring_plan import DBMonitoredMeasure, MonitoredMeasure
from .alarm_type import AlarmType
from .base import AlarmBase, DBAlarmBase, _AlarmBase


class MeasureOutOfBoundsAlarmBase(_AlarmBase):
    __alarm_type__ = AlarmType.measure_out_bounds

    measure: Measure


class MeasureOutOfBoundsAlarm(AlarmBase, MeasureOutOfBoundsAlarmBase):
    type: Literal[AlarmType.measure_out_bounds]
    plan: MonitoredMeasure


class DBMeasureOutOfBoundsAlarm(DBAlarmBase, MeasureOutOfBoundsAlarmBase):
    measure: Measure
    plan: DBMonitoredMeasure

    def __init__(self, **data):
        super().__init__(**{"description": "Measure exceeds the bounds", **data})

    @computed_field  # type: ignore[misc]
    @property
    def type(self) -> AlarmType:
        return self.__alarm_type__
