from datetime import datetime
from typing import List, Literal

from pydantic import BaseModel

from ss_api.models.users.type import UserType


class MonthlyTrend(BaseModel):
    month: datetime
    value: int


class MetricTrend(BaseModel):
    metric_name: str
    trend_data: List[MonthlyTrend]


class AdminMetrics(BaseModel):
    type: Literal[UserType.admin]
    admin_id: str
    name: str
    active_users: int
    active_assistants: int
    managed_alerts: int
    created_care_plans: int
    completed_care_plans: int
    active_care_plans: int
    deaths: int
    hospitalizations: int
    recoveries: int
    administrative_closures: int
    infections: int
    generated_reports: int
    trends: List[MetricTrend] or None


class SuperAdminMetrics(BaseModel):
    type: Literal[UserType.superadmin]
    total_registered_admins: int
    admins_data: List[AdminMetrics]


class MetricDownloadResponse(BaseModel):
    month: str
    value: int
    admin_id: str | None = None
