from datetime import datetime, timezone
from typing import Self

from beanie import Document, PydanticObjectId
from pymongo import IndexModel

from ss_api.models.file.exceptions import FileAlreadyClaimed

from .file import DBFile


class DBFileTemp(Document, DBFile):
    claimed: bool = False
    claimedAt: datetime | None = None

    class Settings:
        name = "files"
        indexes = [IndexModel("ownerId")]

    async def claim(self, ownerId: PydanticObjectId = None) -> None:
        if self.claimed:
            raise FileAlreadyClaimed

        if ownerId is not None:
            await self.change_owner(ownerId)

        self.claimedAt = datetime.now(timezone.utc)
        self.claimed = True

        await self.save()

    async def change_owner(self, ownerId: PydanticObjectId):
        await super().change_owner(ownerId=ownerId)

        await self.save()

    @classmethod
    async def new(
        cls, ownerId: PydanticObjectId, content: bytes = b"", claim: bool = False, autosave: bool = True, **kwargs
    ) -> Self:
        db_file = await super().new(content=content, ownerId=ownerId, **kwargs)

        if claim:
            db_file.claimedAt = datetime.now(timezone.utc)
            db_file.claimed = True

        if autosave:
            await db_file.create()

        return db_file
