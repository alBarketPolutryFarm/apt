from base64 import b64encode
from contextlib import contextmanager
from os import makedirs
from pathlib import Path
from shutil import copy2
from typing import Self

from beanie import PydanticObjectId
from fastapi import UploadFile
from pydantic import PositiveInt, model_validator

from ss_api.models.base.creation import CreationBase
from ss_api.models.base.id import IdBase
from ss_api.utils.settings import get_settings

from .response import FileEncoded


class FileBase(CreationBase):
    path: Path
    filename: str
    contentType: str

    ownerId: PydanticObjectId


class File(FileBase, IdBase):
    size: PositiveInt


class DBFile(FileBase, IdBase):
    size: PositiveInt | None = None

    @model_validator(mode="after")
    def auto_compute_size(self) -> Self:
        if self.size is None:
            self._compute_size()
        return self

    def _compute_size(self) -> None:
        self.size = self.absolute_path.stat().st_size

    async def change_owner(self, ownerId: PydanticObjectId):
        file_path = get_settings().storage_path / str(ownerId) / str(self.id)

        makedirs(file_path.parent, exist_ok=True)

        copy2(self.absolute_path, file_path)

        settings = get_settings()

        self.path = file_path.relative_to(settings.storage_path)
        self.ownerId = ownerId

    @property
    def absolute_path(self) -> Path:
        return get_settings().storage_path / self.path

    @property
    def base64(self) -> str:
        return b64encode(self.absolute_path.read_bytes()).decode("utf-8")

    @property
    def encoded(self) -> FileEncoded:
        return FileEncoded(
            content=self.base64,
            mediaType=self.contentType,
            filename=self.filename,
        )

    @classmethod
    async def upload(cls, file: UploadFile, **kwargs) -> Self:
        return await cls.new(content=await file.read(), filename=file.filename, contentType=file.content_type, **kwargs)

    @classmethod
    async def new(cls, ownerId: PydanticObjectId, content: bytes = b"", **kwargs) -> Self:
        settings = get_settings()
        file_id = PydanticObjectId()
        file_path = settings.storage_path / str(ownerId) / str(file_id)

        makedirs(file_path.parent, exist_ok=True)

        with open(file_path, "x+b") as fs_file:
            fs_file.write(content)

        db_file = cls(
            id=file_id,
            path=file_path.relative_to(settings.storage_path),
            ownerId=ownerId,
            **kwargs,
        )

        return db_file

    @contextmanager
    def open(self, mode="rb", **kwargs):
        file = self.absolute_path.open(mode=mode, **kwargs)
        try:
            yield file
        finally:
            file.close()
            self._compute_size()
