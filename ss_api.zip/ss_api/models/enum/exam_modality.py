from enum import StrEnum


class ExamModality(StrEnum):
    ECG = "ECG"
