import random
import string
from datetime import datetime, timedelta, timezone

from beanie import Document, PydanticObjectId
from fastapi import BackgroundTasks
from pydantic import EmailStr, Field

from ss_api.templates import jinja_env
from ss_api.utils.communications.mail import send_mail_async


class OTP(Document):
    userId: PydanticObjectId
    code: str
    email: EmailStr
    expiresAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc) + timedelta(minutes=10))

    class Settings:
        name = "otp"

    @staticmethod
    def generate_otp(length=6):
        return "".join(random.choices(string.digits, k=length))

    @staticmethod
    async def send_otp_email(email: EmailStr, otp: str, background_tasks: BackgroundTasks):
        try:
            template = jinja_env.get_template("./email/otp_verification.html")
            body = template.render(otp=otp)

            background_tasks.add_task(
                send_mail_async, email=email, subject="Servizio Salute | Codice di verifica", body=body
            )
        except Exception as e:
            print(e)
