# __init__.py
from .otp import OTP

__document_models__ = [OTP]

OTP = OTP
