from .revocation import Revocation, RevocationReason
