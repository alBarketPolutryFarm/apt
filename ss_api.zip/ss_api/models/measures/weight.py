from abc import ABC
from enum import Enum
from typing import Literal

from pydantic import Field

from .base import (
    DBMeasureBase,
    GetMeasureBase,
    MeasureBase,
    MeasureMetadataBase,
    NewMeasureBase,
)
from .type import MeasureType


class WeightUnit(str, Enum):
    KG = "kg"


class WeightMetadata(MeasureMetadataBase):
    type: Literal[MeasureType.weight]
    unit: WeightUnit


class NewWeightMetadata(WeightMetadata):
    unit: WeightUnit = WeightUnit.KG


class _WeightBase(MeasureBase, ABC):
    metadata: WeightMetadata

    value: float = Field(fe=0)


class DBWeight(_WeightBase, DBMeasureBase):
    pass


class Weight(_WeightBase, GetMeasureBase):
    pass


class NewWeight(NewMeasureBase, _WeightBase):
    metadata: NewWeightMetadata
    __db_model__ = DBWeight
