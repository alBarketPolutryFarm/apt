from abc import ABC
from enum import Enum
from typing import Literal

from pydantic import Field

from .base import (
    DBMeasureBase,
    GetMeasureBase,
    MeasureBase,
    MeasureMetadataBase,
    NewMeasureBase,
)
from .type import MeasureType


class RespiratoryRateUnit(str, Enum):
    BREATHS_PER_MINUTE = "bpm"


class RespiratoryRateMetadata(MeasureMetadataBase):
    type: Literal[MeasureType.respiratoryRate]
    unit: RespiratoryRateUnit


class NewRespiratoryRateMetadata(RespiratoryRateMetadata):
    unit: RespiratoryRateUnit = RespiratoryRateUnit.BREATHS_PER_MINUTE


class _RespiratoryRateBase(MeasureBase, ABC):
    metadata: RespiratoryRateMetadata

    value: int = Field(ge=0)


class DBRespiratoryRate(_RespiratoryRateBase, DBMeasureBase):
    pass


class RespiratoryRate(_RespiratoryRateBase, GetMeasureBase):
    pass


class NewRespiratoryRate(NewMeasureBase, _RespiratoryRateBase):
    metadata: NewRespiratoryRateMetadata
    __db_model__ = DBRespiratoryRate
