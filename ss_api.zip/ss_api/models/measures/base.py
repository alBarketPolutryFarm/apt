from __future__ import annotations

from abc import ABC
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Type

from beanie import Document, Granularity, PydanticObjectId, TimeSeriesConfig
from pydantic import BaseModel, Field
from pymongo import IndexModel

from ..base.id import IdBase
from ..users import DBPatient
from .type import MeasureType

if TYPE_CHECKING:
    from ..monitoring_plan.monitored_measure import DBMonitoredGenericMeasure


class MeasureMetadataBase(BaseModel, ABC):
    unit: str
    type: MeasureType


class MeasureBase(BaseModel, ABC):
    metadata: MeasureMetadataBase
    timestamp: datetime
    notes: str | None = None

    def is_out_of_bounds(self, plan: DBMonitoredGenericMeasure) -> bool:
        if (v := self.__dict__.get("value")) is not None:
            if plan.limitMin is not None and v < plan.limitMin:
                return True
            if plan.limitMax is not None and v > plan.limitMax:
                return True

            return False

        raise NotImplementedError


class DBMeasureBase(Document, MeasureBase, ABC):
    patientId: PydanticObjectId

    class Settings:
        is_root = True
        name = "measures"

        timeseries = TimeSeriesConfig(
            time_field="timestamp",
            meta_field="metadata",
            granularity=Granularity.minutes,
            expire_after_seconds=timedelta(days=365).total_seconds(),
        )
        indexes = [IndexModel("patientId")]

    @classmethod
    async def get_last(cls, patient: DBPatient | PydanticObjectId) -> DBMeasureBase:
        return (
            await cls.find(cls.patientId == (patient.id if isinstance(patient, DBPatient) else patient))
            .sort(-cls.timestamp)  # type: ignore
            .first_or_none()
        )


class GetMeasureBase(IdBase, MeasureBase, ABC):
    pass


class NewMeasureBase(MeasureBase, ABC):
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=timezone.utc))

    __db_model__: Type[DBMeasureBase]

    @classmethod
    def get_db_model(cls) -> Type[DBMeasureBase]:
        return cls.__db_model__
