from abc import ABC
from enum import Enum
from typing import Literal

from pydantic import Field

from .base import (
    DBMeasureBase,
    GetMeasureBase,
    MeasureBase,
    MeasureMetadataBase,
    NewMeasureBase,
)
from .type import MeasureType


class PulseUnit(str, Enum):
    BEATS_PER_MINUTE = "bpm"


class PulseMetadata(MeasureMetadataBase):
    type: Literal[MeasureType.pulse]
    unit: PulseUnit


class NewPulseMetadata(PulseMetadata):
    unit: PulseUnit = PulseUnit.BEATS_PER_MINUTE


class _PulseBase(MeasureBase, ABC):
    metadata: PulseMetadata

    value: int = Field(ge=0)


class DBPulse(_PulseBase, DBMeasureBase):
    pass


class Pulse(_PulseBase, GetMeasureBase):
    pass


class NewPulse(NewMeasureBase, _PulseBase):
    metadata: NewPulseMetadata
    __db_model__ = DBPulse
