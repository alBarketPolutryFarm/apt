from __future__ import annotations

from abc import ABC
from enum import Enum
from typing import TYPE_CHECKING, Literal

from pydantic import Field

from .base import (
    DBMeasureBase,
    GetMeasureBase,
    MeasureBase,
    MeasureMetadataBase,
    NewMeasureBase,
)
from .type import MeasureType

if TYPE_CHECKING:
    from ..monitoring_plan.monitored_measure import DBMonitoredPainMeasure


class PainUnit(str, Enum):
    NRS = "NRS"


class PainMetadata(MeasureMetadataBase):
    type: Literal[MeasureType.pain]
    unit: PainUnit


class NewPainMetadata(PainMetadata):
    unit: PainUnit = PainUnit.NRS


class _PainBase(MeasureBase, ABC):
    metadata: PainMetadata

    value: int = Field(ge=0, le=10)

    def is_out_of_bounds(self, plan: DBMonitoredPainMeasure | None) -> bool:
        if plan is None:
            return False

        if plan.limitMax is not None and plan.limitMax <= self.value:
            return True

        return False


class DBPain(_PainBase, DBMeasureBase):
    pass


class Pain(_PainBase, GetMeasureBase):
    pass


class NewPain(NewMeasureBase, _PainBase):
    metadata: NewPainMetadata
    __db_model__ = DBPain
