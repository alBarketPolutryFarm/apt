from __future__ import annotations

from abc import ABC
from enum import Enum
from typing import TYPE_CHECKING, Annotated, Literal

from pydantic import Field

from .base import (
    DBMeasureBase,
    GetMeasureBase,
    MeasureBase,
    MeasureMetadataBase,
    NewMeasureBase,
)
from .type import MeasureType

if TYPE_CHECKING:
    from ..monitoring_plan.monitored_measure import DBMonitoredBloodPressureMeasure


class BloodPressureUnit(str, Enum):
    MM_HG = "mmHg"


class BloodPressureMetadata(MeasureMetadataBase):
    type: Literal[MeasureType.bloodPressure]
    unit: BloodPressureUnit


class NewBloodPressureMetadata(BloodPressureMetadata):
    unit: BloodPressureUnit = BloodPressureUnit.MM_HG


class _BloodPressureBase(MeasureBase, ABC):
    metadata: BloodPressureMetadata

    diastolic: Annotated[int, Field(ge=0)]
    systolic: Annotated[int, Field(ge=0)]

    def is_out_of_bounds(self, plan: DBMonitoredBloodPressureMeasure | None) -> bool:
        if plan is None:
            return False

        if plan.limitMinSystolic is not None and self.systolic < plan.limitMinSystolic:
            return True
        if plan.limitMaxSystolic is not None and plan.limitMaxSystolic < self.systolic:
            return True
        if plan.limitMinDiastolic is not None and self.diastolic < plan.limitMinDiastolic:
            return True
        if plan.limitMaxDiastolic is not None and plan.limitMaxDiastolic < self.diastolic:
            return True

        return False


class DBBloodPressure(_BloodPressureBase, DBMeasureBase):
    pass


class BloodPressure(_BloodPressureBase, GetMeasureBase):
    pass


class NewBloodPressure(NewMeasureBase, _BloodPressureBase):
    metadata: NewBloodPressureMetadata
    __db_model__ = DBBloodPressure
