from __future__ import annotations

from abc import ABC
from enum import Enum
from typing import TYPE_CHECKING, Literal

from pydantic import Field

from .base import (
    DBMeasureBase,
    GetMeasureBase,
    MeasureBase,
    MeasureMetadataBase,
    NewMeasureBase,
)
from .type import MeasureType

if TYPE_CHECKING:
    from ..monitoring_plan.monitored_measure import DBMonitoredOxygenSaturationMeasure


class OxygenSaturationUnit(str, Enum):
    PERCENTAGE = "%"


class OxygenSaturationMetadata(MeasureMetadataBase):
    type: Literal[MeasureType.oxygenSaturation]
    unit: OxygenSaturationUnit


class NewOxygenSaturationMetadata(OxygenSaturationMetadata):
    unit: OxygenSaturationUnit = OxygenSaturationUnit.PERCENTAGE


class _OxygenSaturationBase(MeasureBase, ABC):
    metadata: OxygenSaturationMetadata

    value: int = Field(ge=0, le=100)

    def is_out_of_bounds(self, plan: DBMonitoredOxygenSaturationMeasure | None) -> bool:
        if plan is None:
            return False

        if plan.limitMin is not None and self.value < plan.limitMin:
            return True

        return False


class DBOxygenSaturation(_OxygenSaturationBase, DBMeasureBase):
    pass


class OxygenSaturation(_OxygenSaturationBase, GetMeasureBase):
    pass


class NewOxygenSaturation(NewMeasureBase, _OxygenSaturationBase):
    metadata: NewOxygenSaturationMetadata
    __db_model__ = DBOxygenSaturation
