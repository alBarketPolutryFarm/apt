from fastapi import APIRouter

router = APIRouter(prefix="/structure", tags=["structure"])
