from fastapi import APIRouter
from starlette.responses import Response

from ss_api.models.treatment_plan.treatment_plan import (
    DBTreatmentPlan,
    TreatmentPlan,
    TreatmentPlanWeekSchedule,
)
from ss_api.utils.auth import AuthPatient

router = APIRouter(prefix="/current")


@router.get(
    "",
    response_model=TreatmentPlan,
    responses={204: {"description": "No active treatment plan at the moment"}},
)
async def get_current_treatment_plan(patient: AuthPatient) -> DBTreatmentPlan | Response:
    return (await DBTreatmentPlan.get_current(patient=patient)) or Response(status_code=204)


@router.get(
    "/week-schedule",
    response_model=TreatmentPlanWeekSchedule,
    responses={204: {"description": "No active treatment plan at the moment"}},
)
async def get_current_treatment_plan_week_schedule(
    patient: AuthPatient,
) -> TreatmentPlanWeekSchedule | Response:
    treatment_plan = await DBTreatmentPlan.get_current(patient=patient)
    if treatment_plan is None:
        return Response(status_code=204)

    return treatment_plan.week_schedule
