from datetime import datetime, timedelta, timezone

from fastapi import APIRouter

from ss_api.models.treatment_plan.treatment_intake import (
    DBTreatmentIntake,
    NewTreatmentIntake,
)
from ss_api.models.treatment_plan.treatment_plan import DBTreatmentPlan
from ss_api.models.treatment_plan.treatment_plan_schedule import TreatmentPlanSchedule
from ss_api.utils.auth import AuthPatient
from ss_api.utils.headers import HeaderTimeZone
from ss_api.utils.query_string.date_range import query_date_range
from ss_api.utils.responses import Success

router = APIRouter(prefix="/schedule")


@router.get("", response_model=TreatmentPlanSchedule, response_model_exclude_none=True)
async def get_schedule(
    patient: AuthPatient,
    timezone: HeaderTimeZone,
    date_range=query_date_range(
        default_factory_start_date=lambda: datetime.now(timezone.utc),
        default_factory_end_date=lambda: datetime.now(timezone.utc) + timedelta(days=7),
    ),
) -> TreatmentPlanSchedule:
    return await DBTreatmentPlan.get_complete_schedule(
        patient=patient, start_date=date_range.start, end_date=date_range.end, timezone=timezone
    )


@router.post("/intake", response_model=Success, status_code=201)
async def intake_treatment(treatment_intake: NewTreatmentIntake, patient: AuthPatient) -> Success:
    # TODO: check if the treatment is scheduled
    await DBTreatmentIntake(**treatment_intake.model_dump(), patientId=patient.id).insert()
    return Success()
