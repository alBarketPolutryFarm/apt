__all__ = ["router"]

from . import current, schedule, side_effects
from .routes import router

router.include_router(side_effects.router)
router.include_router(schedule.router)
router.include_router(current.router)
