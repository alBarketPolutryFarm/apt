from typing import Annotated, List

from accept_types import accept_types
from beanie import PydanticObjectId
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Response
from fastapi.responses import HTMLResponse, JSONResponse
from pymongo import DESCENDING
from starlette.responses import FileResponse

from ss_api.models.file import FileEncoded
from ss_api.models.file.file_temp import DBFileTemp
from ss_api.models.report import DBReport, DBReportBase, Report
from ss_api.models.report.external_report import DBExternalReport
from ss_api.templates import jinja_env
from ss_api.utils.auth import AuthPatient, AuthUser
from ss_api.utils.communications.mail import send_mail_async
from ss_api.utils.db import query_sort
from ss_api.utils.depends import QueryPatient
from ss_api.utils.headers import HeaderAccept
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.report.patient_data_report import generate_ehr_report

router = APIRouter(prefix="/reports", tags=["reports"])


@router.get("", response_model=List[Report])
async def get_reports_list(
    pagination: QueryPagination,
    patient: AuthPatient,
    date_range=query_date_range(),
) -> List[DBReport]:
    query = DBReportBase.find_query(by=patient)
    query = query_sort(query, "date", DESCENDING)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    return await query.to_list()


def query_report() -> DBReportBase:
    async def _get_report(report_id: PydanticObjectId, patient: AuthPatient) -> DBReportBase:
        try:
            return (await DBReportBase.find_query(id=report_id, by=patient).to_list())[0]
        except IndexError:
            raise HTTPException(status_code=404, detail="Report not found")

    return Depends(_get_report)


QueryReport = Annotated[DBReport, query_report()]


@router.get("/{report_id}", response_model=Report)
async def get_report(report: QueryReport) -> DBReport:
    return report


@router.get("/{report_id}/file", response_model=FileEncoded, responses={200: {"content": {"application/pdf": {}}}})
async def get_report_file(report: QueryReport, accept: HeaderAccept) -> FileEncoded | FileResponse:
    await report.fetch_all_links()

    if report.file is None:
        raise FileNotFoundError

    if accept_types.get_best_match(accept, ["application/pdf", "application/json"]) == "application/pdf":
        return FileResponse(
            path=report.file.absolute_path, media_type=report.file.contentType, filename=report.file.filename
        )

    return report.file.encoded


@router.get("/{report_id}/exam", response_model=FileEncoded, responses={200: {"content": {"application/zip": {}}}})
async def get_report_exam(report: QueryReport, accept: HeaderAccept) -> FileEncoded | Response:
    # if not isinstance(report, DBExamReport):
    #     raise HTTPException(status_code=404, detail="Report not found")

    if accept_types.get_best_match(accept, ["application/zip", "application/json"]) == "application/zip":
        return Response(content=report.exam.get_file(), media_type="application/zip", status_code=200)

    return report.exam.get_encoded_file()


@router.post("/{patient_id}/ehr_saved", response_class=JSONResponse)
async def save_ehr_report(patient: QueryPatient, user: AuthUser) -> JSONResponse:
    try:
        id = user.id
        pdf_content = await generate_ehr_report(patient)
        file_data = await DBFileTemp.new(
            ownerId=id,
            filename="ehr_report.pdf",
            contentType="application/pdf",
            createdBy=id,
            content=pdf_content,
            claim=True,
        )

        report = DBExternalReport(
            patientId=patient.id,
            createdBy=id,
            date=file_data.createdAt.date(),
            description="info_Referto",
            file=file_data,
        )
        await report.save()

        return JSONResponse({"message": "EHR report generated and saved successfully."}, status_code=201)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating and saving EHR report: {str(e)}")


@router.post("/{patient_id}/ehr", response_class=HTMLResponse)
async def ehr_report(
    patient: QueryPatient,
    _: AuthUser,
    background_tasks: BackgroundTasks,
):
    pdf_content = await generate_ehr_report(patient)
    data_files = []
    reports = await DBReportBase.find_query(patientId=patient.id).to_list()
    data_files.append({"file_name": "ehr_report.pdf", "content": pdf_content})
    for report in reports:
        try:
            if report.file.contentType != "application/pdf":
                continue
            else:
                with open(report.file.absolute_path, "rb") as f:
                    file_content = f.read()
                data_files.append({"file_name": report.file.filename, "content": file_content})
        except Exception as e:
            print(f"Error reading file: {str(e)}")

    template = jinja_env.get_template("./reports/report_attached.html")
    body = template.render()

    background_tasks.add_task(
        send_mail_async, patient.email, "Your Electronic Health Record", body, attachment=data_files
    )
    return JSONResponse(
        {"message": "EHR report generation initiated. An email will be sent to the patient shortly."},
        status_code=201,
    )
