import asyncio

from fastapi import APIRouter, BackgroundTasks, HTTPException
from pydantic import BaseModel

from ss_api.templates import jinja_env
from ss_api.utils.auth import AuthUser
from ss_api.utils.communications.mail import send_mail_async
from ss_api.utils.responses import Success
from ss_api.utils.typing import Password, Secret

router = APIRouter(prefix="/change-password")


class ChangePasswordPayload(BaseModel):
    currentPassword: Secret
    newPassword: Password


@router.post("", response_model=Success)
async def change_password(body: ChangePasswordPayload, user: AuthUser, background_task=BackgroundTasks) -> Success:
    if not user.check_password(body.currentPassword):
        raise HTTPException(status_code=403, detail="Wrong old password")

    user.update_password(body.newPassword)
    await user.save()

    template = jinja_env.get_template("./email/password_updated.html")
    body = template.render()

    loop = asyncio.get_event_loop()
    loop.create_task(send_mail_async(user.email, "La tua password è stata cambiata", body))
    return Success("Password was changed")
