from fastapi import APIRouter

from ss_api.models.users import User
from ss_api.utils.auth import AuthUser

from .change_password import router as change_password_router
from .forgot_password import router as forgot_password_router

router = APIRouter(prefix="/user", tags=["user"])


@router.get("", response_model=User, response_model_exclude_none=True, response_model_exclude_unset=True)
def get_current_user(user: AuthUser):
    return user


router.include_router(forgot_password_router)
router.include_router(change_password_router)
