from fastapi import APIRouter
from starlette.responses import Response

from ss_api.models.medical_record.medical_record import DBMedicalRecord, MedicalRecord
from ss_api.utils.auth import AuthPatient

router = APIRouter(prefix="/medical-record", tags=["medical records"])


@router.get("", response_model=MedicalRecord)
async def get_medical_record(patient: AuthPatient) -> DBMedicalRecord | Response:
    if (
        medical_record := await DBMedicalRecord.find(DBMedicalRecord.patientId == patient.id).first_or_none()
    ) is not None:
        return medical_record
    return Response(status_code=204)
