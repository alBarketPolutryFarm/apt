import secrets
from typing import Callable

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer


def api_auth(token: str | Callable[[], str]) -> Depends:
    class APIAuth:
        def __init__(self, token: str | Callable[[], str]):
            self._token = token

        def __call__(
            self, token: HTTPAuthorizationCredentials = Depends(HTTPBearer(auto_error=True, bearerFormat="API token"))
        ) -> HTTPAuthorizationCredentials:
            if not secrets.compare_digest(token.credentials, self.token):
                raise HTTPException(status_code=401)
            return token

        @property
        def token(self):
            if callable(self._token):
                return self._token()
            return self._token

    return Depends(APIAuth(token))
