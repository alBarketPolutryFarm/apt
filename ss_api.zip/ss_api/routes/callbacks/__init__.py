from fastapi import APIRouter

from .exams import router as exams_router
from .reports import router as reports_router

router = APIRouter(prefix="/callbacks", tags=["callbacks"])

router.include_router(reports_router)
router.include_router(exams_router)
