from ss_api.models.report import DBExamReportRequest
from ss_api.models.users import DBDoctor
from ss_api.templates import jinja_env
from ss_api.utils.communications import send_mail


def send_email_exam_need_report(doctor: DBDoctor, exam_report_request: DBExamReportRequest) -> None:
    template = jinja_env.get_template("./email/exam_need_report.html")
    body = template.render(
        doctor=doctor,
        exam_report_request=exam_report_request,
    )

    send_mail(
        subject="Servizio Salute | Esame in attesa di referto",
        body=body,
        email=doctor.email,
    )
