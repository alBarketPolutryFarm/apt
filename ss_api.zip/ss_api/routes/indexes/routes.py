import logging
from typing import List

from fastapi import APIRouter
from pymongo import DESCENDING

from ss_api.models.index import (
    DBIndexMeasureBase,
    DBIndexMeasuresSummary,
    IndexMeasure,
    IndexMeasuresSummary,
    IndexMeasureType,
)
from ss_api.utils.auth import AuthPatient
from ss_api.utils.db import query_sort
from ss_api.utils.query_string.date_range import query_date_range
from ss_api.utils.query_string.pagination import QueryPagination

_logger = logging.getLogger(__package__)

router = APIRouter(prefix="/indexes", tags=["indexes"])


@router.get("/summary", response_model=IndexMeasuresSummary, response_model_exclude_none=True)
async def get_index_measures_summary(patient: AuthPatient) -> DBIndexMeasuresSummary:
    return await DBIndexMeasuresSummary.compute(patient)


@router.get("/{index_type}", response_model=List[IndexMeasure])
async def get_index_measures(
    pagination: QueryPagination,
    patient: AuthPatient,
    index_type: IndexMeasureType | None = None,
    date_range=query_date_range(),
) -> List[DBIndexMeasureBase]:
    query = DBIndexMeasureBase.find({"patientId": patient.id, "metadata.type": index_type}, with_children=True)

    if date_range.start is not None:
        query = query.find({"timestamp": {"$gte": date_range.start}})

    if date_range.end is not None:
        query = query.find({"timestamp": {"$lte": date_range.end}})

    query = query_sort(query, "timestamp", DESCENDING)
    query = pagination(query)
    return await query.to_list()
