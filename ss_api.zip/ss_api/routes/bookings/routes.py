from datetime import datetime, timedelta, timezone
from typing import List

from beanie import PydanticObjectId
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException

from ss_api.models.base.edits_log import EditLog
from ss_api.models.booking import Booking, DBBooking, NewBooking
from ss_api.models.permissions import DBPermission
from ss_api.models.users import DBDoctor, DBNurse, DBOperator, DBPatient, DBUserBase
from ss_api.routes.bookings.communications import (
    send_email_booking_created,
    send_email_booking_deleted,
    send_email_for_provider_booking_created,
    send_email_for_provider_booking_deleted,
)
from ss_api.utils.auth import AuthAdmin, AuthUser
from ss_api.utils.auth.auth import AuthNotPatient
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/bookings", tags=["bookings"])


@router.get("", response_model=List[Booking])
async def get_bookings(
    user: AuthUser,
    pagination: QueryPagination,
    date_range=query_date_range(default_factory_start_date=lambda: datetime.now(timezone.utc)),
) -> List[DBBooking]:
    query = DBBooking.find_query(user=user)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    return await query.to_list()


@router.post("", response_model=Success, status_code=201)
async def create_booking(
    admin: AuthNotPatient,
    new_booking: NewBooking,
    background_tasks: BackgroundTasks,
) -> Success:
    if new_booking.targetId == new_booking.providerId:
        raise HTTPException(status_code=422, detail="`targetId` and `providerId` cannot be the same")

    if (target := await DBUserBase.get(new_booking.targetId, with_children=True)) is None:
        raise HTTPException(status_code=404, detail="Target not found")

    if not isinstance(target, (DBPatient, DBNurse, DBDoctor, DBOperator)):
        raise HTTPException(status_code=422, detail="Target is not valid")

    if (provider := await DBUserBase.get(new_booking.providerId, with_children=True)) is None:
        raise HTTPException(status_code=404, detail="Provider not found")

    if not isinstance(provider, (DBNurse, DBDoctor, DBOperator)):
        raise HTTPException(status_code=422, detail="Provider is not valid")

    booking = DBBooking(**new_booking.model_dump(), createdBy=admin.id)

    await booking.save()

    if isinstance(target, DBPatient):
        await DBPermission(
            createdBy=admin.id,
            patientId=target.id,
            targetId=provider.id,
            effectiveDate=new_booking.at - timedelta(hours=24),
            expirationDate=new_booking.at + timedelta(hours=72),
        ).create()

    background_tasks.add_task(send_email_booking_created, target=target, booking=booking, provider=provider)
    background_tasks.add_task(
        send_email_for_provider_booking_created, target=target, booking=booking, provider=provider
    )

    try:
        patient = await DBPatient.find(DBPatient.id == target.id).first_or_none()
        patient.insert_edit_log(EditLog(by=admin.id, description="Nuova prenotazione creata"))
        await patient.save()
    except Exception as e:
        print(f"Error in inserting edit log: {e}")

    return Success()


def query_booking() -> DBBooking:
    async def _get_booking(user: AuthUser, booking_id: PydanticObjectId) -> DBBooking:
        bookings_result = await DBBooking.find_query(user=user, id=booking_id).to_list()
        if len(bookings_result) == 0:
            raise HTTPException(status_code=404, detail="Booking not found")
        return bookings_result[0]

    return Depends(_get_booking)


@router.get("/{booking_id}", response_model=Booking)
async def get_own_booking(_: AuthUser, booking=query_booking()) -> DBBooking:
    return booking


@router.delete("/{booking_id}", response_model=Success)
async def delete_booking(
    _: AuthAdmin,
    background_tasks: BackgroundTasks,
    booking=query_booking(),
) -> Success:
    target = await DBUserBase.get(booking.targetId, with_children=True)
    provider = await DBUserBase.get(booking.providerId, with_children=True)

    await booking.delete()

    background_tasks.add_task(send_email_booking_deleted, target=target, booking=booking, provider=provider)
    background_tasks.add_task(
        send_email_for_provider_booking_deleted, target=target, booking=booking, provider=provider
    )

    return Success("Booking has been deleted")
