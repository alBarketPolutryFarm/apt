__all__ = ["router"]

from .routes import router
