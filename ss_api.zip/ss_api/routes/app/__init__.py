__all__ = ["router"]

from fastapi import APIRouter

from .config import router as config_router
from .fcm import router as fcm_router

router = APIRouter(prefix="/app", tags=["app"])

router.include_router(fcm_router)
router.include_router(config_router)
