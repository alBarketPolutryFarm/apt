from fastapi import APIRouter
from pydantic import BaseModel, HttpUrl

from ss_api.utils.settings.settings import get_settings

router = APIRouter(prefix="/config")


class ExternalServices(BaseModel):
    deskDashboardUrl: HttpUrl | None = None


class APPConfig(BaseModel):
    externalServices: ExternalServices


@router.get("")
async def get_app_config() -> APPConfig:
    settings = get_settings()
    return APPConfig(externalServices=ExternalServices(deskDashboardUrl=settings.external_services.desk_dashboard_url))
