from typing import Annotated, List

from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException
from pymongo import DESCENDING

from ss_api.models.pai.pai import DBPAI, PAI, PAIStatus
from ss_api.utils.auth import AuthPatient
from ss_api.utils.db import query_sort
from ss_api.utils.query_string.pagination import QueryPagination

router = APIRouter(prefix="/pai", tags=["pai"])


@router.get("", response_model=List[PAI])
async def get_pai_list(
    pagination: QueryPagination, patient: AuthPatient, status: PAIStatus | None = None
) -> List[DBPAI]:
    query = DBPAI.find_query(patientId=patient.id, status=status)
    query = query_sort(query, "lastUpdate", DESCENDING)
    query = pagination(query)
    return await query.to_list()


def query_pai() -> DBPAI:
    async def _get_pai(pai_id: PydanticObjectId, patient: AuthPatient) -> DBPAI:
        try:
            return (await DBPAI.find({"_id": pai_id}).find(DBPAI.patientId == patient.id).to_list())[0]
        except IndexError:
            raise HTTPException(status_code=404, detail="PAI not found")

    return Depends(_get_pai)


QueryPAI = Annotated[DBPAI, query_pai()]


@router.get("/{pai_id}", response_model=PAI)
async def get_pai(
    _: AuthPatient,
    pai: QueryPAI,
) -> DBPAI:
    return pai
