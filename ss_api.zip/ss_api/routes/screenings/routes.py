from typing import List

from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic import ValidationError

from ss_api.models.screening import DBScreening, NewScreening, Screening
from ss_api.models.utils.patch import PatchBody
from ss_api.utils.auth import AuthAdmin, AuthUser
from ss_api.utils.query_string.date_range import query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/screenings", tags=["screenings"])


@router.get("", response_model=List[Screening])
async def get_screenings(
    pagination: QueryPagination,
    date_range=query_date_range(),
) -> List[DBScreening]:
    query = DBScreening.find_query()
    query = DBScreening.__filter_by_data_range__(query, date_range)
    query = pagination(query)
    return await query.to_list()


@router.post("", response_model=Success, status_code=201)
async def create_screening(
    admin: AuthAdmin,
    new_screening: NewScreening,
) -> Success:

    screening = DBScreening(**new_screening.model_dump(), createdBy=admin.id)
    await screening.save()

    return Success()


def query_screening() -> DBScreening:
    async def _get_screening(screening_id: PydanticObjectId) -> DBScreening:
        screenings_result = await DBScreening.find_query(id=screening_id).to_list()
        if len(screenings_result) == 0:
            raise HTTPException(status_code=404, detail="Screening not found")
        return screenings_result[0]

    return Depends(_get_screening)


@router.get("/{screening_id}", response_model=Screening)
async def get_own_screening(_: AuthUser, screening=query_screening()) -> DBScreening:
    return screening


@router.delete("/{screening_id}", response_model=Success)
async def delete_screening(
    _: AuthAdmin,
    screening=query_screening(),
) -> Success:

    await screening.delete()

    return Success("Screening has been deleted")


@router.patch("/{screening_id}", response_model=Success)
async def update_user(_: AuthAdmin, patch: PatchBody, screening=query_screening()) -> Success:
    try:
        screening = screening.patch(*patch)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    await screening.save()

    return Success()
