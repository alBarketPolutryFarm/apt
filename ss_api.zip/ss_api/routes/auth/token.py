from fastapi import APIRouter
from pydantic import BaseModel

from ss_api.models.users import DBUserBase
from ss_api.utils.auth import NeedAuth
from ss_api.utils.typing import JWT

router = APIRouter()


class TokenResponse(BaseModel):
    token: JWT


@router.get("/token", response_model=TokenResponse)
def refresh_token(user: DBUserBase = NeedAuth()) -> TokenResponse:
    return TokenResponse(token=JWT.create(user))
