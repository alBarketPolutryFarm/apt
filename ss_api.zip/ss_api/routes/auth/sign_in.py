from datetime import datetime, timedelta, timezone

from beanie.odm.operators.find.comparison import Eq
from beanie.odm.operators.find.logical import Or
from fastapi import APIRouter, BackgroundTasks
from fastapi.exceptions import HTTPException
from pydantic import BaseModel, EmailStr

from ss_api.models.otp.otp import OTP
from ss_api.models.users import DBUser, DBUserBase
from ss_api.models.users.base import UserStatus
from ss_api.utils.auth.email_notification import _send_login_notification_email
from ss_api.utils.responses import Success
from ss_api.utils.typing import JWT, FiscalCode

from .token import TokenResponse

router = APIRouter()


class SingInBody(BaseModel):
    username: EmailStr | FiscalCode
    password: str


class OTPVerificationBody(BaseModel):
    otp: str
    email: EmailStr


async def find_user(username: str) -> DBUser | None:
    query = DBUserBase.find(Or(Eq("email", username), Eq("fiscalCode", username)), with_children=True)
    return await query.first_or_none()


@router.post("/sign-in", response_model=TokenResponse | Success)
async def sign_in(
    body: SingInBody,
    background_tasks: BackgroundTasks,
) -> TokenResponse | Success:
    if (user := await find_user(body.username)) is None:
        raise HTTPException(status_code=401, detail="Invalid authentication")

    if user.status == UserStatus.SUSPENDED:
        raise HTTPException(status_code=403, detail="User is suspended")

    if user.login_attempts >= 3 and user.last_login_attempt is not None:
        time_since_last_attempt = datetime.now(timezone.utc) - user.last_login_attempt
        if time_since_last_attempt < timedelta(minutes=3):
            raise HTTPException(
                status_code=429,
                detail="Too many login attempts. Please Wait for "
                + str(3 - time_since_last_attempt.seconds // 60)
                + " minutes",
            )
        else:
            user.login_attempts = 0
            user.last_login_attempt = datetime.now(timezone.utc)
            user.save()

    if not user.check_password(body.password):
        user.login_attempts += 1
        user.last_login_attempt = datetime.now(timezone.utc)
        await user.save()
        raise HTTPException(status_code=401, detail="Invalid authentication")
    else:
        user.login_attempts = 0
        user.last_login_attempt = datetime.now(timezone.utc)
        await user.save()

        otp = OTP(userId=user.id, email=user.email, code=OTP.generate_otp())
        await otp.create()
        await OTP.send_otp_email(user.email, otp.code, background_tasks=background_tasks)

        return Success(message="OTP sent to your email.")

    return TokenResponse(token=JWT.create(user))


@router.post("/sign-in/verify-otp", response_model=TokenResponse)
async def verify_otp(body: OTPVerificationBody, background_task: BackgroundTasks) -> TokenResponse:
    otp = await OTP.find_one(OTP.code == body.otp, OTP.email == body.email, OTP.expiresAt > datetime.now(timezone.utc))
    if otp is None:
        raise HTTPException(status_code=401, detail="Invalid or expired OTP")

    user = await DBUserBase.get(otp.userId, with_children=True)
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid authentication")

    if user.__user_type__:
        background_task.add_task(_send_login_notification_email, user)
    await otp.delete()
    return TokenResponse(token=JWT.create(user))
