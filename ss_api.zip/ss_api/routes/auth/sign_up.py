from typing import List

from fastapi import APIRouter, BackgroundTasks, HTTPException
from pydantic import BaseModel, EmailStr
from pymongo.errors import DuplicateKeyError

from ss_api.models.agreement import DBAgreement
from ss_api.models.agreement.agreement_signing import NewAgreementSigning
from ss_api.models.agreement.exceptions import AgreementSigningError
from ss_api.models.base import IdBase
from ss_api.models.users import DBPatient
from ss_api.utils.responses import Success
from ss_api.utils.typing import NotFutureDate, PhoneNumber

router = APIRouter(prefix="")


class SignUpAgreementSigning(NewAgreementSigning, IdBase):
    pass


class PatientSingUp(BaseModel):
    firstName: str
    lastName: str
    birthDate: NotFutureDate

    email: EmailStr
    phone: PhoneNumber

    agreements: List[SignUpAgreementSigning] = []


@router.post("/sign-up", response_model=Success)
async def patient_sign_up(body: PatientSingUp, background_tasks: BackgroundTasks) -> Success:
    try:
        patient = await DBPatient(**body.model_dump()).create(background_tasks=background_tasks)

    except DuplicateKeyError as e:
        field = list(e.details.get("keyValue").keys())[0]
        if field == "email":
            raise HTTPException(status_code=409, detail="Email already used")
        else:
            raise HTTPException(status_code=409, detail="Conflict in db")

    try:
        for a in body.agreements:
            agreement = (await DBAgreement.query(agreement_id=a.id).to_list())[0]
            await agreement.sign(user=patient, options=a.options)

    except KeyError:
        raise HTTPException(status_code=202, detail="Sing up has been completed but an agreement has not been found")

    except AgreementSigningError:
        raise HTTPException(
            status_code=202, detail="Sing up has been completed but some agreement signings errors occurred"
        )

    return Success(message="Sign up has been completed")
