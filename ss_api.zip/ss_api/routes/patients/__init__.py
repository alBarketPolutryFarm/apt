from fastapi import APIRouter

from . import (
    bookings,
    diets,
    indexes,
    measures,
    medical_record,
    monitoring_plans,
    nurses,
    pai,
    permissions,
    reports,
    treatment_plans,
)
from .routes import router

_router = APIRouter(prefix="/{patient_id}")

_router.include_router(medical_record.router)
_router.include_router(measures.router)
_router.include_router(pai.router)
_router.include_router(indexes.router)
_router.include_router(reports.router)
_router.include_router(treatment_plans.router)
_router.include_router(monitoring_plans.router)
_router.include_router(diets.router)
_router.include_router(permissions.router)
_router.include_router(bookings.router)
_router.include_router(nurses.router)

router.include_router(_router)
