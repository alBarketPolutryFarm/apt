from typing import List

from beanie import PydanticObjectId
from fastapi import APIRouter, HTTPException

from ss_api.models.users import DBNurse, DBUserBase, Nurse
from ss_api.utils.auth import NeedAuth
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.pagination import QueryPagination

router = APIRouter(prefix="/nurses", tags=["nurses"])


@router.get("", response_model=List[Nurse])
async def get_patient_nurses(
    patient: QueryPatient,
    pagination: QueryPagination,
    _: DBUserBase = NeedAuth("nurse", "admin", "doctor", "patient"),
) -> List[DBNurse]:
    query = DBNurse.find_query(by=patient)
    query = pagination(query)
    return await query.to_list()


@router.get("/{nurse_id}", response_model=Nurse)
async def get_patient_nurse(
    nurse_id: PydanticObjectId, patient: QueryPatient, _: DBUserBase = NeedAuth("admin", "nurse", "doctor", "patient")
) -> DBNurse:
    try:
        return (await DBNurse.find_query(by=patient, id=nurse_id).to_list())[0]
    except IndexError:
        raise HTTPException(status_code=404, detail="Nurse not found")
