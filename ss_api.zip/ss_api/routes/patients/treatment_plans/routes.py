from datetime import datetime, timedelta
from typing import List

from fastapi import APIRouter, HTTPException
from pymongo import DESCENDING
from pytz import UTC
from starlette.responses import Response

from ss_api.models.report import DBReportBase
from ss_api.models.treatment_plan.treatment_plan import (
    DBTreatmentPlan,
    NewTreatmentPlan,
    TreatmentPlan,
)
from ss_api.models.treatment_plan.treatment_plan_schedule import TreatmentPlanSchedule
from ss_api.models.treatment_plan.treatment_plan_week_schedule import (
    TreatmentPlanWeekSchedule,
)
from ss_api.utils.auth import AuthNurse, AuthUser
from ss_api.utils.db import query_sort
from ss_api.utils.depends import QueryPatient
from ss_api.utils.headers import HeaderTimeZone
from ss_api.utils.query_string.date_range import query_date_range
from ss_api.utils.responses import Success

from .side_effects import router as side_effect_router

router = APIRouter(prefix="/treatment-plans", tags=["treatment plans"])


@router.post("", status_code=201, response_model=Success)
async def insert_patient_treatment_plan(plan: NewTreatmentPlan, nurse: AuthNurse, patient: QueryPatient) -> Success:
    if (report := await DBReportBase.get(plan.reportId, with_children=True)) is None or report.patientId != patient.id:
        raise HTTPException(status_code=404, detail="Report not found")

    await DBTreatmentPlan(**plan.model_dump(), patientId=patient.id, createdBy=nurse.id).create()

    return Success("Treatment plan has been inserted")


@router.get("", response_model=List[TreatmentPlan])
async def get_patient_treatment_plans_list(_: AuthUser, patient: QueryPatient) -> List[DBTreatmentPlan]:
    query = DBTreatmentPlan.find(DBTreatmentPlan.patientId == patient.id)
    query = query_sort(query, "effectiveDate", DESCENDING)
    return await query.to_list()


@router.get(
    "/current",
    response_model=TreatmentPlan,
    responses={204: {"description": "No active treatment plan at the moment"}},
)
async def get_patient_current_treatment_plan(_: AuthUser, patient: QueryPatient) -> DBTreatmentPlan | Response:
    return (await DBTreatmentPlan.get_current(patient=patient)) or Response(status_code=204)


@router.get(
    "/current/week-schedule",
    response_model=TreatmentPlanWeekSchedule,
    responses={204: {"description": "No active treatment plan at the moment"}},
)
async def get_patient_current_treatment_plan_week_schedule(
    _: AuthUser, patient: QueryPatient
) -> TreatmentPlanWeekSchedule | Response:
    treatment_plan = await DBTreatmentPlan.get_current(patient=patient)
    if treatment_plan is None:
        return Response(status_code=204)

    return treatment_plan.week_schedule


@router.get("/schedule", response_model=TreatmentPlanSchedule, response_model_exclude_none=True)
async def get_schedule(
    _: AuthUser,
    timezone: HeaderTimeZone,
    patient: QueryPatient,
    date_range=query_date_range(
        default_factory_start_date=lambda: datetime.now(UTC),
        default_factory_end_date=lambda: datetime.now(UTC) + timedelta(days=7),
    ),
) -> TreatmentPlanSchedule:
    return await DBTreatmentPlan.get_complete_schedule(
        patient=patient, start_date=date_range.start, end_date=date_range.end, timezone=timezone
    )


router.include_router(side_effect_router)
