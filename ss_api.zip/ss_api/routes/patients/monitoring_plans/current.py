from fastapi import APIRouter, HTTPException

from ss_api.models.monitoring_plan.monitoring_plan import (
    DBMonitoringPlan,
    MonitoringPlan,
)
from ss_api.utils.auth import AuthUser
from ss_api.utils.depends import QueryPatient

router = APIRouter(prefix="/current")


@router.get("", response_model=MonitoringPlan, response_model_exclude_none=True)
async def get_patient_current_monitoring_plan(patient: QueryPatient, _: AuthUser) -> DBMonitoringPlan:
    plan = await DBMonitoringPlan.get_current(patient=patient)

    if plan is None:
        raise HTTPException(status_code=204, detail="No active monitoring plan at the moment")

    return plan
