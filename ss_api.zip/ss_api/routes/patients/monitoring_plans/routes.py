from datetime import datetime, timezone
from typing import List

from beanie import PydanticObjectId
from fastapi import APIRouter, HTTPException
from pymongo import DESCENDING

from ss_api.models.base.edits_log import EditLog
from ss_api.models.monitoring_plan.monitoring_plan import (
    DBMonitoringPlan,
    MonitoringPlan,
    NewMonitoringPlan,
)
from ss_api.models.report import DBReportBase
from ss_api.models.revocation import Revocation, RevocationReason
from ss_api.utils.auth import AuthAdmin, AuthNurse, AuthUser
from ss_api.utils.db import query_sort
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/monitoring-plans", tags=["monitoring plans"])


@router.post("", status_code=201)
async def insert_patient_monitoring_plan(plan: NewMonitoringPlan, patient: QueryPatient, user: AuthNurse) -> Success:
    if (report := await DBReportBase.get(plan.reportId, with_children=True)) is None or report.patientId != patient.id:
        raise HTTPException(status_code=404, detail="Report not found")
    await DBMonitoringPlan(**plan.model_dump(), patientId=patient.id, createdBy=user.id).create()

    try:
        patient.insert_edit_log(EditLog(by=user.id, description="Inserimento del piano di monitoraggio"))
        await patient.save()
    except Exception as e:
        print(e)

    return Success("Monitoring plan has been inserted")


@router.get("", response_model=List[MonitoringPlan])
async def get_patient_monitoring_plans_list(
    patient: QueryPatient,
    pagination: QueryPagination,
    _: AuthUser,
    date_range=query_date_range(),
) -> List[DBMonitoringPlan]:
    query = DBMonitoringPlan.find(DBMonitoringPlan.patientId == patient.id)
    query = filter_by_date_range(query, date_range)
    query = query_sort(query, "effectiveDate", DESCENDING)
    query = pagination(query)
    return await query.to_list()


@router.delete("/{monitoring_plan_id}")
async def revoke_patient_monitoring_plan(
    monitoring_plan_id: PydanticObjectId, patient: QueryPatient, user: AuthAdmin
) -> Success:
    plan = (
        await DBMonitoringPlan.find(DBMonitoringPlan.id == monitoring_plan_id)
        .find(DBMonitoringPlan.patientId == patient.id)
        .first_or_none()
    )

    if plan is None:
        raise HTTPException(status_code=404, detail="Monitoring plan was not found")

    if plan.revocation is not None and plan.revocation.effectiveFrom < datetime.now(tz=timezone.utc):
        raise HTTPException(status_code=409, detail="Monitoring plan was already revoked")

    await plan.revoke(Revocation(by=user.id, dueTo=RevocationReason.manual))

    return Success("Monitoring plan has been revoked")
