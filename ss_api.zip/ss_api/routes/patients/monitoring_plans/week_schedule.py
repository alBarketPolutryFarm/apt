from fastapi import APIRouter, HTTPException

from ss_api.models.monitoring_plan.monitoring_plan import DBMonitoringPlan
from ss_api.models.monitoring_plan.monitoring_plan_week_schedule import (
    MonitoringPlanWeekSchedule,
)
from ss_api.utils.auth import AuthUser
from ss_api.utils.depends import QueryPatient

router = APIRouter()


@router.get("/week-schedule", response_model=MonitoringPlanWeekSchedule)
async def get_patient_monitoring_plan_week_schedule(
    patient: QueryPatient,
    _: AuthUser,
) -> MonitoringPlanWeekSchedule:
    plan = await DBMonitoringPlan.get_current(patient=patient)

    if plan is None:
        raise HTTPException(status_code=204, detail="No active monitoring plan at the moment")

    return plan.week_schedule
