from typing import Annotated

from beanie import PydanticObjectId
from fastapi import Depends, HTTPException

from ss_api.models.report import DBReport, DBReportBase
from ss_api.utils.auth import AuthUser
from ss_api.utils.depends import QueryPatient


async def _get_report(report_id: PydanticObjectId, patient: QueryPatient, user: AuthUser) -> DBReportBase:
    reports = await DBReportBase.find_query(id=report_id, patientId=patient.id, by=user).to_list()

    if len(reports) == 0:
        raise HTTPException(status_code=404, detail="Report not found")

    return reports[0]


QueryReport = Annotated[DBReport, Depends(_get_report)]
