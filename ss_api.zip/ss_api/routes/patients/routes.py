from datetime import datetime
from typing import List

from beanie import PydanticObjectId
from fastapi import APIRouter, BackgroundTasks, HTTPException, Query
from pydantic import ValidationError
from pymongo.errors import DuplicateKeyError
from pytz import UTC

from ss_api.models.base.edits_log import EditLog
from ss_api.models.permissions import DBPermission
from ss_api.models.users import UserType
from ss_api.models.users.limits.exceptions import LimitExceededError
from ss_api.models.users.patient import DBPatient, NewPatient, Patient
from ss_api.models.utils.patch import PatchBody
from ss_api.utils.auth import (
    AuthAdmin,
    AuthAdminDoctor,
    AuthAdminDoctorNurse,
    AuthNotPatient,
    AuthUser,
)
from ss_api.utils.db import query_count
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.pagination import QueryInfo, QueryPagination
from ss_api.utils.responses import Success
from ss_api.utils.user.auth_helpers import _enforce_admin_patient_creation_limit

router = APIRouter(prefix="/patients", tags=["patients"])


@router.get("", response_model=List[Patient])
async def list_patients(
    user: AuthNotPatient,
    pagination: QueryPagination,
    q: str | None = None,
    gender: str | None = None,
    target_ids: List[PydanticObjectId] = Query(None),
) -> List[DBPatient]:
    find_created_by = user.__user_type__ == "admin"
    query = DBPatient.find_query(by=user, q=q, gender=gender, target_ids=target_ids, find_created_by=find_created_by)
    query = pagination(query)
    return await query.to_list()


@router.get("/info", response_model=QueryInfo)
async def get_patients_query_info(user: AuthNotPatient, q: str | None = None) -> QueryInfo:
    query = DBPatient.find_query(by=user, q=q)
    return QueryInfo(count=await query_count(query))


@router.post("", response_model=Success, status_code=201)
async def create_patient(user: AuthAdminDoctor, patient: NewPatient, background_tasks: BackgroundTasks) -> Success:
    if user.__user_type__ == "admin":
        await _enforce_admin_patient_creation_limit(user)
    if user.__user_type__ == UserType.doctor:
        try:
            await user.patientCreationLimit.use()
        except LimitExceededError:
            raise HTTPException(status_code=429, detail="Creation limit exceeded")

    try:
        patient = await DBPatient(**patient.model_dump(), createdBy=user.id).create(background_tasks=background_tasks)

    except DuplicateKeyError as e:
        field = list(e.details.get("keyValue").keys())[0]
        if field == "email":
            raise HTTPException(status_code=409, detail="Email already used")
        elif field == "fiscalCode":
            raise HTTPException(status_code=409, detail="Fiscal code already present")
        else:
            raise HTTPException(status_code=409, detail="Conflict in db")

    if user.__user_type__ == UserType.doctor:
        await DBPermission(
            targetId=user.id, patientId=patient.id, createdBy=user.id, effectiveDate=datetime.now(UTC)
        ).save()

    return Success(message="Patient was added")


@router.get("/{patient_id}", response_model=Patient)
async def get_patient(_: AuthUser, patient: QueryPatient) -> DBPatient:
    return patient


@router.patch("/{patient_id}", response_model=Success)
async def update_patient(operator: AuthAdminDoctorNurse, patch: PatchBody, patient: QueryPatient) -> Success:
    try:
        patient = patient.patch(*patch)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))
    try:
        patient.insert_edit_log(EditLog(by=operator.id, description="Dati del Paziente Aggiornati"))
        await patient.save()
    except DuplicateKeyError as e:
        field = list(e.details.get("keyValue").keys())[0]
        if field == "fiscalCode":
            raise HTTPException(status_code=409, detail="Fiscal code already used")
        else:
            raise HTTPException(status_code=409, detail="Conflict in db")

    return Success()


@router.delete("/{patient_id}", status_code=501, response_description="Not implemented")
async def remove_patient(admin: AuthAdmin, patient: QueryPatient):
    pass
