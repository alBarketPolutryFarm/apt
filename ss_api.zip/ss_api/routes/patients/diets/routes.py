from datetime import datetime, timedelta, timezone
from typing import List

from beanie.odm.operators.find.comparison import Eq
from fastapi import APIRouter, HTTPException
from pymongo import DESCENDING
from starlette.responses import Response

from ss_api.models.base.edits_log import EditLog
from ss_api.models.diet import DBDietOutMeal, DietOutMeal
from ss_api.models.diet.diet import DBDiet, Diet, NewDiet
from ss_api.models.diet.diet_schedule_entry import DietScheduleEntry
from ss_api.models.report import DBReportBase
from ss_api.models.users.patient import DBPatient
from ss_api.utils.auth import AuthNurse, AuthUser
from ss_api.utils.db import query_sort
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/diets", tags=["diets"])


@router.post("", status_code=201, response_model=Success)
async def insert_patient_diet(plan: NewDiet, patient: QueryPatient, nurse: AuthNurse) -> Success:
    if (report := await DBReportBase.get(plan.reportId, with_children=True)) is None or report.patientId != patient.id:
        raise HTTPException(status_code=404, detail="Report not found")

    try:
        newpatient = await DBPatient.find(DBPatient.id == patient.id).first_or_none()
        newpatient.insert_edit_log(EditLog(by=nurse.id, description="Nuova diet creata"))
        await newpatient.save()
    except Exception as e:
        print(f"Error in patient: {e}")
    return Success("Diet has been inserted")


@router.get("", response_model=List[Diet])
async def get_patient_diets_list(
    patient: QueryPatient,
    pagination: QueryPagination,
    _: AuthUser,
    date_range=query_date_range(),
) -> List[DBDiet]:
    query = DBDiet.find(DBDiet.patientId == patient.id)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    query = query_sort(query, "effectiveDate", DESCENDING)
    return await query.to_list()


@router.get(
    "/current",
    response_model=Diet,
    responses={204: {"description": "No active diet at the moment"}},
)
async def get_current_patient_diet(
    patient: QueryPatient,
    _: AuthUser,
) -> Diet | Response:
    current = await DBDiet.find_period().find(DBDiet.patientId == patient.id).first_or_none()
    if current is None:
        return Response(status_code=204)
    return current


@router.get(
    "/schedule",
    response_model=list[DietScheduleEntry],
    response_model_exclude_unset=True,
    response_model_exclude_none=True,
)
async def get_schedule(
    patient: QueryPatient,
    _: AuthUser,
    date_range=query_date_range(
        default_factory_start_date=lambda: datetime.now(timezone.utc),
        default_factory_end_date=lambda: datetime.now(timezone.utc) + timedelta(days=7),
    ),
) -> list[DietScheduleEntry]:
    return await DBDiet.get_complete_schedule(patient=patient, start_date=date_range.start, end_date=date_range.end)


@router.get("/out-meals", response_model=List[DietOutMeal])
async def get_side_effects(
    patient: QueryPatient, _: AuthUser, pagination: QueryPagination, date_range=query_date_range()
) -> List[DBDietOutMeal]:
    query = DBDietOutMeal.find(Eq(DBDietOutMeal.patientId, patient.id))
    query = query_sort(query, "at", DESCENDING)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    return await query.to_list()
