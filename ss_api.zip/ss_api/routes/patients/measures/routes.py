from typing import Annotated, List

from fastapi import APIRouter
from pymongo import ASCENDING

from ss_api.models.measures import (
    DBMeasureBase,
    Measure,
    MeasuresSummary,
    MeasureType,
    NewMeasure,
)
from ss_api.models.measures.summary import DBMeasuresSummary
from ss_api.models.users import DBUserBase
from ss_api.utils.auth import AuthUser, NeedAuth
from ss_api.utils.db import query_sort
from ss_api.utils.depends import QueryPatient
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

from ...measures.routes import insert_measures

router = APIRouter(prefix="/measures", tags=["measures"])


@router.post("", status_code=201, response_model=Success)
async def insert_patient_measures(
    measures: List[NewMeasure],
    patient: QueryPatient,
    _: Annotated[DBUserBase, NeedAuth("patient", "nurse", "doctor")],
) -> Success:
    return await insert_measures(measures=measures, patient=patient)


@router.get("/summary", response_model=MeasuresSummary)
async def get_patient_measures_summary(patient: QueryPatient, _: AuthUser) -> DBMeasuresSummary:
    return await DBMeasuresSummary.compute(patient)


@router.get("/{measure_type}", response_model=List[Measure])
async def get_patient_measures(
    patient: QueryPatient,
    pagination: QueryPagination,
    _: AuthUser,
    measure_type: MeasureType | None = None,
    date_range=query_date_range(),
) -> List[DBMeasureBase]:
    query = DBMeasureBase.find({"patientId": patient.id, "metadata.type": measure_type}, with_children=True)

    query = filter_by_date_range(query, date_range)
    query = query_sort(query, "timestamp", ASCENDING)
    query = pagination(query)

    return await query.to_list()
