from fastapi import APIRouter, HTTPException
from pydantic import ValidationError
from starlette.responses import Response

from ss_api.models.base.edits_log import EditLog
from ss_api.models.medical_record.medical_record import DBMedicalRecord, MedicalRecord
from ss_api.models.utils.patch import PatchBody
from ss_api.utils.auth import AuthAdminDoctorNurse, AuthUser
from ss_api.utils.depends import QueryPatient
from ss_api.utils.responses import Success

router = APIRouter(prefix="/medical-record", tags=["medical records"])


@router.get("", response_model=MedicalRecord, response_model_exclude_unset=True, response_model_exclude_none=True)
async def get_patient_medical_record(patient: QueryPatient, _: AuthUser) -> DBMedicalRecord | Response:
    if (
        medical_record := await DBMedicalRecord.find(DBMedicalRecord.patientId == patient.id).first_or_none()
    ) is not None:
        return medical_record

    return Response(status_code=204)


@router.patch("", response_model=Success)
async def update_patient_medical_record(
    patch: PatchBody, patient: QueryPatient, operator: AuthAdminDoctorNurse
) -> Success:
    medical_record = await DBMedicalRecord.find(DBMedicalRecord.patientId == patient.id).first_or_none()

    if medical_record is None:
        medical_record = DBMedicalRecord(patientId=patient.id)

    try:
        medical_record = medical_record.patch(*patch)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))
    try:
        description = "Modification of " + str(patch[0].path)
        if str(patch[0].path).startswith("/"):
            description = "Modification of " + str((patch[0].path).split("/")[1])
        medical_record.insert_edit_log(EditLog(by=operator.id, description=description))
        await medical_record.save()
    except Exception as e:
        print(e)
    return Success()
