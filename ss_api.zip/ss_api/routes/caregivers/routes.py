from typing import List

from fastapi import APIRouter, HTTPException
from pydantic import ValidationError
from pymongo.errors import DuplicateKeyError
from starlette.background import BackgroundTasks

from ss_api.models.base import EditLog
from ss_api.models.users import Caregiver, DBCaregiver, NewCaregiver
from ss_api.models.utils.patch import PatchBody
from ss_api.utils.auth import AuthAdmin, AuthAdminPatient
from ss_api.utils.depends import QueryCaregiver
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success
from ss_api.utils.user.auth_helpers import _enforce_admin_user_creation_limit

router = APIRouter(prefix="/caregivers", tags=["caregivers"])


@router.get("", response_model=List[Caregiver])
async def list_caregivers(pagination: QueryPagination, user: AuthAdminPatient) -> List[DBCaregiver]:
    if user.__user_type__ == "superadmin":
        query = DBCaregiver.find_all()
    else:
        query = DBCaregiver.find_query(by=user, find_created_by=True)
    query = pagination(query)
    return await query.to_list()


@router.post("", response_model=Success, status_code=201)
async def create_caregiver(caregiver: NewCaregiver, background_tasks: BackgroundTasks, admin: AuthAdmin) -> Success:
    if admin.__user_type__ == "admin":
        await _enforce_admin_user_creation_limit(admin)
    try:
        if admin.__user_type__ == "superadmin":
            await DBCaregiver(**caregiver.model_dump(), createdBy=admin.id).create(
                background_tasks=background_tasks, fiscalCodeCheck=False
            )
        else:
            await DBCaregiver(**caregiver.model_dump(), createdBy=admin.id).create(background_tasks=background_tasks)
    except DuplicateKeyError as e:
        field = list(e.details.get("keyValue").keys())[0]
        if field == "email":
            raise HTTPException(status_code=409, detail="Email already used")
        else:
            raise HTTPException(status_code=409, detail="Conflict in db")

    return Success(message="Caregiver was added")


@router.get("/{caregiver_id}", response_model=Caregiver)
async def get_caregiver(caregiver: QueryCaregiver, _: AuthAdminPatient) -> DBCaregiver:
    return caregiver


@router.patch("/{caregiver_id}", response_model=Success)
async def update_caregiver(caregiver: QueryCaregiver, admin: AuthAdmin, patch: PatchBody) -> Success:
    try:
        caregiver = caregiver.patch(*patch)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    caregiver.insert_edit_log(EditLog(by=admin.id))

    await caregiver.save()

    return Success()


@router.delete("/{caregiver_id}", status_code=501, response_description="Not implemented")
async def remove_caregiver(caregiver: QueryCaregiver, _: AuthAdmin):
    raise NotImplementedError()
