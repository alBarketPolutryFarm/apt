from typing import Annotated

from beanie import PydanticObjectId
from fastapi import Depends, HTTPException

from ss_api.models.report import DBExamReportRequest
from ss_api.utils.auth import AuthAdminDoctor


async def _exam_report_request(user: AuthAdminDoctor, request_id: PydanticObjectId) -> DBExamReportRequest:
    exam = await DBExamReportRequest.find_query(by=user, id=request_id).first_or_none()
    if exam is None:
        raise HTTPException(status_code=404, detail="Exam report request not found")
    return exam


QueryExamReportRequest = Annotated[DBExamReportRequest, Depends(_exam_report_request)]
