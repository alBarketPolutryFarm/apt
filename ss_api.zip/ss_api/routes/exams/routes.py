from accept_types import accept_types
from beanie import WriteRules
from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import ValidationError
from starlette.responses import FileResponse

from ss_api.models.file import FileEncoded
from ss_api.models.report import DBExamReport, DBExamReportRequest, NewExamReport
from ss_api.models.report.exam_report import ExamReportRequest
from ss_api.models.utils.patch import Patch, PatchBody
from ss_api.utils.auth import AuthAdmin, AuthAdminDoctor, AuthDoctor
from ss_api.utils.headers import HeaderAccept
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

from ...models.report.responses import StartSignatureProcessSuccess
from ...models.report.signature import SignatureStatus
from ...models.users.limits.exceptions import LimitExceededError
from ...utils.db import query_sort
from .depends import QueryExamReportRequest

router = APIRouter(prefix="/exam-report-requests", tags=["exams"])


@router.get("", response_model=list[ExamReportRequest])
async def get_exam_report_requests(
    user: AuthAdminDoctor, pagination: QueryPagination, date_range=query_date_range()
) -> list[DBExamReportRequest]:
    query = DBExamReportRequest.find_query(by=user)
    query = filter_by_date_range(query, date_range)
    query = query_sort(query, "createdAt")
    query = pagination(query)
    query.fetch_links = True
    return await query.to_list()


@router.patch("/{request_id}", response_model=Success)
async def update_unreported_exam_request(
    _: AuthAdmin, exam_report_request: QueryExamReportRequest, patch: PatchBody
) -> Success:
    try:
        exam_report_request = exam_report_request.patch(*patch)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    await exam_report_request.save()

    return Success()


@router.get("/{request_id}/exam", response_model=FileEncoded, responses={200: {"content": {"application/zip": {}}}})
async def get_unreported_exam_file(
    _: AuthAdminDoctor,
    exam_report_request: QueryExamReportRequest,
    accept: HeaderAccept,
) -> FileEncoded | Response:
    if accept_types.get_best_match(accept, ["application/zip", "application/json"]) == "application/zip":
        return Response(content=exam_report_request.exam.get_file(), media_type="application/zip", status_code=200)

    return exam_report_request.exam.get_encoded_file()


@router.post("/{request_id}/report", response_model=Success)
async def create_exam_report(
    doctor: AuthDoctor,
    exam_report_request: QueryExamReportRequest,
    new_report: NewExamReport,
) -> Success:
    exam_report_request.report = DBExamReport(
        **new_report.model_dump(),
        patientId=exam_report_request.patientId,
        exam=exam_report_request.exam,
        createdBy=doctor.id
    )

    await exam_report_request.save(link_rule=WriteRules.WRITE)

    return Success()


@router.delete("/{request_id}/report", response_model=Success)
async def delete_exam_report(exam_report_request: QueryExamReportRequest, _: AuthAdmin) -> Success:
    if exam_report_request.report is None:
        raise HTTPException(status_code=404, detail="The report has not yet been created")

    if exam_report_request.report.signature.status == SignatureStatus.completed:
        raise HTTPException(status_code=403, detail="Report already signed cannot be edited")

    if exam_report_request.report.signature.status == SignatureStatus.waiting:
        raise HTTPException(status_code=409, detail="Report with a running signing process cannot be edited")

    exam_report_request.report = None

    await exam_report_request.save()

    return Success("Report has been updated")


@router.patch("/{request_id}/report", response_model=Success)
async def edit_exam_report(exam_report_request: QueryExamReportRequest, patch: Patch, _: AuthDoctor) -> Success:
    if exam_report_request.report is None:
        raise HTTPException(status_code=404, detail="The report has not yet been created")

    if (
        exam_report_request.report.signature is not None
        and exam_report_request.report.signature.status == SignatureStatus.completed
    ):
        raise HTTPException(status_code=403, detail="Report already signed cannot be edited")

    if (
        exam_report_request.report.signature is not None
        and exam_report_request.report.signature.status == SignatureStatus.waiting
    ):
        raise HTTPException(status_code=409, detail="Report with a running signing process cannot be edited")

    await exam_report_request.report.patch(*patch).save()

    return Success("Report has been updated")


@router.get(
    "/{request_id}/report/file", response_model=FileEncoded, responses={200: {"content": {"application/pdf": {}}}}
)
async def get_exam_report_file(
    _: AuthAdminDoctor,
    exam_report_request: QueryExamReportRequest,
    accept: HeaderAccept,
) -> FileEncoded | Response:
    if exam_report_request.report is None:
        raise HTTPException(status_code=404, detail="The report has not yet been created")

    if accept_types.get_best_match(accept, ["application/pdf", "application/json"]) == "application/pdf":
        return FileResponse(
            path=exam_report_request.report.file.absolute_path,
            media_type=exam_report_request.report.file.contentType,
            filename=exam_report_request.report.file.filename,
        )

    return exam_report_request.report.file.encoded


@router.post(
    "/{request_id}/report/signature",
    response_model=StartSignatureProcessSuccess,
    description="Require to start the signature process",
)
async def require_report_signature(exam_report_request: QueryExamReportRequest, doctor: AuthDoctor) -> Success:
    if exam_report_request.report is None:
        raise HTTPException(status_code=404, detail="The report has not yet been created")

    if (
        exam_report_request.report.signature is not None
        and exam_report_request.report.signature.status == SignatureStatus.completed
    ):
        raise HTTPException(status_code=403, detail="Report already signed")

    if (
        exam_report_request.report.signature is not None
        and exam_report_request.report.signature.status == SignatureStatus.waiting
    ):
        raise HTTPException(status_code=409, detail="A signature process is already underway")

    if exam_report_request.report.createdBy != doctor.id:
        raise HTTPException(status_code=403, detail="Only the creator can require to start the signature process")

    try:
        await exam_report_request.report.create_signature_request()
        await exam_report_request.report.save()
    except LimitExceededError:
        raise HTTPException(status_code=428, detail="You have exceeded your signature limit")

    return StartSignatureProcessSuccess(
        "A new signature process has been started", signature=exam_report_request.report.signature
    )
