from typing import Annotated, List

from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic import ValidationError
from pymongo.errors import DuplicateKeyError
from starlette.background import BackgroundTasks

from ss_api.models.base import EditLog
from ss_api.models.users import DBDoctor, DBUserBase, Doctor
from ss_api.models.users.doctor import NewDoctor
from ss_api.models.utils.patch import PatchBody
from ss_api.utils.auth import AuthAdmin, AuthAdminPatient, NeedAuth
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success
from ss_api.utils.user.auth_helpers import _enforce_admin_user_creation_limit

router = APIRouter(prefix="/doctors", tags=["doctors"])


def query_doctor() -> DBDoctor:
    async def _get_doctor(doctor_id: PydanticObjectId, user: DBUserBase | None = NeedAuth()) -> DBDoctor:
        try:
            return (await DBDoctor.find_query(by=user, id=doctor_id).to_list())[0]
        except IndexError:
            raise HTTPException(status_code=404, detail="Doctor not found")

    return Depends(_get_doctor)


@router.get("", response_model=List[Doctor])
async def list_doctors(pagination: QueryPagination, user: AuthAdminPatient) -> List[DBDoctor]:
    if user.__user_type__ == "superadmin":
        query = DBDoctor.find_all()
    else:
        query = DBDoctor.find_query(by=user, find_created_by=True)
    query = pagination(query)
    return await query.to_list()


@router.post("", response_model=Success, status_code=201)
async def create_doctor(doctor: NewDoctor, background_tasks: BackgroundTasks, admin: AuthAdmin) -> Success:
    if admin.__user_type__ == "admin":
        await _enforce_admin_user_creation_limit(admin)
    try:
        if admin.__user_type__ == "superadmin":
            await DBDoctor(**doctor.model_dump(), createdBy=admin.id).create(
                background_tasks=background_tasks, fiscalCodeCheck=False
            )
        else:
            await DBDoctor(**doctor.model_dump(), createdBy=admin.id).create(background_tasks=background_tasks)
    except DuplicateKeyError as e:
        field = list(e.details.get("keyValue").keys())[0]
        if field == "email":
            raise HTTPException(status_code=409, detail="Email already used")
        else:
            raise HTTPException(status_code=409, detail="Conflict in db")
    return Success(message="Doctor was added")


QueryDoctor = Annotated[DBDoctor, query_doctor()]


@router.get("/{doctor_id}", response_model=Doctor)
async def get_doctor(doctor: QueryDoctor, _: AuthAdminPatient) -> DBDoctor:
    return doctor


@router.patch("/{doctor_id}", response_model=Success)
async def update_doctor(patch: PatchBody, doctor: QueryDoctor, admin: AuthAdmin) -> Success:
    try:
        doctor = doctor.patch(*patch)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    doctor.insert_edit_log(EditLog(by=admin.id))

    await doctor.save()

    return Success()


@router.delete("/{doctor_id}", status_code=501, response_description="Not implemented")
async def remove_doctor(doctor: QueryDoctor, _: AuthAdmin):
    raise NotImplementedError()
