from typing import Annotated, List

from beanie import PydanticObjectId
from fastapi import APIRouter, Depends, HTTPException

from ss_api.models.alarm import Alarm, DBAlarm, DBAlarmBase
from ss_api.models.alarm.base import Handling
from ss_api.models.permissions import DBPermission
from ss_api.models.users import DBAdmin
from ss_api.utils.auth import AuthAdminNurse, AuthUser
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success


async def get_alarm(alarm_id: PydanticObjectId, user: AuthUser) -> DBAlarmBase:
    if (alarm := await DBAlarmBase.find_one({"_id": alarm_id}, with_children=True)) is None:
        raise HTTPException(status_code=404, detail="Alarm not found")

    if not isinstance(user, DBAdmin):
        permission_query = DBPermission.find_query(patient=alarm.patientId, target=user)
        permission = await permission_query.to_list()
        print("permission", permission)
        if not permission:
            raise HTTPException(status_code=404, detail="Alarm not found")
    return alarm


QueryAlarm = Annotated[DBAlarm, Depends(get_alarm)]
router = APIRouter(prefix="/alarms", tags=["alarms"])


@router.get("", response_model=List[Alarm])
async def get_alarms(
    pagination: QueryPagination, user: AuthAdminNurse, date_range=query_date_range()
) -> List[DBAlarmBase]:
    query = DBAlarmBase.find_query(user=user)

    if isinstance(user, DBAdmin):
        query = query.find({"createdBy": user.id})

    query = filter_by_date_range(query, date_range)
    query = await pagination(query).to_list()
    return query


@router.get("/unhandled", response_model=List[Alarm], response_model_exclude_none=True)
async def get_unhandled_alarms(
    pagination: QueryPagination, user: AuthAdminNurse, date_range=query_date_range()
) -> List[DBAlarmBase]:
    query = DBAlarmBase.find_query(user=user, only_unhandled=True)
    query = filter_by_date_range(query, date_range)
    query = pagination(query)
    return await query.to_list()


@router.post("/{alarm_id}/handle", response_model=Success)
async def handle_alarm(user: AuthUser, alarm: QueryAlarm) -> Success:
    if alarm.handling is not None:
        raise HTTPException(status_code=409, detail="Alam has already been handled")

    alarm.handling = Handling(by=user.id)
    await alarm.save()

    return Success()
