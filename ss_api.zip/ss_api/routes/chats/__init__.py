from . import messages
from .routes import router

router.include_router(messages.router)
