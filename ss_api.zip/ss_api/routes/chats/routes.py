from typing import List

from fastapi import APIRouter

from ss_api.models.chat import Chat, DBChat, DBChatBase
from ss_api.utils.auth import AuthUser
from ss_api.utils.query_string.pagination import QueryPagination

from .query import QueryChat

router = APIRouter(prefix="/chats", tags=["chats"])


@router.get("", response_model=List[Chat])
async def get_chats(
    pagination: QueryPagination,
    user: AuthUser,
) -> List[DBChat]:
    query = DBChatBase.find_query(by=user)

    query = pagination(query)
    return await query.to_list()


@router.get("/{chat_id}", response_model=Chat)
async def get_chat(
    _: AuthUser,
    chat: QueryChat,
) -> DBChat:
    return chat
