from fastapi import APIRouter, UploadFile

from ss_api.models.file import DBFileTemp, File
from ss_api.utils.auth import AuthInternal

router = APIRouter(prefix="/files", tags=["files"])


@router.post("", status_code=201, response_model=File)
async def upload_file(file: UploadFile, user: AuthInternal) -> DBFileTemp:
    return await DBFileTemp.upload(
        file=file,
        createdBy=user.id,
        ownerId=user.id,
    )
