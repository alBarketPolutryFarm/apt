from typing import List

from beanie.odm.operators.find.comparison import In
from fastapi import APIRouter, HTTPException
from pydantic import ValidationError
from pymongo.errors import DuplicateKeyError
from starlette.background import BackgroundTasks

from ss_api.models.base import EditLog
from ss_api.models.permissions.permissions import DBPermission
from ss_api.models.users import DBNurse
from ss_api.models.users.nurse import NewNurse, Nurse
from ss_api.models.users.type import UserType
from ss_api.models.utils.patch import PatchBody
from ss_api.utils.auth import AuthAdmin, AuthAdminPatient
from ss_api.utils.depends import QueryNurse
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success
from ss_api.utils.user.auth_helpers import _enforce_admin_user_creation_limit

router = APIRouter(prefix="/nurses", tags=["nurses"])


@router.get("", response_model=List[Nurse])
async def list_nurses(pagination: QueryPagination, user: AuthAdminPatient) -> List[DBNurse]:
    if type(user).__user_type__ == UserType.superadmin:
        query = DBNurse.find_all()
    elif type(user).__user_type__ == UserType.admin:
        query = DBNurse.find_query(by=user, find_created_by=True)
    elif type(user).__user_type__ == UserType.patient:
        permissions = await DBPermission.find({"patientId": user.id, "revocation": None}, fetch_links=True).to_list()
        nurse_ids = [p.targetId for p in permissions]
        query = DBNurse.find(In(DBNurse.id, nurse_ids))
    else:
        query = None
    if query is None:
        return []
    query = pagination(query)
    return await query.to_list()

    query = pagination(query)
    return await query.to_list()


@router.post("", response_model=Success, status_code=201)
async def create_nurse(nurse: NewNurse, background_tasks: BackgroundTasks, admin: AuthAdmin) -> Success:
    if admin.__user_type__ == "admin":
        await _enforce_admin_user_creation_limit(admin)
    try:
        if admin.__user_type__ == "superadmin":
            await DBNurse(**nurse.model_dump(), createdBy=admin.id).create(
                background_tasks=background_tasks, fiscalCodeCheck=False
            )
        else:
            await DBNurse(**nurse.model_dump(), createdBy=admin.id).create(background_tasks=background_tasks)
    except DuplicateKeyError as e:
        field = list(e.details.get("keyValue").keys())[0]
        if field == "email":
            raise HTTPException(status_code=409, detail="Email already used")
        else:
            raise HTTPException(status_code=409, detail="Conflict in db")

    return Success(message="Nurse was added")


@router.get("/{nurse_id}", response_model=Nurse)
async def get_nurse(nurse: QueryNurse, _: AuthAdminPatient) -> DBNurse:
    return nurse


@router.patch("/{nurse_id}", response_model=Success)
async def update_nurse(nurse: QueryNurse, patch: PatchBody, admin: AuthAdmin) -> Success:
    try:
        nurse = nurse.patch(*patch)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    nurse.insert_edit_log(EditLog(by=admin.id))

    await nurse.save()

    return Success()


@router.delete("/{nurse_id}", status_code=501, response_description="Not implemented")
async def remove_nurse(nurse: QueryNurse, _: AuthAdmin):
    raise NotImplementedError()
