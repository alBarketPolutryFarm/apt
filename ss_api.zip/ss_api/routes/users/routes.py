from typing import Annotated, List, Set

from beanie.odm.operators.find.comparison import In
from beanie.odm.operators.find.evaluation import Text
from bson import ObjectId
from fastapi import APIRouter, HTTPException, Query
from pydantic import ValidationError

from ss_api.models.base import EditLog
from ss_api.models.permissions.permissions import DBPermission
from ss_api.models.users import DBUser, DBUserBase, User, UserType
from ss_api.models.users.admin import DBAdmin
from ss_api.models.users.base import UserStatus
from ss_api.models.users.doctor import DBDoctor
from ss_api.models.users.limits.admin_creation_limit import DBAdminLimits
from ss_api.models.users.utility import user_type_to_class_id
from ss_api.models.utils.patch import PatchBody, PatchOperation, apply_patch
from ss_api.utils.auth import AuthAdmin, AuthUser
from ss_api.utils.auth.auth import AuthNotPatient, AuthSuperAdmin
from ss_api.utils.depends import QueryUser
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

router = APIRouter(prefix="/users", tags=["users"])


@router.get("", response_model=List[User])
async def query_users(
    _: AuthNotPatient,
    q: str,
    pagination: QueryPagination,
    types: Annotated[Set[UserType], Query(alias="type")] = {*UserType.__members__.values()},
) -> List[DBUser]:
    query = DBUserBase.find(Text(search=q), with_children=True)
    if types is not None:
        class_ids = list(map(user_type_to_class_id, types))
        query = query.find(In("_class_id", class_ids))
    query = pagination(query)
    return await query.to_list()


@router.get("/{user_id}", response_model=User | dict)
async def get_user(_: AuthUser, user: QueryUser) -> DBUser | dict:
    return user


async def doctor_patch(doctor: DBDoctor, operations: list[PatchOperation], admin: DBAdmin) -> DBDoctor:
    try:
        patch_dict = apply_patch(doctor, operations)
        doctor.__update_model__(**patch_dict)

        limit_change = 0
        for operation in operations:
            if operation.path == "/signatureLimit/available" and operation.op == "replace":
                if operation.value is None:
                    raise HTTPException(status_code=422, detail="Signature limit cannot be negative")
                limit_change = operation.value - doctor.signatureLimit.available
        admin_limits = await DBAdminLimits.find_one(DBAdminLimits.adminId == admin.id)
        if not admin_limits:
            raise HTTPException(status_code=404, detail="Admin limits not found")
        available_signatures = admin_limits.docuSignLimit
        if limit_change > available_signatures:
            raise HTTPException(status_code=403, detail="Admin does not have enough DocuSign signatures to allocate")

        # Apply the patch and update admin's allocated limit
        patched = doctor.__class__(**patch_dict)
        admin_limits.docuSignLimit -= limit_change
        await admin_limits.save()
        return patched

    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.patch("/{user_id}", response_model=Success)
async def update_user(admin: AuthAdmin, user: QueryUser, patch: PatchBody) -> Success:
    try:
        if user.__user_type__ == "doctor" and admin.__class__ == DBAdmin:
            detected = False
            for operation in patch:
                if operation.path == "/signatureLimit/available" and operation.op == "replace":
                    detected = True
            if detected:
                user = await doctor_patch(user, patch, admin)
            else:
                user = user.patch(*patch)
        else:
            user = user.patch(*patch)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    user.insert_edit_log(EditLog(by=admin.id))

    await user.save()

    return Success()


@router.get("/{user_id}/change_admin_structure", response_model=Success)
async def get_admin_structure(
    admin: AuthSuperAdmin,
    user: QueryUser,
) -> DBUserBase:
    return Success(data=user)


@router.patch("/{user_id}/change_admin_structure", response_model=Success)
async def change_admin_structure(
    admin: AuthSuperAdmin,
    user: QueryUser,
    createdBy: str,
) -> Success:

    if user.creator is None:
        user.creator = user.createdBy
    # Change the createdBy field to ObjectID of the new admin
    user.createdBy = ObjectId(createdBy)
    query_permissions = DBPermission.find(
        {"$or": [{"patientId": {"$in": [user.id]}}, {"targetId": {"$in": [user.id]}}]}
    )
    await query_permissions.delete()

    await user.save()
    return Success()


@router.put("/{user_id}/suspend", response_model=Success)
async def suspend_admin(
    admin: AuthAdmin,
    user: QueryUser,
):
    if not user:
        print("User not found")
        raise HTTPException(status_code=404, detail="User not found")

    if admin.status == UserStatus.SUSPENDED:
        print("Admin is suspended")
        raise HTTPException(status_code=400, detail="Admin is suspended")

    if user.status == UserStatus.SUSPENDED:
        print("User is already suspended")
        raise HTTPException(status_code=400, detail="User is already suspended")

    user.status = UserStatus.SUSPENDED
    await user.save()

    return Success(message="User suspended successfully")


@router.put("/{user_id}/activate", response_model=Success)
async def activate_admin(admin: AuthAdmin, user: QueryUser):
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if admin.status == UserStatus.SUSPENDED:
        raise HTTPException(status_code=400, detail="Admin is suspended")

    if user.status == UserStatus.ACTIVE:
        raise HTTPException(status_code=400, detail="User is already Active")

    user.status = UserStatus.ACTIVE
    await user.save()
    return Success(message="User Activated successfully")
