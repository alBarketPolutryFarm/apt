import logging
from typing import List

from fastapi import APIRouter, HTTPException
from pymongo import ASCENDING

from ss_api.models.alarm import DBMeasureOutOfBoundsAlarm
from ss_api.models.measures import (
    DBMeasureBase,
    Measure,
    MeasuresSummary,
    MeasureType,
    NewMeasure,
)
from ss_api.models.measures.summary import DBMeasuresSummary
from ss_api.models.monitoring_plan import DBMonitoringPlan
from ss_api.models.monitoring_plan.monitored_measure import DBMonitoredGenericMeasure
from ss_api.utils.auth import AuthPatient
from ss_api.utils.db import query_sort
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination
from ss_api.utils.responses import Success

_logger = logging.getLogger(__package__)

router = APIRouter(prefix="/measures", tags=["measures"])


@router.post("", status_code=201, response_model=Success)
async def insert_measures(measures: List[NewMeasure], patient: AuthPatient) -> Success:
    monitoring_plan = await DBMonitoringPlan.get_current(patient=patient)

    if monitoring_plan is not None:
        for m in measures:
            if monitoring_plan.__dict__.get(m.metadata.type) is None:
                raise HTTPException(status_code=403, detail=f"You cannot send measure of type '{m.metadata.type}'")

    for m in measures:
        m = m.get_db_model()(**m.model_dump(), patientId=patient.id)
        await m.insert()

        if monitoring_plan is not None:
            measure_plan: DBMonitoredGenericMeasure = dict(monitoring_plan).get(m.metadata.type)  # type: ignore

            try:
                if m.is_out_of_bounds(measure_plan):
                    await DBMeasureOutOfBoundsAlarm(
                        patientId=patient.id, measure=m.model_dump(), plan=measure_plan
                    ).create()
            except NotImplementedError:
                _logger.warning(f"Measure bounds check for type '{m.metadata.type}' is ignored")

    return Success("Measures were inserted")


@router.get("/summary", response_model=MeasuresSummary, response_model_exclude_none=True)
async def get_measures_summary(patient: AuthPatient) -> DBMeasuresSummary:
    return await DBMeasuresSummary.compute(patient)


@router.get("/{measure_type}", response_model=List[Measure])
async def get_measures(
    pagination: QueryPagination,
    patient: AuthPatient,
    measure_type: MeasureType | None = None,
    date_range=query_date_range(),
) -> List[Measure]:
    query = DBMeasureBase.find({"patientId": patient.id, "metadata.type": measure_type}, with_children=True)

    query = filter_by_date_range(query, date_range)
    query = query_sort(query, "timestamp", ASCENDING)
    query = pagination(query)

    return await query.to_list()
