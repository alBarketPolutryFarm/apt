from typing import List

from fastapi import APIRouter
from pymongo import DESCENDING

from ss_api.models.monitoring_plan.monitoring_plan import (
    DBMonitoringPlan,
    MonitoringPlan,
)
from ss_api.utils.auth import AuthPatient
from ss_api.utils.db import query_sort
from ss_api.utils.query_string.date_range import filter_by_date_range, query_date_range
from ss_api.utils.query_string.pagination import QueryPagination

router = APIRouter(prefix="/monitoring-plans", tags=["monitoring plans"])


@router.get("", response_model=List[MonitoringPlan], response_model_exclude_none=True)
async def get_monitoring_plans_list(
    pagination: QueryPagination, patient: AuthPatient, date_range=query_date_range()
) -> List[DBMonitoringPlan]:
    query = DBMonitoringPlan.find(DBMonitoringPlan.patientId == patient.id)
    query = filter_by_date_range(query, date_range)
    query = query_sort(query, "effectiveDate", DESCENDING)
    query = pagination(query)
    return await query.to_list()
