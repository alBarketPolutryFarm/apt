import logging
from contextlib import asynccontextmanager
from logging import getLogger

from fastapi import FastAPI
from firebase_admin import credentials, initialize_app
from pydantic import ValidationError
from pymongo.errors import OperationFailure, ServerSelectionTimeoutError
from starlette.middleware.cors import CORSMiddleware

from ss_api.utils.db.init_db import (
    create_broadcast_chat,
    create_first_super_admin,
    init_db_connection,
)
from ss_api.utils.tasks.password_remember import init_password_reminder_tasks

from ._version import __version__
from .utils.init_api import init_api
from .utils.logging import setup_default_logger
from .utils.middleware import RootPathPrefixStrip
from .utils.middleware.error_handlers import init_error_handlers
from .utils.settings import get_settings
from .utils.tasks import init_background_tasks


def create_app() -> FastAPI:
    setup_default_logger()

    try:
        setting = get_settings()
    except ValidationError as e:
        getLogger(__package__).critical(f"> missing required settings field `{e.errors()[0]['loc'][0]}`")
        exit(1)

    logger = getLogger(__package__)

    logger.info(f"> system in '{setting.mode.upper()}' mode")

    incomplete_initialization = None
    if not setting.graylog:
        logger.error("> missing `graylog` configuration, the API will not report logs properly")
    if not setting.orthanc:
        logger.error("> missing `orthanc` connection configuration, the API will not work properly")
        incomplete_initialization = True
    if not setting.smtp:
        logger.error("> missing `smtp` connection configuration, the API will not work properly")
        incomplete_initialization = True
    if not setting.open_api:
        logger.error("> missing `open api` configuration, the API will not work properly")
        incomplete_initialization = True
    if not setting.firebase_credentials_path:
        logger.error("> missing `firebase` configuration, the API will not work properly")
        incomplete_initialization = True
    if not setting.pdf_turtle:
        logger.error("> missing `pdf turtle` configuration, the API will not work properly")
        incomplete_initialization = True

    if incomplete_initialization and setting.mode == "production":
        logger.fatal("> in production mode api must be complitelly configured")
        exit(1)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Setup DB connection
        logger.info("> trying to connect to db and initialize collections...")
        try:
            await init_db_connection()
        except ServerSelectionTimeoutError:
            logger.critical("> unable to connect to db: timeout")
            exit(1)
        except OperationFailure as e:
            logger.critical("> unable to connect to db: authentication")
            logger.debug(e)
            exit(1)

        logger.info("> db connection established")

        if setting.admin:
            if await create_first_super_admin(setting.admin.email, setting.admin.password):
                logger.info("> the admin was created")
            else:
                logger.info("> skip, the admin already exists")
        logger.info("> trying to create broadcast chat...")
        if await create_broadcast_chat():
            logger.info("> the broadcast chat was created")
        else:
            logger.info("> skip, the broadcast chat already exists")

        # Setup Firebase
        if setting.firebase_credentials_path:
            logger.info("> trying to setup to firebase...")
            firebase_credential = credentials.Certificate(setting.firebase_credentials_path)
            initialize_app(firebase_credential)
            logger.info("> firebase setup completed")

        # Setup background tasks
        logger.info("> setup to background tasks")
        init_background_tasks()
        logger.info("> setup to run password reminder tasks")
        init_password_reminder_tasks()
        logger.info("> API ready")
        yield

    app = FastAPI(
        title="Servizio Salute",
        docs_url="/" if setting.debug else None,
        redoc_url="/redoc" if setting.debug else None,
        lifespan=lifespan,
        debug=setting.debug,
        root_path=setting.base_url.path if setting.base_url and setting.base_url.path != "/" else None,
        version=__version__,
    )

    logger.info("> Starting...")

    if app.root_path:
        logger.info("> add middleware to strip prefix")
        app.add_middleware(RootPathPrefixStrip)

    logger.info("> settings loaded")
    if setting.debug:
        internal_loggers = [
            getLogger(name)
            for name in logging.root.manager.loggerDict
            if name.startswith(__package__) or name == "root"
        ]
        for logger in internal_loggers:
            logger.setLevel(logging.DEBUG)

        logger.debug(setting)

        logger.warning("> debug mode enabled")

    app = init_api(app)
    logger.info("> init endpoints")

    if setting.cors:
        logger.warning("> CORS enabled")
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    logger.info("> init error handlers")
    init_error_handlers(app)

    # Fix ip logging if behind a revxpoxy
    # app.app.wsgi_app = ProxyFix(app.app.wsgi_app)
    # app.app.register_error_handler(Exception, mk_errors_handler(app))

    return app
