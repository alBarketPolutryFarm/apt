import os

import uvicorn

from ss_api.utils.settings import ENV_PREFIX

if __name__ == "__main__":
    uvicorn.run(
        f"{__package__}:create_app",
        host=os.getenv(f"{ENV_PREFIX}HOST", "127.0.0.1"),
        port=os.getenv(f"{ENV_PREFIX}PORT", 8001),
        reload=True,
        factory=True,
    )
