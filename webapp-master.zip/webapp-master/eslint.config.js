const eslintConfigPrettier = require('eslint-config-prettier')
const eslintConfigStandard = require('eslint-config-standard')
const eslintImport = require('eslint-plugin-import')
const eslintJS = require('@eslint/js')
const n = require('eslint-plugin-n')
const promise = require('eslint-plugin-promise')
const globals = require('globals')
const sortImportsES6Autofix = require('eslint-plugin-sort-imports-es6-autofix')
const typescriptEslint = require('@typescript-eslint/eslint-plugin')
const typescriptEslintParser = require('@typescript-eslint/parser')
const vue = require('eslint-plugin-vue')
const vueEslintParser = require('vue-eslint-parser')
const prettier = require('eslint-plugin-prettier')

module.exports = [
  {
    ignores: ['node_modules', 'app', '.quasar', 'dist']
  },
  {
    files: ['**/*.js', '**/*.cjs'],
    languageOptions: {
      globals: {
        ...globals.browser,
        ...globals.node
      }
    },
    plugins: {
      'sort-imports-es6-autofix': sortImportsES6Autofix,
      import: eslintImport,
      n,
      promise
    },
    rules: {
      ...eslintJS.configs.recommended.rules,
      ...eslintConfigStandard.rules,
      ...eslintConfigPrettier.rules,
      'sort-imports-es6-autofix/sort-imports-es6': [
        2,
        {
          ignoreCase: false,
          ignoreMemberSort: false,
          memberSyntaxSortOrder: ['none', 'all', 'multiple', 'single']
        }
      ],
      'no-empty-function': 'off',
      'no-console': 'warn'
      // temporary disabled TODO renabled
    }
  },
  {
    files: ['**/*.ts'],
    languageOptions: {
      parser: typescriptEslintParser,
      parserOptions: {
        project: ['./tsconfig.json'],
        ecmaFeatures: {
          jsx: true
        },
        ecmaVersion: 6,
        sourceType: 'module',
        globals: {
          ...globals.browser,
          ...globals.node
        }
      }
    },
    plugins: {
      'sort-imports-es6-autofix': sortImportsES6Autofix,
      '@typescript-eslint': typescriptEslint,
      import: eslintImport
    },
    rules: {
      ...typescriptEslint.configs['recommended-type-checked'].rules,
      ...typescriptEslint.configs.strict.rules,
      ...eslintImport.configs.typescript.rules,
      ...eslintConfigPrettier.rules,
      'no-empty-function': 'off',
      'no-use-before-define': 'off',
      '@typescript-eslint/no-unsafe-enum-comparison': 'off',
      '@typescript-eslint/no-empty-function': 'off',
      '@typescript-eslint/no-use-before-define': 'off',
      '@typescript-eslint/explicit-module-boundary-types': 'off',
      '@typescript-eslint/no-floating-promises': 'off',
      '@typescript-eslint/semi': 'off',
      '@typescript-eslint/member-delimiter-style': 'off',
      '@typescript-eslint/no-unused-vars': [
        'warn',
        { argsIgnorePattern: '^_$' }
      ],
      '@typescript-eslint/no-redundant-type-constituents': 'off',
      '@typescript-eslint/no-invalid-void-type': 'off',
      '@typescript-eslint/no-dynamic-delete': 'off'
    },
    settings: {
      react: {
        createClass: 'createReactClass',
        pragma: 'React',
        fragment: 'Fragment',
        version: 'detect',
        flowVersion: '0.53'
      }
    }
  },
  {
    files: ['**/*.vue'],
    languageOptions: {
      parser: vueEslintParser,
      parserOptions: {
        parser: typescriptEslintParser,
        parserOptions: {
          project: ['./tsconfig.json'],
          tsconfigRootDir: __dirname,
          ecmaFeatures: {
            jsx: true
          },
          ecmaVersion: 6,
          sourceType: 'module',
        }
      },
      globals: {
        ...globals.browser,
        ...globals.node,
        __statics: 'readonly',
        __QUASAR_SSR__: 'readonly',
        __QUASAR_SSR_SERVER__: 'readonly',
        __QUASAR_SSR_CLIENT__: 'readonly',
        __QUASAR_SSR_PWA__: 'readonly'
      }
    },
    plugins: {
      prettier,
      vue
    },
    rules: {
      //
      'prettier/prettier': ['error'],
      ...vue.configs['vue3-essential'].rules,
      ...vue.configs['vue3-strongly-recommended'].rules,
      ...vue.configs['vue3-recommended'].rules,
      'vue/multi-word-component-names': 'off',
      'vue/html-closing-bracket-newline': 'off',
      // prettier conflict rules
      'vue/html-indent': 'off',
      'vue/first-attribute-linebreak': 'off',
      'vue/max-attributes-per-line': 'off',
      'vue/multiline-html-element-content-newline': 'off',
      'vue/singleline-html-element-content-newline': 'off',
      'vue/html-self-closing': 'off'
    },
    settings: {
      'prettier-vue': {
        SFCBlocks: {
          template: true,
          script: true,
          style: true,
          customBlocks: {
            docs: { lang: 'markdown' },
            config: { lang: 'json' },
            module: { lang: 'js' },
            comments: false
          }
        },
        usePrettierrc: true
      }
    }
  }
]
