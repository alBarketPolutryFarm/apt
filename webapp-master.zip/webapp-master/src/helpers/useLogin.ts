import { getUser } from 'src/api/user'
import { computed, watch } from 'vue'
import { User } from 'src/api/user/models'
import { useDispatch, useSelector } from 'src/redux/helpers'
import { resetToken, setUser } from 'src/redux/auth'
import useQuery from 'src/api/useQuery'
import useCookies from 'src/helpers/useCookies'

type Status = {
  isLogged: boolean
  user?: User
}

const COOKIE_NAME = 'Authorization'

export default () => {
  const dispatch = useDispatch()
  const auth = useSelector(state => state.auth)

  const userQuery = useQuery(getUser)

  watch(userQuery, q => {
    if (!q.isSuccess || q.data === undefined) return
    dispatch(setUser(q.data))
  })
  watch(userQuery, q => {
    if (!q.isError) return
    dispatch(resetToken())
  })

  const cookies = useCookies()

  watch(
    auth,
    ({ token }) => {
      const cookiePayload = cookies?.get(COOKIE_NAME) as string | undefined

      if (token && cookiePayload !== token) cookies?.set(COOKIE_NAME, token)
      else if (!token && cookiePayload) cookies?.remove(COOKIE_NAME)
    },
    { immediate: true }
  )

  return computed<Status>(() => ({
    isLogged: auth.value.token !== undefined,
    user: auth.value.user
  }))
}
