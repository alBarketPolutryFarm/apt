import { DateTime } from 'luxon'

const jsonParserKeys = {
  dateTime: [
    'createdAt',
    'at',
    'effectiveDate',
    'expirationDate',
    'birthDate',
    'notBefore',
    'notAfter',
    'claimedAt',
    'time',
    'timestamp',
    'lastUpdate',
    'lastRead'
  ]
}

export const jsonReviver = (key: string, value: string): unknown => {
  if (value === null) return undefined
  if (jsonParserKeys.dateTime.includes(key)) return DateTime.fromISO(value)
  return value as unknown
}

export const jsonParse = (data: string) =>
  JSON.parse(data, jsonReviver) as unknown

export const serializableReplacer = (key: string, value: unknown): unknown => {
  if (DateTime.isDateTime(value)) return value.toISO()
  return value
}
export const makeSerializable = <T, H>(data: T): unknown =>
  JSON.parse(JSON.stringify(data, serializableReplacer)) as unknown as H
