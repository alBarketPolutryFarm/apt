import { VueCookies } from 'vue-cookies'
import { inject } from 'vue'

export default () => inject<VueCookies>('$cookies')
