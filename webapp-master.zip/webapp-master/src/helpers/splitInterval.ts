import { Duration, Interval } from 'luxon'

export type Unit = 'month' | 'day'

const DurationISO: Record<Unit, string> = {
  month: 'P1M',
  day: 'P1D'
} as const

export default (interval: Interval, unit: 'month' | 'day'): Interval[] => {
  interval = interval.set({
    start: interval.start.startOf(unit),
    end: interval.end.endOf(unit)
  })

  return interval.splitBy(Duration.fromISO(DurationISO[unit]))
}
