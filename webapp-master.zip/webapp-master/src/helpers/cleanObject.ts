const cleanObject = <T>(obj: T): T | undefined => {
  if (typeof obj === 'string' && obj === '') return undefined
  if (!obj) return undefined
  if (typeof obj !== 'object') return obj
  for (const key in obj) {
    const value = cleanObject(obj[key])
    if (!value) delete obj[key]
    else obj[key] = value
  }
  if (Object.keys(obj).length === 0) return undefined
  return obj
}

export default cleanObject
