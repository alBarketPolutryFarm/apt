import { FileEncoded } from 'src/api/files/models'
import notify from 'src/helpers/notify'
import { AxiosResponse } from 'axios'

export default async (query: Promise<AxiosResponse<FileEncoded, unknown>>) => {
  await query
    .then(r =>
      window.open(
        new URL(r.config.url as string, r.config.baseURL).href,
        '_blank'
      )
    )
    .catch(() => notify('Impossibile recuperare il documento', 'negative'))
}
