import { QNotifyCreateOptions } from 'quasar'
import { Notify } from 'quasar'

const notificationTypes = ['positive', 'warning', 'negative'] as const

export default (
  message: string,
  type: (typeof notificationTypes)[number] = 'positive',
  options?: QNotifyCreateOptions
) =>
  Notify.create({
    type,
    message,
    position: 'top-right',
    timeout: 2000,
    ...(options ?? {})
  })
