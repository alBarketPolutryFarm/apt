import { DateTime, Interval } from 'luxon'
import splitInterval, { Unit } from './splitInterval'

interface Group<T> {
  interval: Interval
  items: T[]
}

export default <T>(
  items: T[],
  toDate: (item: T) => DateTime,
  unit: Unit,
  interval: Interval,
  order: 'ascendant' | 'descendant'
): Group<T>[] => {
  if (items.length === 0) return []

  const sortFunction =
    order === 'ascendant'
      ? (a: DateTime, b: DateTime) => b.diff(a).toMillis()
      : (a: DateTime, b: DateTime) => a.diff(b).toMillis()

  const splits = Object.fromEntries(
    splitInterval(interval, unit)
      .sort((i, j) => sortFunction(i.start, j.start))
      .map(i => [i.start.toISO(), { interval: i, items: [] }])
  ) as Record<string, Group<T>>

  for (const i of items) {
    splits[toDate(i).startOf(unit).toISO()].items?.push(i)
  }

  return Object.entries(splits)
    .map(([, v]) => v)
    .reverse()
}
