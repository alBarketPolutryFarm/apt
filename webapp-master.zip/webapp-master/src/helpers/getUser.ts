import { computed, Ref, watch } from 'vue'
import { useDispatch, useSelector } from 'src/redux/helpers'
import { getUser } from 'src/api/users'
import { addUser } from 'src/redux/users'
import { User } from 'src/api/user/models'

export default (userId: string | Ref<string>): Ref<User | undefined> => {
  const users = useSelector(state => state.users)
  const _userId = computed(() =>
    typeof userId === 'string' ? userId : userId.value
  )

  const user = computed(() => users.value[_userId.value])

  const dispatch = useDispatch()
  watch(
    user,
    u => {
      if (u !== undefined) return
      getUser(_userId.value).then(r => dispatch(addUser(r.data)))
    },
    { immediate: true }
  )

  return user
}
