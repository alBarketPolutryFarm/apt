import { DateTime } from 'luxon'
import { addChatMessages, updateChatMetadata } from 'src/redux/chats'
import { useDispatch, useSelector } from 'src/redux/helpers'
import { computed, Ref, watch, watchEffect } from 'vue'
import useQuery from 'src/api/useQuery'
import { getChat } from 'src/api/chats'
import { getChatMessages, sendChatMessage } from 'src/api/chats/messages'
import { ChatMessage, NewChatMessage } from 'src/api/chats/messages/models'
import useMutation from 'src/api/useMutation'
import { Chat } from 'src/api/chats/models'

interface ChatStatus {
  chat?: Chat
  messages?: ChatMessage[]
  lastUpdate?: DateTime
  lastRead?: DateTime
  lastMessage?: ChatMessage
  sendMessage: (message: NewChatMessage) => void
}

export default (chatId: Ref<string>) => {
  const dispatch = useDispatch()

  watch(useQuery(getChat, chatId), q => {
    if (!q.isSuccess) return
    if (!q.data) return

    dispatch(updateChatMetadata(q.data))
  })

  const chatsState = useSelector(state => state.chats)
  const chatState = computed(() => chatsState.value[chatId.value])

  const defaultStartDate = DateTime.now().minus({ days: 7 })
  const getChatMessagesParams = computed(() => ({
    //startDate: defaultStartDate
    startDate: chatState.value?.lastUpdate ?? defaultStartDate
  }))

  const getChatMessagesQuery = useQuery(
    getChatMessages,
    chatId,
    getChatMessagesParams
  )

  watch(getChatMessagesQuery, q => {
    if (!q.isSuccess) return
    if (!q.data) return

    dispatch(
      addChatMessages({
        chatId: chatId.value,
        messages: q.data
      })
    )
  })

  watchEffect(onCleanup => {
    const interval = setInterval(() => {
      getChatMessagesQuery.refetch()
    }, 2000)
    onCleanup(() => clearInterval(interval))
  })

  const [triggerSendMessage, sendChatMessageStatus] =
    useMutation(sendChatMessage)
  watch(sendChatMessageStatus, q => {
    if (!q.isSuccess) return
    getChatMessagesQuery.refetch()
  })

  return computed<ChatStatus>(() => ({
    chat: chatState.value?.chat,
    messages: chatState.value?.messages,
    lastUpdate: chatState.value?.lastUpdate,
    lastRead: chatState.value?.lastRead,
    lastMessage:
      chatState.value?.messages !== undefined &&
      chatState.value.messages.length !== 0
        ? chatState.value.messages[chatState.value.messages.length - 1]
        : undefined,
    sendMessage: (message: NewChatMessage) => {
      triggerSendMessage(chatId.value, message)
    }
  }))
}
