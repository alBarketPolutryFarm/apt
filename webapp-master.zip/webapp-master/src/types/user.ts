export enum UserType {
  ADMIN = 'admin',
  SUPERADMIN = 'superadmin',
  PATIENT = 'patient',
  DOCTOR = 'doctor',
  NURSE = 'nurse',
  OPERATOR = 'operator',
  CAREGIVER = 'caregiver'
}
