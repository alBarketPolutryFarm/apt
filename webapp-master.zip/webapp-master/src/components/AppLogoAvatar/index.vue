<script setup lang="ts">
const props = defineProps<{ class?: string }>()
</script>

<template>
  <q-avatar color="white" :class="props.class">
    <img
      src="~assets/logo.png"
      alt="Infermieri Annunci"
      style="width: 100%; height: 100%" />
  </q-avatar>
</template>
