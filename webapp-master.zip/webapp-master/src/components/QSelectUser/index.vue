<script setup lang="ts">
import { computed, ref } from 'vue'
import { User, UserType } from 'src/api/user/models'
import { queryUsers } from 'src/api/users'
import { UserStrings } from 'src/const/User'

const EMBEDDED_RULES = {
  required: (v: string) => !!v || 'utente richiesto'
} as const

const props = defineProps<{
  modelValue?: string
  readonly?: boolean
  label?: string
  class?: string
  userType?: UserType[]
  rules?: (((v: string) => boolean | string) | keyof typeof EMBEDDED_RULES)[]
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()

const options = ref<User[]>()

const filter = (
  q: string,
  update: (callback: () => void) => void,
  abort: () => void
) => {
  if (q.length < 3) return abort()

  queryUsers({ q, type: props.userType, limit: 10 })
    .then(r => r.data)
    .then(v => update(() => (options.value = v)))
    .catch(abort)
}

const rules = computed(() => [
  ...(props.rules ?? []).map(r =>
    typeof r === 'string' && r in EMBEDDED_RULES ? EMBEDDED_RULES[r] : r
  )
])
</script>

<template>
  <q-select
    :model-value="modelValue"
    :option-label="(n: User) => `${n.firstName} ${n.lastName}`"
    option-value="_id"
    map-options
    emit-value
    :rules="rules"
    use-input
    hide-selected
    fill-input
    input-debounce="0"
    :readonly="props.readonly"
    :label="props.label"
    :class="props.class"
    :options="options"
    @filter="filter"
    @update:model-value="(id: string) => emit('update:modelValue', id)">
    <template #option="{ itemProps, opt }">
      <q-item v-if="opt" v-bind="itemProps">
        <q-item-section>
          <q-item-label>{{ opt.firstName }} {{ opt.lastName }}</q-item-label>
          <q-item-label caption>
            {{ UserStrings[opt.type] }}
          </q-item-label>
        </q-item-section>
      </q-item>
    </template>

    <template #no-option>
      <q-item>
        <q-item-section class="text-grey">
          Nessun utente trovato
        </q-item-section>
      </q-item>
    </template>
  </q-select>
</template>
