<template>
  <q-input
    v-model="screeningData.title"
    :readonly="readOnly"
    label="Titolo"
    lazy-rules
    :rules="[val => !!val || 'Il titolo è obbligatorio']" />

  <q-input-date-time
    :model-value="startAtFormatted"
    :readonly="readOnly"
    label="Data di inizio"
    style="width: 50%"
    :rules="[
      val => !!val || 'La data di inizio è obbligatoria',
      val => {
        if (!val) return true
        if (!screeningData.endAt) return true
        return (
          DateTime.fromFormat(val, 'HH:mm dd/MM/yyyy') <
            DateTime.fromISO(screeningData.endAt) ||
          'La data di inizio deve essere precedente a quella di fine'
        )
      }
    ]"
    @update:model-value="
      value => {
        screeningData.startAt = value.toISO()
      }
    " />
  <q-input-date-time
    :model-value="endAtFormatted"
    :readonly="readOnly"
    label="Data di fine"
    style="width: 50%"
    :rules="[
      val => !!val || 'La data di fine è obbligatoria',
      val => {
        if (!val) return true
        return (
          DateTime.fromFormat(val, 'HH:mm dd/MM/yyyy') >
            DateTime.fromISO(screeningData.startAt) ||
          'La data di fine deve essere successiva a quella di inizio'
        )
      }
    ]"
    @update:model-value="
      value => {
        screeningData.endAt = value.toISO()
      }
    " />
  <h6 class="q-mb-md q-mt-md" style="font-size: medium">Contenuto</h6>
  <q-editor
    v-model="screeningData.body"
    :readonly="readOnly"
    min-height="200px"
    toolbar-bg="grey-2"
    :toolbar="[
      ['left', 'center', 'right'],
      [
        {
          label: 'Tipo di paragrafo',
          icon: $q.iconSet.editor.formatting,
          list: 'no-icons',
          options: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p']
        },
        {
          label: 'Dimensione testo',
          icon: $q.iconSet.editor.fontSize,
          fixedLabel: true,
          fixedIcon: true,
          list: 'no-icons',
          options: [
            'size-1',
            'size-2',
            'size-3',
            'size-4',
            'size-5',
            'size-6',
            'size-7'
          ]
        },
        'bold',
        'italic',
        'underline',
        'strike'
      ],
      ['unordered', 'ordered', 'outdent', 'indent'],
      ['link'],
      ['fullscreen']
    ]" />
</template>

<script setup lang="ts">
import { NewScreening, Screening } from 'src/api/screenings/models'
import { computed, ref } from 'vue'
import { DateTime } from 'luxon'
import QInputDateTime from 'src/components/QInputDateTime/index.vue'

const props = defineProps<{
  screening: Screening | NewScreening
  readOnly?: boolean
}>()
const emit = defineEmits<{
  (e: 'update:screening', value: Screening | NewScreening): void
}>()

const screeningData = computed({
  get: () => props.screening,
  set: value => emit('update:screening', value)
})

const validateForm = async () => {
  if (!screeningData.value.title) {
    return false
  }
  if (!screeningData.value.startAt) {
    return false
  }
  if (!screeningData.value.endAt) {
    return false
  }
  if (!screeningData.value.body) {
    return false
  }
  return true
}

const startAtFormatted = computed(() => {
  const date = DateTime.fromISO(screeningData.value.startAt)
  if (date.isValid) {
    return date
  }
  return undefined
})

const endAtFormatted = computed(() => {
  const date = DateTime.fromISO(screeningData.value.endAt)
  if (date.isValid) {
    return date
  }
  return undefined
})

defineExpose({
  validateForm
})
</script>
