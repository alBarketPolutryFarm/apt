<script setup lang="ts">
import { DateTime } from 'luxon'
import { computed, ref, watch } from 'vue'

const EMBEDDED_RULES = {
  required: (v: string) => !!v || 'Data richiesta',
  notFutureDate: (v: string) =>
    !v ||
    DateTime.fromFormat(v, FIELD_FORMAT).startOf('day') <=
      DateTime.now().startOf('day') ||
    'La data non può essere futura'
} as const

const props = defineProps<{
  modelValue?: DateTime
  readonly?: boolean
  loading?: boolean
  label?: string
  class?: string
  rules?: (((v: string) => boolean | string) | keyof typeof EMBEDDED_RULES)[]
  optionsTime?: (hr: number, min: number, sec: number) => boolean
  optionsDate?:
    | ((data: string) => boolean)
    | 'future'
    | 'past'
    | 'notPast'
    | 'notFuture'
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: DateTime): void
}>()

const _modelValue = computed(
  () => props.modelValue?.toFormat('yyyy-MM-dd HH:mm')
)

const FIELD_FORMAT = 'HH:mm dd/MM/yyyy'

const textInput = ref<string>('')
const updateTextInput = (d: string) => {
  const date = DateTime.fromFormat(d, FIELD_FORMAT)
  if (!date.isValid) return
  emit('update:modelValue', date)
}

const rules = computed(() => [
  (v: string) =>
    v === '' ||
    DateTime.fromFormat(v, FIELD_FORMAT).isValid ||
    'Data non valida',
  ...(props.rules ?? []).map(r =>
    typeof r === 'string' && r in EMBEDDED_RULES ? EMBEDDED_RULES[r] : r
  )
])

watch(
  () => props.modelValue,
  v => {
    if (v === undefined) return
    textInput.value = v.toFormat(FIELD_FORMAT)
  },
  { immediate: true }
)

const optionsDate = computed(() => {
  if (!props.optionsDate) return
  else if (props.optionsDate === 'past')
    return (date: string) => date < DateTime.now().toFormat('yyyy/MM/dd')
  else if (props.optionsDate === 'future')
    return (date: string) => date > DateTime.now().toFormat('yyyy/MM/dd')
  else if (props.optionsDate === 'notPast')
    return (date: string) => date >= DateTime.now().toFormat('yyyy/MM/dd')
  else if (props.optionsDate === 'notFuture')
    return (date: string) => date <= DateTime.now().toFormat('yyyy/MM/dd')
  return props.optionsDate
})
</script>

<template>
  <q-input
    :loading="props.loading"
    :model-value="textInput"
    :readonly="props.readonly"
    :label="props.label"
    :class="props.class"
    mask="##:## ##/##/####"
    :rules="rules"
    @update:model-value="updateTextInput">
    <template #append>
      <q-icon v-if="!props.readonly" name="event" class="cursor-pointer">
        <q-popup-proxy cover transition-show="scale" transition-hide="scale">
          <div class="row q-gutter-sm q-pa-sm">
            <q-date
              :options="optionsDate"
              mask="YYYY-MM-DD HH:mm"
              today-btn
              :model-value="_modelValue"
              @update:model-value="
                (_, __, { year, month, day, hour, minute }) =>
                  emit(
                    'update:modelValue',
                    DateTime.fromObject({
                      year,
                      month,
                      day,
                      hour: hour ?? modelValue?.hour ?? 0,
                      minute: minute ?? modelValue?.minute ?? 0
                    })
                  )
              ">
            </q-date>
            <q-time
              :options="props.optionsTime"
              :model-value="_modelValue"
              format24h
              mask="YYYY-MM-DD HH:mm"
              @update:model-value="
                (_, { year, month, day, hour, minute }) =>
                  emit(
                    'update:modelValue',
                    DateTime.fromObject({ year, month, day, hour, minute })
                  )
              " />
          </div>
        </q-popup-proxy>
      </q-icon>
    </template>
  </q-input>
</template>
