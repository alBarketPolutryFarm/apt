<script setup lang="ts">
import { DateTime, Duration } from 'luxon'
import QInputDateTime from 'src/components/QInputDateTime'
import {
  ComponentPublicInstance,
  computed,
  reactive,
  ref,
  toRaw,
  watch
} from 'vue'
import { MeasureType } from 'src/const/Measure'
import ApexChart from 'vue3-apexcharts'
import { COLUMNS, DEFAULT_CHART_OPTIONS } from './consts'
import useQuery from 'src/api/useQuery'
import { getPatientMeasuresByType } from 'src/api/patients/measures'
import {
  BloodPressure,
  Measure,
  WaterBalance
} from 'src/api/patients/measures/models'
import { get_columns } from 'components/UsersTable/const'

const props = defineProps<{
  type: MeasureType
  patientId: string
  isEnabled?: boolean
}>()

const chart = ref<ComponentPublicInstance<typeof ApexChart>>()

const dateRange = reactive<{ start: DateTime; end: DateTime }>({
  start: DateTime.now().minus({ days: 1 }),
  end: DateTime.now()
})
const dateRangeDelta = computed(() => dateRange.end.diff(dateRange.start))

const measuresQuery = useQuery(
  getPatientMeasuresByType,
  computed(() => props.patientId),
  computed(() => props.type),
  computed(() => ({ startDate: dateRange.start, endDate: dateRange.end }))
)

const isAutoUpdateEnabled = ref<boolean>(true)
const autoUpdateInterval = ref<ReturnType<typeof setInterval>>()

const MAX_DATE_RANGE = Duration.fromDurationLike({ months: 1 })
const MIN_DATE_RANGE = Duration.fromDurationLike({ hours: 1 })

const changeStartDataRange = (start: DateTime) => {
  isAutoUpdateEnabled.value = false

  const _start = start > DateTime.now() ? DateTime.now() : start

  const diff = dateRange.end.diff(_start)

  let _end
  if (diff.toMillis() < 0) _end = _start.plus(dateRangeDelta.value)
  else if (diff > MAX_DATE_RANGE) _end = _start.plus(MAX_DATE_RANGE)

  dateRange.start = _start
  if (_end) dateRange.end = _end > DateTime.now() ? DateTime.now() : _end
}
const changeEndDataRange = (end: DateTime) => {
  isAutoUpdateEnabled.value = false

  const _end = end > DateTime.now() ? DateTime.now() : end

  const diff = _end.diff(dateRange.start)

  let _start
  if (diff.toMillis() < 0) _start = _end.minus(dateRangeDelta.value)
  else if (diff > MAX_DATE_RANGE) _start = _end.minus(MAX_DATE_RANGE)

  if (_start) dateRange.start = _start
  dateRange.end = _end
}

const backDateRange = () => {
  isAutoUpdateEnabled.value = false
  updateDateRange(
    dateRange.start.minus(
      Duration.fromMillis(dateRangeDelta.value.toMillis() / 2)
    ),
    dateRange.end.minus(
      Duration.fromMillis(dateRangeDelta.value.toMillis() / 2)
    )
  )
}
const forwardDateRange = () => {
  isAutoUpdateEnabled.value = false
  updateDateRange(
    dateRange.start.plus(
      Duration.fromMillis(dateRangeDelta.value.toMillis() / 2)
    ),
    dateRange.end.plus(Duration.fromMillis(dateRangeDelta.value.toMillis() / 2))
  )
}
const zoomOutDateRange = () => {
  updateDateRange(
    dateRange.start.minus(
      Duration.fromMillis(dateRangeDelta.value.toMillis() / 2)
    ),
    dateRange.end.plus(Duration.fromMillis(dateRangeDelta.value.toMillis() / 2))
  )
}
const zoomInDateRange = () => {
  updateDateRange(
    dateRange.start.plus(
      Duration.fromMillis(dateRangeDelta.value.toMillis() / 4)
    ),
    dateRange.end.minus(
      Duration.fromMillis(dateRangeDelta.value.toMillis() / 4)
    )
  )
}
const homeDateRange = () => {
  updateDateRange(DateTime.now().minus(dateRangeDelta.value), DateTime.now())
}
const updateDateRange = (start: DateTime, end: DateTime) => {
  if (start > end) {
    ;[start, end] = [end, start]
  }

  const middle = start.plus(Duration.fromMillis(end.diff(start).toMillis() / 2))

  if (end.diff(start) > MAX_DATE_RANGE) {
    start = middle.minus(Duration.fromMillis(MAX_DATE_RANGE.toMillis() / 2))
    end = middle.plus(Duration.fromMillis(MAX_DATE_RANGE.toMillis() / 2))
  }

  if (end.diff(start) < MIN_DATE_RANGE) {
    start = middle.minus(Duration.fromMillis(MIN_DATE_RANGE.toMillis() / 2))
    end = middle.plus(Duration.fromMillis(MIN_DATE_RANGE.toMillis() / 2))
  }

  if (end > DateTime.now()) {
    start = DateTime.now().minus(end.diff(start))
    end = DateTime.now()
  }

  dateRange.start = start
  dateRange.end = end
}

const updateChart = (series: unknown) => {
  chart.value?.updateOptions(
    {
      series,
      xaxis: {
        min: dateRange.start.toMillis(),
        max: dateRange.end.toMillis()
      }
    },
    true,
    false,
    false
  )
}

const chartOptions = computed(() => DEFAULT_CHART_OPTIONS)

watch(measuresQuery, m => {
  if (!m.isSuccess || m.data === undefined || m.data.length === 0)
    return updateChart([{ data: [[]] }])
  const data = m.data

  if (props.type === 'bloodPressure')
    return updateChart([
      {
        name: 'sistolica',
        data: (data as BloodPressure[]).map(v => [
          v.timestamp.toMillis(),
          v.systolic
        ])
      },
      {
        name: 'diastolica',
        data: (data as BloodPressure[]).map(v => [
          v.timestamp.toMillis(),
          v.diastolic
        ])
      }
    ])

  if (props.type === 'waterBalance')
    return updateChart([
      {
        name: 'bilancio',
        data: (data as WaterBalance[]).map(v => [
          v.timestamp.toMillis(),
          v.total
        ])
      },
      {
        name: 'entrate/uscite',
        data: (data as WaterBalance[]).map(v => [
          v.timestamp.toMillis(),
          v.value
        ])
      }
    ])

  return updateChart([
    {
      name: 'value',
      data: (data as Exclude<Measure, BloodPressure>[]).map(v => [
        v.timestamp.toMillis(),
        v.value as unknown as number
      ])
    }
  ])
})

watch(
  () => props.isEnabled,
  isEnabled => {
    if (isEnabled) homeDateRange()
  }
)

watch(
  () => [isAutoUpdateEnabled.value, props.isEnabled],
  isEnabled => {
    if (isAutoUpdateEnabled.value && props.isEnabled)
      autoUpdateInterval.value = setInterval(homeDateRange, 10 * 1e3)
    else {
      clearInterval(autoUpdateInterval.value)
      autoUpdateInterval.value = undefined
    }
  },
  { immediate: true }
)

const disableNextbutton = computed(
  () => dateRange.end >= DateTime.now().minus({ minutes: 5 })
)
</script>

<template>
  <div>
    <div
      class="flex row no-wrap items-center justify-between"
      style="gap: 16px">
      <q-input-date-time
        :loading="measuresQuery.isLoading"
        :model-value="dateRange.start"
        label="Da"
        style="flex-grow: 1"
        options-date="notFuture"
        @update:model-value="changeStartDataRange" />
      <q-input-date-time
        :loading="measuresQuery.isLoading"
        :model-value="dateRange.end"
        label="A"
        options-date="notFuture"
        style="flex-grow: 1"
        @update:model-value="changeEndDataRange" />

      <q-btn round size="sm" icon="skip_previous" @click="backDateRange" />
      <q-btn
        round
        size="sm"
        icon="skip_next"
        :disabled="disableNextbutton"
        @click="forwardDateRange" />
      <q-btn
        round
        size="sm"
        icon="zoom_out"
        :disabled="dateRangeDelta >= MAX_DATE_RANGE"
        @click="zoomOutDateRange" />
      <q-btn
        round
        size="sm"
        icon="zoom_in"
        :disabled="dateRangeDelta <= MIN_DATE_RANGE"
        @click="zoomInDateRange" />
      <q-btn round size="sm" icon="home" @click="homeDateRange" />
      <q-btn
        round
        size="sm"
        icon="sync"
        :color="isAutoUpdateEnabled ? 'green' : undefined"
        @click="isAutoUpdateEnabled = !isAutoUpdateEnabled" />
    </div>
    <div>
      <apex-chart
        ref="chart"
        :options="chartOptions"
        :series="[{ data: [[]] }]"
        :height="400" />
    </div>

    <div class="q-pb-lg q-px-md">
      <q-table
        :rows="measuresQuery.data"
        :columns="COLUMNS"
        :loading="measuresQuery.isLoading">
        <template #no-data>
          <div class="full-width row flex-center text-primary q-gutter-sm">
            <div v-if="measuresQuery.isError">
              <q-icon size="2em" name="sentiment_dissatisfied" />
              Impossibile caricare le misurazioni
            </div>
            <div v-else-if="measuresQuery.isSuccess">
              Nessun misurazione presente nell'intervallo selezionato
            </div>
          </div>
        </template>
      </q-table>
    </div>
  </div>
</template>
