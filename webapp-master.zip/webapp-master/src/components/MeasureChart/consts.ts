import { DateTime } from 'luxon'
import { QTableProps } from 'quasar'
import {
  BloodPressure,
  Measure,
  WaterBalance
} from 'src/api/patients/measures/models'

export const DEFAULT_CHART_OPTIONS = {
  chart: {
    animations: {
      enabled: false
    },
    zoom: {
      enabled: true
    },
    toolbar: {
      tools: {
        zoomin: false,
        zoomout: false,
        zoom: false,
        reset: false,
        pan: false
      }
    },
    height: 250,
    type: 'line'
  },
  legend: {
    onItemClick: {
      toggleDataSeries: false
    }
  },
  fill: {
    type: 'solid'
  },
  xaxis: {
    type: 'datetime',
    // min: DateTime.now().minus({ months: 1 }),
    // max: DateTime.now(),
    tickPlacement: 'on',
    labels: {
      datetimeUTC: false
    }
  },
  tooltip: {
    custom: () => '',
    x: {
      formatter: (v: number) =>
        DateTime.fromMillis(v).toLocaleString(DateTime.DATETIME_MED)
    }
  }
}

export const COLUMNS: Readonly<QTableProps['columns']> = [
  {
    name: 'timestamp',
    label: 'Data e ora',
    align: 'left',
    field: 'timestamp',
    format: (value: DateTime) =>
      value?.toLocaleString(DateTime.DATETIME_MED_WITH_SECONDS),
    sortable: true
  },
  {
    name: 'value',
    label: 'Misurazione',
    align: 'left',
    field: (v: Measure) => {
      if (v.metadata.type === 'bloodPressure') {
        v = v as BloodPressure
        return `${v.diastolic}/${v.systolic}`
      }
      if (v.metadata.type === 'waterBalance') {
        v = v as WaterBalance
        return `${v.value} => ${v.total}`
      }
      v = v as Exclude<Measure, BloodPressure | WaterBalance>
      return v.value
    },
    format: (value: string | number, row: Measure) =>
      `${value} ${row.metadata.unit}`,
    sortable: true
  }
]
