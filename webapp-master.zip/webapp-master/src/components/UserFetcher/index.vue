<script setup lang="ts">
import { computed, ComputedRef } from 'vue'
import useQuery from 'src/api/useQuery'
import { User } from 'src/api/user/models'
import { getUser } from 'src/api/users'

const props = defineProps<{
  userId: string
  visualize?: (user: User, defaultText?: string) => string
  disableLink?: boolean
}>()

const query = useQuery(
  getUser,
  computed(() => props.userId)
)

const defaultVisualize = (p: User) => {
  if (p.type === 'doctor') return `Dottor ${p.firstName} ${p.lastName}`
  return `${p.firstName} ${p.lastName}`
}

const _visualize: ComputedRef<(u: User) => string> = computed(() => {
  if (props.visualize !== undefined)
    return (p: User) =>
      props.visualize?.(p, defaultVisualize(p)) ?? defaultVisualize(p)

  return defaultVisualize
})

const url = computed(() =>
  query.isSuccess && query?.data?.type === 'patient'
    ? `/patients/${props.userId}`
    : undefined
)
</script>

<template>
  <template v-if="query.isLoading">Caricamento...</template>
  <router-link
    v-if="query.isSuccess && !props.disableLink && !!url"
    :to="url"
    >{{ _visualize(query.data) }}</router-link
  >
  <template v-else-if="query.isSuccess">{{ _visualize(query.data) }}</template>
  <span v-else class="text-grey-7">
    Riservato
    <q-icon name="info">
      <q-tooltip>
        Le informazioni di questo utente ti sono state nascoste per motivi di
        privacy.
        <br />
        Potrebbe essere normale, nel caso delle visite mediche i dati dei
        pazienti vengono mostrati non prima di 24 ore dall'appuntamento e
        vengono nuovamente nascoste 72 ore dopo.
        <br />
        Se ritieni che ci sia un errore e che questi dati ti dovrebbero essere
        mostarti contatta il centro operativo per risolvere il problema
      </q-tooltip>
    </q-icon>
  </span>
</template>
