<script setup lang="ts">
import { computed } from 'vue'
import getUser from 'src/helpers/getUser'

const props = defineProps<{ userId: string; class?: string }>()

const user = getUser(props.userId)
const text = computed(() => {
  if (!user.value) return '..'
  if (user.value?.type === 'admin' || user.value?.type === 'superadmin')
    return 'S S'

  const firstChar = user.value?.firstName.toUpperCase().charAt(0)
  const secondChar = user.value?.lastName.toUpperCase().charAt(0)

  return `${firstChar} ${secondChar}`
})
</script>

<template>
  <q-avatar color="primary" text-color="white" :class="props.class">
    {{ text ?? '..' }}
  </q-avatar>
</template>
