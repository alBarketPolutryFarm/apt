<script setup lang="ts">
import { computed } from 'vue'
import useQuery from 'src/api/useQuery'
import { getPatientReports } from 'src/api/patients/reports'
import { DateTime } from 'luxon'
import { ReportStrings } from 'src/const/Report'

const EMBEDDED_RULES = {
  required: (v: string) => !!v || 'Referto richiesto'
} as const

const props = defineProps<{
  modelValue?: string
  readonly?: boolean
  label?: string
  class?: string
  patientId: string
  rules?: (((v: string) => boolean | string) | keyof typeof EMBEDDED_RULES)[]
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()

const query = useQuery(
  getPatientReports,
  computed(() => props.patientId)
)

const rules = computed(() => [
  ...(props.rules ?? []).map(r =>
    typeof r === 'string' && r in EMBEDDED_RULES ? EMBEDDED_RULES[r] : r
  )
])
</script>

<template>
  <q-select
    :loading="query.isLoading"
    :model-value="modelValue"
    :rules="rules"
    option-value="_id"
    map-options
    emit-value
    :readonly="props.readonly"
    :label="props.label"
    :class="props.class"
    :options="query.data"
    @update:model-value="(id: string) => emit('update:modelValue', id)">
    <template #option="{ itemProps, opt }">
      <q-item v-if="opt" v-bind="itemProps">
        <q-item-section>
          <q-item-label>{{ opt.description }}</q-item-label>
          <q-item-label caption>
            {{ ReportStrings[opt.type] }} -
            {{ opt.date?.toLocaleString(DateTime.DATE_FULL) }}
          </q-item-label>
        </q-item-section>
      </q-item>
    </template>

    <template #selected-item="{ itemProps, opt }">
      <q-item v-if="opt" v-bind="itemProps">
        <q-item-section>
          <q-item-label>{{ opt.description }}</q-item-label>
          <q-item-label caption>
            {{ ReportStrings[opt.type] }} -
            {{ opt.date?.toLocaleString(DateTime.DATE_FULL) }}
          </q-item-label>
        </q-item-section>
      </q-item>
    </template>
  </q-select>
</template>
