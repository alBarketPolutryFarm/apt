<script setup lang="ts">
const options = ['day', 'week', 'month', 'year'] as const
const labels = {
  day: 'Giorno',
  week: 'Settimana',
  month: 'Mese',
  year: 'Anno'
}
</script>

<template>
  <q-select :option-label="v => labels[v]" :options="options" />
</template>
