<script setup lang="ts">
import { computed, ref, toRaw, watch } from 'vue'
import EmailValidator from 'email-validator'
import notify from 'src/helpers/notify'
import useMutation from 'src/api/useMutation'
import { Validator } from '@marketto/codice-fiscale-utils'
import phone from 'phone'
import _ from 'lodash'
import { getUser, updateUser } from 'src/api/users'
import { createPatch } from 'rfc6902'
import { User, UserType } from 'src/api/user/models'
import { createDoctor } from 'src/api/doctors'
import { createOperator } from 'src/api/operators'
import { createNurse } from 'src/api/nurses'
import { createCaregiver } from 'src/api/caregivers'
import { createAdmin } from 'src/api/admins'
import { OperatorTypes } from 'src/api/operators/models'
import { OperatorTypeStrings } from 'src/const/User'
import QSelectPeriod from './QSelectPeriod'
import useLogin from 'src/helpers/useLogin'

const props = defineProps<{ userId: string | 'new'; type: UserType }>()

const emit = defineEmits<{
  (e: 'changed'): void
  (e: 'dismiss'): void
  (e: 'created'): void
}>()

const config = computed(() => {
  switch (props.type) {
    case 'doctor':
      return { createQuery: createDoctor } as const
    case 'operator':
      return { createQuery: createOperator } as const
    case 'caregiver':
      return { createQuery: createCaregiver } as const
    case 'nurse':
      return { createQuery: createNurse } as const
    case 'admin':
      return { createQuery: createAdmin } as const
    default:
      return { createQuery: createNurse } as const
  }
})

const dataFetched = ref<User>()
const data = ref<Partial<User>>()
const login = useLogin()

const [fetchUser, userQuery] = useMutation(getUser)
watch(
  () => props.userId,
  id => {
    if (!id) return
    if (id === 'new') data.value = {}
    else fetchUser(id)
  },
  { immediate: true }
)
watch(userQuery, s => {
  if (!s.isError) return
  notify("Impossibile recuperare le informazione dell'utente", 'negative')
})
watch(userQuery, q => {
  if (!q.isSuccess) return
  if (!q.data) return
  data.value = _.cloneDeep(q.data)
  dataFetched.value = _.cloneDeep(q.data)
})

const [update, updateStatus] = useMutation(updateUser)
watch(updateStatus, s => {
  if (!s.isError) return
  if (s.statusCode === 403)
    notify('Problema di limite, contattare il Super Admin', 'negative')
  else notify("Impossibile modificare l'utente", 'negative')
})
watch(updateStatus, s => {
  if (!s.isSuccess) return
  notify('Utente modificato', 'positive')
  data.value = undefined
  dataFetched.value = undefined
  emit('changed')
  emit('dismiss')
})

const [create, createStatus] = useMutation(config.value.createQuery)
watch(createStatus, s => {
  if (!s.isError) return
  notify("Impossibile creare l'utente or Limit Issue", 'negative')
})
watch(createStatus, s => {
  if (!s.isSuccess) return
  notify('Utente creato', 'positive')
  data.value = undefined
  emit('changed')
  emit('dismiss')
})
const handleSubmit = () => {
  if (props.userId === 'new') {
    create(data.value as unknown as Parameters<typeof create>[0])
  } else {
    if (!data.value?._id) return
    const patch = createPatch(toRaw(dataFetched.value), toRaw(data.value))
    if (patch.length === 0) return
    update(data.value._id, patch)
  }
}
</script>

<template>
  <q-dialog
    :model-value="props.userId !== undefined"
    @before-hide="emit('dismiss')">
    <q-card style="width: 700px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">
          <template v-if="props.userId === 'new'">Crea utente</template>
          <template v-else>Modifica utente</template>
        </div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form
        v-if="props.userId === 'new' || data !== undefined"
        greedy
        @submit="handleSubmit">
        <q-card-section class="row">
          <q-input
            outlined
            class="q-my-sm q-px-sm col-12"
            maxlength="16"
            :readonly="props.userId !== 'new'"
            label="Codice Fiscale"
            :model-value="data.fiscalCode"
            :rules="[
              v => !!v || 'Codice fiscale richiesto',
              v =>
                Validator.codiceFiscale(v).valid || 'Codice fiscale non valido'
            ]"
            @update:model-value="v => (data.fiscalCode = v.toUpperCase())" />
          <q-input
            v-model="data.firstName"
            outlined
            class="q-my-sm q-px-sm col-6"
            label="Nome"
            :rules="[v => !!v || 'Nome richiesto']" />
          <q-input
            v-model="data.lastName"
            outlined
            class="q-my-sm q-px-sm col-6"
            label="Cognome"
            :rules="[v => !!v || 'Cognome richiesto']" />
          <q-input
            v-model="data.email"
            outlined
            class="q-my-sm q-px-sm col-12"
            label="email"
            :rules="[
              v => !!v || 'Email richiesta',
              v => EmailValidator.validate(v) || 'Email non valida'
            ]" />
          <q-input
            v-model="data.phone"
            outlined
            class="q-my-sm q-px-sm col-12"
            label="Telefono"
            hint="(Includere prefisso e.g. '+39')"
            caption="ssdfd"
            :rules="[
              v => !!v || 'Inserisci un numero di telefono',
              v => phone(v).isValid || 'Numero di telefono non valido'
            ]" />
        </q-card-section>

        <q-card-section v-if="data.type === 'doctor'" class="row">
          <q-select
            v-if="login?.user?.type === 'superadmin'"
            v-model="data.reportableExamModalities"
            outlined
            :options="['ECG']"
            class="q-my-sm q-px-sm col-12"
            label="Tipologie di esami refertabili"
            multiple
            emit-value
            map-options>
            <template #option="{ itemProps, opt, selected, toggleOption }">
              <q-item v-bind="itemProps">
                <q-item-section>
                  <q-item-label>
                    {{ opt }}
                  </q-item-label>
                </q-item-section>
                <q-item-section side>
                  <q-toggle
                    :model-value="selected"
                    @update:model-value="toggleOption(opt)" />
                </q-item-section>
              </q-item>
            </template>
          </q-select>

          <q-expansion-item
            expand-separator
            label="Limiti referti"
            class="full-width">
            <q-card>
              <q-card-section class="row">
                <q-input
                  v-model.number="data.signatureLimit.available"
                  outlined
                  type="number"
                  class="q-my-sm q-px-sm col-12"
                  :rules="[
                    v => v >= 0 || 'Il valore non può essere negativo',
                    v => v % 1 === 0 || 'Il valore deve essere un intero'
                  ]"
                  label="Referti disponibili" />
                <q-input
                  v-model.number="data.signatureLimit.resetValue"
                  outlined
                  type="number"
                  :rules="[
                    v => v >= 0 || 'Il valore non può essere negativo',
                    v => v % 1 === 0 || 'Il valore deve essere un intero'
                  ]"
                  class="q-my-sm q-px-sm col-6"
                  label="Numero referti minimi disponibili su periodo (RF)" />
                <q-input
                  v-model.number="data.signatureLimit.resetPatientsScaleFactor"
                  outlined
                  type="number"
                  step="any"
                  class="q-my-sm q-px-sm col-6"
                  :rules="[v => v >= 0 || 'Il valore non può essere negativo']"
                  label="Numero referti per paziente (RV)" />
                <q-select-period
                  v-model="data.signatureLimit.resetInterval"
                  outlined
                  disable
                  class="q-my-sm q-px-sm col-12"
                  label="Periodo di reset" />
                <p class="q-ma-sm col-12 bg-grey-4 rounded-borders q-pa-sm">
                  All'inizio di ogni nuovo periodo di reset, i referti
                  disponibili vengono ricalcolati secondo la formula:<br />
                  <code
                    >REFERTI_DISPONIBILI = {{ data.signatureLimit.resetValue
                    }}<sub>(RF)</sub> + ({{
                      data.signatureLimit.resetPatientsScaleFactor
                    }}<sub>(RV)</sub> x NUMERO_PAZIENTI_ASSEGNATI)</code
                  >
                </p>
              </q-card-section>
            </q-card>
          </q-expansion-item>

          <q-expansion-item
            expand-separator
            label="Limiti creazione pazienti"
            class="full-width">
            <q-card>
              <q-card-section class="row">
                <q-input
                  v-model.number="data.patientCreationLimit.available"
                  outlined
                  type="number"
                  class="q-my-sm q-px-sm col-12"
                  :rules="[
                    v => v >= 0 || 'Il valore non può essere negativo',
                    v => v % 1 === 0 || 'Il valore deve essere un intero'
                  ]"
                  label="Nuovi pazienti disponibili" />
                <q-input
                  v-model.number="data.patientCreationLimit.resetValue"
                  outlined
                  type="number"
                  :rules="[
                    v => v >= 0 || 'Il valore non può essere negativo',
                    v => v % 1 === 0 || 'Il valore deve essere un intero'
                  ]"
                  class="q-my-sm q-px-sm col-12"
                  label="Numero pazienti creabili per periodo di reset (PF)" />
                <q-select-period
                  v-model="data.signatureLimit.resetInterval"
                  outlined
                  disable
                  class="q-my-sm q-px-sm col-12"
                  label="Periodo di reset" />
                <p class="q-ma-sm col-12 bg-grey-4 rounded-borders q-pa-sm">
                  All'inizio di ogni nuovo periodo di reset, i nuovi pazienti
                  disponibili vengono resettati al valore di<br />
                  <code
                    >NUOVI_PAZIENTI_DISPONIBILI =
                    {{ data.patientCreationLimit.resetValue
                    }}<sub>(PF)</sub></code
                  >
                </p>
              </q-card-section>
            </q-card>
          </q-expansion-item>
        </q-card-section>

        <q-card-section v-if="props.type === 'operator'" class="row">
          <q-select
            v-model="data.operatorType"
            outlined
            :options="OperatorTypes"
            :option-label="t => OperatorTypeStrings[t]"
            class="q-my-sm q-px-sm col-12"
            label="Tipo"
            emit-value
            map-options />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn
            flat
            :label="props.userId === 'new' ? 'Crea' : 'Aggiorna'"
            type="submit"
            :loading="updateStatus.isLoading" />
        </q-card-actions>
      </q-form>

      <div v-else class="flex flex-center q-pa-lg">
        <q-circular-progress
          indeterminate
          rounded
          size="50px"
          class="q-ma-md" />
      </div>
    </q-card>
  </q-dialog>
</template>

<style lang="scss">
.form-section {
  background-color: #efefef;
  border-radius: 0.5rem;
}
</style>
