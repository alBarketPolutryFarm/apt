<script setup lang="ts">
import { FixedOffsetZone, DateTime } from 'luxon'
import { computed, ref, watch } from 'vue'

const EMBEDDED_RULES = {
  required: (v: string) => !!v || 'Data richiesta',
  notFutureDate: (v: string) =>
    !v ||
    DateTime.fromFormat(v, FIELD_FORMAT).startOf('day') <=
      DateTime.now().startOf('day') ||
    'La data non può essere futura'
} as const

const props = defineProps<{
  modelValue?: DateTime
  readonly?: boolean
  label?: string
  class?: string
  rules?: (((v: string) => boolean | string) | keyof typeof EMBEDDED_RULES)[]
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: DateTime): void
}>()

const _modelValue = computed(() => props.modelValue?.toFormat('yyyy/LL/dd'))

const FIELD_FORMAT = 'dd/LL/yyyy'

const textInput = ref<string>('')
const updateTextInput = (d: string) => {
  const date = DateTime.fromFormat(d, FIELD_FORMAT, {
    zone: FixedOffsetZone.utcInstance
  })
  if (!date.isValid) return
  emit('update:modelValue', date)
}

watch(
  () => props.modelValue,
  v => {
    if (v === undefined) return
    textInput.value = v.toFormat(FIELD_FORMAT)
  }
)

const rules = computed(() => [
  (v: string) =>
    v === '' ||
    DateTime.fromFormat(v, FIELD_FORMAT).isValid ||
    'Data non valida',
  ...(props.rules ?? []).map(r =>
    typeof r === 'string' && r in EMBEDDED_RULES ? EMBEDDED_RULES[r] : r
  )
])
</script>

<template>
  <q-input
    :model-value="textInput"
    :readonly="props.readonly"
    :label="props.label"
    :class="props.class"
    mask="##/##/####"
    :rules="rules"
    @update:model-value="updateTextInput">
    <template #append>
      <q-icon v-if="!props.readonly" name="event" class="cursor-pointer">
        <q-popup-proxy cover transition-show="scale" transition-hide="scale">
          <q-date
            :model-value="_modelValue"
            @update:model-value="
              (_, __, date) =>
                emit(
                  'update:modelValue',
                  DateTime.fromObject(date, {
                    zone: FixedOffsetZone.utcInstance
                  })
                )
            ">
            <div class="row items-center justify-end">
              <q-btn v-close-popup label="Close" color="primary" flat />
            </div>
          </q-date>
        </q-popup-proxy>
      </q-icon>
    </template>
  </q-input>
</template>
