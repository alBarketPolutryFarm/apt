<script setup lang="ts">
import { computed, watch, ref } from 'vue'
import notify from 'src/helpers/notify'
import ViewUserDialog from 'src/components/ViewUserDialog'
import { getDoctors, getDocuSignLimits } from 'src/api/doctors'
import useQuery from 'src/api/useQuery'
import { get_columns } from './const'
import { useRoute, useRouter } from 'vue-router'
import { UserType } from 'src/api/user/models'
import { getNurses } from 'src/api/nurses'
import {
  getAdmins,
  suspendAdmin,
  activateAdmin,
  getAdminLimits,
  createAdminLimits,
  updateAdminLimits
} from 'src/api/admins'
import {
  activateOperators,
  getOperators,
  suspendOperators
} from 'src/api/operators'
import { getCaregivers } from 'src/api/caregivers'
import useLogin from 'src/helpers/useLogin'
import {
  QBtn,
  QDialog,
  QForm,
  QInput,
  QList,
  QItem,
  QItemSection,
  QBadge
} from 'quasar'
import { AdminLimitsBase } from 'src/api/admins/models'
import useMutation from 'src/api/useMutation'
import { activateUsers, suspendUsers, updateUserStructure } from 'src/api/users'
import AdminSelectionDialog from 'src/components/AdminPopUp'

const props = defineProps<{ type: UserType }>()

const router = useRouter()
const route = useRoute()
const login = useLogin()

const currentUserId = computed(() =>
  route.params?.id ? (route.params?.id as string) : undefined
)

interface Config {
  basePath: string
  query: Parameters<typeof useQuery>[0]
}

const config = computed<Config>(() => {
  switch (props.type) {
    case 'doctor':
      return { basePath: '/doctors', query: getDoctors }
    case 'operator':
      return { basePath: '/operators', query: getOperators }
    case 'caregiver':
      return { basePath: '/caregivers', query: getCaregivers }
    case 'admin':
      return { basePath: '/admins', query: getAdmins }
    default:
      return { basePath: '/nurses', query: getNurses }
  }
})

const query = useQuery(config.value.query)
const admins = useQuery(getAdmins)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile caricare la lista degli utenti', 'negative')
})

const _suspendUser = async (userId: string) => {
  try {
    await suspendUsers(userId)
    notify('Utente sospeso con successo', 'positive')
    query.refetch()
  } catch (error) {
    console.error("Errore durante la sospensione dell'utente:", error)
    notify("Errore nella sospensione dell'utente", 'negative')
  }
}

const _activateUser = async (userId: string) => {
  try {
    await activateUsers(userId)
    notify('Utente attivato con successo', 'positive')
    query.refetch()
  } catch (error) {
    console.error("Errore durante l'attivazione dell'utente:", error)
    notify("Errore nell'attivazione dell'utente", 'negative')
  }
}

const showCreateDialog = () => {
  router.push(`${config.value.basePath}/new`)
}

const get_permission_access = (type: any, permission_for: string) => {
  if (
    ['/operators', '/doctors', '/caregivers', '/nurses'].includes(
      config.value.basePath
    ) &&
    ['edit', 'delete'].includes(permission_for)
  ) {
    return type === 'superadmin' || type === 'admin'
  }

  switch (config.value.basePath) {
    case '/admins':
      return permission_for !== 'structure_edit' && type === 'superadmin'
    case '/operators':
    case '/doctors':
    case '/caregivers':
    case '/nurses':
      if (permission_for === 'structure_edit') {
        return type === 'superadmin'
      }
      return (
        ['edit', 'delete'].includes(permission_for) &&
        (type === 'superadmin' || type === 'admin')
      )
    default:
      return (
        permission_for === 'edit' && (type === 'superadmin' || type === 'admin')
      )
  }
}

// Limits dialog
const limitsDialog = ref(false)
const limitsFormData = ref<AdminLimitsBase>({
  userCreationLimit: 0,
  docuSignLimit: 0,
  assistantCreationLimit: 0,
  loaded: false,
  id: ''
})
const limitsLoading = ref(false)
const currentLimitsId = ref<string | undefined>()

const openLimitsDialog = async (userId: string) => {
  if (config.value.basePath === '/admins') {
    limitsLoading.value = true
    try {
      const limits = (await getAdminLimits(userId))?.data
      currentLimitsId.value = limits ? userId : undefined

      limitsFormData.value = {
        userCreationLimit: limits?.userCreationLimit || 0,
        assistantCreationLimit: limits?.assistantCreationLimit || 0,
        loaded: !!limits,
        docuSignLimit: limits?.docuSignLimit || 0,
        id: userId
      }
    } catch (error) {
      console.error('Errore nel caricamento dei limiti:', error)
      notify('Errore nel caricamento dei limiti', 'negative')
    } finally {
      limitsLoading.value = false
      limitsDialog.value = true
    }
  }
}

const saveLimits = async (userId: string) => {
  if (config.value.basePath === '/admins') {
    limitsLoading.value = true
    try {
      if (limitsFormData.value.loaded) {
        await updateAdminLimits(limitsFormData.value.id, limitsFormData.value)
        notify('Limiti aggiornati con successo', 'positive')
      } else {
        await createAdminLimits(limitsFormData.value.id, limitsFormData.value)
        notify('Limiti creati con successo', 'positive')
      }
      limitsDialog.value = false
      query.refetch()
    } catch (error) {
      console.error('Errore durante il salvataggio dei limiti:', error)
      notify('Errore durante il salvataggio dei limiti', 'negative')
    } finally {
      limitsLoading.value = false
    }
  }
}

// Structure Edit Dialog
const showConfirmationDialog = ref(false)
const showAdminSelectionDialog = ref(false)
const selectedAdminId = ref<string | null>(null)
const currentPatientAdminId = ref<string | null>(null)
const currentUserIdForStructureChange = ref<string | null>(null)

const newStructureDialog = async (userId: string, createdBy: string) => {
  showConfirmationDialog.value = true
  currentUserIdForStructureChange.value = userId
  currentPatientAdminId.value = createdBy
}

const handleAdminSelection = (adminId: string) => {
  selectedAdminId.value = adminId
  updateUserStructureIns()
}

const updateUserStructureIns = async () => {
  if (!selectedAdminId.value || !currentUserIdForStructureChange.value) {
    console.error('Nessun admin o utente selezionato!')
    return
  }

  try {
    await updateUserStructure(
      currentUserIdForStructureChange.value,
      selectedAdminId.value
    )
    notify("Struttura dell'utente aggiornata con successo!", 'positive')
    query.refetch()
  } catch (error) {
    console.error(
      "Errore durante l'aggiornamento della struttura dell'utente:",
      error
    )
    notify(
      "Errore durante l'aggiornamento della struttura dell'utente",
      'negative'
    )
  } finally {
    showAdminSelectionDialog.value = false
    selectedAdminId.value = null
    currentUserIdForStructureChange.value = null
  }
}
</script>

<template>
  <q-table
    :rows="query.data"
    :columns="get_columns(type)"
    :loading="query.isLoading">
    <template #top-right>
      <q-btn
        v-if="login.user?.type === 'superadmin' || login.user?.type === 'admin'"
        icon="person_add"
        color="primary"
        @click="showCreateDialog" />
    </template>

    <template #body-cell-actions="{ row: { _id, status, createdBy } }">
      <q-td>
        <div class="row no-wrap q-gutter-sm">
          <q-btn
            v-if="get_permission_access(login.user?.type, 'edit')"
            round
            icon="edit"
            color="green"
            size="sm"
            :to="`${config?.basePath}/${_id}`">
          </q-btn>
          <q-btn
            v-if="get_permission_access(login.user?.type, 'limits')"
            round
            :icon="'fa-solid fa-gauge-high'"
            color="positive"
            size="sm"
            @click="openLimitsDialog(_id)">
            <q-tooltip>{{ 'Limiti' }}</q-tooltip>
          </q-btn>
          <q-btn
            v-if="get_permission_access(login.user?.type, 'delete')"
            round
            :icon="
              status === 'active' ? 'fa-solid fa-ban' : 'fa-solid fa-check'
            "
            :color="status === 'active' ? 'negative' : 'positive'"
            size="sm"
            @click="
              status === 'active' ? _suspendUser(_id) : _activateUser(_id)
            ">
            <q-tooltip>{{
              status === 'active' ? 'Sospendi' : 'Attiva'
            }}</q-tooltip>
          </q-btn>
          <q-btn
            v-if="get_permission_access(login.user?.type, 'structure_edit')"
            round
            icon="vpn_key"
            color="green"
            size="sm"
            @click="newStructureDialog(_id, createdBy)">
            <q-tooltip>{{ 'Cambia Struttura' }}</q-tooltip>
          </q-btn>
        </div>
      </q-td>
    </template>

    <template #no-data>
      <div class="full-width row flex-center text-primary q-gutter-sm">
        <div v-if="query.isError">
          <q-icon size="2em" name="sentiment_dissatisfied" />
          Impossibile caricare l'elenco degli utenti
        </div>
        <div v-else-if="query.isSuccess">Nessun utente presente al momento</div>
      </div>
    </template>
  </q-table>

  <view-user-dialog
    :type="props.type"
    :user-id="currentUserId"
    @changed="query.refetch()"
    @created="query.refetch()"
    @dismiss="router.push(config?.basePath)" />

  <q-dialog v-model="limitsDialog" persistent>
    <q-card style="min-width: 350px">
      <q-card-section>
        <div class="text-h6">Limiti utente</div>
      </q-card-section>

      <q-card-section class="q-pt-none">
        <q-form @submit.prevent="saveLimits(currentUserId!)">
          <q-input
            v-if="config.basePath === '/admins'"
            v-model.number="limitsFormData.userCreationLimit"
            type="number"
            label="Limite creazione utenti" />
          <q-input
            v-if="config.basePath === '/admins'"
            v-model.number="limitsFormData.assistantCreationLimit"
            type="number"
            label="Limite creazione assistiti" />
          <q-input
            v-model.number="limitsFormData.docuSignLimit"
            type="number"
            label="Limite creazione DocuSign" />
          <div class="row q-mt-lg justify-end">
            <q-btn
              v-close-popup
              label="Annulla"
              color="negative"
              flat
              class="q-mr-sm" />
            <q-btn
              label="Salva"
              type="submit"
              color="positive"
              :loading="limitsLoading" />
          </div>
        </q-form>
      </q-card-section>
    </q-card>
  </q-dialog>

  <q-dialog v-model="showConfirmationDialog" persistent>
    <q-card>
      <q-card-section>
        <div class="text-h6">Conferma cambio struttura</div>
        <p>sei sicuro di voler cambiare struttura al paziente</p>
      </q-card-section>

      <q-card-actions align="right">
        <q-btn v-close-popup flat label="No" color="negative" />
        <q-btn
          v-close-popup
          label="Sì"
          color="positive"
          @click="showAdminSelectionDialog = true" />
      </q-card-actions>
    </q-card>
  </q-dialog>

  <admin-selection-dialog
    v-model="showAdminSelectionDialog"
    :admins="admins.data"
    :current-patient-admin-id="currentPatientAdminId"
    @select="handleAdminSelection" />
</template>
