// const.ts
import { QTableProps } from 'quasar';
import { UserType } from 'src/api/user/models';
import { OperatorType } from 'src/api/operators/models';
import { OperatorTypeStrings } from 'src/const/User';

export const get_columns = (type?: UserType): QTableProps['columns'] => [
  {
    name: 'firstName',
    label: 'Nome',
    align: 'left',
    field: 'firstName',
    sortable: true,
  },
  {
    name: 'lastName',
    label: 'Cognome',
    align: 'left',
    field: 'lastName',
    sortable: true,
  },
  ...(type === 'operator'
    ? [
      {
        name: 'operatorType',
        label: 'Tipo',
        align: 'left',
        field: 'operatorType',
        sortable: true,
        format: (row: OperatorType) => OperatorTypeStrings[row],
      } as const,
    ]
    : []),
  {
    name: 'fiscalCode',
    label: 'Codice fiscale',
    align: 'left',
    field: 'fiscalCode',
    sortable: true,
  },
  {
    name: 'email',
    label: 'email',
    align: 'left',
    field: 'email',
    sortable: true,
  },
  {
    name: 'phone',
    label: 'Telefono',
    align: 'left',
    field: 'phone',
    sortable: true,
  },
  ...(type === 'superadmin'
    ? [
      {
        name: 'status',
        label: 'Stato',
        align: 'left',
        field: 'status',
        sortable: true,
      } as const,
    ]
    : []),

  {
    name: 'actions',
    align: 'center',
    label: '',
    sortable: false,
    field: (row: UserType) => row,
  },
];