<template>
  <q-dialog v-model="showDialog" persistent>
    <q-card style="width: 700px; max-width: 80vw">
      <q-card-section>
        <div class="text-h6">Seleziona il nuovo amministratore</div>
        <q-input
          v-model="searchQuery"
          dense
          filled
          placeholder="Cerca amministratore..."
          class="q-mb-md">
          <template #append>
            <q-icon name="search" />
          </template>
        </q-input>
        <q-list>
          <q-item
            v-for="admin in filteredAdmins"
            :key="admin._id"
            clickable
            :class="{ 'bg-blue-1': admin._id === selectedAdminId }"
            @click="selectAdmin(admin._id)">
            <q-item-section>
              {{ admin.firstName }} {{ admin.lastName }} ({{ admin.email }})
            </q-item-section>
            <q-item-section side>
              <q-badge v-if="isCurrentAdmin(admin._id)" color="green"
                >Attuale</q-badge
              >
            </q-item-section>
          </q-item>
        </q-list>
      </q-card-section>

      <q-card-actions align="right">
        <q-btn flat label="Annulla" color="negative" @click="cancel" />
        <q-btn
          label="Cambia"
          color="positive"
          :disabled="!selectedAdminId"
          @click="confirmSelection" />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import {
  QDialog,
  QCard,
  QCardSection,
  QList,
  QItem,
  QItemSection,
  QBadge,
  QCardActions,
  QBtn,
  QInput,
  QIcon
} from 'quasar'

const props = defineProps<{
  modelValue: boolean
  admins: any[]
  currentPatientAdminId: string | null
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: boolean): void
  (e: 'select', adminId: string): void
}>()

const showDialog = computed({
  get: () => props.modelValue,
  set: value => emit('update:modelValue', value)
})

const selectedAdminId = ref<string | null>(null)
const searchQuery = ref('')

const filteredAdmins = computed(() => {
  const query = searchQuery.value.toLowerCase()
  return props.admins.filter(
    admin =>
      admin.firstName.toLowerCase().includes(query) ||
      admin.lastName.toLowerCase().includes(query) ||
      admin.email.toLowerCase().includes(query)
  )
})

const selectAdmin = (adminId: string) => {
  selectedAdminId.value = adminId
}

const currentAdmin = computed(() => {
  return props.admins.find(admin => admin._id === props.currentPatientAdminId)
})

const isCurrentAdmin = (adminId: string) => {
  const result = adminId === currentAdmin.value?._id
  return result
}

const cancel = () => {
  selectedAdminId.value = null
  searchQuery.value = ''
  showDialog.value = false
}

const confirmSelection = () => {
  if (selectedAdminId.value) {
    emit('select', selectedAdminId.value)
    searchQuery.value = ''
    showDialog.value = false
  }
}
</script>
