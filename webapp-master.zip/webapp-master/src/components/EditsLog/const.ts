import { QTableProps } from 'quasar'
import { EditLog } from 'src/api/models'
import { DateTime } from 'luxon'

export const EDITS_LOG_COLUMNS: QTableProps['columns'] = [
  {
    name: 'at',
    label: 'Data',
    align: 'left',
    field: (row: EditLog) => row.at,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'by',
    label: 'Da',
    align: 'left',
    field: (row: EditLog) => row.by
  },
  {
    name:'description',
    label: 'Cambiamenti',
    align: 'left',
    field: (row: EditLog) => row.description
  }
]
