<script setup lang="ts">
import { EditLog } from 'src/api/models'
import { defineProps } from 'vue'
import { EDITS_LOG_COLUMNS } from './const'
import { QTable } from 'quasar'
import UserFetcher from 'src/components/UserFetcher'

type Props = { editsLog?: EditLog[] }

const props = defineProps<Props>()
</script>

<template>
  <q-expansion-item expand-separator icon="history" label="Storico modifiche">
    <q-table :rows="props.editsLog" :columns="EDITS_LOG_COLUMNS">
      <template #body-cell-by="{ value }">
        <q-td>
          <user-fetcher :user-id="value" />
        </q-td>
      </template>

      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div>Nessun modifica nello storico</div>
        </div>
      </template>
    </q-table>
  </q-expansion-item>
</template>
