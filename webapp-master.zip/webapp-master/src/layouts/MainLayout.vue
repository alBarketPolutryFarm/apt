<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { resetToken } from 'src/redux/auth'
import { useDispatch } from 'src/redux/helpers'
import { useRouter } from 'vue-router'
import useLogin from 'src/helpers/useLogin'
import { UserStrings } from 'src/const/User'
import DrawerItem, { DrawerItemProps } from 'layouts/DrawerItem.vue'
import { UserType } from 'src/api/user/models'

const dispatch = useDispatch()
const router = useRouter()
const login = useLogin()

type Item = DrawerItemProps & {
  auth?: UserType[]
  children?: Item[]
}

type DrawerEntity =
  | Item
  | ({
      children: Item[]
      to?: never
      onClick?: never
    } & Omit<Item, 'to' | 'onClick'>)

const links: Readonly<DrawerEntity[]> = [
  {
    title: 'Dashboard',
    icon: 'fa-solid fa-house',
    to: '/'
  },
  {
    title: 'Assistiti',
    icon: 'fa-solid fa-hospital-user',
    to: '/patients'
  },
  {
    title: 'Utenze',
    icon: 'summarize',
    auth: ['admin', 'superadmin'],
    children: [
      {
        title: 'Infermieri',
        icon: 'fa-solid fa-user-nurse',
        auth: ['admin', 'superadmin'],
        to: '/nurses'
      },
      {
        title: 'Medici',
        icon: 'fa-solid fa-user-doctor',
        auth: ['admin', 'superadmin'],
        to: '/doctors'
      },
      {
        title: 'Operatori esterni',
        icon: 'medical_services',
        auth: ['admin', 'superadmin'],
        to: '/operators'
      },
      {
        title: 'Caregiver',
        icon: 'group',
        auth: ['admin', 'superadmin'],
        to: '/caregivers'
      },
      {
        title: 'Amministratori',
        icon: 'lock',
        auth: ['superadmin'],
        to: '/admins'
      }
    ]
  },
  {
    title: 'Allarmi',
    icon: 'fa-solid fa-bell',
    auth: ['admin', 'superadmin', 'nurse'],
    to: '/alarms'
  },
  {
    title: 'Appuntamenti',
    icon: 'event',
    to: '/bookings',
    auth: ['nurse', 'doctor', 'caregiver', 'operator', 'patient']
  },
  {
    title: 'Chat',
    icon: 'question_answer',
    to: '/chats'
  },
  {
    title: 'Esami da refertare',
    icon: 'summarize',
    auth: ['doctor'],
    to: '/exam-report-requests'
  },
  {
    title: 'Accordi',
    icon: 'summarize',
    auth: ['superadmin'],
    to: '/agreements'
  },
  {
    title: 'Screening',
    icon: 'fa-solid fa-message',
    auth: ['superadmin'],
    to: '/screenings'
  },
  {
    title: 'Logout',
    icon: 'fa-solid fa-right-from-bracket',
    onClick() {
      dispatch(resetToken())
      sessionStorage.removeItem('user')
      sessionStorage.removeItem('access-token')

      router.push('/login')
    }
  }
] as const

const userLinks = computed(() => {
  const filterLink = (link: DrawerEntity): DrawerEntity | null => {
    if (
      link.auth === undefined ||
      link.auth.includes(login?.value.user?.type ?? '')
    ) {
      if (link?.children) {
        const filteredChildren = link.children
          .map(filterLink)
          .filter((child): child is DrawerEntity => child !== null)

        return filteredChildren.length > 0
          ? { ...link, children: filteredChildren }
          : null
      }
      return link
    }
    return null
  }

  return links
    .map(filterLink)
    .filter((link): link is DrawerEntity => link !== null)
})

const isDrawerOpen = ref<boolean>(false)

const openChangePassword = () => {
  router.push('/change-password')
}

watch(
  login,
  l => {
    if (l.isLogged) return
    router.push('/login')
  },
  { immediate: true }
)
</script>

<template>
  <q-layout v-if="login.isLogged" view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-btn
          flat
          dense
          round
          icon="menu"
          aria-label="Menu"
          @click="isDrawerOpen = !isDrawerOpen" />

        <q-toolbar-title>
          <router-link to="/" class="text-white" style="text-decoration: none">
            SERVIZIO SALUTE
          </router-link>
        </q-toolbar-title>

        <div class="toolbar_size q-mr-sm">
          {{ login.user?.firstName ?? '' }} {{ login.user?.lastName ?? '' }}
          -
          {{ UserStrings[login?.user?.type] }}
        </div>

        <!-- User Icon with Menu -->
        <q-btn round flat icon="person">
          <q-menu>
            <q-list style="min-width: 100px">
              <q-item v-close-popup clickable @click="openChangePassword">
                <q-item-section>Cambio Password</q-item-section>
              </q-item>
            </q-list>
          </q-menu>
        </q-btn>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="isDrawerOpen" show-if-above bordered>
      <q-list class="q-py-lg">
        <div v-for="link in userLinks" :key="link.title">
          <template
            v-if="
              !('auth' in link) ||
              ('auth' in link && link.auth?.includes(login.user?.type ?? ''))
            ">
            <div v-if="'children' in link && link.children">
              <q-expansion-item
                expand-separator
                :icon="link.icon"
                :label="link.title.toUpperCase()"
                :caption="link.caption">
                <div>
                  <template v-for="l in link.children" :key="l.title">
                    <drawer-item
                      v-if="
                        !('auth' in link) ||
                        ('auth' in link &&
                          link.auth?.includes(login.user?.type ?? ''))
                      "
                      class="q-px-xl"
                      :title="l.title"
                      :icon="l.icon"
                      :caption="l.caption"
                      :to="l.to" />
                  </template>
                </div>
              </q-expansion-item>
            </div>

            <drawer-item
              v-else
              :title="link.title"
              :icon="link.icon"
              :caption="link.caption"
              :to="link.to"
              :on-click="link.onClick" />
          </template>
        </div>
      </q-list>
    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>
