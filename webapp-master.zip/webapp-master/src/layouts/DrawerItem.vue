<script setup lang="ts">
export type DrawerItemProps = {
  title: string
  icon?: string
  caption?: string
  onClick?: () => void
  to?: string
}

const props = defineProps<DrawerItemProps>()
</script>

<template>
  <q-item clickable :to="props.to" @click="props.onClick">
    <q-item-section v-if="props.icon" avatar>
      <q-icon :name="props.icon" />
    </q-item-section>

    <q-item-section>
      <q-item-label>{{ props.title.toUpperCase() }}</q-item-label>
      <q-item-label v-if="props.caption" caption>
        {{ props.caption }}
      </q-item-label>
    </q-item-section>
  </q-item>
</template>
