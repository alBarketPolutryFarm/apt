import { UserType } from 'src/api/user/models'
import { OperatorType } from 'src/api/operators/models'

const s: Readonly<Record<UserType, string>> = {
  patient: 'Paziente',
  doctor: 'Medico',
  nurse: 'Infermiere',
  operator: 'Operatore',
  caregiver: 'Caregiver',
  admin: 'Amministratore',
  superadmin: 'Super Amministratore'
}

export const OperatorTypeStrings: Readonly<Record<OperatorType, string>> = {
  physiotherapist: 'Fisioterapista',
  nutritionist: 'Nutrizionista',
  psychologist: 'Psicologoco',
  obstetrician: 'Ostetrica',
  socialWorker: 'Assistente sociale',
  educator: 'Educatore',
  childhoodEducator: "Educatore d'infanzia",
  sociologist: 'Sociologo',
  pharmacist: 'Farmacista',
  labTechnician: 'Tecnico di laboratorio',
  other: 'Altro'
}

export default s
