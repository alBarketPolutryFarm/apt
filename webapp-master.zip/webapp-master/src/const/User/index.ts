import UserStrings, { OperatorTypeStrings } from './strings'

export { UserStrings, OperatorTypeStrings }
