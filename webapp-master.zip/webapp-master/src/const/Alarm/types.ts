const types = ['measureOutBounds'] as const

export default types

export type AlarmType = typeof types[number]
