import { AlarmType } from 'src/const/Alarm/types'

const s: Record<AlarmType, string> = {
  measureOutBounds: 'Misura fuori limiti'
} as const

export default s
