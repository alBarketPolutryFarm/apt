import AlarmStrings from './strings'
import AlarmTypes, { AlarmType } from './types'

export { AlarmTypes, AlarmStrings }

export type { AlarmType }
