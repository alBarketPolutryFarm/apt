import { IndexMeasureType } from './types'

export default {
  barthel: 'https://www.serviziosalute.com/scala-di-barthel/',
  braden: 'https://www.serviziosalute.com/scala-braden/',
  brass: 'https://www.serviziosalute.com/scala-brass/',
  conley: 'https://www.serviziosalute.com/scala-di-conley/',
  must: 'https://www.serviziosalute.com/scala-must/',
  npi: 'https://www.serviziosalute.com/scala-npi/'
} as Readonly<Record<IndexMeasureType, string>>
