import { IndexMeasureType } from './types'

export default {
  barthel: 'Barthel',
  braden: 'Braden',
  brass: 'Brass',
  conley: 'Conley',
  must: 'Must',
  npi: 'NPI'
} as Readonly<Record<IndexMeasureType, string>>
