const types = ['barthel', 'braden', 'brass', 'conley', 'must', 'npi'] as const

export default types

export type IndexMeasureType = typeof types[number]
