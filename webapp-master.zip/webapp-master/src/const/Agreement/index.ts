import AgreementStrings from './strings'
import AgreementTypes, { AgreementType } from './types'

export { AgreementTypes, AgreementStrings }

export type { AgreementType }
