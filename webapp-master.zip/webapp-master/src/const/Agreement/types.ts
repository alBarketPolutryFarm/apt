const types = ['privacy', 'tos'] as const

export default types

export type AgreementType = typeof types[number]
