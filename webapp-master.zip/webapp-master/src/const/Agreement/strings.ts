import { AgreementType } from './types'

const s: Record<AgreementType, string> = {
  tos: 'Termini del servizio',
  privacy: 'Trattamento dei dati personali'
} as const

export default s
