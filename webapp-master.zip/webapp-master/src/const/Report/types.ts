const types = ['exam', 'external', 'medicalExamination'] as const
export default types
export type ReportType = typeof types[number]