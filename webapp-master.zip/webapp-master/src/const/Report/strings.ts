import { ReportType } from './types'

const s: Record<ReportType, string> = {
  exam: 'Esame',
  medicalExamination: 'Visita medica',
  external: 'Esterno'
} as const

export default s
