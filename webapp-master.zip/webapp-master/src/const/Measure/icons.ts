import { MeasureType } from './types'

const icons: Record<MeasureType, string> = {
  bloodPressure: 'bloodtype',
  weight: 'scale',
  pulse: 'favorite',
  temperature: 'thermostat',
  pain: 'sentiment_very_dissatisfied',
  respiratoryRate: 'air',
  glycaemia: 'cake',
  oxygenSaturation: 'bubble_chart',
  waterBalance: 'local_drink'
} as const

export default icons
