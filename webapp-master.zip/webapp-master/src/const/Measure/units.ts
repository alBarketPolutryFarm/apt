import { MeasureType } from './types'

const unit: Record<MeasureType, string | undefined> = {
  bloodPressure: 'mmHg',
  weight: 'kg',
  pulse: 'bpm',
  temperature: '°C',
  pain: undefined,
  respiratoryRate: 'r/m',
  glycaemia: 'mg/dl',
  oxygenSaturation: '%',
  waterBalance: 'ml'
}

export default unit
