export default {
  bloodPressure: 'Pressione arteriosa',
  weight: 'Peso',
  pulse: 'Frequenza cardiaca',
  temperature: 'Temperatura',
  pain: 'Dolore',
  respiratoryRate: 'Frequenza respiratoria',
  glycaemia: 'Glicemia',
  oxygenSaturation: "Saturazione dell'ossigeno",
  waterBalance: 'Bilancio idrico'
} as const
