const types = [
  'bloodPressure',
  'glycaemia',
  'oxygenSaturation',
  'pain',
  'pulse',
  'respiratoryRate',
  'temperature',
  'waterBalance',
  'weight'
] as const

export default types

export type MeasureType = typeof types[number]
