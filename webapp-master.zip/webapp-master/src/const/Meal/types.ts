const types = [
  'breakfast',
  'morningSnack',
  'lunch',
  'afternoonSnack',
  'dinner'
] as const

export default types

export type MealType = typeof types[number]
