export default {
  breakfast: 'Colazione',
  morningSnack: 'Spuntino mattutino',
  lunch: 'Pranzo',
  afternoonSnack: 'Spuntino pomeridiano',
  dinner: 'Cena'
} as const
