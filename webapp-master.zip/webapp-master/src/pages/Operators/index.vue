<script setup lang="ts">
import UsersTable from 'src/components/UsersTable'
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Operatori esterni</h6>

    <q-separator class="q-my-md" />

    <users-table type="operator" />
  </q-page>
</template>
