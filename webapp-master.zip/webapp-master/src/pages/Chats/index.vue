<script setup lang="ts">
import { ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import { getChats, getChatAllowedUsers, createChat } from 'src/api/chats'
import ChatItem from './ChatItem'
import ChatView from './ChatView'
import { useDispatch } from 'src/redux/helpers'
import { updateChatMetadata } from 'src/redux/chats'
import { UserChatModel } from 'src/api/chats/models'
import useLogin from 'src/helpers/useLogin'
import { computed } from 'vue'

const searchTerm = ref('')
const login = useLogin()
const query = useQuery(getChats)
const dispatch = useDispatch()
const currentChatId = ref<string | undefined>()
const showAllowedUsersPopup = ref(false)
const allowedUsers = ref<UserChatModel[]>([])
const loadingAllowedUsers = ref(false)
const errorAllowedUsers = ref(false)
const selectedUser = ref<UserChatModel | null>(null)
const creatingChat = ref(false)

const filteredAllowedUsers = computed(() =>
  allowedUsers.value.filter(user =>
    `${user.firstName} ${user.lastName}`
      .toLowerCase()
      .includes(searchTerm.value.toLowerCase())
  )
)

// Pagination
const offset = ref(0)
const limit = ref(20)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista delle chat', 'negative')
})

watch(query, q => {
  if (!q.isSuccess) return
  if (!q.data) return
  q.data.forEach(c => dispatch(updateChatMetadata(c)))
})

async function fetchAllowedUsers() {
  showAllowedUsersPopup.value = true
  loadingAllowedUsers.value = true
  errorAllowedUsers.value = false
  selectedUser.value = null
  try {
    const response = await getChatAllowedUsers()
    allowedUsers.value = (response.data as UserChatModel[]) || []
  } catch (error) {
    errorAllowedUsers.value = true
    notify('Error fetching allowed users', 'negative')
  } finally {
    loadingAllowedUsers.value = false
  }
}

async function createNewChat() {
  if (selectedUser.value) {
    creatingChat.value = true
    try {
      const newChat = await createChat(selectedUser.value._id)
      dispatch(updateChatMetadata(newChat))
      currentChatId.value = newChat._id
      notify('New chat created successfully', 'positive')
      showAllowedUsersPopup.value = false
      selectedUser.value = null
      // Refresh the chat list
      query.refetch()
    } catch (error) {
      if ((error as any).response && (error as any).response.status === 422) {
        notify('Cannot chat with yourself', 'negative')
      } else if (
        (error as any).response &&
        (error as any).response.status === 403
      ) {
        notify((error as any).response.data.detail, 'negative')
      } else {
        notify('Error creating new chat', 'negative')
      }
    } finally {
      creatingChat.value = false
    }
  }
}

// Function to load more users
async function loadMoreUsers() {
  offset.value += limit.value
  await fetchAllowedUsers()
}
const AllowedRolesForChat = ['admin', 'superadmin', 'patient', 'operator']
</script>

<template>
  <q-page class="q-pa-lg column">
    <div class="row items-center justify-between">
      <h6 class="q-ma-none">Chats</h6>
      <q-btn
        v-if="AllowedRolesForChat.includes(login?.user?.type as string)"
        color="primary"
        label="Aggiungi Chat"
        @click="fetchAllowedUsers" />
    </div>

    <q-separator class="q-my-md" />

    <div class="col-grow content-stretch flex no-wrap row">
      <q-list bordered class="col-4 scroll">
        <template v-if="query.isSuccess && query.data?.length !== 0">
          <chat-item
            v-for="c in query.data"
            :key="c._id"
            :chat="c"
            @click="currentChatId = c._id" />
        </template>

        <template v-if="query.isSuccess && query.data?.length === 0">
          <q-item class="q-my-lg">
            <q-item-section>
              <q-item-label class="text-center">
                Non ci sono chat attive
              </q-item-label>
            </q-item-section>
          </q-item>
        </template>

        <template v-else-if="query.isLoading">
          <q-item v-for="n in 20" :key="n" v-ripple clickable>
            <q-item-section avatar>
              <q-skeleton type="QAvatar" />
            </q-item-section>

            <q-item-section>
              <q-item-label>
                <q-skeleton type="text" />
              </q-item-label>
              <q-item-label caption lines="1">
                <q-skeleton type="text" />
              </q-item-label>
            </q-item-section>

            <q-item-section side></q-item-section>
          </q-item>
        </template>

        <template v-else-if="query.isError"></template>
      </q-list>

      <q-separator vertical class="q-mx-md" />

      <div class="col-grow">
        <chat-view v-if="currentChatId" :chat-id="currentChatId" />
      </div>
    </div>

    <!-- Popup for allowed users -->

    <q-dialog
      v-model="showAllowedUsersPopup"
      persistent
      style="max-width: 90vw; max-height: 80vh">
      <q-card
        style="
          min-width: 400px;
          max-height: 80vh;
          display: flex;
          flex-direction: column;
        ">
        <q-card-section>
          <h6 class="q-mb-md" style="font-size: 1.25rem; font-weight: bold">
            Seleziona Utente
          </h6>

          <q-input
            v-model="searchTerm"
            placeholder="Search users"
            outlined
            dense
            class="q-mb-md"
            style="border-radius: 4px; background-color: #f9f9f9" />
        </q-card-section>

        <q-card-section style="flex: 1; overflow: auto; max-height: 60vh">
          <q-list bordered style="max-height: 100%; border-radius: 4px">
            <q-item
              v-for="user in filteredAllowedUsers"
              :key="user._id"
              class="cursor-pointer"
              style="
                user-select: none;
                background-color: #f5f5f5;
                margin-bottom: 2px;
              "
              @click="selectedUser = user">
              <q-item-section avatar>
                <q-radio v-model="selectedUser" :val="user">
                  <q-item-section>
                    <q-item-label
                      style="
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        font-weight: bold;
                        color: #333;
                      ">
                      {{ user.firstName }} {{ user.lastName }}
                    </q-item-label>
                  </q-item-section>
                </q-radio>
              </q-item-section>
            </q-item>

            <q-item v-if="loadingAllowedUsers">
              <q-item-section>
                <q-skeleton type="text" />
              </q-item-section>
            </q-item>

            <q-item v-if="errorAllowedUsers">
              <q-item-section>
                <q-item-label class="text-center" style="color: #e53935">
                  Error loading users
                </q-item-label>
              </q-item-section>
            </q-item>
          </q-list>
        </q-card-section>

        <q-card-actions align="right" style="border-top: 1px solid #ddd">
          <q-btn
            flat
            label="Cancel"
            :disable="creatingChat"
            class="q-mr-sm"
            style="color: #007bff"
            @click="showAllowedUsersPopup = false" />
          <q-btn
            color="primary"
            label="Start Chat"
            :disable="!selectedUser || creatingChat"
            :loading="creatingChat"
            @click="createNewChat" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>
