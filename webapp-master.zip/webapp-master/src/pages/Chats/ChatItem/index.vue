<script setup lang="ts">
import { computed } from 'vue'
import { Chat } from 'src/api/chats/models'
import useLogin from 'src/helpers/useLogin'
import useChat from 'src/helpers/useChat'
import getUser from 'src/helpers/getUser'
import UserAvatar from 'src/components/UserAvatar'
import AppLogo from 'src/components/AppLogoAvatar'

const props = defineProps<{ chat: Chat }>()
const emit = defineEmits<{
  (e: 'click'): void
}>()

const login = useLogin()

const chatState = useChat(computed(() => props.chat._id))

const membersId = computed(() => {
  const chat = chatState.value.chat
  if (chat && 'membersId' in chat) {
    return chat.membersId.filter(m => m !== login.value.user?._id)
  }
  return []
})

const members = computed(() => {
  const chat = chatState.value.chat
  if (chat && 'membersId' in chat) {
    return chat.membersId.filter(m => m !== login.value.user?._id).map(getUser)
  }
  return []
})

const membersText = computed(() => {
  if (members.value.length === 0) return 'Servizio Salute Annunci'
  return members.value
    ?.map(u => `${u.value?.firstName ?? '...'} ${u.value?.lastName ?? '...'}`)
    .join(', ')
})
</script>

<template>
  <q-item v-ripple clickable @click="emit('click')">
    <q-item-section avatar>
      <app-logo v-if="membersId.length === 0" class="q-message-avatar" />
      <user-avatar
        v-for="m in membersId"
        v-else
        :key="m"
        class="q-message-avatar"
        :user-id="m" />
    </q-item-section>

    <q-item-section>
      <q-item-label>
        {{ membersText }}
      </q-item-label>
      <q-item-label caption lines="1"></q-item-label>
    </q-item-section>

    <q-item-section side> </q-item-section>
  </q-item>
</template>
