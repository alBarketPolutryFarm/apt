<script setup lang="ts">
import { computed, ref, watchEffect } from 'vue'
import useChat from 'src/helpers/useChat'
import ChatMessage from './ChatMessage'
import useLogin from 'src/helpers/useLogin'

const props = defineProps<{ chatId: string }>()

const chatState = useChat(computed(() => props.chatId))

const message = ref<string>()
const handleSubmit = () => {
  if (!message.value) return

  chatState.value.sendMessage({ type: 'text', message: message.value })
  message.value = undefined
}

const login = useLogin()
const messagesContainer = ref<HTMLDivElement | null>(null)

const isBroadcast = computed(
  () => !('membersId' in (chatState.value.chat ?? {}))
)

watchEffect(onCleanup => {
  messagesContainer.value?.scrollIntoView({
    behavior: 'auto',
    block: 'end'
  })
  const inteval = setInterval(() => {
    messagesContainer.value?.scrollIntoView({
      behavior: 'smooth',
      block: 'end'
    })
  }, 1000)
  onCleanup(() => clearInterval(inteval))
})
</script>

<template>
  <div class="full-width full-height flex column">
    <div class="full-width col-grow scroll-y" style="height: 0">
      <div ref="messagesContainer" class="full-width overflow-hidden">
        <chat-message
          v-for="m in chatState.messages"
          :key="m._id"
          :chat-id="props.chatId"
          :message="m"
          :is-servizio-salute="isBroadcast" />
      </div>
    </div>

    <div
      v-if="
        !isBroadcast ||
        login?.user?.type === 'admin' ||
        login?.user?.type === 'superadmin'
      ">
      <q-form
        class="q-ma-none"
        @submit="handleSubmit"
        @reset="message = undefined">
        <q-toolbar
          class="bg-primary text-white rounded-borders flex row no-wrap">
          <q-input
            v-model="message"
            filled
            :hide-bottom-space="true"
            dark
            dense
            standout
            type="textarea"
            autogrow
            clearable
            :rules="[val => val && val.length > 0]"
            class="q-ma-sm col-grow text-white" />

          <q-btn round flat class="q-my-sm" icon="send" type="submit" />
        </q-toolbar>
      </q-form>
    </div>
  </div>
</template>
