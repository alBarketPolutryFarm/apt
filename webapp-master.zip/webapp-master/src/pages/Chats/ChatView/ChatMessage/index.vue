<script setup lang="ts">
import { computed } from 'vue'
import useLogin from 'src/helpers/useLogin'
import getUser from 'src/helpers/getUser'
import { ChatMessage } from 'src/api/chats/messages/models'
import UserAvatar from 'src/components/UserAvatar'
import { DateTime } from 'luxon'
import AppLogo from 'src/components/AppLogoAvatar'

const props = defineProps<{
  chatId: string
  message: ChatMessage
  isServizioSalute: boolean
}>()

const login = useLogin()

const isSent = computed(() => props.message.createdBy === login.value.user?._id)

let user
if (!props.isServizioSalute) {
  user = getUser(props.message.createdBy)
}
</script>

<template>
  <q-chat-message
    :sent="isSent"
    :text-color="isSent ? 'white' : 'black'"
    :bg-color="isSent ? 'primary' : 'amber'">
    <div v-if="props.message.type === 'bookingRequest'">
      <h6 class="q-ma-none">Richiesta prenotazione appuntamento</h6>
      <div>
        Preferenza data:
        <i>{{ props.message.at.toLocaleString(DateTime.DATETIME_FULL) }}</i>
      </div>
      <div style="white-space: pre-line">
        Descrizione: <i>{{ props.message.description }}</i>
      </div>
    </div>
    <div v-else style="white-space: pre-line">
      {{ props.message.message }}
    </div>

    <template
      v-if="
        isSent &&
        (login.user?.type === 'admin' || login.user?.type === 'superadmin')
      "
      #name>
      Servizio Salute
    </template>
    <template v-else-if="isServizioSalute" #name> Servizio Salute </template>
    <template v-else #name>{{
      `${user?.firstName} ${user?.lastName}`
    }}</template>

    <template #stamp>{{ props.message.createdAt.toRelative() }}</template>
    <template #avatar>
      <app-logo
        v-if="isServizioSalute"
        :class="`q-message-avatar q-message-avatar--${
          isSent ? 'sent' : 'received'
        }`" />
      <user-avatar
        v-else
        :class="`q-message-avatar q-message-avatar--${
          isSent ? 'sent' : 'received'
        }`"
        :user-id="props.message.createdBy" />
    </template>
  </q-chat-message>
</template>
