<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import useStore from 'src/redux'
import { getDashboardMetrics } from 'src/api/dashboard'
import { UserType } from 'src/types/user'
import type {
  AdminMetrics,
  SuperAdminMetrics,
  MetricTrend
} from 'src/api/dashboard'
import { Line } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
)

const metrics = ref<AdminMetrics | SuperAdminMetrics | null>(null)
const loading = ref(true)

const currentUser = computed(() => useStore.getState().auth.user)

const getChartData = (trend: MetricTrend) => ({
  labels: trend.trend_data.map(d => d.month),
  datasets: [
    {
      label: trend.metric_name,
      data: trend.trend_data.map(d => d.value),
      borderColor: '#1976D2',
      backgroundColor: 'rgba(25, 118, 210, 0.1)',
      tension: 0.4,
      fill: true
    }
  ]
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top' as const
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      ticks: {
        precision: 0
      }
    }
  }
}

onMounted(async () => {
  console.log(currentUser.value)
  if (
    currentUser.value?.type === UserType.ADMIN ||
    currentUser.value?.type === UserType.SUPERADMIN
  ) {
    console.log('Fetching metrics...')
    try {
      const response = await getDashboardMetrics()
      metrics.value = response.data
    } catch (error) {
      console.error('Error fetching metrics:', error)
    }
  }
  loading.value = false
})
</script>

<template>
  <q-page class="q-pa-lg">
    <div
      v-if="loading"
      class="flex justify-center items-center"
      style="height: 400px">
      <q-spinner color="primary" size="3em" />
    </div>

    <template v-else>
      <!-- Show logo for non-admin users -->
      <div v-if="!metrics" class="flex justify-center">
        <img
          src="~assets/logo_infermieri.png"
          alt="Infermieri"
          style="width: 60vw; max-height: 100%; max-width: 800px" />
      </div>

      <!-- Admin Dashboard -->
      <div
        v-else-if="metrics.type === UserType.ADMIN"
        class="row q-col-gutter-md">
        <div class="col-12">
          <h4 class="q-mt-none q-mb-md">
            Benvenuto, {{ (metrics as AdminMetrics).name }}
          </h4>
        </div>

        <!-- Key Metrics -->
        <div class="col-12 col-md-3">
          <q-card class="dashboard-card">
            <q-card-section>
              <div class="text-h6">Utenti</div>
              <div class="text-h4 q-mt-sm">
                {{ (metrics as AdminMetrics).active_users }}
              </div>
              <div class="text-caption">Utenti Attivi</div>
            </q-card-section>
          </q-card>
        </div>

        <div class="col-12 col-md-3">
          <q-card class="dashboard-card">
            <q-card-section>
              <div class="text-h6">Assistenti</div>
              <div class="text-h4 q-mt-sm">
                {{ (metrics as AdminMetrics).active_assistants }}
              </div>
              <div class="text-caption">Assistenti Attivi</div>
            </q-card-section>
          </q-card>
        </div>

        <div class="col-12 col-md-3">
          <q-card class="dashboard-card">
            <q-card-section>
              <div class="text-h6">Piani di Cura</div>
              <div class="text-h4 q-mt-sm">
                {{ (metrics as AdminMetrics).active_care_plans }}
              </div>
              <div class="text-caption">Piani di Cura Attivi</div>
            </q-card-section>
          </q-card>
        </div>

        <div class="col-12 col-md-3">
          <q-card class="dashboard-card">
            <q-card-section>
              <div class="text-h6">Avvisi</div>
              <div class="text-h4 q-mt-sm">
                {{ (metrics as AdminMetrics).managed_alerts }}
              </div>
              <div class="text-caption">Avvisi Gestiti</div>
            </q-card-section>
          </q-card>
        </div>

        <!-- Statistiche Piani di Cura -->
        <div class="col-12">
          <q-card>
            <q-card-section>
              <div class="text-h6">Statistiche Piani di Cura</div>
              <div class="row q-col-gutter-md q-mt-md">
                <div class="col-6 col-md-3">
                  <div class="text-subtitle2">Creati</div>
                  <div class="text-h5">
                    {{ (metrics as AdminMetrics).created_care_plans }}
                  </div>
                </div>
                <div class="col-6 col-md-3">
                  <div class="text-subtitle2">Completati</div>
                  <div class="text-h5">
                    {{ (metrics as AdminMetrics).completed_care_plans }}
                  </div>
                </div>
                <div class="col-6 col-md-3">
                  <div class="text-subtitle2">Attivi</div>
                  <div class="text-h5">
                    {{ (metrics as AdminMetrics).active_care_plans }}
                  </div>
                </div>
                <div class="col-6 col-md-3">
                  <div class="text-subtitle2">Rapporti</div>
                  <div class="text-h5">
                    {{ (metrics as AdminMetrics).generated_reports }}
                  </div>
                </div>
              </div>
            </q-card-section>
          </q-card>
        </div>

        <!-- Risultati -->
        <div class="col-12">
          <q-card>
            <q-card-section>
              <div class="text-h6">Risultati Clinici</div>
              <div class="row q-col-gutter-md q-mt-md">
                <div class="col-6 col-md-2">
                  <div class="text-subtitle2">Guarigioni</div>
                  <div class="text-h5">
                    {{ (metrics as AdminMetrics).recoveries }}
                  </div>
                </div>
                <div class="col-6 col-md-2">
                  <div class="text-subtitle2">Ospedalizzazioni</div>
                  <div class="text-h5">
                    {{ (metrics as AdminMetrics).hospitalizations }}
                  </div>
                </div>
                <div class="col-6 col-md-2">
                  <div class="text-subtitle2">Decessi</div>
                  <div class="text-h5">
                    {{ (metrics as AdminMetrics).deaths }}
                  </div>
                </div>
                <div class="col-6 col-md-2">
                  <div class="text-subtitle2">Infezioni</div>
                  <div class="text-h5">
                    {{ (metrics as AdminMetrics).infections }}
                  </div>
                </div>
                <div class="col-6 col-md-2">
                  <div class="text-subtitle2">Amministrativi</div>
                  <div class="text-h5">
                    {{ (metrics as AdminMetrics).administrative_closures }}
                  </div>
                </div>
              </div>
            </q-card-section>
          </q-card>
        </div>

        <!-- Trends Section for Admin -->
        <!-- <div class="col-12">
          <q-card>
            <q-card-section>
              <div class="text-h6 q-mb-md">Trends</div>
              <div class="row q-col-gutter-md">
                <div v-for="trend in (metrics as AdminMetrics).trends" :key="trend.metric_name" class="col-12 col-md-6">
                  <q-card flat bordered>
                    <q-card-section>
                      <div class="text-subtitle1 q-mb-sm">{{ trend.metric_name }}</div>
                      <div style="height: 300px">
                        <Line :data="getChartData(trend)" :options="chartOptions" />
                      </div>
                    </q-card-section>
                  </q-card>
                </div>
              </div>
            </q-card-section>
          </q-card>
        </div> -->
      </div>

      <!-- SuperAdmin Dashboard -->
      <div v-else class="row q-col-gutter-md">
        <div class="col-12">
          <h4 class="q-mt-none q-mb-md">Cruscotto SuperAdmin</h4>
          <div class="text-h5 q-mb-lg">
            Totale Amministratori Attivi:
            {{ (metrics as SuperAdminMetrics).total_registered_admins }}
          </div>
        </div>

        <!-- Lista Amministratori -->
        <div class="col-12">
          <q-card
            v-for="admin in (metrics as SuperAdminMetrics).admins_data"
            :key="admin.admin_id"
            class="q-mb-md">
            <q-card-section>
              <div class="text-h6">{{ admin.name }}</div>
              <div class="row q-col-gutter-md q-mt-md">
                <div class="col-12 col-md-3">
                  <q-list dense>
                    <q-item>
                      <q-item-section>
                        <q-item-label>Utenti Attivi</q-item-label>
                        <q-item-label caption>{{
                          admin.active_users
                        }}</q-item-label>
                      </q-item-section>
                    </q-item>
                    <q-item>
                      <q-item-section>
                        <q-item-label>Assistenti Attivi</q-item-label>
                        <q-item-label caption>{{
                          admin.active_assistants
                        }}</q-item-label>
                      </q-item-section>
                    </q-item>
                  </q-list>
                </div>
                <div class="col-12 col-md-3">
                  <q-list dense>
                    <q-item>
                      <q-item-section>
                        <q-item-label
                          >Piani di Cura (Attivi/Totale)</q-item-label
                        >
                        <q-item-label caption
                          >{{ admin.active_care_plans }}/{{
                            admin.created_care_plans
                          }}</q-item-label
                        >
                      </q-item-section>
                    </q-item>
                    <q-item>
                      <q-item-section>
                        <q-item-label>Avvisi Gestiti</q-item-label>
                        <q-item-label caption>{{
                          admin.managed_alerts
                        }}</q-item-label>
                      </q-item-section>
                    </q-item>
                  </q-list>
                </div>
                <div class="col-12 col-md-3">
                  <q-list dense>
                    <q-item>
                      <q-item-section>
                        <q-item-label>Risultati Clinici</q-item-label>
                        <q-item-label caption>
                          Guarigioni: {{ admin.recoveries }}<br />
                          Decessi: {{ admin.deaths }}<br />
                          Ospedalizzazioni: {{ admin.hospitalizations }}
                        </q-item-label>
                      </q-item-section>
                    </q-item>
                  </q-list>
                </div>
                <div class="col-12 col-md-3">
                  <q-list dense>
                    <q-item>
                      <q-item-section>
                        <q-item-label>Rapporti & Amministrativi</q-item-label>
                        <q-item-label caption>
                          Rapporti: {{ admin.generated_reports }}<br />
                          Chiusure Amministrative:
                          {{ admin.administrative_closures }}
                        </q-item-label>
                      </q-item-section>
                    </q-item>
                  </q-list>
                </div>
              </div>
            </q-card-section>
          </q-card>
        </div>

        <!-- Sezione Tendenze per ogni Amministratore nella Vista SuperAdmin -->
        <!-- <template v-for="admin in (metrics as SuperAdminMetrics).admins_data" :key="admin.admin_id">
          <div class="col-12">
            <q-card>
              <q-card-section>
                <div class="text-h6 q-mb-md">Tendenze - {{ admin.name }}</div>
                <div class="row q-col-gutter-md">
                  <div v-for="trend in admin.trends" :key="trend.metric_name" class="col-12 col-md-6">
                    <q-card flat bordered>
                      <q-card-section>
                        <div class="text-subtitle1 q-mb-sm">{{ trend.metric_name }}</div>
                        <div style="height: 300px">
                          <Line :data="getChartData(trend)" :options="chartOptions" />
                        </div>
                      </q-card-section>
                    </q-card>
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
        </template> -->
      </div>
    </template>
  </q-page>
</template>

<style scoped>
.dashboard-card {
  height: 100%;
}
</style>
