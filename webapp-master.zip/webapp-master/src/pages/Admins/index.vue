<script setup lang="ts">
import { watch } from 'vue'
import { DateTime } from 'luxon'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import { COLUMNS } from './const'
import { getAdmins } from 'src/api/admins'
import UsersTable from 'components/UsersTable/index.vue'

const query = useQuery(getAdmins)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile caricare la lista degli amministratori', 'negative')
})
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Amministratori</h6>
    <q-separator class="q-my-md" />
    <users-table type="admin" />
  </q-page>
</template>
