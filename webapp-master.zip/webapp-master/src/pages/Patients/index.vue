<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'
import {
  getPatients,
  GetPatientsParams,
  getPatientsQueryInfo,
  updatePatient
} from 'src/api/patients'
import NewPatientDialog from './NewPatientDialog'
import useLogin from 'src/helpers/useLogin'
import notify from 'src/helpers/notify'
import { COLUMNS } from './const'
import { QTable, QTableProps } from 'quasar'
import useMutation from 'src/api/useMutation'
import useQuery from 'src/api/useQuery'
import { getDoctors } from 'src/api/doctors'
import { getNurses } from 'src/api/nurses'
import { Doctor } from 'src/api/doctors/models'
import { Nurse } from 'src/api/nurses/models'
import { GENDERS } from '../Patient/PersonalDataPanel/const'
import { Pushreport } from 'src/api/reports'
import { getAdmins } from 'src/api/admins'
import { updateUserStructure } from 'src/api/users'
import AdminSelectionDialog from 'src/components/AdminPopUp'

const login = useLogin()

const table = ref<QTable>()
onMounted(() => {
  table.value?.requestServerInteraction()
})

const [fetch, query] = useMutation(getPatients)
const [fetchInfo, queryInfo] = useMutation(getPatientsQueryInfo)

const doctors = useQuery(getDoctors)
const nurses = useQuery(getNurses)
const admins = useQuery(getAdmins)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile caricare la lista pazienti', 'negative')
})
watch(queryInfo, q => {
  if (!q.isError) return
  notify('Impossibile caricare la lista pazienti', 'negative')
})

const pagination = ref({
  sortBy: 'desc',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  rowsNumber: 10
})
const filter = ref<GetPatientsParams>({})

type OnRequestArgument = Omit<
  Parameters<NonNullable<QTableProps['onRequest']>>[0],
  'filter'
> & {
  filter?: GetPatientsParams
}

const selectedDoctors = ref<string[]>([])
const selectedNurses = ref<string[]>([])

watch([selectedDoctors, selectedNurses], () => {
  filter.value.target_ids = [...selectedDoctors.value, ...selectedNurses.value]
})

const handleRequest = ({
  pagination: { page, rowsPerPage },
  filter
}: OnRequestArgument) => {
  const params = {
    q: filter?.q || undefined,
    target_ids: [...(filter?.target_ids || [])] || undefined,
    gender: filter?.gender || undefined,
    limit: rowsPerPage,
    offset: (page - 1) * rowsPerPage
  }
  fetchInfo(params)
    .then(r => r.data.count)
    .then(c => {
      pagination.value.rowsNumber = c
      return fetch(params)
    })
    .then(() => {
      pagination.value.page = page
      pagination.value.rowsPerPage = rowsPerPage
    })
}

const sendEHRReport = async (patientId: string) => {
  try {
    const response = await Pushreport(patientId)
    if (response.status === 200 || response.status === 201) {
      notify('Email sent successfully!', 'positive')
    } else {
      notify('Error sending email.', 'negative')
    }
  } catch (error) {
    notify('Error sending email.', 'negative')
    console.error('Error sending email:', error)
  }
}

const showConfirmationDialog = ref(false)
const showAdminSelectionDialog = ref(false)
const selectedAdminId = ref<string | null>(null)
const currentPatientAdminId = ref<string | null>(null)
const currentUserIdForStructureChange = ref<string | null>(null)

const newStructureDialog = async (userId: string, createdBy: string) => {
  showConfirmationDialog.value = true
  currentUserIdForStructureChange.value = userId
  currentPatientAdminId.value = createdBy
}

const handleAdminSelection = (adminId: string) => {
  // console.log('Selected admin:', adminId)
  selectedAdminId.value = adminId
  updateUserStructureIns()
}

const updateUserStructureIns = async () => {
  if (!selectedAdminId.value || !currentUserIdForStructureChange.value) {
    console.error('Nessun admin o utente selezionato!')
    return
  }

  try {
    await updateUserStructure(
      currentUserIdForStructureChange.value,
      selectedAdminId.value
    )
    notify("Struttura dell'utente aggiornata con successo!", 'positive')
    table.value?.requestServerInteraction()
  } catch (error) {
    console.error(
      "Errore durante l'aggiornamento della struttura dell'utente:",
      error
    )
    notify(
      "Errore durante l'aggiornamento della struttura dell'utente",
      'negative'
    )
  } finally {
    showAdminSelectionDialog.value = false
    selectedAdminId.value = null
    currentUserIdForStructureChange.value = null
  }
}
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Assistiti</h6>
    <q-separator class="q-my-md" />
    <q-table
      ref="table"
      v-model:pagination="pagination"
      title="Assistiti"
      :rows="query.data"
      :rows-per-page-options="[5, 10, 20]"
      :loading="query.isLoading"
      :columns="COLUMNS"
      :filter="filter"
      @request="handleRequest">
      <template
        v-if="['admin', 'superadmin', 'doctor'].includes(login.user?.type)"
        #top-right>
        <q-btn
          icon="person_add"
          color="primary"
          @click="$refs.newPatientDialog.show()" />
      </template>
      <template #top-left>
        <div class="row items-center">
          <q-input
            v-model="filter.q"
            class="q-mr-md"
            borderless
            dense
            debounce="300"
            placeholder="Cerca">
            <template #append>
              <q-icon name="search" />
            </template>
          </q-input>
          <q-select
            v-model="filter.gender"
            clearable
            class="q-mr-md"
            dense
            style="min-width: 150px"
            :options="['female', 'male', 'other', 'unknown']"
            :option-label="g => GENDERS[g as keyof typeof GENDERS]"
            label="Genere" />
          <q-select
            :model-value="selectedDoctors"
            multiple
            clearable
            class="q-mr-md"
            style="width: 150px"
            dense
            full-width
            :options="doctors.data"
            label="Medico"
            emit-value
            map-options
            :option-label="
              (doctor: Doctor) => doctor.firstName + ' ' + doctor.lastName
            "
            option-value="_id"
            @clear="selectedDoctors = []"
            @update:model-value="(v: string[]) => (selectedDoctors = v)" />
          <q-select
            :model-value="selectedNurses"
            multiple
            clearable
            style="width: 150px"
            dense
            :options="nurses.data"
            label="Infermiere"
            emit-value
            map-options
            :option-label="
              (nurse: Nurse) => nurse.firstName + ' ' + nurse.lastName
            "
            option-value="_id"
            @clear="selectedNurses = []"
            @update:model-value="(v: string[]) => (selectedNurses = v)" />
        </div>
      </template>
      <template #body-cell-actions="props">
        <q-td>
          <div
            style="display: flex; align-items: center; justify-content: center">
            <q-btn
              v-if="login.user?.type === 'superadmin'"
              round
              icon="email"
              color="green"
              size="sm"
              class="q-ml-lg"
              @click="sendEHRReport(props.row._id)" />
            <q-btn
              v-if="login.user?.type === 'superadmin'"
              round
              icon="vpn_key"
              color="green"
              size="sm"
              class="q-ml-lg"
              @click="newStructureDialog(props.row._id, props.row.createdBy)" />
            <q-btn
              round
              icon="visibility"
              color="blue"
              size="sm"
              class="q-ml-lg"
              @click="$router.push(`/patients/${props.row._id}`)" />
          </div>
        </q-td>
      </template>
      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare gli assistiti
          </div>
          <div v-else-if="query.isSuccess">Nessun assistito presente</div>
        </div>
      </template>
    </q-table>

    <q-dialog v-model="showConfirmationDialog" persistent>
      <q-card>
        <q-card-section>
          <div class="text-h6">Conferma cambio struttura</div>
          <p>sei sicuro di voler cambiare struttura al paziente</p>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn v-close-popup flat label="No" color="negative" />
          <q-btn
            v-close-popup
            label="Sì"
            color="positive"
            @click="showAdminSelectionDialog = true" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <admin-selection-dialog
      v-model="showAdminSelectionDialog"
      :admins="admins.data"
      :current-patient-admin-id="currentPatientAdminId"
      @select="handleAdminSelection" />

    <new-patient-dialog
      ref="newPatientDialog"
      @created="table?.requestServerInteraction()" />
  </q-page>
</template>

<style scoped>
.selected-admin {
  background-color: lightblue;
}

.current-admin {
  font-weight: bold;
}
</style>
