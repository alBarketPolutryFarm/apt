import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { Patient } from 'src/api/patients/models'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'fiscalCode',
    label: 'Codice Fiscale',
    align: 'left',
    field: 'fiscalCode',
    sortable: true
  },
  {
    name: 'firstName',
    label: 'Nome',
    align: 'left',
    field: 'firstName',
    sortable: true
  },
  {
    name: 'lastName',
    label: 'Cognome',
    align: 'left',
    field: 'lastName',
    sortable: true
  },
  {
    name: 'phone',
    label: 'Telefono',
    align: 'left',
    field: 'phone',
    sortable: true
  },
  {
    name: 'birthDate',
    label: 'Data di Nascita',
    align: 'left',
    field: 'birthDate',
    format: (value: DateTime) => value?.toLocaleString(DateTime.DATE_MED),
    sortable: true
  },
  {
    name: 'createdAt',
    label: 'Creato il',
    align: 'left',
    field: 'createdAt',
    format: (value: DateTime) => value?.toLocaleString(DateTime.DATE_MED),
    sortable: true
  },
  {
    name: 'actions',
    align: 'center',
    label: 'Azioni',
    sortable: false,
    field: (row: Patient) => row
  }
]
