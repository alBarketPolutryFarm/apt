<script setup lang="ts">
import { ref } from 'vue'
import EmailValidator from 'email-validator'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import { NewPatient } from 'src/api/patients/models'
import { createPatient } from 'src/api/patients'
import notify from 'src/helpers/notify'
import { Validator } from '@marketto/codice-fiscale-utils'
import phone from 'phone'

const emit = defineEmits<{
  (e: 'created'): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<RecursivePartial<NewPatient>>({})

const handleSubmit = () => {
  createPatient(data.value as NewPatient)
    .then(() => {
      notify('Paziente creato', 'positive')
      isDialogOpen.value = false
      data.value = {}
      emit('created')
    })
    .catch(e => {
      if (e.response.status === 429)
        notify('Limite di creazione pazienti raggiunto', 'warning')
      else notify('Impossibile creare il paziente', 'warning')
    })
}

defineExpose({
  show: () => (isDialogOpen.value = true)
})
</script>

<template>
  <q-dialog v-model="isDialogOpen">
    <q-card style="width: 700px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Nuovo paziente</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section class="row">
          <q-input
            outlined
            class="q-my-sm q-px-sm col-12"
            maxlength="16"
            label="Codice Fiscale"
            :model-value="data.fiscalCode"
            :rules="[
              v => !!v || 'Codice fiscale richiesto',

              v =>
                Validator.codiceFiscale(v).valid || 'Codice fiscale non valido'
            ]"
            @update:model-value="v => (data.fiscalCode = v.toUpperCase())" />
          <q-input
            v-model="data.firstName"
            outlined
            class="q-my-sm q-px-sm col-6"
            label="Nome"
            :rules="[v => !!v || 'Nome richiesto']" />
          <q-input
            v-model="data.lastName"
            outlined
            class="q-my-sm q-px-sm col-6"
            label="Cognome"
            :rules="[v => !!v || 'Cognome richiesto']" />
          <q-input
            v-model="data.email"
            outlined
            class="q-my-sm q-px-sm col-12"
            label="email"
            :rules="[
              v => !!v || 'Email richiesta',
              v => EmailValidator.validate(v) || 'Email non valida'
            ]" />
          <q-input
            v-model="data.phone"
            outlined
            class="q-my-sm q-px-sm col-12"
            label="Telefono"
            hint="(Includere prefisso e.g. '+39')"
            caption="ssdfd"
            :rules="[
              v => !!v || 'Inserisci un numero di telefono',
              v => phone(v).isValid || 'Numero di telefono non valido'
            ]" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
