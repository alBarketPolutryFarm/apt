<script setup lang="ts">
import UsersTable from 'components/UsersTable/index.vue'
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Medici</h6>

    <q-separator class="q-my-md" />

    <users-table type="doctor" />
    <!-- <q-btn
            v-if="get_permission_access(login.user?.type, 'limits')"
            round
            :icon="'fa-solid fa-gauge-high'"
            color="positive"
            size="sm"
            @click="openLimitsDialog(_id)">
            <q-tooltip>{{ 'Limiti' }}</q-tooltip>
          </q-btn> -->
  </q-page>
</template>
