<script setup lang="ts">
import UsersTable from 'components/UsersTable'
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Caregiver</h6>

    <q-separator class="q-my-md" />

    <users-table type="caregiver" />
  </q-page>
</template>
