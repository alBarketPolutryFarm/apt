<script setup lang="ts">
import { ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import { getAgreements } from 'src/api/agreements'
import { AgreementType } from 'src/api/agreements/models'
import { AgreementStrings, AgreementTypes } from 'src/const/Agreement'
import AgreementEditor from './AgreementEditor'

const query = useQuery(getAgreements)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista degli esami da refertare', 'negative')
})

const currentAgreementType = ref<AgreementType>()
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Accordi</h6>

    <q-separator class="q-my-md" />

    <q-list separator bordered class="rounded-borders">
      <q-expansion-item
        v-for="t in AgreementTypes"
        :key="t"
        group="charts"
        expand-separator
        :label="AgreementStrings[t]"
        @hide="currentAgreementType = undefined"
        @show="currentAgreementType = t">
        <agreement-editor :type="t" />
      </q-expansion-item>
    </q-list>
  </q-page>
</template>
