import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { ExamReportRequest } from 'src/api/exam_report_requests/models'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'at',
    label: 'Data',
    align: 'left',
    field: (row: ExamReportRequest) => row.createdAt,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'status',
    label: 'Stato',
    align: 'left',
    field: (row: ExamReportRequest) => row
  },
  {
    name: 'actions',
    label: '',
    align: 'center',
    field: (row: ExamReportRequest) => row
  }
]
