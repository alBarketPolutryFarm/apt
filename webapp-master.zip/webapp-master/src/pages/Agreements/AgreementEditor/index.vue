<script setup lang="ts">
import { ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import { createAgreement, getAgreementByType } from 'src/api/agreements'
import { AgreementType } from 'src/api/agreements/models'
import useMutation from 'src/api/useMutation'
import { AgreementStrings } from 'src/const/Agreement'

const props = defineProps<{
  type: AgreementType
}>()

const query = useQuery(getAgreementByType, ref(props.type))

watch(query, q => {
  if (!q.isError) return
  notify("Impossibile recuperare l'accordo", 'negative')
})

const data = ref<string>('')

watch(query, q => {
  if (!q.isSuccess) return
  if (q.data === undefined) return

  data.value = q.data.content
})

const [triggerMutation, mutationStatus] = useMutation(createAgreement)

watch(mutationStatus, q => {
  if (!q.isError) return
  notify("Impossibile salvare l'accordo", 'negative')
})
watch(mutationStatus, q => {
  if (!q.isSuccess) return
  query.refetch()
  notify('Accordo salvato con successo', 'positive')
})

const saveHandler = () => {
  triggerMutation({
    type: props.type,
    content: data.value,
    description: AgreementStrings[props.type],
    options: [
      {
        required: true,
        description: `Ho preso visione e acconsento a "${
          AgreementStrings[props.type]
        }"`
      }
    ]
  })
}
</script>

<template>
  <q-editor
    v-model="data"
    min-height="5rem"
    :definitions="{
      save: {
        tip: 'Salva l\'accordo',
        icon: 'save',
        label: 'Salva',
        handler: saveHandler
      }
    }"
    :toolbar="[
      [
        {
          label: $q.lang.editor.align,
          icon: $q.iconSet.editor.align,
          fixedLabel: true,
          list: 'only-icons',
          options: ['left', 'center', 'right', 'justify']
        }
      ],
      ['bold', 'italic', 'strike', 'underline', 'subscript', 'superscript'],
      ['token', 'hr', 'link', 'custom_btn'],
      ['print', 'fullscreen'],
      [
        {
          label: $q.lang.editor.formatting,
          icon: $q.iconSet.editor.formatting,
          list: 'no-icons',
          options: ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'code']
        },
        'removeFormat'
      ],
      ['quote', 'unordered', 'ordered', 'outdent', 'indent'],
      ['undo', 'redo'],
      ['viewsource'],
      ['save']
    ]" />
</template>
