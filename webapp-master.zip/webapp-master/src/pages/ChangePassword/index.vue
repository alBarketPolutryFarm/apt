<template>
  <q-layout view="lHh Lpr lFf">
    <q-page-container>
      <q-page padding class="column items-center justify-center">
        <q-card style="width: 400px; max-width: 80vw">
          <q-card-section>
            <div class="text-h6 text-center">Cambio Password</div>
          </q-card-section>

          <q-card-section>
            <q-form @submit.prevent="handleChangePassword">
              <q-input
                v-model="oldPassword"
                outlined
                type="password"
                label="Old Password"
                :rules="[val => !!val || 'Please enter your old password']" />
              <q-input
                v-model="newPassword"
                outlined
                type="password"
                label="New Password"
                :rules="[
                  val => !!val || 'Please enter a new password',
                  val =>
                    val.length >= 12 ||
                    'Password must be at least 12 characters long',
                  val =>
                    /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(val) ||
                    'Password must contain at least one lowercase letter, one uppercase letter, and one number'
                ]" />
              <q-input
                v-model="confirmPassword"
                outlined
                type="password"
                label="Confirm New Password"
                :rules="[
                  val => !!val || 'Please confirm your new password',
                  val => val === newPassword || 'Passwords do not match'
                ]" />
              <div class="q-mt-md">
                <q-btn
                  :loading="isLoading"
                  :disable="!isFormValid"
                  color="primary"
                  align="center"
                  label="Cambio Password"
                  type="submit" />
              </div>
            </q-form>
          </q-card-section>
        </q-card>
      </q-page>
    </q-page-container>
  </q-layout>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useQuasar } from 'quasar'
import useMutation from 'src/api/useMutation'
import { changePassword } from 'src/api/auth'

const router = useRouter()
const $q = useQuasar()

const oldPassword = ref('')
const newPassword = ref('')
const confirmPassword = ref('')

const [triggerMutation, { isLoading }] = useMutation(changePassword)

const isFormValid = computed(
  () =>
    oldPassword.value &&
    newPassword.value &&
    confirmPassword.value &&
    newPassword.value === confirmPassword.value &&
    newPassword.value.length >= 12 &&
    /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(newPassword.value)
)

const handleChangePassword = async () => {
  try {
    await triggerMutation({
      currentPassword: oldPassword.value,
      newPassword: newPassword.value
    })

    $q.notify({
      type: 'positive',
      message: 'Password changed successfully.'
    })

    router.push('/')
  } catch (error) {
    $q.notify({
      type: 'negative',
      message: 'Error changing password. Please try again later.'
    })
  }
}
</script>
