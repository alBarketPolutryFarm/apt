<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Dettagli screening</h6>
    <q-separator class="q-my-md" />
    <div v-if="query.data">
      <q-form @submit="saveScreening">
        <screening-page
          ref="screeningPageRef"
          :screening="updatedScreening"
          :read-only="isReadOnly"
          @update:screening="screening => (updatedScreening = screening)" />
        <div class="q-mt-md row justify-end">
          <div
            v-if="
              login?.user?.type === 'admin' ||
              login?.user?.type === 'superadmin'
            ">
            <q-btn
              v-if="currentMode === 'view'"
              color="primary"
              label="Modifica"
              @click="() => (currentMode = 'edit')" />
            <q-btn
              v-else
              type="submit"
              color="primary"
              label="Salva"
              :loading="isSaving" />
          </div>

          <q-btn
            class="q-ml-md"
            flat
            color="primary"
            :label="currentMode === 'edit' ? 'Annulla' : 'Indietro'"
            @click="cancel" />
        </div>
      </q-form>
    </div>

    <q-spinner
      v-else-if="query.isLoading"
      :size="'lg'"
      color="primary"
      style="position: absolute; top: 50%; left: 50%" />
  </q-page>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import useQuery from 'src/api/useQuery'
import { getScreening, updateScreening } from 'src/api/screenings'
import ScreeningPage from 'src/components/ScreeningPage/index.vue'
import notify from 'src/helpers/notify'
import useLogin from 'src/helpers/useLogin'
type mode = 'view' | 'edit'

const route = useRoute()
const router = useRouter()
const login = useLogin()

const screeningId = computed(() => {
  const id = route.params?.id
  return Array.isArray(id) ? id[0] : id
})

const query = useQuery(() => getScreening(screeningId.value))

const currentMode = ref<mode>('view')
const isFormValid = ref(true)
const screeningPageRef = ref<InstanceType<typeof ScreeningPage>>()
const isSaving = ref(false)

const isReadOnly = computed(() => currentMode.value === 'view')

const updatedScreening = ref({
  title: '',
  description: '',
  startAt: '',
  endAt: '',
  body: ''
})

watch(
  query,
  () => {
    if (query.data) {
      updatedScreening.value.title = query.data.title ?? ''
      updatedScreening.value.description = query.data.description ?? ''
      updatedScreening.value.startAt = query.data.startAt ?? ''
      updatedScreening.value.endAt = query.data.endAt ?? ''
      updatedScreening.value.body = query.data.body ?? ''
    }
  },
  { immediate: true, deep: true }
)

const saveScreening = async () => {
  if (!screeningPageRef.value) return
  if (!query.data) return
  if (!updatedScreening.value) return
  isFormValid.value = await screeningPageRef.value?.validateForm()
  if (!isFormValid.value) return
  isSaving.value = true
  try {
    await updateScreening(query.data._id, updatedScreening.value)
    currentMode.value = 'view'
    notify('Screening aggiornato con successo', 'positive')
    query.refetch()
  } catch (error) {
    console.error('Error updating screening:', error)
  } finally {
    isSaving.value = false
  }
}

const cancel = () => {
  if (currentMode.value === 'edit') {
    query.refetch()
    currentMode.value = 'view'
  } else {
    router.back()
  }
}
</script>
