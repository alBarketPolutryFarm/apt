import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { Alarm } from 'src/api/alarms/models'
import { AlarmStrings, AlarmType } from 'src/const/Alarm'
import { MeasureStrings } from 'src/const/Measure'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'type',
    label: 'Tipo',
    align: 'left',
    field: (row: Alarm) => row.type,
    format: (type: AlarmType, row: Alarm) => {
      if (type === 'measureOutBounds' && row.measure !== undefined) {
        return `${AlarmStrings[type]} [${
          MeasureStrings[row.measure.metadata.type]
        }]`
      }
      return AlarmStrings[type]
    },
    sortable: true
  },
  {
    name: 'description',
    label: 'Descrizione',
    align: 'left',
    field: (row: Alarm) => row.description,
    sortable: true
  },
  {
    name: 'createAt',
    label: 'Data',
    align: 'left',
    field: (row: Alarm) => row.createdAt,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'patient',
    label: 'Paziente',
    align: 'left',
    field: (row: Alarm) => row.patientId,
    sortable: true
  },
  {
    name: 'actions',
    label: '',
    align: 'center',
    field: (row: Alarm) => row
  }
]
