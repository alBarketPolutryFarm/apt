<script setup lang="ts">
import { ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import { handleAlarm } from 'src/api/alarms'
import useMutation from 'src/api/useMutation'
import { Alarm } from 'src/api/alarms/models'

const props = defineProps<{
  alarm: Alarm
}>()

const [triggerMutation, mutationStatus] = useMutation(handleAlarm)
const handled = (id: string) => triggerMutation(id)

watch(
  () => mutationStatus.isError,
  isError => {
    if (!isError) return
    notify("Impossibile gestire l'allarme al momento", 'negative')
  }
)

const hover = ref<boolean>(false)
</script>

<template>
  <div style="display: flex; align-items: center; justify-content: center">
    <q-btn
      v-if="!mutationStatus.isSuccess && props.alarm.handling === undefined"
      round
      :icon="hover ? 'done' : 'warning'"
      :color="hover ? 'green' : 'red'"
      size="sm"
      class="q-ml-lg"
      @mouseover="hover = true"
      @mouseout="hover = false"
      @click="handled(props.alarm._id)" />
  </div>
</template>
