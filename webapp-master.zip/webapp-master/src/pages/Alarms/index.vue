<script setup lang="ts">
import { ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import { getAlarms } from 'src/api/alarms'
import { COLUMNS } from './const'
import UserFetcher from 'src/components/UserFetcher'
import Actions from './Actions'

const query = useQuery(getAlarms, ref({ limit: 100 }))

watch(
  () => query.isError,
  isError => {
    if (!isError) return
    notify('Impossibile recuperare la lista degli allarmi', 'negative')
  }
)
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Allarmi</h6>

    <q-separator class="q-my-md" />

    <q-table title="Allarmi" :rows="query.data" :columns="COLUMNS">
      <template #body-cell-actions="{ row }">
        <q-td>
          <actions :alarm="row" />
        </q-td>
      </template>

      <template #body-cell-patient="{ value }">
        <q-td>
          <user-fetcher type="patient" :user-id="value" />
        </q-td>
      </template>

      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare gli allarmi
          </div>
          <div v-else-if="query.isSuccess">Nessun allarme presente</div>
        </div>
      </template>
    </q-table>
  </q-page>
</template>
