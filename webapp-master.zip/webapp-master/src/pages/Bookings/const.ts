import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { Booking } from 'src/api/bookings/models'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'at',
    label: 'Data',
    align: 'left',
    field: (row: Booking) => row.at,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'description',
    label: 'Descrizione',
    align: 'left',
    field: (row: Booking) => row.description,
    sortable: true
  },
  {
    name: 'target',
    label: 'Richiedente',
    align: 'left',
    field: (row: Booking) => row.targetId,
    sortable: true
  },
  {
    name: 'provider',
    label: 'Operatore',
    align: 'left',
    field: (row: Booking) => row.providerId,
    sortable: true
  },
  {
    name: 'isRemote',
    label: 'Da remoto',
    align: 'center',
    field: (row: Booking) => row.isRemote,
    sortable: true
  },
  {
    name: 'actions',
    label: '',
    align: 'center',
    field: (row: Booking) => row
  }
]
