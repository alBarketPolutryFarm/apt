<script setup lang="ts">
import { watch } from 'vue'
import notify from 'src/helpers/notify'
import useMutation from 'src/api/useMutation'
import { Booking } from 'src/api/bookings/models'
import { deleteBooking } from 'src/api/bookings'

const props = defineProps<{
  booking: Booking
}>()

const [triggerMutation, mutationStatus] = useMutation(deleteBooking)
const handleDelete = () => triggerMutation(props.booking._id)

watch(mutationStatus, q => {
  if (!q.isError) return
  notify("Impossibile cancellare l'appuntamento al momento", 'negative')
})

const emit = defineEmits<{
  (e: 'deleted'): void
}>()

watch(mutationStatus, q => {
  if (!q.isSuccess) return
  notify('Appuntamento cancellato con successo', 'positive')
  emit('deleted')
})
</script>

<template>
  <div style="display: flex; align-items: center; justify-content: center">
    <a v-if="props.booking.remoteLink" :href="props.booking.remoteLink">
      <q-btn round icon="link" color="blue" size="sm" class="q-ml-lg" />
    </a>
    <q-btn
      round
      icon="delete"
      color="red"
      size="sm"
      class="q-ml-lg"
      @click="handleDelete()" />
  </div>
</template>
