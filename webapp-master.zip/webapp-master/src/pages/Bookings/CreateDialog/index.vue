<script setup lang="ts">
import { ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import useMutation from 'src/api/useMutation'
import { NewBooking } from 'src/api/bookings/models'
import QInputDateTime from 'src/components/QInputDateTime'
import QSelectUser from 'src/components/QSelectUser'
import { createBooking } from 'src/api/bookings'

const props = defineProps<{ targetId?: string }>()

const emit = defineEmits<{
  (e: 'created'): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<Partial<NewBooking>>({})

const reset = () => {
  data.value = {}
}

const [create, createStatus] = useMutation(createBooking)

watch(createStatus, q => {
  if (!q.isError) return
  notify("Impossibile creare l'appuntamento", 'negative')
})

watch(createStatus, q => {
  if (!q.isSuccess) return
  notify('Appuntamento creato con successo', 'positive')
  isDialogOpen.value = false
  reset()
  emit('created')
})

const createMonitoringPlan = () =>
  create({ targetId: props.targetId, ...data.value } as NewBooking)

defineExpose({
  show: () => {
    reset()
    isDialogOpen.value = true
  }
})
</script>

<template>
  <q-dialog v-model="isDialogOpen" @before-hide="reset()">
    <q-card style="width: 400px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Nuovo appuntamento</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="createMonitoringPlan">
        <q-card-section class="column no-wrap" style="min-height: 300px">
          <q-select-user
            v-if="!props.targetId"
            v-model="data.targetId"
            :rules="['required']"
            label="Richiedente" />
          <q-select-user
            v-model="data.providerId"
            :rules="['required']"
            :user-type="['operator', 'doctor', 'nurse']"
            label="Operatore" />
          <q-input-date-time
            v-model="data.at"
            :rules="['required']"
            class="input"
            label="Data" />
          <q-input
            v-model="data.description"
            class="input"
            type="textarea"
            :rules="[v => !!v || 'Campo richiesto']"
            label="Descrizione" />
          <q-checkbox
            :model-value="data.isRemote ?? false"
            label="Visita da remoto"
            @update:model-value="v => (data.isRemote = v)" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn
            flat
            label="Crea"
            type="submit"
            :loading="createStatus.isLoading" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
