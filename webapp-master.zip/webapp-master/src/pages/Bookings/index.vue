<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import { COLUMNS } from './const'
import UserFetcher from 'src/components/UserFetcher'
import BookingActions from './BookingActions'
import { getBookings } from 'src/api/bookings'
import { DateTime } from 'luxon'
import CreateDialog from './CreateDialog'
import useLogin from 'src/helpers/useLogin'

const login = useLogin()
const dialog = ref<CreateDialog>()

const getBookingsParams = computed(() => {
  if (true) {
    // (login.user?.type === 'admin' || login.user?.type === 'superadmin') {
    return {}
  } else {
    return { startDate: DateTime.now().minus({ days: 7 }) }
  }
})

const query = useQuery(getBookings, getBookingsParams)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista degli appuntamenti', 'negative')
})
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Appuntamenti</h6>

    <q-separator class="q-my-md" />

    <q-table
      :rows="query.data"
      :columns="COLUMNS"
      row-key="_id"
      class="row"
      :loading="query.isLoading">
      <template #top-right>
        <q-btn
          v-if="
            login?.user?.type === 'admin' || login?.user?.type === 'superadmin'
          "
          icon="add"
          color="primary"
          @click="dialog?.show()" />
        <q-btn
          v-else
          icon="add"
          color="primary"
          target="_blank"
          href="https://alphaformazioneservizisanitari.com/prenotazione-partner" />
      </template>

      <template #body-cell-provider="{ value }">
        <q-td>
          <user-fetcher :user-id="value" />
        </q-td>
      </template>
      <template #body-cell-target="{ value }">
        <q-td>
          <user-fetcher :user-id="value" />
        </q-td>
      </template>

      <template #body-cell-isRemote="{ value }">
        <q-td class="flex justify-center items-center">
          <q-icon v-if="value" name="done" size="sm" />
        </q-td>
      </template>

      <template #body-cell-actions="{ row }">
        <q-td>
          <booking-actions :booking="row" @deleted="query.refetch()" />
        </q-td>
      </template>

      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare gli appuntamenti
          </div>
          <div v-else-if="query.isSuccess">Nessun appuntamento presente</div>
        </div>
      </template>
    </q-table>
  </q-page>
  <create-dialog ref="dialog" @created="query.refetch()" />
</template>
