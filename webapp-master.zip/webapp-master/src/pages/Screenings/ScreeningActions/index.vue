<script setup lang="ts">
import { watch } from 'vue'
import notify from 'src/helpers/notify'
import useMutation from 'src/api/useMutation'
import { deleteScreening } from 'src/api/screenings'
import { Screening } from 'src/api/screenings/models'
import { useRouter } from 'vue-router'
import useLogin from 'src/helpers/useLogin'

const props = defineProps<{
  screening: Screening
}>()

const router = useRouter()
const login = useLogin()

const [triggerMutation, mutationStatus] = useMutation(deleteScreening)

watch(mutationStatus, q => {
  if (!q.isError) return
  notify('Impossibile cancellare lo screening al momento', 'negative')
})

const emit = defineEmits<{
  (e: 'deleted'): void
}>()

watch(mutationStatus, q => {
  if (!q.isSuccess) return
  notify('Screening cancellato con successo', 'positive')
  emit('deleted')
})

const handleDelete = () => triggerMutation(props.screening._id)

const handleView = () => {
  router.push(`/screenings/${props.screening._id}`)
}
</script>

<template>
  <div style="display: flex; align-items: center; justify-content: center">
    <q-btn
      round
      icon="visibility"
      color="blue"
      size="sm"
      class="q-ml-lg"
      @click="handleView()" />
    <q-btn
      v-if="login?.user?.type === 'admin' || login?.user?.type === 'superadmin'"
      round
      icon="delete"
      color="red"
      size="sm"
      class="q-ml-lg"
      @click="handleDelete()" />
  </div>
</template>
