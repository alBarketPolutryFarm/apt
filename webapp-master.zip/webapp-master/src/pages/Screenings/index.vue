<script setup lang="ts">
import { computed, Ref, ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import { COLUMNS } from './const'

import { getBookings } from 'src/api/bookings'
import { DateTime } from 'luxon'
import useLogin from 'src/helpers/useLogin'
import { useRouter } from 'vue-router'
import { getScreenings } from 'src/api/screenings'
import ScreeningActions from './ScreeningActions/index.vue'
import { Screening } from 'src/api/screenings/models'

const login = useLogin()
const router = useRouter()

const query = useQuery(getScreenings)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista degli screening', 'negative')
})

// sort the query data when it changes
const sortedData: Ref<Screening[]> = ref([])

watch(query, data => {
  if (!data || !data.data) return
  const upcomingScreenings = data.data.filter(
    s =>
      DateTime.fromISO(s.startAt) > DateTime.now() &&
      DateTime.fromISO(s.endAt) > DateTime.now()
  )
  const pastScreenings = data.data.filter(
    s => DateTime.fromISO(s.endAt) < DateTime.now()
  )
  const currentScreenings = data.data.filter(
    s =>
      DateTime.fromISO(s.startAt) < DateTime.now() &&
      DateTime.fromISO(s.endAt) > DateTime.now()
  )
  sortedData.value = [
    ...currentScreenings,
    ...upcomingScreenings,
    ...pastScreenings
  ]
})
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Screening</h6>

    <q-separator class="q-my-md" />

    <q-table
      :rows="sortedData"
      :columns="COLUMNS"
      row-key="_id"
      class="row"
      :loading="query.isLoading">
      <template #top-right>
        <q-btn
          v-if="
            login?.user?.type === 'admin' || login?.user?.type === 'superadmin'
          "
          label="Crea nuovo documento"
          color="primary"
          @click="
            () => {
              router.push('/screenings/create')
            }
          " />
      </template>

      <template #body-cell-status="{ row }">
        <q-td class="text-center">
          <q-badge
            v-if="
              DateTime.fromISO(row.startAt) < DateTime.now() &&
              DateTime.fromISO(row.endAt) > DateTime.now()
            "
            color="primary"
            rounded />
          <q-badge
            v-else-if="DateTime.fromISO(row.startAt) > DateTime.now()"
            color="warning"
            rounded />
          <q-badge v-else color="negative" rounded />
        </q-td>
      </template>

      <template #body-cell-actions="{ row }">
        <q-td>
          <screening-actions :screening="row" @deleted="query.refetch()" />
        </q-td>
      </template>

      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare gli screening
          </div>
          <div v-else-if="query.isSuccess">Nessuno screening presente</div>
        </div>
      </template>
    </q-table>
  </q-page>
  <create-dialog ref="dialog" @created="query.refetch()" />
</template>
