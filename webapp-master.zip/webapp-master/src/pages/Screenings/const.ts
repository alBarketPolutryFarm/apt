import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { Screening } from 'src/api/screenings/models'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'status',
    label: 'Stato',
    align: 'center',
    field: (row: Screening) => row
  },
  {
    name: 'title',
    label: 'Titolo',
    align: 'left',
    field: (row: Screening) => row.title,
    sortable: true
  },
  {
    name: 'startAt',
    label: 'Data di inizio',
    align: 'left',
    field: (row: Screening) => row.startAt,
    format: (v: string) =>
      DateTime.fromISO(v).toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'endAt',
    label: 'Data di fine',
    align: 'left',
    field: (row: Screening) => row.endAt,
    format: (v: string) =>
      DateTime.fromISO(v).toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'createdAt',
    label: 'Data di creazione',
    align: 'left',
    field: (row: Screening) => row.createdAt,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'actions',
    label: 'Azioni',
    align: 'center',
    field: (row: Screening) => row
  }
]
