<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">Crea nuovo screening</h6>
    <q-separator class="q-my-md" />

    <screening-page
      ref="screeningPageRef"
      :screening="newScreening"
      @update:screening="screening => (newScreening = screening)" />

    <div class="q-mt-md row justify-end">
      <q-btn
        color="primary"
        label="Crea"
        :disable="isCreating || !isFormValid"
        @click="createScreening" />
      <q-btn
        class="q-ml-md"
        flat
        color="primary"
        label="Annulla"
        @click="router.back()" />
    </div>
  </q-page>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { Notify } from 'quasar'
import { useRouter } from 'vue-router'
import { createScreening as createScreeningApi } from 'src/api/screenings'
import ScreeningPage from 'src/components/ScreeningPage/index.vue'
import { NewScreening, Screening } from 'src/api/screenings/models'
import { DateTime } from 'luxon'

const router = useRouter()
const screeningPageRef = ref<InstanceType<typeof ScreeningPage>>()

const isCreating = ref(false)
const isFormValid = ref(true)

const newScreening = ref<NewScreening>({
  title: '',
  description: '',
  startAt: '',
  endAt: '',
  body: ''
})

async function createScreening() {
  if (!screeningPageRef.value) return
  isFormValid.value = await screeningPageRef.value?.validateForm()
  if (!isFormValid.value) return
  isCreating.value = true
  try {
    await createScreeningApi(newScreening.value)
    Notify.create({
      message: 'Screening creato con successo!',
      color: 'positive'
    })
    router.back()
  } catch (error) {
    Notify.create({
      message: 'Errore durante la creazione dello screening',
      color: 'negative'
    })
    console.error(error)
  } finally {
    isCreating.value = false
  }
}
</script>
