<template>
  <div
    class="column no-wrap items-center content-center justify-center fullscreen">
    <img
      src="~assets/logo_infermieri.png"
      alt="Infermieri"
      style="width: 60vw; max-height: 100%; max-width: 800px" />

    <q-form
      v-if="!isOtpSent"
      class="full-width q-ma-lg column no-wrap items-center"
      style="width: 60vw; max-height: 100%; max-width: 300px"
      @submit="handleSignIn">
      <q-input v-model="email" label="email" type="email" class="full-width" />
      <q-input
        v-model="password"
        label="password"
        type="password"
        class="full-width" />
      <q-card-actions align="right" class="text-primary">
        <q-btn
          flat
          label="Invia email di recupero"
          @click="
            () => {
              router.push('/Forgot-Password')
            }
          " />
      </q-card-actions>
      <q-btn type="submit" class="q-ma-lg">Login</q-btn>
    </q-form>

    <q-form
      v-else
      class="full-width q-ma-lg column no-wrap items-center"
      style="width: 60vw; max-height: 100%; max-width: 300px"
      @submit.prevent="handleOtpVerification">
      <q-input
        v-model="otp"
        outlined
        label="OTP"
        class="full-width"
        :rules="[val => !!val || 'Inserisci il codice OTP']" />
      <q-btn type="submit" class="q-ma-lg" :loading="isOtpLoading">
        Verifica OTP
      </q-btn>
    </q-form>

    <div v-if="signInError" class="text-negative q-mt-md">
      {{ signInError }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useQuasar } from 'quasar'
import { useRouter } from 'vue-router'
import { useDispatch } from 'src/redux/helpers'
import { resetToken, setToken, setUser } from 'src/redux/auth'
import { signIn, verifyOtp } from 'src/api/auth'
import { getUser } from 'src/api/user'

const router = useRouter()
const dispatch = useDispatch()
const $q = useQuasar()

const showNotify = (t: string, msg: string) => {
  $q.notify({
    type: t,
    message: msg,
    position: 'top-right',
    timeout: 2000
  })
}

onMounted(() => {
  sessionStorage.setItem('bearer', '')
  sessionStorage.setItem('user', '')
  sessionStorage.setItem('requiredAut', 'false')
})

const email = ref<string>()
const password = ref<string>()
const isOtpSent = ref(false)
const otp = ref<string>()
const isOtpLoading = ref(false)
const signInError = ref<string | null>(null)

const handleSignIn = () => {
  if (email.value === undefined) return
  if (password.value === undefined) return

  sessionStorage.setItem('bearer', '')
  sessionStorage.setItem('requiredAut', 'false')
  signInError.value = null

  signIn({ username: email.value, password: password.value })
    .then(() => {
      isOtpSent.value = true
    })
    .catch(error => {
      dispatch(resetToken())
      if (error.response.status == 429) {
        if (error.response.data.detail) {
          showNotify('negative', error.response.data.detail)
        } else {
          signInError.value = 'Credenziali errate'
        }
      } else {
        signInError.value = 'Credenziali errate'
      }
    })
}

const handleOtpVerification = () => {
  if (otp.value === undefined) return

  isOtpLoading.value = true
  signInError.value = null

  verifyOtp({ otp: otp.value, email: email.value as string })
    .then(response => {
      const token = response.token
      dispatch(setToken(token))

      // TODO remove this shit
      sessionStorage.setItem('access-token', token)
      sessionStorage.setItem('bearer', token)
      sessionStorage.setItem('requiredAut', 'true')

      getUser()
        .then(r => r.data)
        .then(user => {
          if (
            ![
              'superadmin',
              'admin',
              'doctor',
              'nurse',
              'operator',
              'patient',
              'caregiver'
            ].includes(user.type)
          )
            return Promise.reject()
          if (user?.status != 'active') {
            // console.log(user)
            showNotify('negative', 'You are Suspended')
            return Promise.reject()
          }
          dispatch(setUser(user))
          // console.log(user)

          isOtpSent.value = false
          router.push('/')
        })
        .catch(() => {
          dispatch(resetToken())
          signInError.value = 'Errore in fase di autenticazione'
        })
    })
    .catch(() => {
      dispatch(resetToken())
      signInError.value = 'OTP non valido'
    })
    .finally(() => {
      isOtpLoading.value = false
    })
}
</script>
