<script setup lang="ts">
import { ref, watch } from 'vue'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import { uploadFile } from 'src/api/files'
import notify from 'src/helpers/notify'
import { NewExternalReport, Report } from 'src/api/patients/reports/models'
import { createPatientReport } from 'src/api/patients/reports'
import useMutation from 'src/api/useMutation'

const props = defineProps<{
  patientId: string
}>()

const emit = defineEmits<{
  (e: 'create'): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<RecursivePartial<Report>>({})
const file = ref<File>()
const isReadonly = ref(false)

const [create, createStatus] = useMutation(createPatientReport)
const [upload, uploadStatus] = useMutation(uploadFile)

const handleSubmit = () => {
  if (data.value.description === undefined) return
  if (file.value === undefined) return

  upload(file.value).then(r => {
    create(props.patientId, {
      ...data.value,
      file: r.data._id,
      type: 'external'
    } as NewExternalReport)
  })
}

const reset = () => {
  data.value = {}
  file.value = undefined
}

watch(createStatus, q => {
  if (!q.isSuccess) return
  notify('Referto inserito con successo', 'positive')
  isDialogOpen.value = false
  reset()
  emit('create')
})
watch(createStatus, q => {
  if (!q.isError) return
  notify('Impossibile creare il referto', 'negative')
})
watch(uploadStatus, q => {
  if (!q.isError) return
  notify('Impossibile caricare il file', 'negative')
})

defineExpose({
  show: () => {
    reset()
    isDialogOpen.value = true
  }
})
</script>

<template>
  <q-dialog v-model="isDialogOpen">
    <q-card style="width: 400px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Carica referto</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-input
            v-model="data.description"
            label="Descrizione"
            :rules="[v => !!v || 'Campo richiesto']" />
          <q-file
            v-model="file"
            filled
            label="File"
            :rules="[v => !!v || 'Campo richiesto']" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn v-if="!isReadonly" flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
