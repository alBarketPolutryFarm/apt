<script setup lang="ts">
import { ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import AddExternalReportDialog from './AddExternalReportDialog'
import MedicalExaminationReportDialog from './MedicalExaminationReportDialog'
import { COLUMNS } from './const'
import {
  getPatientReportFile,
  getPatientReports
} from 'src/api/patients/reports'
import useLogin from 'src/helpers/useLogin'
import useQuery from 'src/api/useQuery'
import downloadFileEncoded from 'src/helpers/downloadFileEncoded'
import ReportActions from './ReportActions'
import ReportBadge from './ReportBadge'
import { PushAndSaveReport } from 'src/api/reports'

const login = useLogin()

const props = defineProps<{ patientId: string }>()

const externalReportDialog = ref<AddExternalReportDialog>()
const medicalExaminationReportDialogRef = ref<MedicalExaminationReportDialog>()

const query = useQuery(getPatientReports, ref(props.patientId))

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista dei referti', 'negative')
})

async function GenerateThePatientReportFile() {
  await PushAndSaveReport(props.patientId)
  query.refetch()
}

// const downloadReport = (reportId: string) =>
//   downloadFileEncoded(getPatientReportFile(props.patientId, reportId))
</script>

<template>
  <div>
    <div class="row no-wrap justify-between q-pb-md">
      <div class="text-h6">Referti</div>

      <div class="row no-wrap justify-between q-pb-md" style="gap: 10px">
        <q-btn-dropdown
          v-if="login.user?.type === 'doctor'"
          icon="add"
          color="primary"
          split
          @click="medicalExaminationReportDialogRef?.show()">
          <q-list>
            <q-item
              v-close-popup
              clickable
              @click="externalReportDialog?.show()">
              <q-item-section>
                <q-item-label>Carica referto</q-item-label>
              </q-item-section>
            </q-item>
            <q-item
              v-close-popup
              clickable
              @click="GenerateThePatientReportFile()">
              <q-item-section>
                <q-item-label>Info referto</q-item-label>
              </q-item-section>
            </q-item>
          </q-list>
        </q-btn-dropdown>

        <q-btn
          v-else-if="login.user?.type === 'nurse'"
          icon="add"
          color="primary"
          @click="externalReportDialog?.show()" />
      </div>
    </div>

    <q-table
      :rows="query.data"
      :columns="COLUMNS"
      row-key="name"
      class="row"
      :loading="query.isLoading">
      <template #body-cell-actions="{ row: report }">
        <q-td>
          <report-actions
            :patient-id="patientId"
            :report="report"
            @change="query.refetch()"
            @edit-click="medicalExaminationReportDialogRef?.show(report)" />
        </q-td>
      </template>

      <template #body-cell-type="{ row: report }">
        <q-td>
          <report-badge :report="report" />
        </q-td>
      </template>

      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare i referti
          </div>
          <div v-else-if="query.isSuccess">Nessun referto presente</div>
        </div>
      </template>
    </q-table>
  </div>

  <add-external-report-dialog
    ref="externalReportDialog"
    :patient-id="props.patientId"
    @create="query.refetch()" />

  <medical-examination-report-dialog
    ref="medicalExaminationReportDialogRef"
    :patient-id="props.patientId"
    @create="query.refetch()"
    @edit="query.refetch()" />
</template>
