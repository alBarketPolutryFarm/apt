<script setup lang="ts">
import { computed } from 'vue'
import { Report } from 'src/api/patients/reports/models'
import { DateTime } from 'luxon'
import { ReportStrings } from 'src/const/Report'

const props = defineProps<{
  report: Report
}>()

const reportTypeLabel = computed(() => ReportStrings[props.report.type])
</script>

<template>
  <q-chip
    v-if="props.report.type === 'external'"
    color="orange"
    text-color="white"
    :label="reportTypeLabel" />

  <q-chip
    v-else-if="!props.report.signature"
    color="red"
    icon="warning"
    text-color="white"
    :label="`${reportTypeLabel} (non firmato)`">
    <q-tooltip>
      Il documento non sarà valido fintanto che non sarà stato firmato
    </q-tooltip>
  </q-chip>

  <q-chip
    v-else-if="props.report.signature.status === 'completed'"
    color="purple"
    text-color="white"
    :label="reportTypeLabel">
    <q-tooltip>
      Documento firmato il
      {{
        props.report.signature.updatedAt?.toLocaleString(DateTime.DATETIME_MED)
      }}
    </q-tooltip>
  </q-chip>

  <q-chip
    v-else-if="props.report.signature.status === 'failed'"
    color="red"
    icon="warning"
    text-color="white"
    :label="`${reportTypeLabel} (firma fallita)`" />

  <q-chip
    v-else-if="props.report.signature.status === 'waiting'"
    color="blue"
    icon="warning"
    text-color="white"
    :label="`${reportTypeLabel} (in attesa di firma)`">
    <q-tooltip>
      Il documento non sarà valido fintanto che la procedura di firma non sarà
      completata
    </q-tooltip>
  </q-chip>
</template>
