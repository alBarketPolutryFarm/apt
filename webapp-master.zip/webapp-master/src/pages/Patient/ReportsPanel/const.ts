import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { Report } from 'src/api/patients/reports/models'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'date',
    label: 'Data',
    align: 'left',
    field: (row: Report) => row.date,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATE_MED),
    sortable: true
  },
  {
    name: 'description',
    label: 'Descrizione',
    align: 'left',
    field: 'description',
    sortable: true
  },
  {
    name: 'type',
    label: 'Tipologia',
    align: 'left',
    field: 'type',
    sortable: true
  },
  {
    name: 'actions',
    label: '',
    field: (row: Report) => row
  }
]
