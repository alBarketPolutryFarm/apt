<template>
  <div ref="pdfContainer" class="pdf-container">
    <vue-pdf-embed
      :source="src"
      :width="width"
      :height="height"
      @rendered="onRendered"
      @loading="onLoading"
      @error="onError" />
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, watch } from 'vue'
import VuePdfEmbed from 'vue-pdf-embed'

type PdfBlobUrl = {
  url: string
  name: string
  type: string
}

export default defineComponent({
  name: 'PDFViewer',
  components: {
    VuePdfEmbed
  },
  props: {
    src: {
      type: String,
      required: true
    },
    width: {
      type: Number,
      default: 600
    },
    height: {
      type: Number,
      default: 800
    },
    initialPage: {
      type: Number,
      default: 1
    }
  },
  emits: ['rendered', 'loading', 'error'],
  setup(props, { emit }) {
    const pdfContainer = ref<HTMLElement | null>(null)
    const page = ref(props.initialPage)

    const onRendered = (numberOfPages: number) => {
      emit('rendered', numberOfPages)
    }

    const onLoading = (loadingProgress: number) => {
      emit('loading', loadingProgress)
    }

    const onError = (error: Error) => {
      console.error('Error loading PDF:', error)
      emit('error', error)
    }

    onMounted(() => {
      if (pdfContainer.value) {
      }
    })

    watch(
      () => props.initialPage,
      newPage => {
        page.value = newPage
      }
    )

    return {
      pdfContainer,
      page,
      onRendered,
      onLoading,
      onError
    }
  }
})
</script>

<style scoped>
.pdf-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f0f0f0;
  padding: 20px;
}

/* .vue-pdf-embed iframe .toolbarButtonDownload {
    display: none !important;
} */
</style>
