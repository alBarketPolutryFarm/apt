<script setup lang="ts">
import { DateTime } from 'luxon'
import useLogin from 'src/helpers/useLogin'
import downloadFileEncoded from 'src/helpers/downloadFileEncoded'
import { Report } from 'src/api/patients/reports/models'
import {
  getPatientReportExamFile,
  getPatientReportFile,
  startSignatureProcessPatientReport
} from 'src/api/patients/reports'
import { QDialog } from 'quasar'
import { ref, watch } from 'vue'
import useQuery from 'src/api/useQuery'
import useMutation from 'src/api/useMutation'
import notify from 'src/helpers/notify'
import PDFViewer from './Reports'
import axios from 'axios'

const props = defineProps<{
  patientId: string
  report: Report
}>()

const emit = defineEmits<{
  (e: 'editClick'): void
  (e: 'change'): void
}>()

const login = useLogin()

const downloadReport = (reportId: string) =>
  downloadFileEncoded(getPatientReportFile(props.patientId, reportId))

const downloadExam = (reportId: string) =>
  downloadFileEncoded(getPatientReportExamFile(props.patientId, reportId))

const startSignDialogRef = ref<QDialog>()
const viewReportDialogRef = ref<QDialog>()
const viewImageDialogRef = ref<QDialog>()
const dataBlobUrl = ref<{
  url: string
  name: string
  type: string
} | null>(null)

const [startSignatureProcess, signatureProcessStatus] = useMutation(
  startSignatureProcessPatientReport
)

watch(signatureProcessStatus, s => {
  if (!s.isLoading && s.isError) {
    if (s.statusCode === 403) {
      notify(
        'Il tuo limite è esaurito.Contatta il tuo amministratore',
        'negative'
      )
    } else {
      notify('Impossibile avviare la procedura di firma', 'negative')
    }
  }
})

watch(signatureProcessStatus, s => {
  if (s.isLoading || !s.isSuccess || !s.data) return
  startSignDialogRef.value?.hide()
  emit('change')
  window.open(s.data.signature.link as string, '_blank')
})

const fetchAndCreateBlobUrl = async (reportId: string): Promise<any> => {
  try {
    const fileResponse = await getPatientReportFile(props.patientId, reportId)
    const pdfData = fileResponse.data
    const byteCharacters = atob(pdfData.content)
    const byteNumbers = new Array(byteCharacters.length)
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i)
    }
    const byteArray = new Uint8Array(byteNumbers)
    const blob = new Blob([byteArray], { type: pdfData.mediaType })

    // return URL.createObjectURL(blob)
    return {
      type: pdfData.mediaType,
      url: URL.createObjectURL(blob)
    }
  } catch (error) {
    console.error('Error fetching file:', error)
    notify('Impossibile recuperare il documento', 'negative')
    return null
  }
}

const isImageType = (mimeType: string): boolean => {
  const IMAGE_MIME_TYPES = [
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/bmp',
    'image/tiff'
  ]
  return IMAGE_MIME_TYPES.includes(mimeType)
}
const validateImageUrl = (url: string): Promise<boolean> => {
  return new Promise(resolve => {
    const img = new Image()

    img.onload = () => {
      resolve(true)
    }

    img.onerror = () => {
      resolve(false)
    }

    img.src = url
  })
}

const downloadFetchedReport = async (name: string) => {
  const blobUrl = await fetchAndCreateBlobUrl(props.report._id)
  if (blobUrl == null || !blobUrl.url) {
    notify('Impossibile recuperare il documento', 'negative')
    return
  }

  const link = document.createElement('a')
  link.href = blobUrl.url
  link.download = name
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

const viewReport = async () => {
  const blobUrl = await fetchAndCreateBlobUrl(props.report._id)
  if (blobUrl == null) {
    return
  } else {
    if (!blobUrl.url) {
      notify('Impossibile recuperare il documento', 'negative')
      return
    } else if (blobUrl.type == 'application/pdf') {
      const isValidPDF = await validatePdfBlobUrl(blobUrl?.url)
      if (!isValidPDF) {
        notify('Il Document è corrotto o non valido', 'negative')
        return
      }
      dataBlobUrl.value = {
        url: blobUrl.url,
        name: 'Referto',
        type: blobUrl.type
      }
      viewReportDialogRef.value?.show()
    } else if (isImageType(blobUrl.type)) {
      try {
        const isValidImage = await validateImageUrl(blobUrl.url)
        if (!isValidImage) {
          notify("L'immagine è corrotta o non valida", 'negative')
          return
        }

        dataBlobUrl.value = {
          url: blobUrl.url,
          name: 'Immagine Referto',
          type: blobUrl.type
        }
        viewImageDialogRef.value?.show()
      } catch (error) {
        console.error('Error handling image:', error)
        notify("Errore durante l'apertura dell'immagine", 'negative')
      }
    } else if (blobUrl.type == '') {
    } else {
      notify('Il Document non è un PDF', 'negative')
      return
    }
  }
}

const validatePdfBlobUrl = (blobUrl: string): Promise<boolean> => {
  return new Promise(resolve => {
    const iframe = document.createElement('iframe')
    iframe.style.display = 'none'
    iframe.src = blobUrl
    document.body.appendChild(iframe)

    iframe.onload = () => {
      resolve(true) // PDF is valid
      document.body.removeChild(iframe)
    }
    iframe.onerror = () => {
      console.error('Failed to load the PDF')
      document.body.removeChild(iframe)
      resolve(false)
    }
  })
}

const handlePdfError = (error: any) => {
  console.error('Error loading PDF:', error)
  notify('Impossibile caricare il referto', 'negative')
}

watch(viewReportDialogRef, dialog => {
  if (!dialog && dataBlobUrl.value) {
    URL.revokeObjectURL(dataBlobUrl.value?.url)
    dataBlobUrl.value = null
  }
})
</script>

<template>
  <!-- <q-btn
    round
    icon="visibility"
    color="green"
    size="sm"
    class="q-ml-lg"
    @click="viewReport">
    <q-tooltip>Visualizza referto</q-tooltip>
  </q-btn> -->

  <q-btn
    v-if="props.report.type === 'exam'"
    round
    icon="download"
    color="purple"
    size="sm"
    class="q-ml-lg"
    @click="downloadExam(props.report._id)">
    <q-tooltip>Scarica esame</q-tooltip>
  </q-btn>

  <q-btn
    round
    icon="fa-solid fa-file-arrow-down"
    color="blue"
    size="sm"
    class="q-ml-lg"
    @click="downloadReport(props.report._id)">
    <q-tooltip>Scarica il referto</q-tooltip>
  </q-btn>

  <template
    v-if="
      ['exam', 'medicalExamination'].includes(props.report.type) &&
      login.user?.type === 'doctor'
    ">
    <q-btn
      v-if="
        login.user._id === props.report.createdBy &&
        (!props.report.signature || props.report.signature.status === 'failed')
      "
      round
      icon="edit"
      color="orange"
      size="sm"
      class="q-ml-lg"
      @click="emit('editClick')">
      <q-tooltip>Modifca il referto</q-tooltip>
    </q-btn>
    <q-btn
      v-if="
        login.user._id === report.createdBy &&
        props.report.signature?.status !== 'completed'
      "
      round
      icon="draw"
      color="green"
      size="sm"
      class="q-ml-lg"
      type="a"
      target="_blank"
      :href="props.report.signature?.link"
      @click="
        () => {
          props.report.signature?.link || startSignDialogRef?.show()
        }
      ">
      <q-tooltip>Firma il documento</q-tooltip>
    </q-btn>
  </template>

  <q-dialog ref="startSignDialogRef" persistent>
    <q-card>
      <q-card-section>
        <div class="text-h6">Procedura di firma elettronica</div>
      </q-card-section>
      <q-card-section class="row items-center">
        <span class="q-ml-sm">
          Una volta iniziata la procedura di firma non sarà più possibile
          modificare il referto, pertanto
          <b>verficarne attentamente il contenuto prima di procedere</b>
        </span>
      </q-card-section>

      <q-card-actions class="row justify-between">
        <q-btn
          label="Scarica referto"
          color="grey-6"
          @click="downloadReport(props.report._id)" />
        <div class="q-gutter-sm">
          <q-btn v-close-popup label="Annulla" color="primary" />
          <q-btn
            label="Firma"
            color="negative"
            :loading="signatureProcessStatus.isLoading"
            @click="startSignatureProcess(props.patientId, props.report._id)" />
        </div>
      </q-card-actions>
    </q-card>
  </q-dialog>

  <q-dialog ref="viewReportDialogRef" full-width>
    <q-card>
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Referto</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-card-section>
        <template v-if="dataBlobUrl?.type === 'application/pdf'">
          <PDFViewer :src="dataBlobUrl" @error="handlePdfError" />
        </template>

        <template v-else>
          <div class="text-center">
            <q-icon name="error" color="negative" size="2em" />
            <p>Impossibile caricare il referto. URL non valido.</p>
          </div>
        </template>
      </q-card-section>
    </q-card>
  </q-dialog>

  <!-- Image Viewer Dialog -->
  <q-dialog
    v-if="isImageType(dataBlobUrl?.type as string)"
    ref="viewImageDialogRef"
    full-width>
    <q-card class="full-width">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Immagine Referto</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-card-section class="q-pa-none">
        <template v-if="dataBlobUrl?.url">
          <div class="image-container">
            <img
              :src="dataBlobUrl.url"
              :alt="dataBlobUrl.name"
              class="fit-image" />
          </div>
        </template>
      </q-card-section>
    </q-card>
  </q-dialog>
</template>
