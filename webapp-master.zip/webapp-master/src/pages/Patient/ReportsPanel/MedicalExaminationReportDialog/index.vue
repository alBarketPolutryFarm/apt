<script setup lang="ts">
import { computed, ref, watch, toRaw } from 'vue'
import DietDialog from '../../DietPanel/DietDialog'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import notify from 'src/helpers/notify'
import {
  MedicalExaminationReport,
  NewMedicalExaminationReport
} from 'src/api/patients/reports/models'
import {
  createPatientReport,
  editPatientReport
} from 'src/api/patients/reports'
import useMutation from 'src/api/useMutation'
import useQuery from 'src/api/useQuery'
import MonitoringPlanDialog from '../../MonitoringPlanPanel/MonitoringPlanDialog'
import TreatmentPlanDialog from '../../TreatmentPlanPanel/TreatmentPlanDialog'
import { getPatientCurrentDiet } from 'src/api/patients/diets'
import { DateTime } from 'luxon'
import { getPatientCurrentMonitoringPlan } from 'src/api/patients/monitoringPlans'
import { getPatientCurrentTreatmentPlan } from 'src/api/patients/treatmentsPlans'
import { createPatch } from 'rfc6902'
import _ from 'lodash'
import { FormMedicalExaminationReport } from 'src/api/patients/reports/models/MedicalExaminationReport'
import cleanObject from 'src/helpers/cleanObject'

const props = defineProps<{
  patientId: string
}>()

const emit = defineEmits<{
  (e: 'create'): void
  (e: 'edit'): void
}>()

const initialValue = (): FormMedicalExaminationReport => ({
  description: '',
  diagnosis: {},
  objectiveExamination: {
    abdomen: {},
    cardiovascularSystem: {},
    nervousSystem: {},
    detail: {},
    reproductiveSystem: {},
    respiratorySystem: {}
  }
})

const completeToNew = (
  r: MedicalExaminationReport
): FormMedicalExaminationReport => {
  return {
    description: r.description,
    diagnosis: r.diagnosis ?? {},
    objectiveExamination: {
      ...initialValue()['objectiveExamination'],
      ...r.objectiveExamination
    },
    diet: r.diet,
    treatmentPlan: r.treatmentPlan,
    monitoringPlan: r.monitoringPlan,
    diagnosticExaminations: r.diagnosticExaminations,
    remotely: r.remotely,
    conclusion: r.conclusion,
    plannedInterventions: r.plannedInterventions
  }
}

const isDialogOpen = ref<boolean>(false)
const data = ref<FormMedicalExaminationReport>(initialValue())
const isReadonly = ref(false)

const editReport = ref<MedicalExaminationReport>()
const isEdit = computed(() => editReport.value !== undefined)

const reset = () => {
  data.value = initialValue()
  editReport.value = undefined
}
reset()

defineExpose({
  show: (report?: MedicalExaminationReport) => {
    if (report) {
      data.value = completeToNew(_.cloneDeep(report))
      editReport.value = _.cloneDeep(report)
    } else reset()
    isDialogOpen.value = true
  }
})

const [create, createStatus] = useMutation(createPatientReport)

watch(createStatus, q => {
  if (!q.isSuccess) return
  notify('Referto inserito con successo', 'positive')
  isDialogOpen.value = false
  reset()
  emit('create')
})
watch(createStatus, q => {
  if (!q.isError) return
  notify('Impossibile creare il referto', 'warning')
})

const [edit, editStatus] = useMutation(editPatientReport)

watch(editStatus, q => {
  if (!q.isSuccess) return
  notify('Referto modifcato con successo', 'positive')
  isDialogOpen.value = false
  reset()
  emit('edit')
})
watch(editStatus, q => {
  if (!q.isError) return
  notify('Impossibile modificare il referto', 'warning')
})

const handleSubmit = () => {
  if (isEdit.value && editReport.value) {
    const newData = cleanObject(_.cloneDeep(toRaw(data.value)))
    const editData = cleanObject(
      completeToNew(_.cloneDeep(toRaw(editReport.value)))
    )
    const patch = createPatch(editData, newData)
    if (patch.length === 0) return
    edit(props.patientId, editReport.value._id, patch)
  } else
    create(props.patientId, {
      type: 'medicalExamination',
      ...data.value
    } as NewMedicalExaminationReport)
}

const dietQuery = useQuery(getPatientCurrentDiet, ref(props.patientId))
const monitoringPlanQuery = useQuery(
  getPatientCurrentMonitoringPlan,
  ref(props.patientId)
)
const treatmentPlanQuery = useQuery(
  getPatientCurrentTreatmentPlan,
  ref(props.patientId)
)
</script>

<template>
  <q-dialog v-model="isDialogOpen" no-backdrop-dismiss>
    <q-card style="width: 1000px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div v-if="isEdit" class="text-h6">Modifca referto visita medica</div>
        <div v-else class="text-h6">Crea referto visita medica</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-checkbox
            :model-value="data.remotely ?? false"
            label="In telemedicina"
            @update:model-value="v => (data.remotely = v)" />
          <q-input
            v-model="data.description"
            label="Descrizione referto"
            :rules="[
              val => (val && val.length > 0) || 'Descrizione richiesta'
            ]" />
          <q-expansion-item
            group="form"
            switch-toggle-side
            expand-separator
            label="Diagnosi">
            <q-card>
              <q-card-section>
                <q-input
                  v-model="data.diagnosis.pathology"
                  type="textarea"
                  label="Patologia prevalente" />
                <q-input
                  v-model="data.diagnosis.secondaryPathologies"
                  type="textarea"
                  label="Patologie concomitanti" />
              </q-card-section>
            </q-card>
          </q-expansion-item>

          <q-expansion-item
            group="form"
            switch-toggle-side
            expand-separator
            label="Esame obiettivo">
            <q-card>
              <q-card-section>
                <q-input
                  v-model="data.objectiveExamination.general"
                  type="textarea"
                  label="Osservazioni generali" />

                <q-expansion-item
                  group="objective"
                  switch-toggle-side
                  expand-separator
                  label="Particolare">
                  <q-input
                    v-model="data.objectiveExamination.detail.head"
                    type="textarea"
                    label="Capo" />
                  <q-input
                    v-model="data.objectiveExamination.detail.noseEars"
                    type="textarea"
                    label="Naso e orecchi" />
                  <q-input
                    v-model="data.objectiveExamination.detail.eyes"
                    type="textarea"
                    label="Occhi" />
                  <q-input
                    v-model="data.objectiveExamination.detail.monthThroat"
                    type="textarea"
                    label="Bocca e faringe" />
                  <q-input
                    v-model="data.objectiveExamination.detail.neck"
                    type="textarea"
                    label="Collo" />
                </q-expansion-item>

                <q-expansion-item
                  group="objective"
                  switch-toggle-side
                  expand-separator
                  label="Apparato respiratorio">
                  <q-input
                    v-model="
                      data.objectiveExamination.respiratorySystem.inspection
                    "
                    type="textarea"
                    label="Ispezione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.respiratorySystem.palpation
                    "
                    type="textarea"
                    label="Palpazione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.respiratorySystem.percussion
                    "
                    type="textarea"
                    label="Percussione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.respiratorySystem.auscultation
                    "
                    type="textarea"
                    label="Auscultazione" />
                </q-expansion-item>

                <q-expansion-item
                  group="objective"
                  switch-toggle-side
                  expand-separator
                  label="Apparato cardiovascolare">
                  <q-input
                    v-model="
                      data.objectiveExamination.cardiovascularSystem.inspection
                    "
                    type="textarea"
                    label="Ispezione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.cardiovascularSystem.palpation
                    "
                    type="textarea"
                    label="Palpazione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.cardiovascularSystem.percussion
                    "
                    type="textarea"
                    label="Percussione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.cardiovascularSystem
                        .auscultation
                    "
                    type="textarea"
                    label="Auscultazione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.cardiovascularSystem
                        .peripheralVessels
                    "
                    type="textarea"
                    label="Vasi periferici" />
                </q-expansion-item>

                <q-expansion-item
                  group="objective"
                  switch-toggle-side
                  expand-separator
                  label="Addome">
                  <q-input
                    v-model="data.objectiveExamination.abdomen.inspection"
                    type="textarea"
                    label="Ispezione" />
                  <q-input
                    v-model="data.objectiveExamination.abdomen.palpation"
                    type="textarea"
                    label="Palpazione" />
                  <q-input
                    v-model="data.objectiveExamination.abdomen.percussion"
                    type="textarea"
                    label="Percussione" />
                  <q-input
                    v-model="data.objectiveExamination.abdomen.auscultation"
                    type="textarea"
                    label="Auscultazione" />
                </q-expansion-item>

                <q-expansion-item
                  group="objective"
                  switch-toggle-side
                  expand-separator
                  label="Apparato genitale">
                  <q-input
                    v-model="
                      data.objectiveExamination.reproductiveSystem.inspection
                    "
                    type="textarea"
                    label="Ispezione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.reproductiveSystem.palpation
                    "
                    type="textarea"
                    label="Palpazione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.reproductiveSystem.percussion
                    "
                    type="textarea"
                    label="Percussione" />
                  <q-input
                    v-model="
                      data.objectiveExamination.reproductiveSystem.auscultation
                    "
                    type="textarea"
                    label="Auscultazione" />
                </q-expansion-item>

                <q-expansion-item
                  group="objective"
                  switch-toggle-side
                  expand-separator
                  label="Sistema nervoso">
                  <q-input
                    v-model="data.objectiveExamination.nervousSystem.reflexes"
                    type="textarea"
                    label="Riflessi" />
                  <q-input
                    v-model="data.objectiveExamination.nervousSystem.motility"
                    type="textarea"
                    label="Motilità" />
                  <q-input
                    v-model="
                      data.objectiveExamination.nervousSystem.sensitivity
                    "
                    type="textarea"
                    label="Sensibilità" />
                  <q-input
                    v-model="data.objectiveExamination.nervousSystem.gait"
                    type="textarea"
                    label="Andatura" />
                </q-expansion-item>

                <q-input
                  v-model="data.objectiveExamination.other"
                  type="textarea"
                  label="Altre osservazioni" />
              </q-card-section>
            </q-card>
          </q-expansion-item>

          <q-expansion-item
            group="form"
            switch-toggle-side
            expand-separator
            label="Dieta"
            :caption="
              data.diet !== undefined
                ? '(è stata creata una nuova dieta)'
                : undefined
            ">
            <q-card>
              <q-card-section>
                <p v-if="dietQuery.isSuccess && dietQuery.data !== undefined">
                  È attualmente presente una dieta emessa in data
                  <b>
                    {{
                      dietQuery.data.createdAt.toLocaleString(
                        DateTime.DATETIME_MED
                      )
                    }}</b
                  >
                </p>
                <q-btn-group>
                  <q-btn
                    v-if="dietQuery.isSuccess && dietQuery.data !== undefined"
                    label="Visualizza dieta attuale"
                    icon="visibility"
                    @click="$refs.dietDialog.show(dietQuery.data)" />
                  <q-btn
                    v-if="data.diet === undefined"
                    label="Crea nuova dieta"
                    icon="add"
                    @click="$refs.dietDialog.show()" />
                  <q-btn
                    v-else
                    label="Rimuovi nuova dieta"
                    icon="remove"
                    @click="data.diet = undefined" />
                </q-btn-group>
              </q-card-section>
            </q-card>
          </q-expansion-item>

          <q-expansion-item
            group="form"
            switch-toggle-side
            expand-separator
            label="Piano di monitoraggio"
            :caption="
              data.monitoringPlan !== undefined
                ? '(è stata creato un nuovo piano di monitoraggio)'
                : undefined
            ">
            <q-card>
              <q-card-section>
                <p
                  v-if="
                    monitoringPlanQuery.isSuccess &&
                    monitoringPlanQuery.data !== undefined
                  ">
                  È attualmente presente un piano di monitoraggio emessa in data
                  <b>
                    {{
                      monitoringPlanQuery.data.createdAt.toLocaleString(
                        DateTime.DATETIME_MED
                      )
                    }}</b
                  >
                </p>
                <q-btn-group>
                  <q-btn
                    v-if="
                      monitoringPlanQuery.isSuccess &&
                      monitoringPlanQuery.data !== undefined
                    "
                    label="Visualizza piano di monitoraggio attuale"
                    icon="visibility"
                    @click="
                      $refs.monitoringPlanDialog.show(monitoringPlanQuery.data)
                    " />
                  <q-btn
                    v-if="data.monitoringPlan === undefined"
                    label="Crea nuova piano di monitoraggio"
                    icon="add"
                    @click="$refs.monitoringPlanDialog.show()" />
                  <q-btn
                    v-else
                    label="Rimuovi nuovo piano di monitoraggio"
                    icon="remove"
                    @click="data.monitoringPlan = undefined" />
                </q-btn-group>
              </q-card-section>
            </q-card>
          </q-expansion-item>

          <q-expansion-item
            group="form"
            switch-toggle-side
            expand-separator
            label="Piano di trattamento"
            :caption="
              data.treatmentPlan !== undefined
                ? '(è stata creata una nuovo piano di trattamento)'
                : undefined
            ">
            <q-card>
              <q-card-section>
                <p
                  v-if="
                    treatmentPlanQuery.isSuccess &&
                    treatmentPlanQuery.data !== undefined
                  ">
                  È attualmente presente un piano di trattamento emesso in data
                  <b>
                    {{
                      treatmentPlanQuery.data.createdAt.toLocaleString(
                        DateTime.DATETIME_MED
                      )
                    }}</b
                  >
                </p>
                <q-btn-group>
                  <q-btn
                    v-if="
                      treatmentPlanQuery.isSuccess &&
                      treatmentPlanQuery.data !== undefined
                    "
                    label="Visualizza piano di trattamento attuale"
                    icon="visibility"
                    @click="
                      $refs.treatmentPlanDialog.show(treatmentPlanQuery.data)
                    " />
                  <q-btn
                    v-if="data.treatmentPlan === undefined"
                    label="Crea nuovo piano di trattamento"
                    icon="add"
                    @click="$refs.treatmentPlanDialog.show()" />
                  <q-btn
                    v-else
                    label="Rimuovi nuovo piano di trattamento"
                    icon="remove"
                    @click="data.treatmentPlan = undefined" />
                </q-btn-group>
              </q-card-section>
            </q-card>
          </q-expansion-item>

          <q-input
            v-model="data.diagnosticExaminations"
            type="textarea"
            label="Esami diagnostici" />

          <q-input
            v-model="data.conclusion"
            type="textarea"
            label="Conclusioni" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn
            v-if="!isReadonly && !isEdit"
            :loading="createStatus.isLoading"
            flat
            label="Crea"
            type="submit" />
          <q-btn
            v-if="!isReadonly && isEdit"
            :loading="editStatus.isLoading"
            flat
            label="Modifica"
            type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>

  <diet-dialog
    ref="dietDialog"
    :auto-create="false"
    :patient-id="props.patientId"
    @created="d => (data.diet = d)" />
  <monitoring-plan-dialog
    ref="monitoringPlanDialog"
    :auto-create="false"
    :patient-id="props.patientId"
    @created="d => (data.monitoringPlan = d)" />
  <treatment-plan-dialog
    ref="treatmentPlanDialog"
    :auto-create="false"
    :patient-id="props.patientId"
    @created="d => (data.treatmentPlan = d)" />
</template>
