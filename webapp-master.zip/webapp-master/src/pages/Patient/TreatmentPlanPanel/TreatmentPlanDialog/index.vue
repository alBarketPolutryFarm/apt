<script setup lang="ts">
import { QForm, uid } from 'quasar'
import { computed, ref, watch } from 'vue'
import {
  NewTreatmentPeriodicSchedule,
  NewTreatmentPlan,
  TreatmentPeriodicSchedule,
  TreatmentPlan,
  TreatmentSchedule
} from 'src/api/patients/treatmentsPlans/models'
import notify from 'src/helpers/notify'
import { DateTime, Duration, Info } from 'luxon'
import { createPatientTreatmentPlan } from 'src/api/patients/treatmentsPlans'
import _ from 'lodash'
import QSelectReport from 'src/components/QSelectReport'
import AddScheduleDialog from './AddScheduleDialog'
import AddPeriodicScheduleDialog from './AddPeriodicScheduleDialog'
import { Drug } from 'src/api/drugs/models'
import { getDrugs } from 'src/api/drugs'

const WEEKDAYS = Info.weekdays()

const props = defineProps<{
  patientId: string
  treatmentPlan?: string
  autoCreate?: boolean
  readonly?: boolean
}>()

const getInitialData = (): Partial<TreatmentPlan> => ({
  treatments: [{ _id: uid(), description: '', schedule: [] }]
})

const emit = defineEmits<{
  (e: 'created', treatmentPlan: NewTreatmentPlan): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<Partial<TreatmentPlan>>(getInitialData())
const currentTreatment = ref<string>()
const isReadonly = ref(false)
const form = ref<QForm>()
const drugsFiltered = ref<Drug[]>([])
const scheduleModes = [
  {
    label: 'Giornaliera',
    value: 'daily'
  },
  {
    label: 'Periodica',
    value: 'periodic'
  }
]
const selectedScheduleMode = ref<string>(
  Array.isArray(
    data.value.treatments?.find(t => t._id === currentTreatment.value)?.schedule
  )
    ? 'daily'
    : 'periodic'
)

watch(
  currentTreatment,
  () => {
    const treatment = data.value.treatments?.find(
      t => t._id === currentTreatment.value
    )
    if (treatment === undefined) return

    selectedScheduleMode.value = Array.isArray(treatment.schedule)
      ? 'daily'
      : 'periodic'
  },
  { immediate: true }
)

watch(
  () => data.value.treatments,
  () => {
    if (data.value.treatments?.some(t => t._id === currentTreatment.value))
      return
    currentTreatment.value = data.value.treatments?.at(0)?._id
  }
)

const areTreatmentsReady = computed<Record<string, boolean>>(() =>
  Object.fromEntries(
    data.value.treatments?.map(t => [
      t._id,
      !!t.description &&
        (Array.isArray(t.schedule)
          ? t.schedule.length > 0
          : !!(t.schedule?.period && t.schedule.firstOccurence))
    ]) ?? []
  )
)

const isReady = computed(() =>
  Object.values(areTreatmentsReady.value).every(r => r)
)

const addTreatment = () => {
  const id = uid()
  data.value.treatments = [
    ...(data.value?.treatments ?? []),
    { _id: id, description: '', schedule: [] }
  ]
  currentTreatment.value = id
}

const removeTreatment = (id: string) => {
  data.value.treatments = data.value.treatments?.filter(t => t._id !== id)
}

const removeScheduleEntry = (id: string) => {
  const treatment = data.value.treatments?.find(
    t => t._id === currentTreatment.value
  )
  if (treatment === undefined) return

  data.value.treatments = data.value.treatments?.map(t => {
    if (t._id !== treatment._id) return t
    return {
      ...t,
      schedule: Array.isArray(t.schedule)
        ? t.schedule.filter(s => s._id !== id)
        : undefined
    }
  })
}

const createFrom = () => {
  data.value = { treatments: data.value.treatments }
  form.value?.reset()
  isReadonly.value = false
}

const reset = () => {
  data.value = getInitialData()
  currentTreatment.value = undefined
  isReadonly.value = false
}

const createTreatmentPlan = () => {
  if (!isReady.value) return

  const _data = _.cloneDeep(data.value as NewTreatmentPlan)

  if (props.autoCreate === false) {
    isDialogOpen.value = false
    reset()
    return emit('created', _data)
  }

  createPatientTreatmentPlan(props.patientId, _data)
    .then(() => {
      notify('Piano di trattamento creato con successo', 'positive')
      isDialogOpen.value = false
      reset()
      emit('created', _data)
    })
    .catch(() => {
      notify('Impossibile creare il piano di trattamento', 'warning')
    })
}

defineExpose({
  show: (plan?: TreatmentPlan) => {
    reset()
    if (plan !== undefined) data.value = plan
    isReadonly.value = plan !== undefined
    isDialogOpen.value = true
  }
})

const filterDrugs = (val: string, update: any, abort: any) => {
  if (val.trim() === '' || val.length < 2) {
    update(() => {
      drugsFiltered.value = []
    })
    return
  }

  getDrugs(`*${val.trim()}*`)
    .then(drugs => {
      update(() => {
        drugsFiltered.value = drugs.data
      })
    })
    .catch(() => {
      abort()
    })
}

const selectDrug = (drug?: Drug | string | null) => {
  const treatment = data.value.treatments?.find(
    t => t._id === currentTreatment.value
  )
  if (treatment === undefined) return

  if (typeof drug === 'string') {
    treatment.description = drug
    return
  }
  if (!drug) {
    treatment.description = ''
    treatment.activeIngredient = ''
    return
  }
  treatment.description = drug.description
  treatment.activeIngredient = drug.activeIngredient
}

const getDrugDisplay = (drug: Drug | string) => {
  if (typeof drug === 'string') return drug
  return `${drug.description} - ${drug.activeIngredient}`
}

const addScheduleDialog = ref<AddScheduleDialog>()
const addPeriodicScheduleDialog = ref<AddPeriodicScheduleDialog>()

const handleDailyScheduleCreateted = (schedule: TreatmentSchedule[]) => {
  const treatment = data.value.treatments?.find(
    t => t._id === currentTreatment.value
  )
  if (treatment === undefined) return

  if (!Array.isArray(treatment.schedule)) treatment.schedule = []

  const scheduleEntries = [...(treatment.schedule ?? []), ...schedule]

  scheduleEntries.sort((s1: TreatmentSchedule, s2: TreatmentSchedule) => {
    if (s1.weekday == s2.weekday) return s1.time > s2.time ? 1 : -1
    return s1.weekday > s2.weekday ? 1 : -1
  })

  treatment.schedule = scheduleEntries
}

const handlePeriodicScheduleCreateted = (
  schedule: TreatmentPeriodicSchedule
) => {
  const treatment = data.value.treatments?.find(
    t => t._id === currentTreatment.value
  )
  if (treatment === undefined) return

  treatment.schedule = schedule
}
</script>

<template>
  <q-dialog v-model="isDialogOpen" @before-hide="reset()">
    <q-card style="width: 700px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div v-if="!isReadonly" class="text-h6">Nuova piano terapeutico</div>
        <div v-else class="text-h6">Piano terapeutico</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form ref="form" greedy @submit="createTreatmentPlan">
        <q-card-section>
          <q-select-report
            v-if="props.autoCreate"
            v-model="data.reportId"
            :readonly="isReadonly"
            class="q-mb-md"
            :rules="['required']"
            :patient-id="props.patientId"
            label="Referto di riferimento" />

          <q-tabs
            v-model="currentTreatment"
            dense
            class="text-grey"
            active-color="primary"
            indicator-color="primary"
            align="left"
            narrow-indicator>
            <q-tab v-for="t in data.treatments" :key="t._id" :name="t._id">
              <q-badge
                v-if="!areTreatmentsReady?.[t._id] && !isReadonly"
                color="orange"
                floating
                rounded></q-badge>
              <div class="row no-wrap justify-center items-center">
                {{ t.description || 'nuova terapia' }}
                <q-btn
                  v-if="!isReadonly"
                  flat
                  round
                  size="sm"
                  icon="delete"
                  @click.stop="removeTreatment(t._id)" />
              </div>
            </q-tab>
            <q-tab v-if="!isReadonly" icon="add" @click="addTreatment()">
            </q-tab>
          </q-tabs>
          <q-separator />

          <q-tab-panels v-model="currentTreatment" animated keep-alive>
            <q-tab-panel
              v-for="t in data.treatments"
              :key="t._id"
              :name="t._id"
              style="max-height: 50vh">
              <q-select
                :model-value="t.description"
                label="Nome commerciale"
                outlined
                use-input
                hide-selected
                clearable
                fill-input
                hide-dropdown-icon
                :options="drugsFiltered"
                :option-label="getDrugDisplay"
                option-value="description"
                class="q-my-sm q-px-sm col-12"
                :readonly="isReadonly"
                :rules="[v => !!v || 'valore richiesto']"
                @filter="filterDrugs"
                @update:model-value="selectDrug"
                @input-value="selectDrug">
                <template #no-option>
                  <q-item>
                    <q-item-section>
                      <q-item-label class="text-grey"
                        >Nessun risultato</q-item-label
                      >
                    </q-item-section>
                  </q-item>
                </template>
              </q-select>
              <q-input
                v-model="t.activeIngredient"
                label="Principio attivo"
                outlined
                class="q-my-sm q-px-sm col-12"
                :readonly="isReadonly" />
              <q-input
                v-model="t.dosage"
                label="Dosaggio"
                outlined
                class="q-my-sm q-px-sm col-12"
                :readonly="isReadonly" />
              <q-input
                v-model="t.administrationRoute"
                label="Via di somministrazione"
                outlined
                class="q-my-sm q-px-sm col-12"
                :readonly="isReadonly" />
              <q-input
                v-model="t.notes"
                label="Note"
                outlined
                class="q-my-sm q-px-sm col-12"
                :readonly="isReadonly" />

              <div class="q-mt-md">
                <q-card-section class="column items-start q-pb-none q-mb-sm">
                  <div class="text-h6 q-mb-sm">Schedule</div>

                  <div class="row">
                    <q-btn-toggle
                      v-model="selectedScheduleMode"
                      :disable="isReadonly"
                      :options="scheduleModes"
                      toggle-color="primary"
                      @update:model-value="
                        value => {
                          if (value === 'daily') {
                            t.schedule = []
                            return
                          }
                          t.schedule = undefined
                        }
                      " />
                    <q-btn
                      v-if="
                        !isReadonly &&
                        (selectedScheduleMode === 'daily' ||
                          !('period' in (t.schedule ?? {})))
                      "
                      class="q-mx-sm"
                      icon="add"
                      round
                      flat
                      @click="
                        () => {
                          if (selectedScheduleMode === 'daily') {
                            addScheduleDialog.show()
                            return
                          }
                          addPeriodicScheduleDialog.show()
                        }
                      " />
                  </div>
                </q-card-section>
                <q-chip
                  v-if="!Array.isArray(t.schedule) && t.schedule"
                  :key="t.schedule._id"
                  :removable="!isReadonly"
                  color="primary"
                  text-color="white"
                  icon="alarm"
                  @remove="removeScheduleEntry(t.schedule._id)">
                  a partire dal
                  {{
                    new Date(t.schedule.firstOccurence).toLocaleString(
                      undefined,
                      {
                        year: 'numeric',
                        month: 'numeric',
                        day: 'numeric',
                        hour: 'numeric',
                        minute: 'numeric'
                      }
                    )
                  }}
                  ogni
                  {{
                    Duration.fromISO(t.schedule.period).as('days') > 1
                      ? Duration.fromISO(t.schedule.period).toFormat('d giorni')
                      : 'giorno'
                  }}
                  fino al
                  {{
                    new Date(t.schedule.endPeriod).toLocaleString(undefined, {
                      year: 'numeric',
                      month: 'numeric',
                      day: 'numeric'
                    })
                  }}
                </q-chip>
                <q-chip
                  v-for="s in t.schedule ?? []"
                  v-else-if="Array.isArray(t.schedule)"
                  :key="s._id"
                  :removable="!isReadonly"
                  color="primary"
                  text-color="white"
                  icon="alarm"
                  @remove="removeScheduleEntry(s._id)">
                  {{ WEEKDAYS[s.weekday] }}
                  alle
                  {{ s.time.toLocaleString(DateTime.TIME_SIMPLE) }}
                </q-chip>
              </div>
            </q-tab-panel>
          </q-tab-panels>
        </q-card-section>

        <q-card-actions
          v-if="!props.readonly"
          align="right"
          class="text-primary">
          <q-btn
            v-if="isReadonly"
            flat
            label="Crea piano a partire da questo"
            @click="createFrom()" />
          <q-btn v-if="!isReadonly" flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>

  <AddScheduleDialog
    ref="addScheduleDialog"
    @created="handleDailyScheduleCreateted" />
  <AddPeriodicScheduleDialog
    ref="addPeriodicScheduleDialog"
    @created="handlePeriodicScheduleCreateted" />
</template>
