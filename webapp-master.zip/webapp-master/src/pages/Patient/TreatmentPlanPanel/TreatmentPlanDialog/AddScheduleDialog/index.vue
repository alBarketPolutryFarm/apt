<script setup lang="ts">
import { QForm, uid } from 'quasar'
import { DateTime, Info } from 'luxon'
import { ref } from 'vue'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import {
  TreatmentSchedule,
  Weekday
} from 'src/api/patients/treatmentsPlans/models'

const WEEKDAYS = Info.weekdays()

const emit = defineEmits<{
  (e: 'created', schedule: TreatmentSchedule[]): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<RecursivePartial<{ time: DateTime; weekday: Weekday | 7 }>>({})

const handleSubmit = () => {
  if (data.value.weekday !== 7)
    emit('created', [{ ...data.value, _id: uid() } as TreatmentSchedule])
  else
    emit(
      'created',
      [...Array(7).keys()].map(w => ({
        ...data.value,
        _id: uid(),
        weekday: w
      })) as TreatmentSchedule[]
    )
  isDialogOpen.value = false
}

const reset = () => (data.value = {})

defineExpose({
  show: () => (isDialogOpen.value = true)
})
</script>

<template>
  <q-dialog v-model="isDialogOpen" @before-hide="reset">
    <q-card>
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Aggiungi orario</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-select
            v-model="data.weekday"
            :options="[...Array(8).keys()]"
            :option-label="i => [...WEEKDAYS, 'Ogni giorno'][i]"
            label="Giorno"
            outlined
            class="q-my-sm q-px-sm col-12"
            :rules="[v => v !== undefined || 'valore richiesto']" />
          <q-input
            v-model="data.time"
            outlined
            mask="##:##"
            label="alle ore  "
            class="q-my-sm q-px-sm col-12"
            :rules="[v => DateTime.fromFormat(v ?? '', 'HH:mm').isValid]">
            <template #append>
              <q-icon name="event" class="cursor-pointer">
                <q-popup-proxy
                  cover
                  transition-show="scale"
                  transition-hide="scale">
                  <q-time v-model="data.time" mask="HH:mm" format24h>
                    <div class="row items-center justify-end">
                      <q-btn v-close-popup label="Ok" color="primary" flat />
                    </div>
                  </q-time>
                </q-popup-proxy>
              </q-icon>
            </template>
          </q-input>
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
