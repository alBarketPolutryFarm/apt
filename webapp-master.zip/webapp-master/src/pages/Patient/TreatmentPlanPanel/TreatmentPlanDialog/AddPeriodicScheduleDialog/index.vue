<script setup lang="ts">
import { QForm, uid } from 'quasar'
import { DateTime, Duration, Info } from 'luxon'
import { ref, watch } from 'vue'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import {
  NewTreatmentPeriodicSchedule,
  TreatmentPeriodicSchedule
} from 'src/api/patients/treatmentsPlans/models'

const emit = defineEmits<{
  (e: 'created', schedule: TreatmentPeriodicSchedule): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<RecursivePartial<NewTreatmentPeriodicSchedule>>({
  period: 1,
  firstOccurence: undefined,
  endPeriod: undefined
})

const handleSubmit = () => {
  if (data.value.firstOccurence === undefined) return
  if (data.value.period === undefined) return
  if (data.value.endPeriod === undefined) return
  emit('created', {
    firstOccurence: DateTime.fromFormat(
      data.value.firstOccurence,
      'yyyy-MM-dd HH:mm'
    )
      .toUTC()
      .toISO(),
    period: Duration.fromObject({ days: data.value.period }).toISO(),
    endPeriod: data.value.endPeriod,
    _id: uid()
  })
  isDialogOpen.value = false
}

const reset = () => (data.value = {})

watch(
  data,
  () => {
    if (data.value.firstOccurence === undefined) return
    if (data.value.endPeriod !== undefined) return
    data.value.endPeriod = DateTime.fromFormat(
      data.value.firstOccurence,
      'yyyy-MM-dd HH:mm'
    )
      .plus({ years: 1 })
      .toFormat('yyyy-MM-dd')
  },

  { deep: true }
)

defineExpose({
  show: () => (isDialogOpen.value = true)
})
</script>

<template>
  <q-dialog v-model="isDialogOpen" @before-hide="reset">
    <q-card>
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Aggiungi periodo</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-input
            v-model.number="data.period"
            type="number"
            min="1"
            outlined
            class="q-my-sm q-px-sm col-12"
            label="Periodo (in giorni)"
            :rules="[v => v !== undefined || 'valore richiesto']" />
          <q-input
            v-model="data.firstOccurence"
            outlined
            label="Giorno di inizio e orario"
            class="q-my-sm q-px-sm col-12"
            :rules="[
              v => !!v || 'valore richiesto',
              v =>
                Date.parse(v) >= DateTime.now().toMillis() ||
                'date passate non ammesse'
            ]">
            <template #prepend>
              <q-icon name="event" class="cursor-pointer">
                <q-popup-proxy
                  cover
                  transition-show="scale"
                  transition-hide="scale">
                  <q-date
                    v-model="data.firstOccurence"
                    format24h
                    mask="YYYY-MM-DD HH:mm"
                    :options="
                      day =>
                        Date.parse(day) >=
                        DateTime.now().startOf('day').toMillis()
                    ">
                    <div class="row items-center justify-end">
                      <q-btn v-close-popup label="Ok" color="primary" flat />
                    </div>
                  </q-date>
                </q-popup-proxy>
              </q-icon>
            </template>
            <template #append>
              <q-icon name="access_time" class="cursor-pointer">
                <q-popup-proxy
                  cover
                  transition-show="scale"
                  transition-hide="scale">
                  <q-time
                    v-model="data.firstOccurence"
                    format24h
                    mask="YYYY-MM-DD HH:mm">
                    <div class="row items-center justify-end">
                      <q-btn v-close-popup label="Close" color="primary" flat />
                    </div>
                  </q-time>
                </q-popup-proxy>
              </q-icon>
            </template>
          </q-input>
          <q-input
            v-model="data.endPeriod"
            outlined
            label="Giorno di fine"
            class="q-my-sm q-px-sm col-12"
            :rules="[
              v => !!v || 'valore richiesto',
              v =>
                Date.parse(v) >= DateTime.now().toMillis() ||
                'date passate non ammesse'
            ]">
            <template #append>
              <q-icon name="event" class="cursor-pointer">
                <q-popup-proxy
                  cover
                  transition-show="scale"
                  transition-hide="scale">
                  <q-date
                    v-model="data.endPeriod"
                    format24h
                    mask="YYYY-MM-DD"
                    :options="
                      day =>
                        Date.parse(day) >=
                        DateTime.now().startOf('day').toMillis()
                    ">
                    <div class="row items-center justify-end">
                      <q-btn v-close-popup label="Ok" color="primary" flat />
                    </div>
                  </q-date>
                </q-popup-proxy>
              </q-icon>
            </template>
          </q-input>
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
