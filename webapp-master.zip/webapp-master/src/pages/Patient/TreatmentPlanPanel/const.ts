import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { TreatmentPlan } from 'src/api/patients/treatmentsPlans/models'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'effectiveDate',
    label: 'Decorrenza dal',
    align: 'left',
    field: (row: TreatmentPlan) => row.effectiveDate,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'revocationDate',
    label: 'Revocato il',
    align: 'left',
    field: (row: TreatmentPlan) => row.revocation?.date,
    format: (v?: DateTime) => v?.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'report',
    label: 'Referto di riferimento',
    align: 'left',
    field: (row: TreatmentPlan) => row.reportId,
    sortable: true
  },
  {
    name: 'actions',
    label: '',
    align: 'center',
    field: (row: TreatmentPlan) => row
  }
]
