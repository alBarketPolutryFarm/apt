<script setup lang="ts">
import { ComponentPublicInstance, computed, ref, watch } from 'vue'
import useQuery from 'src/api/useQuery'
import { COLUMNS_SIDE_EFFECTS, DEFAULT_CHART_OPTIONS } from './consts'
import { DateTime, Interval } from 'luxon'
import groupByDate from 'src/helpers/groupByDate'
import { QueryDate } from 'src/api/models'
import ApexChart from 'vue3-apexcharts'
import {
  getPatientTreatmentPlanSchedule,
  getPatientTreatmentSideEffects
} from 'src/api/patients/treatmentsPlans'

const props = defineProps<{ patientId: string }>()

const chart = ref<ComponentPublicInstance<typeof ApexChart>>()

const dateRange = ref<Required<QueryDate>>({
  startDate: DateTime.now().minus({ days: 30 }),
  endDate: DateTime.now()
})

const query = useQuery(
  getPatientTreatmentPlanSchedule,
  ref(props.patientId),
  dateRange
)

const interval = computed(() =>
  Interval.fromDateTimes(dateRange.value.startDate, dateRange.value.endDate)
)

const updateChart = (series: unknown) => {
  chart.value?.updateOptions(
    {
      series,
      xaxis: {
        min: dateRange.value.startDate.toMillis(),
        max: dateRange.value.endDate.toMillis()
      }
    },
    true,
    false,
    false
  )
}

watch(query, q => {
  if (!q.isSuccess || q.data === undefined || q.data.length === 0)
    return updateChart([{ data: [[]] }])

  const data = groupByDate(
    q.data,
    d => d.at,
    'day',
    interval.value,
    'ascendant'
  )
    .map(d => ({
      date: d.interval.start,
      value:
        d.items.length !== 0
          ? (d.items
              .map(t => (t.intake?.isTaken ? 1 : 0))
              .reduce((a: number, b: number) => a + b, 0) /
              d.items.length) *
            100
          : 100
    }))
    .map(v => [v.date.toMillis(), v.value])

  updateChart([{ data: data }])
})

const querySideEffects = useQuery(
  getPatientTreatmentSideEffects,
  ref(props.patientId),
  dateRange
)
</script>

<template>
  <apex-chart
    ref="chart"
    :options="DEFAULT_CHART_OPTIONS"
    :series="[{ data: [[]] }]"
    :height="400" />

  <q-table
    :rows="querySideEffects.data"
    :columns="COLUMNS_SIDE_EFFECTS"
    row-key="_id"
    class="row"
    :loading="querySideEffects.isLoading">
    <template #no-data>
      <div class="full-width row flex-center text-primary q-gutter-sm">
        <div v-if="query.isError">
          <q-icon size="2em" name="sentiment_dissatisfied" />
          Impossibile caricare gli effetti collaterali
        </div>
        <div v-else-if="query.isSuccess">
          Nessun effetto collaterale presente
        </div>
      </div>
    </template>
  </q-table>
</template>
