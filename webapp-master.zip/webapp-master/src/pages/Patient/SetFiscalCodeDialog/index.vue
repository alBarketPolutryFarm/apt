<script setup lang="ts">
import { ref } from 'vue'
import { updatePatient } from 'src/api/patients'
import notify from 'src/helpers/notify'
import { Validator } from '@marketto/codice-fiscale-utils'

const props = defineProps<{
  patientId: string
}>()

const emit = defineEmits<{
  (e: 'change'): void
}>()

const isDialogOpen = ref<boolean>(false)

defineExpose({
  show: () => (isDialogOpen.value = true)
})

const fiscalCode = ref<string>()

const handleSubmit = () => {
  updatePatient(props.patientId, [
    { op: 'add', path: '/fiscalCode', value: fiscalCode.value }
  ])
    .then(() => {
      notify('Codice fiscale impostato correttamente')
      isDialogOpen.value = false
      emit('change')
    })
    .catch(e => {
      if (e.response.status === 409)
        return notify(
          'Il codice fiscale è già stato attribuito ad un altro paziente',
          'negative'
        )
      notify('Impossibile salvare il codice fiscale', 'negative')
    })
}
</script>

<template>
  <q-dialog v-model="isDialogOpen" @hide="fiscalCode = undefined">
    <q-card style="width: 80vw; max-width: 600px">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Aggiungi codice fiscale</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <p>
            Questo paziente non presenta alcun codice fiscale, questo impedirà
            l'accesso ad alcune funzionalità del servizio. È consigliabile
            inserire un codice fiscala prima di procedere con altre operazioni
          </p>
          <p class="bg-amber q-pa-sm">
            Attenzione: Il codice fiscale <b>NON</b> sarà più modificabile in
            seguito a questa operazione
          </p>
          <q-input
            class="full-width"
            maxlength="16"
            label="Codice fiscale"
            :model-value="fiscalCode"
            :rules="[
              v => !!v || 'Codice fiscale richiesto',
              v =>
                Validator.codiceFiscale(v).valid || 'Codice fiscale non valido'
            ]"
            @update:model-value="v => (fiscalCode = v.toUpperCase())" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn flat label="Imposta codice fiscale" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
