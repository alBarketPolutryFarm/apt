<script setup lang="ts">
import { ref, watch } from 'vue'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import notify from 'src/helpers/notify'
import { NewPermission } from 'src/api/patients/permissions/models'
import { createPatientPermission } from 'src/api/patients/permissions'
import { getNurses } from 'src/api/nurses'
import { getOperators } from 'src/api/operators'
import useQuery from 'src/api/useQuery'
import { getDoctors } from 'src/api/doctors'
import QSelectUser from 'src/components/QSelectUser'

const props = defineProps<{
  patientId: string
}>()

const emit = defineEmits<{
  (e: 'created'): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<RecursivePartial<NewPermission>>({})
const file = ref<File>()
const isReadonly = ref(false)

const queryNurses = useQuery(getNurses)
const queryDoctors = useQuery(getDoctors)
const queryOperators = useQuery(getOperators)

watch(queryNurses, q => {
  if (!q.isError) return
  notify('Impossibile caricare la lista degli infermieri', 'negative')
})
watch(queryDoctors, q => {
  if (!q.isError) return
  notify('Impossibile caricare la lista dei dottori', 'negative')
})
watch(queryOperators, q => {
  if (!q.isError) return
  notify('Impossibile caricare la lista degli operatori', 'negative')
})

const handleSubmit = () => {
  if (data.value.targetId === undefined) return

  createPatientPermission(props.patientId, data.value as NewPermission)
    .then(() => {
      notify('Permesso creato con successo', 'positive')
      isDialogOpen.value = false
      data.value = {}
      file.value = undefined
      emit('created')
    })
    .catch(() => notify('Impossibile creare il permesso', 'warning'))
}

defineExpose({
  show: () => (isDialogOpen.value = true)
})
</script>

<template>
  <q-dialog v-model="isDialogOpen">
    <q-card style="width: 400px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Aggiungi permessi</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-select-user
            v-model="data.targetId"
            label="Operatore"
            :rules="['required']"
            :user-type="['doctor', 'nurse', 'operator', 'caregiver']" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn v-if="!isReadonly" flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
