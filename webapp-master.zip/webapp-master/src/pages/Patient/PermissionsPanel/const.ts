import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { Permission } from 'src/api/patients/permissions/models'

export const COLUMNS: Readonly<QTableProps['columns']> = [
  {
    name: 'target',
    label: 'Nome',
    align: 'left',
    field: (row: Permission) => row.targetId,
    sortable: true
  },
  {
    name: 'effectiveDate',
    label: 'Decorrenza dal',
    align: 'left',
    field: (row: Permission) => row.effectiveDate,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'expirationDate',
    label: 'Scade il',
    align: 'left',
    field: (row: Permission) => row.expirationDate,
    format: (v?: DateTime) => v?.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'createAt',
    label: 'Creato il',
    align: 'left',
    field: (row: Permission) => row.createdAt,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'createBy',
    label: 'Creato da',
    align: 'left',
    field: (row: Permission) => row.createdBy,
    sortable: true
  },
  {
    name: 'actions',
    label: '',
    align: 'center',
    field: (row: Permission) => row
  }
] as const
