<script setup lang="ts">
import { ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import { COLUMNS } from './const'
import {
  getPatientCurrentPermissions,
  getPatientPermissions,
  revokePatientPermission
} from 'src/api/patients/permissions'
import AddPermissionDialog from './AddPermissionDialog'
import useQuery from 'src/api/useQuery'
import useLogin from 'src/helpers/useLogin'
import UserFetcher from 'src/components/UserFetcher'
import { UserStrings } from 'src/const/User'

const props = defineProps<{ patientId: string }>()

const login = useLogin()

const query = useQuery(getPatientCurrentPermissions, ref(props.patientId))

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista dei permessi attivi', 'negative')
})

const queryHistory = useQuery(getPatientPermissions, ref(props.patientId))

watch(
  () => queryHistory,
  q => {
    if (!q.isError) return
    notify('Impossibile recuperare la lista dei permessi', 'negative')
  }
)

const refetchPermissions = () => {
  query.refetch()
  queryHistory.refetch()
}

const revoke = (targetId: string) => {
  revokePatientPermission(props.patientId, {
    targetId
  })
    .then(() => {
      refetchPermissions()
      notify('Permesso revocato', 'positive')
    })
    .catch(() => notify('Impossibile cancellare il permesso', 'negative'))
}
</script>

<template>
  <div>
    <div class="row no-wrap justify-between q-pb-md">
      <div class="text-h6">Permessi</div>

      <div class="row no-wrap justify-between q-pb-md" style="gap: 10px">
        <q-btn
          v-if="
            login.user?.type === 'admin' || login.user?.type === 'superadmin'
          "
          icon="add"
          color="primary"
          @click="$refs.dialog.show()" />
      </div>
    </div>

    <q-table
      :rows="query.data"
      :columns="COLUMNS"
      row-key="name"
      class="row"
      :loading="query.isLoading">
      <template #body-cell-target="{ value }">
        <q-td>
          <user-fetcher
            :user-id="value"
            :visualize="(user, d) => `${d} (${UserStrings[user.type]})`" />
        </q-td>
      </template>

      <template #body-cell-createBy="{ value }">
        <q-td>
          <user-fetcher :user-id="value" />
        </q-td>
      </template>

      <template #body-cell-actions="p">
        <q-td>
          <q-btn
            v-if="
              login.user?.type === 'admin' || login.user?.type === 'superadmin'
            "
            round
            icon="delete"
            color="red"
            size="sm"
            class="q-ml-lg"
            @click="revoke(p.row.targetId)" />
        </q-td>
      </template>
      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare i permessi al momento
          </div>
          <div v-else-if="query.isSuccess">Nessun permesso presente</div>
        </div>
      </template>
    </q-table>

    <q-expansion-item
      style="flex-basis: 100%; flex-grow: 1"
      class="q-pt-md"
      expand-separator
      icon="history"
      label="Storico permessi">
      <q-table
        :rows="queryHistory.data"
        :columns="COLUMNS"
        :loading="queryHistory.isLoading">
        <template #body-cell-target="{ value }">
          <q-td>
            <user-fetcher
              :user-id="value"
              :visualize="(user, d) => `${d} (${UserStrings[user.type]})`" />
          </q-td>
        </template>

        <template #body-cell-createBy="{ value }">
          <q-td>
            <user-fetcher :user-id="value" />
          </q-td>
        </template>

        <template #no-data>
          <div class="full-width row flex-center text-primary q-gutter-sm">
            <div v-if="query.isError">
              <q-icon size="2em" name="sentiment_dissatisfied" />
              Impossibile caricare i permessi al momento
            </div>
            <div v-else-if="query.isSuccess">Nessun permesso presente</div>
          </div>
        </template>
      </q-table>
    </q-expansion-item>
  </div>
  <add-permission-dialog
    v-if="login.user?.type === 'admin' || login.user?.type === 'superadmin'"
    ref="dialog"
    :patient-id="patientId"
    @created="refetchPermissions()" />
</template>
