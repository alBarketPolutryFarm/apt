<script setup lang="ts">
import { computed, watch } from 'vue'
import CreateDialog from 'src/pages/Bookings/CreateDialog'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import { COLUMNS } from './const'
import { getPatientBookings } from 'src/api/patients/bookings'
import BookingActions from '../../Bookings/BookingActions'
import UserFetcher from 'src/components/UserFetcher'
import { DateTime } from 'luxon'
import useLogin from 'src/helpers/useLogin'

const props = defineProps<{ patientId: string }>()

const login = useLogin()

const query = useQuery(
  getPatientBookings,
  computed(() => props.patientId),
  computed(() => ({ startDate: DateTime.now().minus({ days: 7 }) }))
)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista degli appuntamenti', 'negative')
})
</script>

<template>
  <div>
    <div class="row no-wrap justify-between q-pb-md">
      <div class="text-h6">Appuntamenti</div>

      <div class="row no-wrap justify-between q-pb-md" style="gap: 10px">
        <q-btn
          v-if="
            login?.user?.type === 'doctor' ||
            login?.user?.type === 'admin' ||
            login?.user?.type === 'nurse' ||
            login?.user?.type === 'operator'
          "
          icon="add"
          color="primary"
          @click="$refs.dialog.show()" />
      </div>
    </div>

    <q-table
      :rows="query.data"
      :columns="COLUMNS"
      row-key="_id"
      class="row"
      :loading="query.isLoading">
      <template #body-cell-provider="{ value }">
        <q-td>
          <user-fetcher :user-id="value" />
        </q-td>
      </template>

      <template #body-cell-isRemote="{ value }">
        <q-td class="flex justify-center items-center">
          <q-icon v-if="value" name="done" size="sm" />
        </q-td>
      </template>

      <template #body-cell-actions="{ row }">
        <q-td>
          <booking-actions :booking="row" @deleted="query.refetch()" />
        </q-td>
      </template>

      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare gli appuntamenti
          </div>
          <div v-else-if="query.isSuccess">Nessun appuntamento presente</div>
        </div>
      </template>
    </q-table>

    <create-dialog
      ref="dialog"
      :target-id="patientId"
      @created="query.refetch()" />
  </div>
</template>
