<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import useQuery from 'src/api/useQuery'
import { getPatient } from 'src/api/patients'
import useLogin from 'src/helpers/useLogin'

// Import panels
import PersonalDataPanel from './PersonalDataPanel'
import MedicalRecordPanel from './MedicalRecordPanel'
import MeasuresPanel from './MeasuresPanel'
import MonitoringPlanPanel from './MonitoringPlanPanel'
import PaiPanel from './PAIPanel'
import IndexMeasuresPanel from './IndexMeasuresPanel'
import ReportsPanel from './ReportsPanel'
import TreatmentPlanPanel from './TreatmentPlanPanel'
import DietPanel from './DietPanel'
import BookingsPanel from './BookingsPanel'
import PermissionsPanel from './PermissionsPanel'
import SetFiscalCodeDialog from './SetFiscalCodeDialog'

const route = useRoute()
const router = useRouter()
const login = useLogin()

const patientId = computed(() => route.params?.id as string)
const query = useQuery(getPatient, patientId)
const currentPanel = computed(
  () => (route.params?.panel as string) || 'personal-data'
)

const scrollTo = (direction: string) => {
  const tabs = document.querySelector('.q-tabs__content')
  if (tabs) {
    const offset = direction === 'left' ? -200 : 200
    tabs.scrollBy({ left: offset, behavior: 'smooth' })
  }
}

const fetchPermissions = (role: string, tab: string) => {
  switch (tab) {
    case 'personal-data':
      return [
        'admin',
        'superadmin',
        'nurse',
        'doctor',
        'caregiver',
        'operator'
      ].includes(role)
    case 'medical-record':
      return ['nurse', 'doctor', 'caregiver', 'operator'].includes(role)
    case 'measures':
      return ['nurse', 'doctor', 'caregiver', 'operator'].includes(role)
    case 'monitoring-plan':
      return ['nurse', 'doctor', 'caregiver', 'operator'].includes(role)
    case 'pai':
      return ['nurse', 'doctor', 'caregiver', 'operator'].includes(role)
    case 'indexMeasures':
      return ['nurse', 'doctor', 'caregiver', 'operator'].includes(role)
    case 'reports':
      return ['nurse', 'doctor', 'caregiver', 'operator'].includes(role)
    case 'treatment-plan':
      return ['nurse', 'doctor', 'caregiver', 'operator'].includes(role)
    case 'diet':
      return ['nurse', 'doctor', 'caregiver', 'operator'].includes(role)
    case 'bookings':
      return ['admin', 'nurse', 'doctor', 'caregiver', 'operator'].includes(
        role
      )
    case 'permissions':
      return ['admin', 'nurse', 'doctor', 'operator'].includes(role)
    default:
      return true
  }
}

const toPanel = (panel: string) =>
  router.push(`/patients/${patientId.value}/${panel}`)
</script>

<template>
  <div class="q-ml-lg">
    <h4 style="font-size: larger; margin: 1%">Dettagli Cartella Assistito</h4>
    <q-separator class="q-ml-sm" style="width: 95%; background: #8080809c" />
  </div>
  <div style="margin: 1%">
    <div class="q-pa-sm">
      <q-card style="padding-top: 10px">
        <div class="q-ma-sm">
          <div class="row">
            <q-avatar
              rounded
              size="100px"
              font-size="82px"
              color="teal"
              text-color="white"
              icon="person" />
            <div v-if="query.isSuccess" class="col">
              <div class="row">
                <h6
                  style="
                    margin-left: 10px;
                    margin-top: 10px;
                    margin-bottom: 5px;
                  ">
                  {{ query.data?.firstName }} {{ query.data?.lastName }}
                </h6>
              </div>
              <div class="row">
                <span style="margin-left: 10px; margin-top: 5px">
                  <b>Email:</b> {{ query.data?.email }}
                </span>
              </div>
              <div class="row">
                <span
                  v-if="query.data?.fiscalCode !== undefined"
                  style="margin-left: 10px; margin-top: 5px">
                  <b>Codice fiscale:</b> {{ query.data?.fiscalCode }}
                </span>
                <a
                  v-else
                  class="text-red"
                  href="#"
                  style="margin-left: 10px; margin-top: 5px"
                  @click="
                    e => {
                      e.preventDefault()
                      $refs.setFiscalCodeDialog.show()
                    }
                  ">
                  <b>Aggiungi codice fiscale</b>
                </a>
              </div>
            </div>
          </div>
          <div class="row no-wrap items-center">
            <!-- <q-btn
              icon="chevron_left"
              flat
              dense
              class="text-teal"
              @click="scrollTo('left')"
            /> -->
            <q-tabs
              ref="tabs"
              v-model="currentPanel"
              class="text-teal q-mt-md"
              style="max-width: 100%; overflow: hidden"
              :arrows="false"
              @update:model-value="toPanel">
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'personal-data')"
                name="personal-data"
                icon="person"
                label="Dati anagrafici" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'medical-record')"
                name="medical-record"
                icon="folder"
                label="Dossier sanitario elettronico" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'measures')"
                name="measures"
                icon="insert_chart"
                label="Misurazioni" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'monitoring-plan')"
                name="monitoring-plan"
                icon="addchart"
                label="Piano di monitoraggio" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'pai')"
                name="pai"
                icon="description"
                label="PAI" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'indexMeasures')"
                name="indexMeasures"
                icon="leaderboard"
                label="Scale di valutazione" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'reports')"
                name="reports"
                icon="summarize"
                label="Referti" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'treatment-plan')"
                name="treatment-plan"
                icon="vaccines"
                label="Trattamenti" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'diet')"
                name="diet"
                icon="scale"
                label="Dieta" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'bookings')"
                name="bookings"
                icon="event"
                label="Appuntamenti" />
              <q-tab
                v-if="fetchPermissions(login.user?.type, 'permissions')"
                name="permissions"
                icon="workspace_premium"
                label="Permessi" />
            </q-tabs>
            <!-- <q-btn
              icon="chevron_right"
              flat
              dense
              class="text-teal"
              @click="scrollTo('right')"
            /> -->
          </div>
          <div class="row">
            <q-tab-panels v-model="currentPanel" animated style="width: 100%">
              <q-tab-panel name="personal-data">
                <personal-data-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="medical-record">
                <medical-record-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="measures">
                <measures-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="monitoring-plan">
                <monitoring-plan-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="pai">
                <pai-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="indexMeasures">
                <index-measures-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="reports">
                <reports-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="treatment-plan">
                <treatment-plan-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="diet">
                <diet-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="bookings">
                <bookings-panel :patient-id="patientId" />
              </q-tab-panel>
              <q-tab-panel name="permissions">
                <permissions-panel :patient-id="patientId" />
              </q-tab-panel>
            </q-tab-panels>
          </div>
        </div>
      </q-card>
    </div>
  </div>
  <set-fiscal-code-dialog
    ref="setFiscalCodeDialog"
    :patient-id="patientId"
    @change="query.refetch()" />
</template>
<style scoped>
.pointed {
  cursor: pointer;
}
</style>

<style lang="sass">
.my-menu-link
  color: white !important
  background: #26a69a
</style>

<style lang="scss" scoped>
.step1_btn {
  background: $palette_color_1;
  color: white;
}

.step2_btn {
  color: $palette_color_1;
}

.q-tabs__arrow-container {
  display: none;
}
</style>
