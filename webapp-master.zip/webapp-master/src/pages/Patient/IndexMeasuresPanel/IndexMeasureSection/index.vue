<script setup lang="ts">
import { computed, watch } from 'vue'
import notify from 'src/helpers/notify'
import {
  getPatientIndexMeasures,
  getPatientIndexMeasuresSummary
} from 'src/api/patients/indexes'
import {
  IndexMeasureReferences,
  IndexMeasureStrings,
  IndexMeasureType
} from 'src/const/IndexMeasure'
import useQuery from 'src/api/useQuery'
import { COLUMNS } from './const'

const props = defineProps<{
  patientId: string
  type: IndexMeasureType
}>()

const summaryQuery = useQuery(
  getPatientIndexMeasuresSummary,
  computed(() => props.patientId)
)

watch(summaryQuery, q => {
  if (!q.isError) return
  notify('Impossibile recuperare i dati delle scale di valutazione', 'negative')
})

const query = useQuery(
  getPatientIndexMeasures,
  computed(() => props.patientId),
  computed(() => props.type),
  computed(() => ({ limit: 20 }))
)

watch(query, q => {
  if (!q.isError) return
  notify(
    `Impossibile recuperare i dati per la scala di valutazione ${
      IndexMeasureStrings[props.type]
    }`,
    'negative'
  )
})
</script>

<template>
  <q-expansion-item group="indexes" expand-separator>
    <template #header>
      <div class="q-item__section column q-item__section--main justify-center">
        <div class="q-item__label">
          {{ IndexMeasureStrings[props.type] }}
          <q-btn
            icon="help"
            size="xs"
            round
            dense
            flat
            :href="IndexMeasureReferences[props.type]"
            target="_blank"
            @click="e => e.stopPropagation()" />
        </div>
        <div class="q-item__label q-item__label--caption text-caption">
          {{ summaryQuery.data?.[props.type]?.value ?? '-' }}
        </div>
      </div>
    </template>
    <div class="q-pa-md">
      <q-table :loading="query.isLoading" :rows="query.data" :columns="COLUMNS">
        <template #no-data>
          <div class="full-width row flex-center text-primary q-gutter-sm">
            <div v-if="query.isError">
              <q-icon size="2em" name="sentiment_dissatisfied" />
              Impossibile caricare i dati della scala di valutazione
            </div>
            <div v-else-if="query.isSuccess">Nessun dato presente</div>
          </div>
        </template>
      </q-table>
    </div>
  </q-expansion-item>
</template>
