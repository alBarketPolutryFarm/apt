import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { IndexMeasure } from 'src/api/patients/indexes/models'

export const COLUMNS: Readonly<QTableProps['columns']> = [
  {
    name: 'value',
    label: 'Valore',
    align: 'left',
    field: (row: IndexMeasure) => row.value,
    sortable: true
  },
  {
    name: 'timestamp',
    label: 'Data',
    align: 'left',
    field: (row: IndexMeasure) => row.timestamp,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_FULL),
    sortable: true
  },
  {
    name: 'timestamp',
    label: 'Prossima valutazione',
    align: 'left',
    field: (row: IndexMeasure) => row.nextCheck,
    format: (v: DateTime) => v?.toLocaleString(DateTime.DATE_MED),
    sortable: true
  }
] as const
