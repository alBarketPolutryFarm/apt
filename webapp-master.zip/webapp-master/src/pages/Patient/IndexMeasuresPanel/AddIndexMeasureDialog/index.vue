<script setup lang="ts">
import { ref, watch } from 'vue'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import QInputDate from 'src/components/QInputDate'
import notify from 'src/helpers/notify'
import { addPatientIndexMeasures } from 'src/api/patients/indexes'
import { NewIndexMeasure } from 'src/api/patients/indexes/models'
import useMutation from 'src/api/useMutation'
import { IndexMeasureStrings, IndexMeasureTypes } from 'src/const/IndexMeasure'

const props = defineProps<{
  patientId: string
}>()

const emit = defineEmits<{
  (e: 'created'): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<RecursivePartial<NewIndexMeasure>>({})

watch(isDialogOpen, () => {
  data.value = { metadata: {} }
})

const [mutationTrigger, mutationStatus] = useMutation(addPatientIndexMeasures)

watch(mutationStatus, s => {
  if (!s.isSuccess) return
  notify('Dato inserito correttamente', 'positive')
  isDialogOpen.value = false
  emit('created')
})
watch(mutationStatus, s => {
  if (!s.isError) return
  notify('Impossibile aggiugnere il dato', 'negative')
})

const handleSubmit = () =>
  mutationTrigger(props.patientId, [data.value as NewIndexMeasure])

defineExpose({
  show: () => (isDialogOpen.value = true)
})
</script>

<template>
  <q-dialog v-model="isDialogOpen">
    <q-card style="width: 400px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Aggiungi dato per scala di valutazione</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-select
            v-model="data.metadata.type"
            :options="
              IndexMeasureTypes.map(m => ({
                value: m,
                label: IndexMeasureStrings[m]
              }))
            "
            label="Scala"
            :rules="[v => !!v || 'Campo richiesto']"
            map-options
            :readonly="mutationStatus.isLoading"
            emit-value />
          <q-input
            v-model.number="data.value"
            type="number"
            :min="0"
            :readonly="mutationStatus.isLoading"
            label="Valore"
            :rules="[v => !!v || 'Campo richiesto']" />
          <q-input-date
            v-model="data.nextCheck"
            :readonly="mutationStatus.isLoading"
            label="Prossima valutazione" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn
            :loading="mutationStatus.isLoading"
            flat
            label="Aggiungi"
            type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
