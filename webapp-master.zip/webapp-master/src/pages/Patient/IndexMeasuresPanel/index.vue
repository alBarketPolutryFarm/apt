<script setup lang="ts">
import useLogin from 'src/helpers/useLogin'
import AddIndexMeasureDialog from './AddIndexMeasureDialog'
import { IndexMeasureTypes } from 'src/const/IndexMeasure'
import IndexMeasureSection from './IndexMeasureSection'

const props = defineProps<{ patientId: string }>()

const login = useLogin()
</script>

<template>
  <div>
    <div class="row no-wrap justify-between q-pb-md">
      <div class="text-h6">Scale di valutazione</div>

      <div class="row no-wrap justify-between q-pb-md" style="gap: 10px">
        <q-btn
          v-if="login.user?.type === 'nurse'"
          icon="add"
          color="primary"
          @click="$refs.dialog.show()" />
      </div>
    </div>

    <q-list separator>
      <index-measure-section
        v-for="t in IndexMeasureTypes"
        :key="t"
        :type="t"
        :patient-id="props.patientId" />
    </q-list>
  </div>

  <add-index-measure-dialog ref="dialog" :patient-id="patientId" />
</template>
