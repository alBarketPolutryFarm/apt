<script setup lang="ts">
import { computed, ref, toRaw, watch } from 'vue'
import notify from 'src/helpers/notify'
import { createPatch } from 'rfc6902'
import { GENDERS } from './const'
import { getPatient, updatePatient } from 'src/api/patients'
import { Patient } from 'src/api/patients/models'
import _ from 'lodash'
import QInputDate from 'src/components/QInputDate'
import { DateTime } from 'luxon'
import useQuery from 'src/api/useQuery'
import EditsLog from 'src/components/EditsLog'

const props = defineProps<{ patientId: string }>()
const patientId = computed(() => props.patientId)

const isReadonly = ref<boolean>(true)
const personalDataFetched = ref<Patient>({} as Patient)
const personalData = ref<Patient>({} as Patient)

const query = useQuery(getPatient, patientId)

watch(query, q => {
  if (q.data === undefined) return

  const _data = Object.assign({}, q.data, {
    editsLog: undefined
  })

  personalData.value = _.cloneDeep(_data)
  personalDataFetched.value = _.cloneDeep(_data)
})

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare i dati del paziente', 'negative')
})

const cancelEdits = () => {
  personalData.value = _.cloneDeep(personalDataFetched.value)
  isReadonly.value = true
}

const saveEdits = () => {
  const patch = createPatch(
    toRaw(personalDataFetched.value),
    toRaw(personalData.value),
    (input, output, ptr) => {
      if (
        (input instanceof DateTime || output instanceof DateTime) &&
        !input.equals(output)
      )
        return [{ op: 'replace', path: ptr.toString(), value: output }]
    }
  )

  if (patch.length === 0) return

  updatePatient(patientId.value, patch)
    .then(() => {
      isReadonly.value = true
      query.refetch()
    })
    .catch(() =>
      notify(
        'Impossibile salvare le modifiche alla cartella clinica',
        'negative'
      )
    )
}
</script>

<template>
  <div class="row no-wrap justify-between q-pb-md">
    <div class="text-h6">Dati anagrafici</div>

    <div class="row no-wrap justify-between q-pb-md" style="gap: 10px">
      <q-btn
        v-if="!isReadonly"
        label="Cancella"
        color="primary-light"
        @click="cancelEdits()" />
      <q-btn
        v-if="!isReadonly"
        label="Salva"
        color="primary"
        @click="saveEdits()" />
      <q-btn
        v-if="isReadonly"
        label="Modifica"
        color="primary"
        @click="isReadonly = false" />
    </div>
  </div>

  <div class="row wrap q-my-sm" style="gap: 20px">
    <q-input
      v-model="personalData.firstName"
      :readonly="isReadonly"
      class="input"
      label="Nome" />
    <q-input
      v-model="personalData.lastName"
      :readonly="isReadonly"
      class="input"
      label="Cognome" />
    <q-input
      v-model="personalData.birthPlace"
      :readonly="isReadonly"
      class="input"
      label="Luogo di nascita" />
    <q-input-date
      v-model="personalData.birthDate"
      :rules="['notFutureDate']"
      :readonly="isReadonly"
      class="input"
      label="Data di nascita" />
    <q-select
      v-model="personalData.gender"
      style="min-width: 150px"
      :options="['female', 'male', 'other', 'unknown']"
      :option-label="g => GENDERS[g as keyof typeof GENDERS]"
      :readonly="isReadonly"
      class="input"
      label="Genere" />
    <q-input
      v-model="personalData.phone"
      :readonly="isReadonly"
      class="input"
      label="Numero di telefono" />
    <q-input
      v-model="personalData.doctor"
      :readonly="isReadonly"
      class="input"
      label="Medico curante" />
    <q-input
      v-model="personalData.caregiver"
      :readonly="isReadonly"
      class="input"
      label="Ente" />
  </div>

  <edits-log :edits-log="query?.data?.editsLog" />
</template>
