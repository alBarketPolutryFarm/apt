import { Gender } from 'src/api/patients/models'

export const GENDERS: Record<Gender, string> = {
  female: 'Femmina',
  male: 'Maschio',
  other: 'Altro',
  unknown: 'Sconosciuto'
} as const
