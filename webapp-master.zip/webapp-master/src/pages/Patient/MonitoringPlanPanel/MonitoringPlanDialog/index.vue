<script setup lang="ts">
import { uid, QForm } from 'quasar'
import { computed, ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import { DateTime, Info } from 'luxon'
import useMutation from 'src/api/useMutation'
import { createPatientMonitoringPlan } from 'src/api/patients/monitoringPlans'
import {
  MonitoredMeasureSchedule,
  MonitoringPlan,
  NewMonitoringPlan
} from 'src/api/patients/monitoringPlans/models'
import {
  MeasureIcons,
  MeasureStrings,
  MeasureType,
  MeasureTypes,
  MeasureUnits
} from 'src/const/Measure'
import _ from 'lodash'
import QSelectReport from 'src/components/QSelectReport'

const WEEKDAYS = Info.weekdays()

const props = defineProps<{
  patientId: string
  monitoringPlan?: string
  autoCreate?: boolean
  readonly?: boolean
}>()

const getInitialData = (): Partial<MonitoringPlan> => ({})

const emit = defineEmits<{
  (e: 'created', monitoringPlan: NewMonitoringPlan): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<Partial<MonitoringPlan>>({})
const currentMeasure = ref<MeasureType>()
const isReadonly = ref(false)
const form = ref<QForm>()

watch(data, data => {
  if (currentMeasure.value !== undefined) return
  currentMeasure.value = MeasureTypes.find(v => data[v] !== undefined)
})

const isReady = computed(() =>
  MeasureTypes.some(m => data.value[m]?.schedule !== undefined)
)

const addMeasure = (m: MeasureType) => {
  data.value = { ...data.value, [m]: { schedule: [] } }
  currentMeasure.value = m
}

const removeMeasure = (m: MeasureType) => {
  data.value = Object.fromEntries(
    Object.entries(_.cloneDeep(data.value)).filter(([k]) => k !== m)
  )
  if (currentMeasure.value === m) currentMeasure.value = undefined
}
const removeScheduleEntry = (id: string) => {
  if (currentMeasure.value === undefined) return

  const measure = data.value[currentMeasure.value]
  if (measure === undefined) return

  measure.schedule = measure.schedule?.filter(s => s._id !== id)
}

const createFrom = () => {
  data.value = _.cloneDeep(
    Object.fromEntries(
      MeasureTypes.map(m => [m, data.value[m]]).filter(
        ([, v]) => v !== undefined
      )
    )
  )

  form.value?.reset()
  isReadonly.value = false
}

const [create, createStatus] = useMutation(createPatientMonitoringPlan)

watch(createStatus, q => {
  if (!q.isError) return
  notify('Impossibile creare il piano di monitoraggio', 'negative')
})

watch(createStatus, q => {
  if (!q.isSuccess) return
  notify('Piano di monitoraggio creato con successo', 'positive')
  isDialogOpen.value = false
  data.value = getInitialData()
  emit('created', _.cloneDeep(data.value as NewMonitoringPlan))
})

const reset = () => {
  data.value = getInitialData()
  currentMeasure.value = undefined
  isReadonly.value = false
}

const createMonitoringPlan = () => {
  if (!isReady.value) return

  const _data = _.cloneDeep(data.value as NewMonitoringPlan)

  if (props.autoCreate === false) {
    isDialogOpen.value = false
    reset()
    return emit('created', _data)
  }

  create(props.patientId, _data)
}

defineExpose({
  show: (plan?: MonitoringPlan) => {
    reset()
    if (plan !== undefined) data.value = plan
    isReadonly.value = plan !== undefined
    isDialogOpen.value = true
  }
})

const addScheduleDialog = ref<MeasureType>()
const scheduleDialog = ref<Partial<MonitoredMeasureSchedule>>({})
const addScheduleEntry = () => {
  if (currentMeasure.value === undefined) return

  const measure = data.value[currentMeasure.value]
  if (measure === undefined) return

  const scheduleEntries = [
    ...measure.schedule,
    {
      ...(scheduleDialog.value as MonitoredMeasureSchedule),
      _id: uid(),
      time: DateTime.fromFormat(
        scheduleDialog.value.time as unknown as string,
        'HH:mm'
      )
    }
  ]

  scheduleEntries.sort(
    (s1: MonitoredMeasureSchedule, s2: MonitoredMeasureSchedule) => {
      if (s1.weekday === s2.weekday) return s1.time > s2.time ? 1 : -1
      return (s1.weekday ?? -1) > (s2.weekday ?? -1) ? 1 : -1
    }
  )

  measure.schedule = scheduleEntries

  addScheduleDialog.value = undefined
  scheduleDialog.value = {}
}
</script>

<template>
  <q-dialog v-model="isDialogOpen" @before-hide="reset()">
    <q-card style="width: 1000px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div v-if="!isReadonly" class="text-h6">
          Nuovo piano di monitoraggio
        </div>
        <div v-else class="text-h6">Piano di monitoraggio</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form ref="form" greedy @submit="createMonitoringPlan">
        <q-card-section class="q-pb-none">
          <q-select-report
            v-if="props.autoCreate"
            v-model="data.reportId"
            :readonly="isReadonly"
            class="q-mb-md"
            :rules="['required']"
            :patient-id="props.patientId"
            label="Referto di riferimento" />
        </q-card-section>

        <q-card-section v-if="!isReadonly" class="q-pb-none">
          <div class="text-caption q-pb-sm">
            Seleziona i parametri vitali che potranno essere inviati
            dall'assistito
          </div>
          <div>
            <q-chip
              v-for="m in MeasureTypes"
              v-show="data?.[m] === undefined"
              :key="m"
              color="primary"
              text-color="white"
              icon-remove="add"
              :icon="MeasureIcons[m]"
              clickable
              @click="addMeasure(m)">
              {{ MeasureStrings[m] }}
            </q-chip>
          </div>
        </q-card-section>

        <q-card-section class="row no-wrap" style="min-height: 400px">
          <div class="full-height">
            <q-tabs
              v-model="currentMeasure"
              style="min-width: 300px"
              vertical
              active-color="primary"
              indicator-color="primary"
              narrow-indicator
              class="text-grey">
              <q-tab
                v-for="m in MeasureTypes"
                v-show="data?.[m] !== undefined"
                :key="m"
                :name="m"
                content-class="full-width row no-wrap justify-space-between items-center"
                :icon="MeasureIcons[m]"
                :label="MeasureStrings[m]">
                <q-btn
                  v-if="!isReadonly"
                  flat
                  round
                  size="sm"
                  icon="delete"
                  @click.stop="removeMeasure(m)" />
              </q-tab>
            </q-tabs>
          </div>

          <div class="full-height">
            <q-tab-panels
              v-model="currentMeasure"
              animated
              keep-alive
              vertical
              class="full-height">
              <q-tab-panel
                v-for="m in MeasureTypes"
                v-show="data?.[m] !== undefined"
                :key="m"
                :name="m"
                style="max-height: 50vh">
                <div>
                  <q-card-section v-if="!isReadonly" class="q-pb-none">
                    Al paziente è consentità la raccolta dati del parametro
                    <b>{{ MeasureStrings[m] }}</b>
                  </q-card-section>

                  <q-card-section class="q-pb-none">
                    <div class="row items-center q-pb-none">
                      <div class="text-h6">Schedule</div>
                      <q-btn
                        v-if="!isReadonly"
                        class="q-mx-sm"
                        icon="add"
                        round
                        flat
                        @click="addScheduleDialog = m" />
                    </div>
                    <div v-if="!isReadonly" class="text-caption">
                      Puoi opzionalmente indicare una schedule di notifiche per
                      la raccolta dei dati che l'assistito dovrà seguire
                    </div>

                    <div class="q-pt-sm">
                      <q-chip
                        v-for="s in data?.[m]?.schedule"
                        :key="s._id"
                        color="primary"
                        text-color="white"
                        icon="alarm"
                        :removable="!isReadonly"
                        @remove="removeScheduleEntry(s._id)">
                        <template v-if="s.weekday !== undefined"
                          >{{ WEEKDAYS[s.weekday] }}
                        </template>
                        <template v-else>ogni giorno</template>
                        alle
                        {{ s.time.toLocaleString(DateTime.TIME_SIMPLE) }}
                      </q-chip>
                      <div v-if="data?.[m]?.schedule?.length === 0">
                        Nessuna schedule impostata
                      </div>
                    </div>
                  </q-card-section>

                  <q-card-section
                    v-if="
                      !isReadonly ||
                      data[m].limitMin ||
                      data[m].limitMax ||
                      data[m].limitMinSystolic ||
                      data[m].limitMaxSystolic ||
                      data[m].limitMinDiastolic ||
                      data[m].limitMaxDiastolic
                    ">
                    <div class="text-h6">Allarmi</div>
                    <div v-if="!isReadonly" class="text-caption">
                      Puoi impostare dei valori limite per il parametro. Se
                      l'assistito dovesse inserire una misurazione fuori da
                      questo range la centrale operativa verrà notificata
                    </div>
                    <div
                      v-if="m === 'bloodPressure'"
                      class="row justify-around">
                      <q-input
                        v-if="!isReadonly || data[m].limitMinSystolic"
                        :model-value="data?.[m]?.limitMinSystolic"
                        type="number"
                        :suffix="MeasureUnits[m]"
                        :readonly="isReadonly"
                        class="input"
                        label="Limite minimo SIStolica"
                        @update:model-value="
                          v =>
                            (data[m].limitMinSystolic =
                              v === '' ? undefined : parseFloat(v))
                        " />
                      <q-input
                        v-if="!isReadonly || data[m].limitMaxSystolic"
                        :model-value="data?.[m]?.limitMaxSystolic"
                        type="number"
                        :readonly="isReadonly"
                        :suffix="MeasureUnits[m]"
                        class="input"
                        label="Limite massimo SIStolica"
                        @update:model-value="
                          v =>
                            (data[m].limitMaxSystolic =
                              v === '' ? undefined : parseFloat(v))
                        " />
                      <q-input
                        v-if="!isReadonly || data[m].limitMinDiastolic"
                        :model-value="data?.[m]?.limitMinDiastolic"
                        type="number"
                        :suffix="MeasureUnits[m]"
                        :readonly="isReadonly"
                        class="input"
                        label="Limite minimo DIAstolica"
                        @update:model-value="
                          v =>
                            (data[m].limitMinDiastolic =
                              v === '' ? undefined : parseFloat(v))
                        " />
                      <q-input
                        v-if="!isReadonly || data[m].limitMaxDiastolic"
                        :model-value="data?.[m]?.limitMaxDiastolic"
                        type="number"
                        :readonly="isReadonly"
                        :suffix="MeasureUnits[m]"
                        class="input"
                        label="Limite massimo DIAstolica"
                        @update:model-value="
                          v =>
                            (data[m].limitMaxDiastolic =
                              v === '' ? undefined : parseFloat(v))
                        " />
                    </div>
                    <div v-else class="row justify-around">
                      <q-input
                        v-if="
                          (!isReadonly &&
                            !['pain', 'bloodPressure'].includes(m)) ||
                          data[m].limitMin
                        "
                        :model-value="data?.[m]?.limitMin"
                        type="number"
                        :suffix="MeasureUnits[m]"
                        :readonly="isReadonly"
                        class="input"
                        label="Limite minimo"
                        @update:model-value="
                          v =>
                            (data[m].limitMin =
                              v === '' ? undefined : parseFloat(v))
                        " />
                      <q-input
                        v-if="
                          (!isReadonly &&
                            !['oxygenSaturation', 'bloodPressure'].includes(
                              m
                            )) ||
                          data[m].limitMax
                        "
                        :model-value="data?.[m]?.limitMax"
                        type="number"
                        :readonly="isReadonly"
                        :suffix="MeasureUnits[m]"
                        class="input"
                        label="Limite massimo"
                        @update:model-value="
                          v =>
                            (data[m].limitMax =
                              v === '' ? undefined : parseFloat(v))
                        " />
                    </div>
                  </q-card-section>
                </div>
              </q-tab-panel>
            </q-tab-panels>
          </div>
        </q-card-section>

        <q-card-actions
          v-if="!props.readonly"
          align="right"
          class="text-primary">
          <q-btn
            v-if="isReadonly"
            flat
            label="Crea piano a partire da questo"
            @click="createFrom()" />
          <q-btn
            v-if="!isReadonly"
            :disable="!isReady"
            flat
            label="Crea"
            type="submit"
            :loading="createStatus.isLoading" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>

  <q-dialog
    :model-value="addScheduleDialog !== undefined"
    @update:model-value="v => v || (addScheduleDialog = undefined)">
    <q-card>
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Aggiungi orario</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="addScheduleEntry">
        <q-card-section>
          <q-select
            v-model="scheduleDialog.weekday"
            clearable
            stack-label
            :options="[...Array(7).keys()]"
            :option-label="i => WEEKDAYS[i]"
            label="Giorno"
            outlined
            class="q-my-sm q-px-sm col-12"
            @clear="scheduleDialog.weekday = undefined">
            <template #selected>
              <template v-if="scheduleDialog.weekday !== undefined"
                >{{ WEEKDAYS[scheduleDialog.weekday] }}
              </template>
              <template v-else>Ogni giorno</template>
            </template>
          </q-select>
          <q-input
            v-model="scheduleDialog.time"
            outlined
            mask="##:##"
            label="alle ore"
            class="q-my-sm q-px-sm col-12"
            :rules="[v => DateTime.fromFormat(v ?? '', 'HH:mm').isValid]">
            <template #append>
              <q-icon name="event" class="cursor-pointer">
                <q-popup-proxy
                  cover
                  transition-show="scale"
                  transition-hide="scale">
                  <q-time v-model="scheduleDialog.time" mask="HH:mm" format24h>
                    <div class="row items-center justify-end">
                      <q-btn v-close-popup label="Ok" color="primary" flat />
                    </div>
                  </q-time>
                </q-popup-proxy>
              </q-icon>
            </template>
          </q-input>
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
