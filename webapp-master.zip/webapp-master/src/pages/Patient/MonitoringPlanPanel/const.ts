import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { MonitoringPlan } from 'src/api/patients/monitoringPlans/models'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'effectiveDate',
    label: 'Decorrenza dal',
    align: 'left',
    field: (row: MonitoringPlan) => row.effectiveDate,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'revocationDate',
    label: 'Revocato il',
    align: 'left',
    field: (row: MonitoringPlan) => row.revocation?.date,
    format: (v?: DateTime) => v?.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'report',
    label: 'Referto di riferimento',
    align: 'left',
    field: (row: MonitoringPlan) => row.reportId,
    sortable: true
  },
  {
    name: 'actions',
    label: '',
    align: 'center',
    field: (row: MonitoringPlan) => row
  }
]
