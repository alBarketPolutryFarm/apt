<script setup lang="ts">
import { ref, watch } from 'vue'
import MonitoringPlanDialog from './MonitoringPlanDialog'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import {
  getPatientMonitoringPlans,
  revokePatientMonitoringPlan
} from 'src/api/patients/monitoringPlans'
import { COLUMNS } from './const'
import useMutation from 'src/api/useMutation'
import useLogin from 'src/helpers/useLogin'
import { getPatientReportFile } from 'src/api/patients/reports'
import downloadFileEncoded from 'src/helpers/downloadFileEncoded'

const props = defineProps<{ patientId: string }>()

const login = useLogin()

const query = useQuery(getPatientMonitoringPlans, ref(props.patientId))

watch(query, q => {
  if (!q.isError) return
  notify(
    'Impossibile recuperare la lista dei piani di monitoraggio',
    'negative'
  )
})

const [revoke, revokeStatus] = useMutation(revokePatientMonitoringPlan)

watch(revokeStatus, q => {
  if (!q.isError) return
  notify('Impossibile revocare il piano di monitoraggio', 'negative')
})
watch(revokeStatus, q => {
  if (!q.isSuccess) return
  query.refetch()
  notify('Piano revocato', 'positive')
})

const downloadReport = (reportId: string) =>
  downloadFileEncoded(getPatientReportFile(props.patientId, reportId))
</script>

<template>
  <div>
    <div class="row no-wrap justify-between q-pb-md">
      <div class="text-h6">Piani di monitoraggio</div>

      <div class="row no-wrap justify-between q-pb-md" style="gap: 10px">
        <q-btn
          v-if="login.user?.type === 'doctor'"
          icon="add"
          color="primary"
          to="./reports">
          <q-tooltip>
            Per creare un nuovo piano di monitoraggio è necessario creare un
            nuovo referto
          </q-tooltip>
        </q-btn>
        <q-btn
          v-else-if="login.user?.type === 'nurse'"
          icon="add"
          color="primary"
          @click="$refs.dialog.show()" />
      </div>
    </div>

    <q-table
      :rows="query.data"
      :columns="COLUMNS"
      row-key="_id"
      class="row"
      :loading="query.isLoading || revokeStatus.isLoading">
      <template #body-cell-report="{ value }">
        <q-td>
          <q-btn
            round
            icon="description"
            color="green"
            size="sm"
            class="q-ml-lg"
            @click="downloadReport(value)">
            <q-tooltip>Scarica il referto</q-tooltip>
          </q-btn>
        </q-td>
      </template>

      <template #body-cell-actions="{ row }">
        <q-td>
          <q-btn
            round
            icon="visibility"
            color="blue"
            size="sm"
            class="q-ml-lg"
            @click="$refs.dialog.show(row)" />
        </q-td>
      </template>

      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare i piani di monitoraggio
          </div>
          <div v-else-if="query.isSuccess">
            Nessun piano di monitoraggio presente
          </div>
        </div>
      </template>
    </q-table>

    <monitoring-plan-dialog
      ref="dialog"
      auto-create
      :patient-id="patientId"
      :readonly="login.user?.type !== 'nurse'"
      @created="query.refetch()" />
  </div>
</template>
