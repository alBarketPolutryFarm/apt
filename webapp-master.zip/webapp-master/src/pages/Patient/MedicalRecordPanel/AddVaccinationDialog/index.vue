<script setup lang="ts">
import { ref } from 'vue'
import QInputDate from 'src/components/QInputDate'
import { Vaccination } from 'src/api/patients/medicalRecord/models'

const emit = defineEmits<{
  (e: 'created', value: Vaccination): void
}>()

const isDialogOpen = ref<boolean>(false)

defineExpose({
  show: () => (isDialogOpen.value = true)
})

const data = ref<Partial<Vaccination>>({})

const handleSubmit = () => {
  emit('created', data.value as Vaccination)
  isDialogOpen.value = false
}
</script>

<template>
  <q-dialog v-model="isDialogOpen" @hide="data = {}">
    <q-card style="width: 80vw; max-width: 600px">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Registra nuova vaccinazione</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-input-date
            v-model="data.date"
            class="full-width"
            :rules="['notFutureDate', 'required']"
            label="Data" />
          <q-input
            v-model="data.type"
            type="textarea"
            class="full-width"
            :rules="[r => !!r || 'Campo richiesto']"
            label="Tipologia" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn flat label="Aggiungi" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
