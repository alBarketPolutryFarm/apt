<script setup lang="ts">
import { computed, ref, toRaw, watch } from 'vue'
import notify from 'src/helpers/notify'
import { createPatch } from 'rfc6902'
import QInputDate from 'src/components/QInputDate'
import {
  getPatientMedicalRecord,
  updatePatientMedicalRecord
} from 'src/api/patients/medicalRecord'
import { MedicalRecord } from 'src/api/patients/medicalRecord/models'
import {
  COMORBIDITY,
  SURGERY_COLUMNS,
  INJURY_COLUMNS,
  VACCINE_COLUMNS
} from './const'
import useQuery from 'src/api/useQuery'
import EditsLog from 'src/components/EditsLog'
import { getPatient } from 'src/api/patients'
import _ from 'lodash'
import AddInjuryDialog from './AddInjuryDialog'
import AddSurgeryDialog from './AddSurgeryDialog'
import AddVaccinationDialog from './AddVaccinationDialog'
import useLogin from 'src/helpers/useLogin'

const props = defineProps<{ patientId: string }>()
const patientId = computed(() => props.patientId)

const login = useLogin()

const isReadonly = ref<boolean>(true)
const medicalRecordFetched = ref<MedicalRecord>({} as MedicalRecord)
const medicalRecord = ref<MedicalRecord>({
  comorbidity: {}
} as MedicalRecord)

const queryPatient = useQuery(getPatient, patientId)
const query = useQuery(getPatientMedicalRecord, patientId)

watch(query, q => {
  if (!q.isSuccess) return
  if (!q.data) return

  medicalRecord.value = _.cloneDeep(q.data)
  medicalRecordFetched.value = _.cloneDeep(q.data)
})

watch(query, q => {
  if (!q.isError) return

  notify('Impossibile recuperare la cartella clinica', 'negative')
})

const cancelEdits = () => {
  medicalRecord.value = Object.assign({}, medicalRecordFetched.value)
  isReadonly.value = true
}

const saveEdits = () => {
  const patch = createPatch(
    toRaw(medicalRecordFetched.value),
    toRaw(medicalRecord.value)
  )

  updatePatientMedicalRecord(patientId.value, patch)
    .then(() => {
      isReadonly.value = true
      query.refetch()
    })
    .catch(() =>
      notify(
        'Impossibile salvare le modifiche alla cartella clinica',
        'negative'
      )
    )
}
</script>

<template>
  <div class="row no-wrap justify-between q-pb-md">
    <div class="text-h6">Dossier sanitario elettronico</div>

    <div
      v-if="
        login.user?.type &&
        ['doctor', 'admin', 'superadmin', 'nurse'].includes(login.user.type)
      "
      class="row no-wrap justify-between q-pb-md"
      style="gap: 10px">
      <q-btn
        v-if="!isReadonly"
        label="Cancella"
        color="primary-light"
        @click="cancelEdits()" />
      <q-btn
        v-if="!isReadonly"
        label="Salva"
        color="primary"
        @click="saveEdits()" />
      <q-btn
        v-if="isReadonly"
        label="Modifica"
        color="primary"
        @click="isReadonly = false" />
    </div>
  </div>

  <q-list bordered separator>
    <q-expansion-item
      group="histories"
      expand-separator
      class="full-width"
      label="Anamnesi patologica">
      <q-list bordered class="row wrap q-ma-md" separator>
        <q-expansion-item
          group="pathologicalHistory"
          expand-separator
          class="full-width"
          label="Comorbidità">
          <q-list bordered class="row wrap q-pa-md" style="gap: 20px">
            <q-input
              v-for="v in COMORBIDITY"
              :key="v.field"
              v-model="medicalRecord.comorbidity[v.field]"
              :readonly="isReadonly"
              type="textarea"
              style="min-width: 600px; flex-grow: 1"
              :label="v.label" />
          </q-list>
        </q-expansion-item>

        <q-expansion-item
          group="pathologicalHistory"
          expand-separator
          class="full-width"
          label="Interventi chirurgici">
          <q-list bordered class="q-pa-md">
            <q-table
              class="full-width"
              :rows="medicalRecord.surgeries"
              :columns="SURGERY_COLUMNS">
              <template v-if="!isReadonly" #top-right>
                <q-btn
                  icon="add"
                  color="primary"
                  @click="$refs.addSurgeryDialog.show()" />
              </template>

              <template #body-cell-actions="{ row }">
                <q-td class="row no-wrap justify-end items-center">
                  <q-btn
                    v-if="!isReadonly"
                    round
                    icon="delete"
                    color="red"
                    size="sm"
                    class="q-ml-lg"
                    @click="
                      medicalRecord.surgeries = medicalRecord.surgeries.filter(
                        v => v !== row
                      )
                    " />
                </q-td>
              </template>

              <template #no-data> Nessun intervento registrato </template>
            </q-table>
            <add-surgery-dialog
              ref="addSurgeryDialog"
              @created="
                v =>
                  (medicalRecord.surgeries = [
                    ...(medicalRecord.surgeries ?? []),
                    v
                  ].sort((a, b) => b.date.diff(a.date)))
              " />
          </q-list>
        </q-expansion-item>

        <q-expansion-item
          group="pathologicalHistory"
          expand-separator
          class="full-width"
          label="Traumi e infortuni">
          <q-list bordered class="row wrap q-pa-md">
            <q-table
              class="full-width"
              :rows="medicalRecord.injuries"
              :columns="INJURY_COLUMNS">
              <template v-if="!isReadonly" #top-right>
                <q-btn
                  icon="add"
                  color="primary"
                  @click="$refs.addInjuryDialog.show()" />
              </template>

              <template #body-cell-actions="{ row }">
                <q-td class="row no-wrap justify-end items-center">
                  <q-btn
                    v-if="!isReadonly"
                    round
                    icon="delete"
                    color="red"
                    size="sm"
                    class="q-ml-lg"
                    @click="
                      medicalRecord.injuries = medicalRecord.injuries.filter(
                        v => v !== row
                      )
                    " />
                </q-td>
              </template>

              <template #no-data>
                Nessun trauma o infortunio registrato
              </template>
            </q-table>
            <add-injury-dialog
              ref="addInjuryDialog"
              @created="
                v =>
                  (medicalRecord.injuries = [
                    ...(medicalRecord.injuries ?? []),
                    v
                  ].sort((a, b) => b.date.diff(a.date)))
              " />

            <q-input
              v-model="medicalRecord.prostheses"
              :readonly="isReadonly"
              type="textarea"
              class="full-width"
              label="Protesi" />
          </q-list>
        </q-expansion-item>
      </q-list>
    </q-expansion-item>

    <q-expansion-item
      group="histories"
      expand-separator
      class="full-width"
      label="Anamnesi fisiologica">
      <q-list bordered class="row wrap q-ma-md" separator>
        <q-expansion-item
          group="physiologicalHistory"
          expand-separator
          class="full-width"
          label="Generale">
          <q-list class="q-ma-md">
            <q-select
              v-model="medicalRecord.nutrition"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'insufficient', label: 'Insufficiente' },
                { value: 'overeating', label: 'Eccessiva' }
              ]"
              emit-value
              map-options
              label="Alimentazione"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.alcohol"
              :options="[
                { value: 'teetotaler', label: 'Astemio' },
                { value: 'mediumDrinker', label: 'Medio bevitore' },
                { value: 'heavyDrinker', label: 'Forte bevitore' }
              ]"
              emit-value
              map-options
              label="Alcolici"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.coffe"
              :options="[
                { value: 'never', label: 'Normale' },
                { value: 'mediumDrinker', label: 'Medio bevitore' },
                { value: 'heavyDrinker', label: 'Forte bevitore' }
              ]"
              emit-value
              map-options
              label="Caffè"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.sleep"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'sleepless', label: 'Insonnia' },
                { value: 'excessive', label: 'Eccesivo' }
              ]"
              emit-value
              map-options
              label="Sonno"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.physicalActivity"
              :options="[
                { value: 'never', label: 'Nessuna' },
                { value: 'moderate', label: 'Moderata' },
                { value: 'intense', label: 'Intensa' }
              ]"
              emit-value
              map-options
              label="Attività fisica"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.sexLife"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'low', label: 'Scarsa' },
                { value: 'never', label: 'Assente' }
              ]"
              emit-value
              map-options
              label="Vita sessuale"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.bowel"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'diarrhea', label: 'Diarroico' },
                { value: 'constipated', label: 'Statico' },
                { value: 'tenesmus', label: 'Tenesmo' }
              ]"
              emit-value
              map-options
              label="Alvo"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.diuresis"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'oliguria', label: 'Oliguria' },
                { value: 'polyuria', label: 'Poliuria' },
                { value: 'dysuria', label: 'Disuria' },
                { value: 'pollakiuria', label: 'Pollacchiura' }
              ]"
              emit-value
              map-options
              label="Diuresi"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.appetite"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'increased', label: 'Aumentato' },
                { value: 'reduced', label: 'Ridotto' }
              ]"
              emit-value
              map-options
              label="Appetito"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.thirst"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'increased', label: 'Aumentata' },
                { value: 'reduced', label: 'Ridotta' }
              ]"
              emit-value
              map-options
              label="Sete"
              :readonly="isReadonly"
              class="full-width" />
            <q-input
              v-model="medicalRecord.drugs"
              :readonly="isReadonly"
              type="textarea"
              label="Droghe"
              class="full-width" />
          </q-list>
        </q-expansion-item>

        <q-expansion-item
          v-if="queryPatient.data?.gender !== 'male'"
          group="physiologicalHistory"
          expand-separator
          class="full-width"
          label="Per genere femminile">
          <q-list class="row wrap q-ma-md">
            <q-select
              v-model="medicalRecord.menarche"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'premature', label: 'Prematuro' },
                { value: 'late', label: 'Ritardato' },
                { value: 'absent', label: 'Assente' }
              ]"
              emit-value
              map-options
              label="Menarca"
              :readonly="isReadonly"
              class="full-width" />
            <q-select
              v-model="medicalRecord.menopause"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'premature', label: 'Prematura' },
                { value: 'late', label: 'Ritardata' },
                { value: 'caused', label: 'Provocata' },
                { value: 'absent', label: 'Assente' }
              ]"
              emit-value
              map-options
              label="Menopausa"
              :readonly="isReadonly"
              class="full-width" />
            <q-input
              v-model="medicalRecord.pregnanciesNumber"
              :readonly="isReadonly"
              :min="0"
              type="number"
              class="full-width"
              label="Numero di gravidanze" />
            <q-input-date
              v-model="medicalRecord.lastMenstruation"
              :readonly="isReadonly"
              class="full-width"
              label="Data ultima mestruazione" />
          </q-list>
        </q-expansion-item>

        <q-expansion-item
          v-if="queryPatient.data?.gender !== 'female'"
          group="physiologicalHistory"
          expand-separator
          class="full-width"
          label="Per genere maschile">
          <q-list bordered class="row wrap q-pa-md">
            <q-select
              v-model="medicalRecord.andropause"
              :options="[
                { value: 'normal', label: 'Normale' },
                { value: 'premature', label: 'Prematura' },
                { value: 'late', label: 'Ritardata' },
                { value: 'absent', label: 'Assente' }
              ]"
              emit-value
              map-options
              label="Andropausa"
              :readonly="isReadonly"
              class="full-width" />
          </q-list>
        </q-expansion-item>

        <q-expansion-item
          group="physiologicalHistory"
          expand-separator
          class="full-width"
          label="Vaccinazioni effettuate">
          <q-list bordered class="row wrap q-pa-md">
            <q-table
              class="full-width"
              :rows="medicalRecord.vaccinations"
              :columns="VACCINE_COLUMNS">
              <template v-if="!isReadonly" #top-right>
                <q-btn
                  icon="add"
                  color="primary"
                  @click="$refs.addVaccinationDialog.show()" />
              </template>

              <template #body-cell-actions="{ row }">
                <q-td class="row no-wrap justify-end items-center">
                  <q-btn
                    v-if="!isReadonly"
                    round
                    icon="delete"
                    color="red"
                    size="sm"
                    class="q-ml-lg"
                    @click="
                      medicalRecord.vaccinations =
                        medicalRecord.vaccinations.filter(v => v !== row)
                    " />
                </q-td>
              </template>

              <template #no-data> Nessuna vaccinazione registrata</template>
            </q-table>
            <add-vaccination-dialog
              ref="addVaccinationDialog"
              @created="
                v =>
                  (medicalRecord.vaccinations = [
                    ...(medicalRecord.vaccinations ?? []),
                    v
                  ].sort((a, b) => b.date.diff(a.date)))
              " />
          </q-list>
        </q-expansion-item>

        <q-expansion-item
          group="physiologicalHistory"
          expand-separator
          class="full-width"
          label="Altro">
          <q-list class="row wrap q-ma-md">
            <q-select
              v-model="medicalRecord.bloodType"
              :options="['0+', '0-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-']"
              label="Gruppo sanguigno"
              :readonly="isReadonly"
              class="full-width" />

            <q-input
              v-model="medicalRecord.weight"
              :readonly="isReadonly"
              :min="0"
              type="number"
              class="full-width"
              label="Peso"
              suffix="kg" />
            <q-input
              v-model="medicalRecord.height"
              :readonly="isReadonly"
              :min="0"
              type="number"
              class="full-width"
              label="Altezza"
              suffix="cm" />
            <q-input
              v-model="medicalRecord.bmi"
              :readonly="isReadonly"
              :min="0"
              type="number"
              class="full-width"
              label="BMI" />

            <q-input
              v-model="medicalRecord.riskFactors"
              :readonly="isReadonly"
              type="textarea"
              class="full-width"
              label="Fattori di rischio" />

            <q-input
              v-model="medicalRecord.allergiesIntolerances"
              :readonly="isReadonly"
              type="textarea"
              class="full-width"
              label="Allergie e intolleranze" />

            <q-input
              v-model="medicalRecord.notes"
              :readonly="isReadonly"
              type="textarea"
              class="full-width"
              label="Altro" />
          </q-list>
        </q-expansion-item>
      </q-list>
    </q-expansion-item>

    <q-expansion-item
      group="histories"
      expand-separator
      class="full-width"
      label="Anamnesi familiare">
      <q-list bordered class="row wrap q-pa-md">
        <q-input
          v-model="medicalRecord.familyHistory"
          :readonly="isReadonly"
          type="textarea"
          class="full-width"
          label="Anamnesi familiare" />
      </q-list>
    </q-expansion-item>
  </q-list>

  <edits-log :edits-log="query?.data?.editsLog" />
</template>
