import {
  Comorbidity,
  Injury,
  Surgery,
  Vaccination
} from 'src/api/patients/medicalRecord/models'
import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'

export const COMORBIDITY: {
  field: keyof Comorbidity
  label: string
}[] = [
  {
    field: 'congenitalMalformations',
    label: 'Malformazioni congenite'
  },
  {
    field: 'exanthematousDiseases',
    label: 'Malattie esentematiche'
  },
  {
    field: 'venerealDiseases',
    label: 'Malattie veneree'
  },
  {
    field: 'infectiousDiseases',
    label: 'Malattie infettive'
  },
  {
    field: 'respiratoryDiseases',
    label: 'Malattie respiratorie'
  },
  {
    field: 'digestiveDiseases',
    label: 'Malattie apparato digerente'
  },
  {
    field: 'cardiovascularDiseases',
    label: 'Malattie cardiovascolari'
  },
  {
    field: 'nervousPsycheDiseases',
    label: 'Malattie del sistema nervoso e della psiche'
  },
  {
    field: 'genitourinaryDiseases',
    label: 'Malattie genito-urinarie'
  },
  {
    field: 'osteoarticularDiseases',
    label: 'Malattie osteo-articolari'
  },
  {
    field: 'bloodDiseases',
    label: 'Malattie del sangue'
  },
  {
    field: 'skinDiseases',
    label: 'Malattie cutanee'
  },
  {
    field: 'metabolicDiseases',
    label: 'Malattie del metabolismo'
  },
  {
    field: 'otherDiseases',
    label: 'Altre malattie'
  }
]

export const INJURY_COLUMNS: Readonly<QTableProps['columns']> = [
  {
    name: 'date',
    label: 'Data',
    align: 'left',
    field: 'date',
    format: (v: DateTime) => v.toLocaleString(DateTime.DATE_FULL),
    sortable: true
  },
  {
    name: 'description',
    label: 'Description',
    align: 'left',
    field: 'description',
    sortable: false
  },
  {
    name: 'actions',
    align: 'center',
    label: '',
    sortable: false,
    field: (row: Injury) => row
  }
] as const

export const SURGERY_COLUMNS: Readonly<QTableProps['columns']> = [
  {
    name: 'date',
    label: 'Data',
    align: 'left',
    field: 'date',
    format: (v: DateTime) => v.toLocaleString(DateTime.DATE_FULL),
    sortable: true
  },
  {
    name: 'cause',
    label: 'Causa',
    align: 'left',
    field: 'cause',
    sortable: false
  },
  {
    name: 'sideEffects',
    label: 'Postumi',
    align: 'left',
    field: 'sideEffects',
    sortable: false
  },
  {
    name: 'actions',
    align: 'center',
    label: '',
    sortable: false,
    field: (row: Surgery) => row
  }
] as const

export const VACCINE_COLUMNS: Readonly<QTableProps['columns']> = [
  {
    name: 'date',
    label: 'Data',
    align: 'left',
    field: 'date',
    format: (v: DateTime) => v.toLocaleString(DateTime.DATE_FULL),
    sortable: true
  },
  {
    name: 'type',
    label: 'Tipo',
    align: 'left',
    field: 'type',
    sortable: true
  },
  {
    name: 'actions',
    align: 'center',
    label: '',
    sortable: false,
    field: (row: Vaccination) => row
  }
] as const
