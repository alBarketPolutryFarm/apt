<script setup lang="ts">
import { ref, watch } from 'vue'
import DietDialog from './DietDialog'
import { getPatientDiets } from 'src/api/patients/diets'
import { COLUMNS } from './const'
import useLogin from 'src/helpers/useLogin'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import AdherenceChart from './AdherenceChart'
import { getPatientReportFile } from 'src/api/patients/reports'
import downloadFileEncoded from 'src/helpers/downloadFileEncoded'

const props = defineProps<{ patientId: string }>()

const login = useLogin()

const query = useQuery(getPatientDiets, ref(props.patientId))

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista delle diete', 'negative')
})

const downloadReport = (reportId: string) =>
  downloadFileEncoded(getPatientReportFile(props.patientId, reportId))
</script>

<template>
  <div class="column q-gutter-lg">
    <div>
      <div class="row no-wrap justify-between q-pb-md">
        <div class="text-h6">Dieta</div>

        <div class="row no-wrap justify-between q-pb-md" style="gap: 10px">
          <q-btn
            v-if="login.user?.type === 'doctor'"
            icon="add"
            color="primary"
            to="./reports">
            <q-tooltip>
              Per creare una nuova dieta è necessario creare un nuovo referto
            </q-tooltip>
          </q-btn>
          <q-btn
            v-else-if="login.user?.type === 'nurse'"
            icon="add"
            color="primary"
            @click="$refs.dialog.show()" />
        </div>
      </div>

      <q-table
        :rows="query.data"
        :columns="COLUMNS"
        row-key="_id"
        class="row"
        :loading="query.isLoading">
        <template #body-cell-report="{ value }">
          <q-td>
            <q-btn
              round
              icon="description"
              color="green"
              size="sm"
              class="q-ml-lg"
              @click="downloadReport(value)">
              <q-tooltip>Scarica il referto</q-tooltip>
            </q-btn>
          </q-td>
        </template>

        <template #body-cell-actions="{ row }">
          <q-td>
            <q-btn
              round
              icon="visibility"
              color="blue"
              size="sm"
              class="q-ml-lg"
              @click="$refs.dialog.show(row)" />
          </q-td>
        </template>

        <template #no-data>
          <div class="full-width row flex-center text-primary q-gutter-sm">
            <div v-if="query.isError">
              <q-icon size="2em" name="sentiment_dissatisfied" />
              Impossibile caricare le diete
            </div>
            <div v-else-if="query.isSuccess">Nessun dieta presente</div>
          </div>
        </template>
      </q-table>
    </div>
    <div>
      <div class="row no-wrap justify-between q-pb-md">
        <div class="text-h6">Aderenza dieta</div>
      </div>

      <adherence-chart :patient-id="patientId" />
    </div>
  </div>

  <diet-dialog
    ref="dialog"
    :patient-id="patientId"
    auto-create
    :readonly="login.user?.type !== 'nurse'"
    @created="query.refetch()" />
</template>
