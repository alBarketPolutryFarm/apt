<script setup lang="ts">
import { computed, ref } from 'vue'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import { createNewPatientDiet } from 'src/api/patients/diets'
import { Diet, NewDiet } from 'src/api/patients/diets/models'
import _ from 'lodash'
import QSelectReport from 'src/components/QSelectReport'
import notify from 'src/helpers/notify'
import { QForm } from 'quasar'

const WEEKDAYS = [
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
  'sunday'
] as const
const MEALS = [
  'breakfast',
  'morningSnack',
  'lunch',
  'afternoonSnack',
  'dinner'
] as const

const WEEKDAYS_TRANSLATION: Record<(typeof WEEKDAYS)[number], string> = {
  monday: 'Lunedì',
  tuesday: 'Martedì',
  wednesday: 'Mercoledì',
  thursday: 'Giovedì',
  friday: 'Venerdì',
  saturday: 'Sabato',
  sunday: 'Domenica'
} as const

const MEALS_TRANSLATION: Record<(typeof MEALS)[number], string> = {
  breakfast: 'Colazione',
  morningSnack: 'Spuntino mattutino',
  lunch: 'Pranzo',
  afternoonSnack: 'Spuntino pomeridiano',
  dinner: 'Cena'
} as const

const DEFAULT_FIELD_VALUE = 'Libero'

const props = defineProps<{
  patientId: string
  diet?: string
  autoCreate?: boolean
  readonly?: boolean
}>()

const getInitialData = (): RecursivePartial<NewDiet> => ({
  diet: Object.fromEntries(
    WEEKDAYS.map(d => [
      d,
      Object.fromEntries(
        MEALS.map(m => [m, { description: DEFAULT_FIELD_VALUE }])
      )
    ])
  )
})

const emit = defineEmits<{
  (e: 'created', diet: NewDiet): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<RecursivePartial<NewDiet>>(getInitialData())
const currentDay = ref<RecursivePartial<(typeof WEEKDAYS)[number]>>('monday')
const isReadonly = ref(false)
const form = ref<QForm>()

const areDaysReady = computed(() => {
  return Object.fromEntries(
    WEEKDAYS.map(d => [
      d,
      MEALS.every(m => !!data.value.diet?.[d]?.[m]?.description)
    ])
  )
})

const isReady = computed(() =>
  Object.entries(areDaysReady.value).every(([, r]) => r)
)

const show = (diet?: Diet) => {
  data.value = diet !== undefined ? diet : getInitialData()
  isReadonly.value = diet !== undefined
  isDialogOpen.value = true
}

const createFrom = () => {
  data.value = { diet: data.value.diet }
  form.value?.reset()
  isReadonly.value = false
}

const cloneCurrentDay = () => {
  if (data.value.diet === undefined) return
  const daySchedule = data.value.diet[currentDay.value]
  for (const d of WEEKDAYS) {
    data.value.diet[d] = _.cloneDeep(daySchedule)
  }
}

const createDiet = () => {
  if (!isReady.value) return

  const _data = _.cloneDeep(data.value as NewDiet)

  if (props.autoCreate === false) {
    isDialogOpen.value = false
    data.value = getInitialData()
    return emit('created', _data)
  }

  createNewPatientDiet(props.patientId, _data)
    .then(() => {
      notify('Dieta creata con successo', 'positive')
      isDialogOpen.value = false
      data.value = getInitialData()
      emit('created', _data)
    })
    .catch(() => notify('Impossibile creare la dieta', 'negative'))
}

defineExpose({
  show
})
</script>

<template>
  <q-dialog v-model="isDialogOpen">
    <q-card style="width: 700px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div v-if="!isReadonly" class="text-h6">Nuova dieta</div>
        <div v-else class="text-h6">Dieta</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form ref="form" greedy @submit="createDiet">
        <q-card-section>
          <q-select-report
            v-if="props.autoCreate"
            v-model="data.reportId"
            :readonly="isReadonly"
            class="q-mb-md"
            :rules="['required']"
            :patient-id="props.patientId"
            label="Referto di riferimento" />

          <q-tabs
            v-model="currentDay"
            dense
            class="text-grey"
            active-color="primary"
            indicator-color="primary"
            align="justify"
            narrow-indicator>
            <q-tab
              v-for="d in WEEKDAYS"
              :key="d"
              :name="d"
              :label="WEEKDAYS_TRANSLATION[d]">
              <q-badge
                v-if="!areDaysReady?.[d]"
                color="orange"
                floating
                rounded></q-badge>
            </q-tab>
          </q-tabs>

          <q-separator />

          <q-tab-panels v-model="currentDay" animated keep-alive>
            <q-tab-panel
              v-for="d in WEEKDAYS"
              :key="d"
              style="max-height: 50vh"
              :name="d">
              <div v-for="m in MEALS" :key="m" class="q-pb-md">
                <q-input
                  v-model="data.diet[d][m].description"
                  filled
                  :readonly="isReadonly"
                  type="textarea"
                  :rules="[v => !!v || 'Campo obbligatorio']"
                  :label="MEALS_TRANSLATION[m]" />
              </div>
            </q-tab-panel>
          </q-tab-panels>
        </q-card-section>

        <q-card-actions
          v-if="!props.readonly"
          align="right"
          class="text-primary">
          <q-btn
            v-if="isReadonly"
            flat
            label="Crea dieta a partire da questa"
            @click="createFrom()" />
          <q-btn
            v-if="!isReadonly"
            flat
            label="Copia giornata su tutta la settimana"
            @click="cloneCurrentDay()" />
          <q-btn v-if="!isReadonly" flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
