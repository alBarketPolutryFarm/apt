import { DateTime } from 'luxon'
import { ApexOptions } from 'apexcharts'
import { QTableProps } from 'quasar'
import { DietOutMeal } from 'src/api/patients/diets/models'

export const DEFAULT_CHART_OPTIONS: ApexOptions = {
  chart: {
    animations: {
      enabled: true
    },
    zoom: {
      enabled: true
    },
    toolbar: {
      tools: {
        zoomin: false,
        zoomout: false,
        zoom: false,
        reset: false,
        pan: false
      }
    },
    height: 250,
    type: 'bar',
    stacked: true
  },
  grid: {
    xaxis: {
      lines: {
        show: true
      }
    }
  },
  dataLabels: {
    formatter: (val: number) => `${val * 5}%`,
    enabled: true,
    dropShadow: {
      enabled: true,
      left: 2,
      top: 2,
      opacity: 0.5
    }
  },
  fill: {
    type: 'solid'
  },
  yaxis: {
    min: 0,
    max: 100
  },
  xaxis: {
    type: 'datetime',
    tickPlacement: 'on',
    labels: {
      datetimeUTC: false
    }
  },
  tooltip: {
    custom: () => '',
    x: {
      formatter: (v: number) =>
        DateTime.fromMillis(v).toLocaleString(DateTime.DATE_MED)
    }
  }
}

export const COLUMNS_OUT_MEALS: QTableProps['columns'] = [
  {
    name: 'at',
    label: 'Data',
    align: 'left',
    field: (row: DietOutMeal) => row.at,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED),
    sortable: true
  },
  {
    name: 'description',
    label: 'Descrizione',
    align: 'left',
    field: (row: DietOutMeal) => row.description,
    sortable: true
  }
]
