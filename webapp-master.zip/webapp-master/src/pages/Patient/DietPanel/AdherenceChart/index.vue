<script setup lang="ts">
import { ComponentPublicInstance, computed, ref, watch } from 'vue'
import {
  getPatientDietOutMeals,
  getPatientDietSchedule
} from 'src/api/patients/diets'
import useQuery from 'src/api/useQuery'
import { COLUMNS_OUT_MEALS, DEFAULT_CHART_OPTIONS } from './consts'
import { DateTime, Interval } from 'luxon'
import groupByDate from 'src/helpers/groupByDate'
import { QueryDate } from 'src/api/models'
import ApexChart from 'vue3-apexcharts'
import { MealStrings, MealTypes } from 'src/const/Meal'

const props = defineProps<{ patientId: string }>()

const chart = ref<ComponentPublicInstance<typeof ApexChart>>()

const dateRange = ref<Required<QueryDate>>({
  startDate: DateTime.now().minus({ days: 30 }),
  endDate: DateTime.now()
})

const query = useQuery(getPatientDietSchedule, ref(props.patientId), dateRange)

const interval = computed(() =>
  Interval.fromDateTimes(dateRange.value.startDate, dateRange.value.endDate)
)

const updateChart = (series: unknown) => {
  chart.value?.updateOptions(
    {
      series,
      xaxis: {
        min: dateRange.value.startDate.toMillis(),
        max: dateRange.value.endDate.toMillis()
      }
    },
    true,
    false,
    false
  )
}

watch(query, q => {
  if (!q.isSuccess || q.data === undefined || q.data.length === 0)
    return updateChart([{ data: [[]] }])

  const data = groupByDate(
    q.data,
    d => d.at,
    'day',
    interval.value,
    'ascendant'
  ).map(d => ({ date: d.interval.start, value: d.items.pop() }))

  const series = MealTypes.map(m => ({
    name: MealStrings[m],
    data: data
      .map(d => ({ date: d.date.toMillis(), value: d.value?.[m] }))
      .map(d => [
        d.date,
        d.value ? ((d.value.adherence?.adherence ?? 0) * 100) / 5 : undefined
      ])
  }))

  return updateChart(series)
})

const queryOutMeals = useQuery(
  getPatientDietOutMeals,
  ref(props.patientId),
  dateRange
)
</script>

<template>
  <apex-chart
    ref="chart"
    :options="DEFAULT_CHART_OPTIONS"
    :series="[{ data: [[]] }]"
    :height="400" />

  <q-table
    :rows="queryOutMeals.data"
    :columns="COLUMNS_OUT_MEALS"
    row-key="_id"
    class="row"
    :loading="queryOutMeals.isLoading">
    <template #no-data>
      <div class="full-width row flex-center text-primary q-gutter-sm">
        <div v-if="query.isError">
          <q-icon size="2em" name="sentiment_dissatisfied" />
          Impossibile caricare i fuori pasto
        </div>
        <div v-else-if="query.isSuccess">Nessun fuori pasto presente</div>
      </div>
    </template>
  </q-table>
</template>
