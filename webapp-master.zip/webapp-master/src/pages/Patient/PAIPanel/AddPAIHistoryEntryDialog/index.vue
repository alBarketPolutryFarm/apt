<script setup lang="ts">
import { ref } from 'vue'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import QInputDate from 'src/components/QInputDate'
import { NewPAIHistoryEntry } from 'src/api/patients/pai/models'
import notify from 'src/helpers/notify'
import { updatePatientPAIHistory } from 'src/api/patients/pai'

const props = defineProps<{
  patientId: string
  paiId: string
}>()

const emit = defineEmits<{
  (e: 'created'): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<RecursivePartial<NewPAIHistoryEntry>>({})
const isReadonly = ref(false)

const handleSubmit = () =>
  updatePatientPAIHistory(
    props.patientId,
    props.paiId,
    data.value as NewPAIHistoryEntry
  )
    .then(() => {
      notify('PAI aggiornato con successo', 'positive')
      isDialogOpen.value = false
      data.value = {}
      emit('created')
    })
    .catch(() => notify('Impossibile aggiornare il PAI', 'warning'))

defineExpose({
  show: () => (isDialogOpen.value = true)
})
</script>

<template>
  <q-dialog v-model="isDialogOpen">
    <q-card style="width: 400px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Aggiorna PAI</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-input
            v-model="data.description"
            label="Interventi assistenziali"
            :rules="[v => !!v || 'Campo richiesto']" />
          <q-input
            v-model="data.hostStructure"
            label="Struttura ospitante"
            :rules="[v => !!v || 'Campo richiesto']" />
          <q-input-date v-model="data.nextCheck" label="Prossimo accesso" />
          <q-select
            v-model="data.condition"
            :options="[
              { value: 'improved', label: 'Migliorate' },
              { value: 'stationary', label: 'Stazionarie' },
              { value: 'deteriorated', label: 'Peggiorate' }
            ]"
            :rules="[v => !!v || 'Campo richiesto']"
            map-options
            emit-value />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn v-if="!isReadonly" flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
