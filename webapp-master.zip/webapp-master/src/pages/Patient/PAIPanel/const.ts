import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { PAI } from 'src/api/patients/pai/models'

export const COLUMNS: Readonly<QTableProps['columns']> = [
  {
    name: 'diagnosis',
    label: 'Diagnosi',
    align: 'left',
    field: (row: PAI) => row.diagnosis,
    sortable: true
  },
  {
    name: 'goal',
    label: 'Obiettivo',
    align: 'left',
    field: (row: PAI) => row.goal,
    sortable: true
  },

  {
    name: 'lastUpdate',
    label: 'Ultimo aggiornamento',
    align: 'left',
    field: (row: PAI) => row.lastUpdate,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_FULL),
    sortable: true
  },
  {
    name: 'actions',
    label: '',
    align: 'center',
    field: (row: PAI) => row
  }
] as const

export const COLUMNS_COMPLETED: Readonly<QTableProps['columns']> = [
  {
    name: 'reason',
    label: 'Motivo',
    align: 'left',
    field: (row: PAI) => row.reason,
    sortable: false
  },
  {
    name: 'completedAt',
    label: 'Completato il',
    align: 'left',
    field: (row: PAI) => row.completedAt,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_FULL),
    sortable: true
  },
  ...COLUMNS
] as const

export const COLUMNS_COMPLETED_EXTENDED: Readonly<QTableProps['columns']> = [
  {
    name: 'closedBy',
    label: 'Completato da',
    align: 'left',
    field: (row: PAI) => row.closedBy,
    sortable: false
  },
  ...COLUMNS_COMPLETED
] as const
