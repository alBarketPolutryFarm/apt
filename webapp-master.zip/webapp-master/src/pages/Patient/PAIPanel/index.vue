<script setup lang="ts">
import { watch, computed } from 'vue'
import notify from 'src/helpers/notify'
import CreatePaiDialog from './CreatePAIDialog'
import PaiHistoryTable from './PAIHistoryTable'
import { getPatientPAI } from 'src/api/patients/pai'
import { COLUMNS, COLUMNS_COMPLETED_EXTENDED } from './const'
import useLogin from 'src/helpers/useLogin'
import useQuery from 'src/api/useQuery'
import { getNurses } from 'src/api/nurses'

const props = defineProps<{ patientId: string }>()

const login = useLogin()
const nurses = login.value.user?.type === 'admin' ? useQuery(getNurses) : null

const query = useQuery(
  getPatientPAI,
  computed(() => props.patientId),
  computed(() => ({ status: 'active' }) as const)
)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista dei PAI', 'negative')
})

const queryCompleted = useQuery(
  getPatientPAI,
  computed(() => props.patientId),
  computed(() => ({ status: 'completed' }) as const)
)

watch(queryCompleted, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista dei PAI completati', 'negative')
})

const refetch = () => {
  query.refetch()
  queryCompleted.refetch()
}
</script>

<template>
  <div>
    <div class="row no-wrap justify-between q-pb-md">
      <div class="text-h6">PAI</div>

      <div class="row no-wrap justify-between q-pb-md" style="gap: 10px">
        <q-btn
          v-if="login.user?.type != 'admin' || login.user?.type != 'superadmin'"
          icon="add"
          color="primary"
          @click="$refs.createDialog.show()" />
      </div>
    </div>

    <q-table
      :rows="query.data"
      :columns="COLUMNS"
      row-key="_id"
      class="row"
      :loading="query.isLoading">
      <template #body="bodyProps">
        <q-tr :props="bodyProps">
          <q-td
            v-for="col in bodyProps.cols"
            :key="col.name"
            :props="bodyProps">
            <template v-if="col.name === 'actions'">
              <q-btn
                round
                color="blue"
                size="sm"
                class="q-ml-lg"
                :icon="bodyProps.expand ? 'visibility_off' : 'visibility'"
                @click="bodyProps.expand = !bodyProps.expand">
                <q-tooltip v-if="bodyProps.expand">Nascondi storico</q-tooltip>
                <q-tooltip v-else>Mostra storico</q-tooltip>
              </q-btn>
            </template>
            <template v-else>
              {{ col.value }}
            </template>
          </q-td>
        </q-tr>

        <q-tr v-show="bodyProps.expand" :props="bodyProps">
          <q-td colspan="100%">
            <pai-history-table
              :readonly="
                login.user?.type == 'admin' || login?.user?.type == 'superadmin'
              "
              :pai="bodyProps.row"
              @updated="refetch()" />
          </q-td>
        </q-tr>
      </template>

      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare i PAI
          </div>
          <div v-else-if="query.isSuccess">Nessun piano PAI presente</div>
        </div>
      </template>
    </q-table>

    <q-expansion-item
      switch-toggle-side
      expand-separator
      class="q-ma-sm"
      label="PAI completati">
      <q-card>
        <q-card-section>
          <q-table
            :rows="queryCompleted.data"
            :columns="COLUMNS_COMPLETED_EXTENDED"
            row-key="_id"
            class="row"
            :loading="queryCompleted.isLoading">
            <template #body="bodyProps">
              <q-tr :props="bodyProps">
                <q-td
                  v-for="col in bodyProps.cols"
                  :key="col.name"
                  :props="bodyProps">
                  <template v-if="col.name === 'actions'">
                    <q-btn
                      round
                      color="blue"
                      size="sm"
                      class="q-ml-lg"
                      :icon="bodyProps.expand ? 'visibility_off' : 'visibility'"
                      @click="bodyProps.expand = !bodyProps.expand">
                      <q-tooltip v-if="bodyProps.expand"
                        >Nascondi storico</q-tooltip
                      >
                      <q-tooltip v-else>Mostra storico</q-tooltip>
                    </q-btn>
                  </template>
                  <template v-else-if="col.name === 'closedBy'">
                    <q-td style="padding-left: 0px">
                      <div class="row">
                        {{
                          col.value
                            ? login.user?.type === 'admin'
                              ? `${
                                  nurses?.data?.find(n => n._id === col.value)
                                    ?.firstName
                                } ${
                                  nurses?.data?.find(n => n._id === col.value)
                                    ?.lastName
                                }`
                              : col.value === login.user?._id
                              ? `${login.user?.firstName} ${login.user?.lastName}`
                              : 'Altri'
                            : ''
                        }}
                      </div>
                    </q-td>
                  </template>
                  <template v-else>
                    {{ col.value }}
                  </template>
                </q-td>
              </q-tr>

              <q-tr v-show="bodyProps.expand" :props="bodyProps">
                <q-td colspan="100%">
                  <pai-history-table
                    :readonly="true"
                    :pai="bodyProps.row"
                    @updated="refetch()" />
                </q-td>
              </q-tr>
            </template>

            <template #no-data>
              <div class="full-width row flex-center text-primary q-gutter-sm">
                <div v-if="queryCompleted.isError">
                  <q-icon size="2em" name="sentiment_dissatisfied" />
                  Impossibile caricare i PAI completati
                </div>
                <div v-else-if="queryCompleted.isSuccess">
                  Nessun piano PAI completato presente
                </div>
              </div>
            </template>
          </q-table>
        </q-card-section>
      </q-card>
    </q-expansion-item>
  </div>

  <create-pai-dialog
    ref="createDialog"
    :patient-id="patientId"
    :readonly="false"
    @created="refetch()" />
</template>
