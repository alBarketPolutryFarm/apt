<script setup lang="ts">
import { ref } from 'vue'

const emit = defineEmits<{
  (e: 'completionReasonSubmitted', reason: string): void
}>()

const completionReasons = [
  'Decesso',
  'Ricovero',
  'Guarigione',
  'Chiusura amministrativa',
  "Infezione correlata all'assistenza"
]

const isDialogOpen = ref(false)
const completionReason = ref('')

const openDialog = () => {
  isDialogOpen.value = true
  completionReason.value = ''
  return new Promise<string>(resolve => {
    resolve(completionReason.value)
  })
}

const handleSubmit = () => {
  if (completionReason.value.trim() !== '') {
    emit('completionReasonSubmitted', completionReason.value)
    isDialogOpen.value = false
  }
}

defineExpose({
  openDialog
})
</script>

<template>
  <q-dialog v-model="isDialogOpen">
    <q-card style="width: 400px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Motivo di chiusura del PAI</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form @submit.prevent="handleSubmit">
        <q-card-section>
          <q-select
            v-model="completionReason"
            :options="completionReasons"
            filled
            label="Seleziona motivo"
            class="q-my-md" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn flat type="submit" label="Salva" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
