import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { PAIHistoryEntry } from 'src/api/patients/pai/models'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'at',
    label: 'Data',
    align: 'left',
    field: (row: PAIHistoryEntry) => row.at,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_FULL),
    sortable: true
  },
  {
    name: 'description',
    label: 'Diagnosi',
    align: 'left',
    field: (row: PAIHistoryEntry) => row.description,
    sortable: false
  },
  {
    name: 'hostStructure',
    label: 'Struttura ospitante',
    align: 'left',
    field: (row: PAIHistoryEntry) => row.hostStructure,
    sortable: false
  },
  {
    name: 'condition',
    label: 'Condizione',
    align: 'left',
    field: (row: PAIHistoryEntry) => row.condition,
    sortable: false
  },
  {
    name: 'nextCheck',
    label: 'Prossimo accesso',
    align: 'left',
    field: (row: PAIHistoryEntry) => row.nextCheck,
    format: (v?: DateTime) => v?.toLocaleString(DateTime.DATE_FULL),
    sortable: true
  }
]
