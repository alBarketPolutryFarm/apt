<script setup lang="ts">
import { nextTick, ref, watch } from 'vue'
import { NewPAIHistoryEntry, PAI } from 'src/api/patients/pai/models'
import AddPaiHistoryEntryDialog from '../AddPAIHistoryEntryDialog'
import { COLUMNS } from './const'
import {
  setPatientPAIAsCompleted,
  updatePatientPAIHistory
} from 'src/api/patients/pai'
import notify from 'src/helpers/notify'
import PaiCompleteDialog from './PAICompleteDialog/index.vue'

const props = defineProps<{
  pai: PAI
  readonly?: boolean
}>()

const emit = defineEmits<{
  (e: 'updated'): void
}>()

const paiCompleteDialogRef = ref<InstanceType<typeof PaiCompleteDialog> | null>(
  null
)

const handleCompleted = async () => {
  paiCompleteDialogRef.value?.openDialog()
}

const completionReason = ref('')

watch(completionReason, async completionReason => {
  if (completionReason.trim() !== '') {
    setPatientPAIAsCompleted(
      props.pai.patientId,
      props.pai._id,
      completionReason
    )
      .then(() => {
        notify('PAI aggiornato con successo', 'positive')
        completionReason = ''
        emit('updated')
      })
      .catch(() => notify('Impossibile aggiornare il PAI', 'warning'))
  }
})
</script>

<template>
  <q-table
    :rows="props.pai.history"
    row-key="_id"
    class="row"
    :columns="COLUMNS">
    <template #top-left>Storico</template>

    <template v-if="!readonly" #top-right>
      <q-btn
        class="q-mx-sm"
        icon="done"
        color="primary"
        @click="handleCompleted()">
        <q-tooltip>Segna come completato</q-tooltip>
      </q-btn>
      <q-btn
        class="q-mx-sm"
        icon="add"
        color="primary"
        @click="$refs.dialog.show()">
        <q-tooltip>Aggiungi elemento allo storico</q-tooltip>
      </q-btn>
    </template>

    <template #body-cell-condition="{ value }">
      <q-td>
        <q-icon
          v-if="value === 'improved'"
          color="green"
          name="fa-solid fa-arrow-trend-up" />
        <q-icon
          v-else-if="value === 'deteriorated'"
          color="red"
          name="fa-solid fa-arrow-trend-down" />
        <q-icon
          v-else-if="value === 'stationary'"
          color="black"
          name="fa-solid fa-arrow-right-long" />
      </q-td>
    </template>

    <template #no-data>
      <div class="full-width row flex-center text-primary q-gutter-sm">
        Storico PAI vuoto
      </div>
    </template>
  </q-table>

  <add-pai-history-entry-dialog
    ref="dialog"
    :patient-id="props.pai.patientId"
    :pai-id="props.pai._id"
    @created="emit('updated')" />

  <pai-complete-dialog
    ref="paiCompleteDialogRef"
    @completion-reason-submitted="completionReason = $event" />
</template>
