<script setup lang="ts">
import { ref } from 'vue'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import { NewPAI } from 'src/api/patients/pai/models'
import notify from 'src/helpers/notify'
import { createPatientPAI } from 'src/api/patients/pai'

const props = defineProps<{
  patientId: string
}>()

const emit = defineEmits<{
  (e: 'created'): void
}>()

const isDialogOpen = ref<boolean>(false)
const data = ref<RecursivePartial<NewPAI>>({})

const handleSubmit = () =>
  createPatientPAI(props.patientId, data.value as NewPAI)
    .then(() => {
      notify('PAI creato con successo', 'positive')
      isDialogOpen.value = false
      data.value = {}
      emit('created')
    })
    .catch(() => notify('Impossibile creare il PAI', 'warning'))

defineExpose({
  show: () => (isDialogOpen.value = true)
})
</script>

<template>
  <q-dialog v-model="isDialogOpen">
    <q-card style="width: 400px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Nuovo PAI</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-input
            v-model="data.diagnosis"
            label="Diagnosi (NANDA)"
            :rules="[v => !!v || 'Campo richiesto']" />
          <q-input
            v-model="data.goal"
            label="Obiettivo"
            :rules="[v => !!v || 'Campo richiesto']" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn v-if="!isReadonly" flat label="Crea" type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
