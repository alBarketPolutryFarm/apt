<script setup lang="ts">
import { onUnmounted, ref, watch } from 'vue'
import { getPatientMeasuresSummary } from 'src/api/patients/measures'
import notify from 'src/helpers/notify'
import MeasureChart from 'src/components/MeasureChart'
import {
  MeasureIcons,
  MeasureStrings,
  MeasureType,
  MeasureTypes,
  MeasureUnits
} from 'src/const/Measure'
import useQuery from 'src/api/useQuery'

const props = defineProps<{ patientId: string }>()

const measuresSummaryQuery = useQuery(
  getPatientMeasuresSummary,
  ref(props.patientId)
)

watch(measuresSummaryQuery, query => {
  if (!query.isError) return
  notify('Impossibile recuperare il sommario delle misurazioni', 'negative')
})

const isAutoUpdateEnabled = ref<boolean>(true)
const autoUpdateInterval = ref<ReturnType<typeof setInterval>>()

watch(
  isAutoUpdateEnabled,
  isEnabled => {
    if (isEnabled)
      autoUpdateInterval.value = setInterval(
        measuresSummaryQuery.refetch,
        10 * 1e3
      )
    else {
      clearInterval(autoUpdateInterval.value)
      autoUpdateInterval.value = undefined
    }
  },
  { immediate: true }
)
onUnmounted(() => {
  if (isAutoUpdateEnabled.value) clearInterval(autoUpdateInterval.value)
})

const currentMeasureType = ref<MeasureType>()
</script>

<template>
  <div>
    <div class="row no-wrap justify-between q-pb-md">
      <div class="text-h6">Misurazioni</div>
    </div>

    <q-list separator>
      <q-expansion-item
        v-for="t in MeasureTypes"
        :key="t"
        group="charts"
        expand-separator
        :icon="MeasureIcons[t]"
        :label="MeasureStrings[t]"
        :caption="`${
          t === 'bloodPressure'
            ? `${measuresSummaryQuery.data?.[t]?.systolic ?? '-'}/${
                measuresSummaryQuery.data?.[t]?.diastolic ?? '-'
              }`
            : t === 'waterBalance'
            ? `${measuresSummaryQuery.data?.[t]?.value ?? '-'} -> ${
                measuresSummaryQuery.data?.[t]?.total ?? '-'
              }`
            : measuresSummaryQuery.data?.[t]?.value ?? '-'
        } ${MeasureUnits[t] ?? ''}`"
        @hide="currentMeasureType = undefined"
        @show="currentMeasureType = t">
        <measure-chart
          :is-enabled="currentMeasureType === t"
          :type="t"
          :patient-id="props.patientId" />
      </q-expansion-item>
    </q-list>
  </div>
</template>

<style scoped>
.pointed {
  cursor: pointer;
}
</style>
<style lang="sass">
.my-menu-link
  color: white !important
  background: #26a69a
</style>
<style lang="scss" scoped>
.step1_btn {
  background: $palette_color_1;
  color: white;
}

.step2_btn {
  color: $palette_color_1;
}
</style>
