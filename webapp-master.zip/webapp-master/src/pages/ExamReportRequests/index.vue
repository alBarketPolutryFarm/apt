<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import useQuery from 'src/api/useQuery'
import { COLUMNS } from './const'
import {
  getExamReportRequestExamEncodedFile,
  getExamReportRequests
} from 'src/api/exam_report_requests'
import useLogin from 'src/helpers/useLogin'
import downloadFileEncoded from 'src/helpers/downloadFileEncoded'
import Actions from './Actions'
import { DateTime } from 'luxon'
import ReportBadge from 'pages/Patient/ReportsPanel/ReportBadge/index.vue'
import UserFetcher from 'components/UserFetcher/index.vue'

const login = useLogin()

const showOld = ref<boolean>(false)

const param = computed(() => ({
  startDate: showOld.value ? undefined : DateTime.now().minus({ days: 7 })
}))

const query = useQuery(getExamReportRequests, param)

watch(query, q => {
  if (!q.isError) return
  notify('Impossibile recuperare la lista degli esami da refertare', 'negative')
})

const downloadExam = (requestId: string) =>
  downloadFileEncoded(getExamReportRequestExamEncodedFile(requestId))
</script>

<template>
  <q-page class="q-pa-lg">
    <h6 class="q-ma-none">
      Esami da refertare
      <template
        v-if="
          login.user?.type === 'admin' || login.user?.type === 'superadmin'
        ">
        (Senza paziente associato)
      </template>
    </h6>

    <q-separator class="q-my-md" />

    <q-table
      :rows="query.data"
      :columns="COLUMNS"
      row-key="_id"
      class="row"
      :loading="query.isLoading">
      <template #top-right>
        <q-chip
          v-model:selected="showOld"
          clickable
          :color="showOld ? 'primary' : 'disabled'"
          :text-color="showOld ? 'white' : 'black'">
          Mosta archiviati
        </q-chip>
      </template>

      <template #body-cell-status="{ value: { report } }">
        <q-td>
          <report-badge v-if="report" :report="report" />
          <q-chip v-else round label="Da refertare" color="blue" />
        </q-td>
      </template>

      <template #body-cell-reporter="{ value }">
        <q-td>
          <user-fetcher v-if="value" :user-id="value" />
        </q-td>
      </template>

      <template #body-cell-modalities="{ value }">
        <q-td>
          <q-chip v-for="v in value" :key="v" round :label="v" />
        </q-td>
      </template>

      <template #body-cell-actions="{ value }">
        <q-td>
          <actions :exam-report-request="value" @change="query.refetch()" />
        </q-td>
      </template>

      <template #no-data>
        <div class="full-width row flex-center text-primary q-gutter-sm">
          <div v-if="query.isError">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            Impossibile caricare gli esami da refertare
          </div>
          <div v-else-if="query.isSuccess">Nessun esame da refertare</div>
        </div>
      </template>
    </q-table>
  </q-page>
</template>
