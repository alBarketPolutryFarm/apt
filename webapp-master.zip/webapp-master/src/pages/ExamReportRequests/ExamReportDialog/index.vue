<script setup lang="ts">
import { ref, watch, computed, toRaw } from 'vue'
import RecursivePartial from 'src/helpers/typescript/RecursivePartial'
import notify from 'src/helpers/notify'
import {
  ExamReport,
  MedicalExaminationReport,
  NewExamReport
} from 'src/api/patients/reports/models'
import useMutation from 'src/api/useMutation'
import {
  createExamReportRequestReport,
  editExamReportRequestReport
} from 'src/api/exam_report_requests'
import { ExamReportRequest } from 'src/api/exam_report_requests/models'
import { FormExamReport } from 'src/api/patients/reports/models/ExamReport'
import { FormMedicalExaminationReport } from 'src/api/patients/reports/models/MedicalExaminationReport'
import _ from 'lodash'
import { editPatientReport } from 'src/api/patients/reports'
import cleanObject from 'src/helpers/cleanObject'
import { createPatch } from 'rfc6902'

const emit = defineEmits<{
  (e: 'create'): void
  (e: 'edit'): void
}>()

const initialValue = (): FormExamReport => ({
  description: '',
  conclusion: ''
})
const completeToNew = (r: ExamReport): FormExamReport => {
  return {
    description: r.description,
    conclusion: r.conclusion
  }
}

const request = ref<ExamReportRequest>()

const isDialogOpen = ref<boolean>(false)
const data = ref<FormExamReport>(initialValue())
const isReadonly = ref(false)

const editReport = ref<ExamReport>()
const isEdit = computed(() => editReport.value !== undefined)

const reset = () => (data.value = initialValue())
reset()

defineExpose({
  show: (_request: ExamReportRequest) => {
    reset()
    request.value = _request
    if (_request.report) {
      data.value = completeToNew(_.cloneDeep(_request.report))
      editReport.value = _.cloneDeep(_request.report)
    }
    isDialogOpen.value = true
  }
})

const [create, createStatus] = useMutation(createExamReportRequestReport)

watch(createStatus, q => {
  if (!q.isSuccess) return
  notify('Referto inserito con successo', 'positive')
  isDialogOpen.value = false
  reset()
  emit('create')
})
watch(createStatus, q => {
  if (!q.isError) return
  notify('Impossibile creare il referto', 'warning')
})

const [edit, editStatus] = useMutation(editExamReportRequestReport)

watch(editStatus, q => {
  if (!q.isSuccess) return
  notify('Referto modifcato con successo', 'positive')
  isDialogOpen.value = false
  reset()
  emit('edit')
})
watch(editStatus, q => {
  if (!q.isError) return
  notify('Impossibile modificare il referto', 'warning')
})

const handleSubmit = () => {
  if (!request.value) return
  if (isEdit.value && editReport.value) {
    const newData = cleanObject(_.cloneDeep(toRaw(data.value)))
    const editData = cleanObject(
      completeToNew(_.cloneDeep(toRaw(editReport.value)))
    )
    const patch = createPatch(editData, newData)
    if (patch.length === 0) return
    edit(request.value?._id, patch)
  } else
    create(request.value._id, {
      type: 'exam',
      ...data.value
    } as NewExamReport)
}
</script>

<template>
  <q-dialog v-model="isDialogOpen" no-backdrop-dismiss>
    <q-card style="width: 1000px; max-width: 80vw">
      <q-card-section class="row items-center q-pb-none">
        <div v-if="isEdit" class="text-h6">Modifca referto esame</div>
        <div v-else class="text-h6">Crea referto esame</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-input
            v-model="data.description"
            label="Descrizione referto"
            :rules="[v => !!v || 'Descrizione richiesta']" />

          <q-input
            v-model="data.conclusion"
            type="textarea"
            :rules="[v => !!v || 'Conclusioni richieste']"
            label="Conclusioni" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn
            v-if="!isReadonly && !isEdit"
            :loading="createStatus.isLoading"
            flat
            label="Crea"
            type="submit" />
          <q-btn
            v-if="!isReadonly && isEdit"
            :loading="editStatus.isLoading"
            flat
            label="Modifica"
            type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
