import { QTableProps } from 'quasar'
import { DateTime } from 'luxon'
import { ExamReportRequest } from 'src/api/exam_report_requests/models'

export const COLUMNS: QTableProps['columns'] = [
  {
    name: 'at',
    label: 'Data',
    align: 'left',
    field: (row: ExamReportRequest) => row.createdAt,
    format: (v: DateTime) => v.toLocaleString(DateTime.DATETIME_MED)
  },
  {
    name: 'reporter',
    label: 'Refertatore',
    align: 'left',
    field: (row: ExamReportRequest) => row.report?.createdBy
  },
  {
    name: 'reportDatetime',
    label: 'Data referto',
    align: 'left',
    field: (row: ExamReportRequest) => row.report?.createdAt,
    format: (v: DateTime) => v?.toLocaleString(DateTime.DATETIME_MED)
  },
  {
    name: 'status',
    label: 'Stato',
    align: 'center',
    field: (row: ExamReportRequest) => row
  },
  {
    name: 'modalities',
    label: 'Tipologia',
    align: 'center',
    field: (row: ExamReportRequest) => row.exam.modalities
  },
  {
    name: 'actions',
    label: '',
    align: 'center',
    field: (row: ExamReportRequest) => row
  }
]
