<script setup lang="ts">
import { ref, watch } from 'vue'
import notify from 'src/helpers/notify'
import useMutation from 'src/api/useMutation'
import { updateExamReportRequest } from 'src/api/exam_report_requests'
import { ExamReportRequest } from 'src/api/exam_report_requests/models'
import QSelectUser from 'src/components/QSelectUser'

const emit = defineEmits<{
  (e: 'set'): void
}>()

const isDialogOpen = ref<boolean>(false)

const examReportRequest = ref<ExamReportRequest>()

const patientId = ref<string>()

const reset = () => (patientId.value = undefined)
reset()

defineExpose({
  show: (_request: ExamReportRequest) => {
    reset()
    examReportRequest.value = _request
    isDialogOpen.value = true
  }
})

const [update, updateStatus] = useMutation(updateExamReportRequest)

watch(updateStatus, q => {
  if (!q.isSuccess) return
  notify('Richiesta aggiornata con successo', 'positive')
  isDialogOpen.value = false
  reset()
  emit('set')
})
watch(updateStatus, q => {
  if (!q.isError) return
  notify('Impossibile creare il referto', 'warning')
})

const handleSubmit = () => {
  if (!examReportRequest.value) return
  if (!patientId.value) return
  update(examReportRequest.value._id, [
    {
      path: '/patientId',
      op: 'replace',
      value: patientId.value
    }
  ])
}
</script>

<template>
  <q-dialog v-model="isDialogOpen" no-backdrop-dismiss>
    <q-card>
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">Associa esame a paziente</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-form greedy @submit="handleSubmit">
        <q-card-section>
          <q-select-user
            v-model="patientId"
            user-type="patient"
            label="Paziente"
            :rules="['required']" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn
            :loading="updateStatus.isLoading"
            flat
            label="Associa"
            type="submit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>
