<script setup lang="ts">
import { DateTime } from 'luxon'
import useLogin from 'src/helpers/useLogin'
import downloadFileEncoded from 'src/helpers/downloadFileEncoded'
import { Report } from 'src/api/patients/reports/models'
import {
  getPatientReportExamFile,
  getPatientReportFile,
  startSignatureProcessPatientReport
} from 'src/api/patients/reports'
import { QDialog } from 'quasar'
import { ref, watch } from 'vue'
import useQuery from 'src/api/useQuery'
import useMutation from 'src/api/useMutation'
import notify from 'src/helpers/notify'
import {
  getExamReportRequestReportEncodedFile,
  startSignatureProcessExamReportRequestReport
} from 'src/api/exam_report_requests'
import { ExamReportRequest } from 'src/api/exam_report_requests/models'
import _ from 'lodash'

const props = defineProps<{
  examReportRequest: ExamReportRequest
}>()

const emit = defineEmits<{
  (e: 'change'): void
}>()

const isDialogOpen = ref<boolean>(false)

defineExpose({
  show: () => {
    isDialogOpen.value = true
  }
})

const login = useLogin()

const downloadReport = () =>
  downloadFileEncoded(
    getExamReportRequestReportEncodedFile(props.examReportRequest._id)
  )

const downloadExam = (reportId: string) =>
  downloadFileEncoded(
    getPatientReportExamFile(props.examReportRequest.patientId ?? '', reportId)
  )

const startSignDialogRef = ref<QDialog>()

const [startSignatureProcess, signatureProcessStatus] = useMutation(
  startSignatureProcessExamReportRequestReport
)
watch(signatureProcessStatus, s => {
  if (!s.isLoading && s.isError) {
    if (s.statusCode === 428)
      notify(
        'Numero massimo di firme raggiunto, contattare la centrale operativa',
        'negative'
      )
    else notify('Impossibile avviare la procedura di firma', 'negative')
  }
})

watch(signatureProcessStatus, s => {
  if (s.isLoading || !s.isSuccess || !s.data) return
  startSignDialogRef.value?.hide()
  emit('change')
  window.open(s.data.signature.link as string, '_blank')
})
</script>

<template>
  <q-dialog v-model="isDialogOpen" persistent>
    <q-card>
      <q-card-section>
        <div class="text-h6">Procedura di firma elettronica</div>
      </q-card-section>
      <q-card-section class="row items-center">
        <span class="q-ml-sm">
          Una volta iniziata la procedura di firma non sarà più possibile
          modificare il referto, pertanto
          <b>verficarne attentamente il contenuto prima di procedere</b>
        </span>
      </q-card-section>

      <q-card-actions class="row justify-between">
        <q-btn
          label="Scarica referto"
          color="grey-6"
          @click="downloadReport(props.examReportRequest.report?._id)" />
        <div class="q-gutter-sm">
          <q-btn v-close-popup label="Annulla" color="primary" />
          <q-btn
            label="Firma"
            color="negative"
            :loading="signatureProcessStatus.isLoading"
            @click="startSignatureProcess(props.examReportRequest._id)" />
        </div>
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>
