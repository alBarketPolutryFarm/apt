<script setup lang="ts">
import { computed, ref } from 'vue'
import { ExamReportRequest } from 'src/api/exam_report_requests/models'
import downloadFileEncoded from 'src/helpers/downloadFileEncoded'
import {
  getExamReportRequestExamEncodedFile,
  getExamReportRequestReportEncodedFile
} from 'src/api/exam_report_requests'
import useLogin from 'src/helpers/useLogin'
import ExamReportDialog from '../ExamReportDialog'
import SetPatientDialog from '../SetPatientDialog'
import StartSignExamReportDialog from '../StartSignExamReportDialog'
import ReportActions from 'src/pages/Patient/ReportsPanel/ReportActions'
import { QForm } from 'quasar'

const login = useLogin()

const props = defineProps<{
  examReportRequest: ExamReportRequest
}>()

const emit = defineEmits<{
  (e: 'change'): void
}>()

const setPatientDialogRef = ref<SetPatientDialog>()
const examReportDialogRef = ref<ExamReportDialog>()
const startSignExamReportDialogRef = ref<StartSignExamReportDialog>()

const downloadExam = () =>
  downloadFileEncoded(
    getExamReportRequestExamEncodedFile(props.examReportRequest._id)
  )

const downloadReport = () =>
  downloadFileEncoded(
    getExamReportRequestReportEncodedFile(props.examReportRequest._id)
  )

const canDownloadExam = computed(() => true)
const canDownloadReport = computed(
  () =>
    !!props.examReportRequest.report &&
    (login.value.user?.type === 'admin' ||
      login.value.user?._id === props.examReportRequest.report.createdBy ||
      login.user?.type === 'superadmin')
)
const canCreateReport = computed(
  () => !props.examReportRequest.report && login.value.user?.type === 'doctor'
)
const canEditReport = computed(
  () =>
    !!props.examReportRequest.report &&
    login.value.user?._id === props.examReportRequest.report.createdBy &&
    (!props.examReportRequest.report.signature ||
      props.examReportRequest.report.signature.status === 'failed')
)
const canSignReport = computed(
  () =>
    !!props.examReportRequest.report &&
    login.value.user?._id === props.examReportRequest.report.createdBy &&
    props.examReportRequest.report.signature?.link &&
    props.examReportRequest.report.signature.status === 'waiting'
)
const canStartSignReport = computed(
  () =>
    !!props.examReportRequest.report &&
    login.value.user?._id === props.examReportRequest.report.createdBy &&
    !props.examReportRequest.report.signature
)
const canAssociateToPatient = computed(
  () =>
    !props.examReportRequest.patientId &&
    (login.value.user?.type === 'admin' || login.user?.type === 'superadmin')
)
</script>

<template>
  <q-btn
    v-if="canDownloadExam"
    round
    icon="download"
    color="purple"
    size="sm"
    class="q-ml-lg"
    @click="downloadExam()">
    <q-tooltip>Scarica esame</q-tooltip>
  </q-btn>

  <q-btn
    v-if="canDownloadReport"
    round
    icon="fa-solid fa-file-arrow-down"
    color="blue"
    size="sm"
    class="q-ml-lg"
    @click="downloadReport()">
    <q-tooltip>Scarica il referto</q-tooltip>
  </q-btn>

  <q-btn
    v-if="canCreateReport"
    round
    icon="summarize"
    color="blue"
    size="sm"
    class="q-ml-lg"
    @click="examReportDialogRef?.show(props.examReportRequest)">
    <q-tooltip>Referta</q-tooltip>
  </q-btn>

  <q-btn
    v-if="canEditReport"
    round
    icon="edit"
    color="orange"
    size="sm"
    class="q-ml-lg"
    @click="examReportDialogRef?.show(props.examReportRequest)">
    <q-tooltip>Modifca il referto</q-tooltip>
  </q-btn>

  <q-btn
    v-if="canStartSignReport"
    round
    icon="draw"
    color="green"
    size="sm"
    class="q-ml-lg"
    type="a"
    target="_blank"
    @click="startSignExamReportDialogRef?.show()">
    <q-tooltip>Inizia la procedura di firma</q-tooltip>
  </q-btn>

  <q-btn
    v-if="canSignReport"
    round
    icon="draw"
    color="green"
    size="sm"
    class="q-ml-lg"
    type="a"
    target="_blank"
    :href="props.examReportRequest.report?.signature?.link">
    <q-tooltip>Firma il documento</q-tooltip>
  </q-btn>

  <q-btn
    v-if="canAssociateToPatient"
    round
    icon="link"
    color="red"
    size="sm"
    class="q-ml-lg"
    @click="setPatientDialogRef?.show(props.examReportRequest)">
    <q-tooltip>
      Il sistema non è riuscito ad associato questo esame ad alcun paziente<br />
      Procedi con l'associazione manuale
    </q-tooltip>
  </q-btn>

  <exam-report-dialog
    ref="examReportDialogRef"
    @create="emit('change')"
    @edit="emit('change')" />
  <set-patient-dialog ref="setPatientDialogRef" @set="emit('change')" />

  <start-sign-exam-report-dialog
    ref="startSignExamReportDialogRef"
    :exam-report-request="props.examReportRequest"
    @create="emit('change')"
    @edit="emit('change')" />
</template>
