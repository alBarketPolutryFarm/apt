<template>
  <q-layout view="lHh Lpr lFf">
    <q-page-container>
      <q-page padding class="column items-center justify-center">
        <q-card style="width: 400px; max-width: 80vw">
          <q-card-section>
            <div class="text-h6">Password dimenticata?</div>
          </q-card-section>

          <q-card-section>
            <q-input
              v-model="username"
              outlined
              label="Email o codice fiscale"
              :rules="[val => !!val || 'Inserisci email o codice fiscale']"
              :disable="isLoading" />
          </q-card-section>

          <q-card-actions align="right" class="text-primary">
            <q-btn
              :loading="isLoading"
              :disable="!isValidInput"
              flat
              label="Invia email di recupero"
              @click="handleForgotPassword" />
          </q-card-actions>

          <q-card-actions align="center" class="text-primary">
            <q-btn
              type="submit"
              class="q-ma-lg"
              @click="
                () => {
                  router.push('/login')
                }
              "
              >Login</q-btn
            >
          </q-card-actions>

          <q-card-section v-if="isSuccess" class="text-center text-positive">
            Ti abbiamo inviato un'email con le istruzioni per reimpostare la tua
            password.
          </q-card-section>
          <q-card-section v-if="isError" class="text-center text-negative">
            Errore durante l'invio dell'email. Riprova più tardi.
          </q-card-section>
        </q-card>
      </q-page>
    </q-page-container>
  </q-layout>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useQuasar } from 'quasar'
import { startForgotPasswordProcess } from 'src/api/auth'

const router = useRouter()
const $q = useQuasar()

const username = ref<string>('')
const isLoading = ref(false)
const isSuccess = ref(false)
const isError = ref(false)

const isValidInput = computed(() => username.value.trim().length > 0)

const handleForgotPassword = async () => {
  if (!isValidInput.value) return

  isLoading.value = true
  isSuccess.value = false
  isError.value = false

  try {
    await startForgotPasswordProcess({ username: username.value.trim() })
    isSuccess.value = true
    $q.notify({
      type: 'positive',
      message: 'Email di recupero inviata con successo.'
    })
  } catch (error) {
    console.error('Error during password reset:', error)
    isError.value = true
    $q.notify({
      type: 'negative',
      message: "Errore durante l'invio dell'email. Riprova più tardi."
    })
  } finally {
    isLoading.value = false
  }
}
</script>
