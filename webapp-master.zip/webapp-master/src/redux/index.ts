import { combineReducers, configureStore } from '@reduxjs/toolkit'
import { createTransform, persistReducer, persistStore } from 'redux-persist'
import { setupListeners } from '@reduxjs/toolkit/query'
import auth from './auth'
import storage from 'redux-persist/lib/storage'
import chats from './chats'
import { jsonParse, makeSerializable } from 'src/helpers/serialization'
import users from './users'

const rootReducer = combineReducers({
  auth,
  chats,
  users
})

const persistedReducer = persistReducer(
  {
    key: 'root',
    version: 1,
    storage,
    blacklist: ['users'],
    transforms: [
      createTransform(
        <T, H>(
          s: T,
          reducer: string | number | symbol,
          encoded: Record<string | number | symbol, string>
        ): H => makeSerializable(encoded[reducer]) as H,
        <T, H>(
          s: T,
          reducer: string | number | symbol,
          encoded: Record<string | number | symbol, string>
        ): H => jsonParse(encoded[reducer]) as H
      )
    ]
  },
  rootReducer
) as unknown as typeof rootReducer

export const store = configureStore({
  reducer: persistedReducer,
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: false
    })
})

setupListeners(store.dispatch)

export const persistor = persistStore(store)

export type RootState = ReturnType<typeof store.getState>

export default store
