import { inject, computed } from 'vue'
import { store, RootState } from './index'
import { storeKey } from './storePlugin'

export const useDispatch = () => store.dispatch

export const useSelector = <SubState, State extends RootState = RootState>(
  fn: (state: State) => SubState
) => {
  const rootStore = inject(storeKey) as { state: RootState }
  return computed(() => fn(rootStore.state as State))
}
