import { App, reactive } from 'vue'
import { EnhancedStore } from '@reduxjs/toolkit'
import { RootState } from './index'

export const storeKey = Symbol('Redux-Store')

export const createRedux = (store: EnhancedStore<RootState>) => {
  const rootStore = reactive<{ state: RootState }>({
    state: store.getState()
  })
  return {
    install: (app: App) => {
      app.provide<{ state: RootState }>(storeKey, rootStore)

      store.subscribe(() => {
        rootStore.state = store.getState()
      })
    }
  }
}
