import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { User } from 'src/api/user/models'

type State = Record<string, User>

const { reducer, actions } = createSlice({
  name: 'users',
  initialState: {} as State,
  reducers: {
    addUser: (state, { payload: user }: PayloadAction<User>) => {
      state[user._id] = user
      return state
    },
    clearUsers: () => ({})
  }
})

export const { addUser, clearUsers } = actions

export default reducer
