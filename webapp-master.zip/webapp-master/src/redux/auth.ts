import { PayloadAction, createSlice } from '@reduxjs/toolkit'
import { User } from 'src/api/user/models'

type State =
  | {
      token?: never
      user?: never
    }
  | {
      token?: string
      user?: User
    }
  | {
      token: string
      user: User
    }

const { reducer, actions } = createSlice({
  name: 'auth',
  initialState: {} as State,
  reducers: {
    setToken: (state, action: PayloadAction<string>) => {
      state.token = action.payload
    },
    resetToken: () => ({}),
    setUser: (state, action: PayloadAction<User>) => {
      if (state.token !== undefined) {
        state.user = action.payload
      }
    }
  }
})

export const { setToken, resetToken, setUser } = actions

export default reducer
