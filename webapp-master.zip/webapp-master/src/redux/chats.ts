import { DateTime } from 'luxon'
import { PayloadAction, createSlice } from '@reduxjs/toolkit'
import { ChatMessage } from 'src/api/chats/messages/models'
import { Chat as ChatType } from 'src/api/chats/models'

interface Chat {
  chat?: ChatType
  messages: ChatMessage[]
  lastRead: DateTime
  lastUpdate: DateTime
}

type State = Record<string, Chat>

const { reducer, actions } = createSlice({
  name: 'chats',
  initialState: {} as State,
  reducers: {
    addChatMessages: (
      state,
      {
        payload: { chatId, messages }
      }: PayloadAction<{ chatId: string; messages: ChatMessage[] }>
    ) => {
      if (state[chatId] === undefined)
        state[chatId] = {
          lastRead: DateTime.fromMillis(0),
          lastUpdate: DateTime.fromMillis(0),
          messages: []
        }
      if (messages.length === 0) return state

      state[chatId].messages.push(
        ...messages.filter(m => m.createdAt > state[chatId].lastUpdate)
      )
      state[chatId].lastUpdate =
        state[chatId].messages[state[chatId].messages.length - 1].createdAt
      return state
    },
    updateChatMetadata: (state, { payload: chat }: PayloadAction<ChatType>) => {
      if (state[chat._id] === undefined)
        state[chat._id] = {
          lastRead: DateTime.fromMillis(0),
          lastUpdate: DateTime.fromMillis(0),
          messages: []
        }
      state[chat._id].chat = chat
      return state
    },
    updateChatMessagesRead: (
      state,
      { payload: { chatId } }: PayloadAction<{ chatId: string }>
    ) => {
      if (!state[chatId]) return state
      if (state[chatId].messages.length === 0) return state
      state[chatId].lastRead =
        state[chatId].messages[state[chatId].messages.length - 1].createdAt
    },
    clearChatsState: () => ({})
  }
})

export const {
  addChatMessages,
  updateChatMessagesRead,
  clearChatsState,
  updateChatMetadata
} = actions

export default reducer
