import { boot } from 'quasar/wrappers'
import { createRedux } from '../redux/storePlugin'
import { store } from '../redux'
import { setupAPIQueryInterceptors } from 'src/api'

setupAPIQueryInterceptors(store)

export default boot(({ app }) => {
  app.use(createRedux(store))
})
