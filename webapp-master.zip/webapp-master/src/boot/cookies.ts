import VueCookies from 'vue-cookies'
import { boot } from 'quasar/wrappers'

export default boot(({ app }) => {
  app.use(VueCookies, { expires: '4h', domain: location.hostname })
})
