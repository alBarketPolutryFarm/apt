const routes = [
  {
    path: '',
    component: () => import('src/layouts/MainLayout'),
    children: [
      {
        path: '',
        target: self,
        component: () => import('src/pages/Dashboard')
      },
      {
        path: '/patients',
        target: self,
        component: () => import('src/pages/Patients')
      },
      {
        path: '/patients/:id/:panel?',
        target: self,
        component: () => import('src/pages/Patient')
      },
      {
        path: '/nurses/:id?',
        target: self,
        component: () => import('src/pages/Nurses')
      },
      {
        path: '/doctors/:id?',
        target: self,
        component: () => import('src/pages/Doctors')
      },
      {
        path: '/operators/:id?',
        target: self,
        component: () => import('src/pages/Operators')
      },
      {
        path: '/caregivers/:id?',
        target: self,
        component: () => import('src/pages/Caregivers')
      },
      {
        path: '/admins/:id?',
        target: self,
        component: () => import('src/pages/Admins')
      },
      {
        path: '/admins/limits/:id?',
        target: self,
        component: () => import('src/pages/Admins')
      },
      {
        path: '/alarms',
        target: self,
        component: () => import('src/pages/Alarms')
      },
      {
        path: '/bookings',
        target: self,
        component: () => import('src/pages/Bookings')
      },
      {
        path: '/exam-report-requests',
        target: self,
        component: () => import('src/pages/ExamReportRequests')
      },
      {
        path: '/agreements',
        target: self,
        component: () => import('src/pages/Agreements')
      },
      {
        path: '/screenings',
        target: self,
        component: () => import('src/pages/Screenings')
      },
      {
        path: 'screenings/create',
        target: self,
        component: () => import('src/pages/Screenings/CreateScreening')
      },
      {
        path: '/screenings/:id',
        target: self,
        component: () => import('src/pages/Screening')
      },

      {
        path: '/chats',
        target: self,
        component: () => import('src/pages/Chats')
      },
      {
        path: '/change-password',
        target: self,
        component: () => import('src/pages/ChangePassword')
      }
    ],
    meta: {
      requiresAuth: true,
      type: ''
    }
  },
  { path: '/login', target: self, component: () => import('src/pages/SignIn') },

  {
    path: '/forgot-password',
    target: self,
    component: () => import('src/pages/ForgotPassword')
  },

  {
    path: '/forgot-password',
    target: self,
    component: () => import('src/pages/ForgotPassword')
  },
  {
    path: '/:catchAll(.*)*',
    component: () => import('src/pages/ErrorNotFound')
  }
]

export default routes
