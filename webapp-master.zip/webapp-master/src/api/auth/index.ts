import api from 'src/api'
import { ChangePasswordPayload, ForgotPasswordPayload, SingInBody, TokenResponse } from './models'

export const signIn = (body: SingInBody) =>
  api.post<TokenResponse>('/auth/sign-in', body).then(r => r.data.token)

export const startForgotPasswordProcess = (
  data: ForgotPasswordPayload
) => api.post('/user/forgot-password', data)

export const changePassword = (data: ChangePasswordPayload) =>
  api.post('/user/change-password', data)

export const verifyOtp = (body: { otp: string,email:string }) =>
  api.post<TokenResponse>('/auth/sign-in/verify-otp', body).then(r => r.data)
