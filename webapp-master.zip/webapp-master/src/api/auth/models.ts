export type SingInBody = {
  username: string
  password: string
}
export type TokenResponse = {
  token: string
}


export type ForgotPasswordPayload = {
  username: string
}

export type ChangePasswordPayload = {
  currentPassword: string
  newPassword: string
}
