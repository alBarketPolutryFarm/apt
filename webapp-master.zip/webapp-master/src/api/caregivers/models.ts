import { EditLog } from 'src/api/models'
import { DateTime } from 'luxon'

export type Caregiver = {
  firstName: string
  lastName: string
  fiscalCode: string
  phone?: string
  email: string
  editsLog: EditLog[]
  createdAt: DateTime
  createdBy: string
  _id: string
  type: 'caregiver'
}
export type NewCaregiver = {
  firstName: string
  lastName: string
  fiscalCode: string
  phone?: string
  email: string
}
