import api from 'src/api'
import { Caregiver, NewCaregiver } from './models'
import { Operation } from 'rfc6902'

export const createCaregiver = (data: NewCaregiver) =>
  api.post<NewCaregiver>('/caregivers', data)

export const getCaregivers = () => api.get<Caregiver[]>('/caregivers')

export const getCaregiver = (caregiverId: string) =>
  api.get<Caregiver>(`/caregivers/${caregiverId}`)

export const updateCaregiver = (caregiverId: string, data: Operation[]) =>
  api.patch(`/caregivers/${caregiverId}`, data)
