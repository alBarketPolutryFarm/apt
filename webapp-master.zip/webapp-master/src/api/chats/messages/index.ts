import api from 'src/api'
import { ChatMessage, NewChatMessage } from './models'
import { QueryDate, QueryPagination } from 'src/api/models'

export const getChatMessages = (
  chatId: string,
  params: QueryPagination & QueryDate
) => api.get<ChatMessage[]>(`/chats/${chatId}/messages`, { params })

export const sendChatMessage = (chatId: string, message: NewChatMessage) =>
  api.post(`/chats/${chatId}/messages`, message)
