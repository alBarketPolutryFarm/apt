import { DateTime } from 'luxon'

export type ChatMessageText = {
  message: string
  createdAt: DateTime
  createdBy: string
  _id: string
  type: 'text'
  chatId: string
}
export type ChatMessageBookingRequest = {
  at: DateTime
  description: string
  createdAt: DateTime
  createdBy: string
  _id: string
  type: 'bookingRequest'
  chatId: string
}
export type NewChatMessageText = {
  message: string
  type: 'text'
}
export type NewChatMessageBookingRequest = {
  at: DateTime
  description: string
  type: 'bookingRequest'
}

export type ChatMessage = ChatMessageText | ChatMessageBookingRequest
export type NewChatMessage = NewChatMessageText | NewChatMessageBookingRequest
