import { DateTime } from 'luxon'

export type UsersChat = {
  membersId: string[]
  description?: string
  createdAt: DateTime
  createdBy: string
  _id: string
}
export type ServiceChat = {
  membersId: string[]
  createdAt: DateTime
  createdBy: string
  _id: string
}

export type BroadcastChat = {
  createdAt: DateTime
  _id: string
}

export type NewUsersChat = {
  membersId: string[]
  description?: string
}
export type NewChatPrivate = {
  targetId: string
}

export type Chat = ServiceChat | UsersChat | BroadcastChat



export interface UserChatModel {
  _id: string
  firstName: string
  lastName: string
  type: string
}

export interface ChatCreationSuccess {
  message:string,
  resourceId:string
}