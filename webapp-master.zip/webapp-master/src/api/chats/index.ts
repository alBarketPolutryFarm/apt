import api from 'src/api'
import { Chat, ChatCreationSuccess, UserChatModel } from './models'
import { QueryPagination } from 'src/api/models'

export const getChats = (params?: QueryPagination) =>
  api.get<Chat[]>('/chats', { params })

export const getChatAllowedUsers = () => {
  const data = api.get<UserChatModel[]>(`/chat/permit_list`);
  return data
}

export const createChat = (targetUserId: string) => 
  api.post<ChatCreationSuccess>('/chat/create', null, { params: { target: targetUserId } })

export const getChat = (chatId: string) => api.get<Chat>(`/chats/${chatId}`)
