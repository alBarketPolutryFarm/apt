import { EditLog } from 'src/api/models'

export type Operator = {
  firstName: string
  lastName: string
  fiscalCode: string
  email: string
  phone?: string
  editsLog: EditLog[]
  createdAt: string
  createdBy: string
  _id: string
  operatorType: OperatorType
  type: 'operator'
}
export type NewOperator = {
  firstName: string
  lastName: string
  fiscalCode: string
  phone?: string
  email: string
  operatorType?: OperatorType
}
export const OperatorTypes = [
  'physiotherapist',
  'nutritionist',
  'psychologist',
  'obstetrician',
  'socialWorker',
  'educator',
  'childhoodEducator',
  'sociologist',
  'pharmacist',
  'labTechnician',
  'other'
] as const
export type OperatorType = (typeof OperatorTypes)[number]
