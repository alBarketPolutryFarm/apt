import api from 'src/api'
import { NewOperator, Operator } from './models'
import { Operation } from 'rfc6902'

export const createOperator = (data: NewOperator) =>
  api.post<NewOperator>('/operators', data)

export const getOperators = () => api.get<Operator[]>('/operators')

export const suspendOperators = (OperatorId: string) =>
  api.put(`/operators/${OperatorId}/suspend`);

export const activateOperators = (OperatorId: string) =>
  api.put(`/operators/${OperatorId}/activate`);

export const getOperator = (operatorId: string) =>
  api.get<Operator>(`/operators/${operatorId}`).then(r => r.data)

export const updateOperator = (operatorId: string, data: Operation[]) =>
  api.patch(`/operators/${operatorId}`, data)
