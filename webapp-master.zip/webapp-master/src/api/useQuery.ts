import { AxiosResponse } from 'axios'
import { ComputedRef, Ref, shallowReactive, ShallowRef, watch } from 'vue'

type Query<P extends unknown[], T = unknown> = (
  ...param: P
) => Promise<AxiosResponse<T>>

type Status<T> = {
  isLoading: boolean
  isSuccess: boolean
  isError: boolean
  data?: T
  refetch: () => Promise<AxiosResponse<T>> | void
}

type GenericRef<P> = ComputedRef<P> | Ref<P> | ShallowRef<P>

type GenericProps<T extends unknown[]> = T extends [infer H, ...infer T]
  ? [GenericRef<H>, ...GenericProps<T>]
  : []

export default <P extends [...unknown[]], T>(
  query: Query<P, T>,
  ...param: GenericProps<P>
): Status<T> => {
  const queryStatus = shallowReactive<Status<T>>({
    isLoading: false,
    isError: false,
    isSuccess: false,
    data: undefined,
    refetch: () => {}
  })

  const fetch = async () => {
    queryStatus.isLoading = true
    queryStatus.isError = false

    try {
      const r = await query(
        ...(param.map((v: GenericRef<unknown>) => v.value) as P)
      )

      queryStatus.isLoading = false
      queryStatus.isSuccess = true
      queryStatus.data = r.data
      return r
    } catch (error) {
      queryStatus.isLoading = false
      queryStatus.isSuccess = false
      queryStatus.isError = true
      throw error
    }
  }

  watch(param, () => fetch(), {
    immediate: true,
    deep: true
  })

  queryStatus.refetch = fetch
  return queryStatus
}
