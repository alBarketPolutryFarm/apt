import { DateTime } from 'luxon'

export type RevocationReason = 'outdated' | 'manual'
export type Revocation = {
  by: string
  effectiveFrom?: DateTime
  dueTo?: RevocationReason
  date?: DateTime
  notes?: string
}

export type EditLog = {
  at: DateTime
  by: string
  description?: string
}

export type QueryPagination = {
  limit?: number
  offset?: number
}

export type QueryInfo = {
  count: number
}

export type QueryDate = {
  startDate?: DateTime
  endDate?: DateTime
}
