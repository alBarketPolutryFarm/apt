import { AxiosResponse } from 'axios';
import api from 'src/api'

export interface MetricTrendData {
  month: string;
  value: number;
}

export interface MetricTrend {
  metric_name: string;
  trend_data: MetricTrendData[];
}

export interface AdminMetrics {
  type: string;
  admin_id: string;
  name: string;
  active_users: number;
  active_assistants: number;
  managed_alerts: number;
  created_care_plans: number;
  completed_care_plans: number;
  active_care_plans: number;
  deaths: number;
  hospitalizations: number;
  recoveries: number;
  administrative_closures: number;
  infections: number;
  generated_reports: number;
  trends: MetricTrend[];
}

export interface SuperAdminMetrics {
  type: string;
  total_registered_admins: number;
  admins_data: AdminMetrics[];
}

export const getDashboardMetrics = (): Promise<AxiosResponse<AdminMetrics | SuperAdminMetrics>> => {
  return api.get('/dashboard/');
};

export const downloadMetricData = (metricName: string): Promise<AxiosResponse<Blob>> => {
  return api.get(`/dashboard/download/${metricName}`, {
    responseType: 'blob'
  });
};
