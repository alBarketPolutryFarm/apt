export type Drug = {
  id: string
  description: string
  activeIngredient: string
}
