import { drugsApiClient } from 'src/api'
import { Drug } from './models'

export const getDrugs = (query: string) =>
  drugsApiClient.get<Drug[]>(`/drugs`, { params: { q: query } })
