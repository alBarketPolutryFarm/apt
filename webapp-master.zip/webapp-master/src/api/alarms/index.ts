import api from 'src/api'
import { Alarm } from './models'
import { QueryPagination } from 'src/api/models'

export const getAlarms = (params: QueryPagination) =>
  api.get<Alarm[]>('/alarms', { params })

export const getUnhandledAlarms = (params?: QueryPagination) =>
  api.get<Alarm[]>(`/alarms/unhandled`, { params }).then(r => r.data)

export const handleAlarm = (alarmId: string) =>
  api.post(`/alarms/${alarmId}/handle`)
