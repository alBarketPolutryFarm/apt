import { DateTime } from 'luxon'
import { AlarmType } from 'src/const/Alarm'
import { Measure } from 'src/api/patients/measures/models'
import { MonitoredMeasure } from 'src/api/patients/monitoringPlans/models'

export type Handling = {
  at: DateTime
  by: string
}

export type MeasureOutOfBoundsAlarm = {
  createdAt: DateTime
  createdBy?: string
  description: string
  patientId: string
  handling?: Handling
  _id: string
  type: AlarmType
  measure: Measure
  plan: MonitoredMeasure
}

export type Alarm = MeasureOutOfBoundsAlarm
