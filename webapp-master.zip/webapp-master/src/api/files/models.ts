import { DateTime } from 'luxon'

export type File = {
  createdAt: DateTime
  createdBy: string
  _id: string
  filename: string
  contentType: string
  size: number
  claimed?: boolean
  claimedAt?: DateTime
}

export type FileEncoded = {
  content: string
  mediaType: string
  filename: string
}
