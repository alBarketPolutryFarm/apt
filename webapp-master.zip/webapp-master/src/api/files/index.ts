import api from 'src/api'
import { File as FileAPI } from './models'
import { FormData } from 'formdata-node'

export const uploadFile = (file: File) => {
  const formData = new FormData()
  formData.append('file', file)

  return api.post<FileAPI>('/files', formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}
