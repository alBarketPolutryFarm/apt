import { AxiosError, AxiosResponse } from 'axios'
import { shallowReactive } from 'vue'

type Query<P extends unknown[], T> = (...args: P) => Promise<AxiosResponse<T>>

type Status<T> = {
  isLoading: boolean
  isSuccess: boolean
  isError: boolean
  data?: T
  statusCode?: number
}

export default <P extends unknown[], T>(
  query: Query<P, T>
): [(...args: P) => ReturnType<Query<P, T>>, Status<T>] => {
  const status = shallowReactive<Status<T>>({
    isLoading: false,
    isError: false,
    isSuccess: false,
    data: undefined
  })

  const perform = async (...args: P) => {
    status.isLoading = true
    status.isError = false
    status.isSuccess = false

    try {
      const r = await query(...args)

      status.isLoading = false
      status.isSuccess = true
      status.data = r.data
      return r
    } catch (error) {
      status.isLoading = false
      status.isSuccess = false
      status.isError = true
      status.statusCode = (error as AxiosError).response?.status
      throw error
    }
  }

  return [perform, status]
}
