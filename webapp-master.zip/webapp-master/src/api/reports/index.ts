import api from 'src/api'

export const Pushreport = (patientId: string) =>
    api.post(`/reports/${patientId}/ehr`)

export const PushAndSaveReport = (patientId: string) =>
    api.post(`/reports/${patientId}/ehr_saved`)