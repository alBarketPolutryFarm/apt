import api from 'src/api'
import { User, UserType } from 'src/api/user/models'
import { QueryPagination } from 'src/api/models'
import { Operation } from 'rfc6902'

export const queryUsers = (
  params: { q?: string; type?: UserType[] } & QueryPagination
) => api.get<User[]>(`/users`, { params })

export const getUser = (userId: string) => api.get<User>(`/users/${userId}`)

export const updateUser = (userId: string, data: Operation[]) =>
  api.patch(`/users/${userId}`, data)

export const updateUserStructure = (userId: string, structure_id: string) =>
  api.patch(`/users/${userId}/change_admin_structure?createdBy=${structure_id}`)

export const activateUsers = (adminId: string) =>
  api.put(`/users/${adminId}/activate`)

export const suspendUsers = (adminId: string) =>
  api.put(`/users/${adminId}/suspend`);