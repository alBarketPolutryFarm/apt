import { EditLog } from 'src/api/models'

export type ExamModality = 'ECG'
export type PatientCreationLimit = {
  available: number
  lastReset: string
  resetValue: number
  resetInterval: 'day' | 'week' | 'month' | 'year'
}
export type SignatureLimit = {
  available: number
  lastReset: string
  resetValue: number
  resetPatientsScaleFactor: number
  resetInterval: 'day' | 'week' | 'month' | 'year'
}

export type Doctor = {
  firstName: string
  lastName: string
  phone: string
  fiscalCode: string
  email: string
  editsLog: EditLog[]
  createdAt: string
  createdBy: string
  _id: string
  type: 'doctor'
  reportableExamModalities: ExamModality[]
  patientCreationLimit: PatientCreationLimit
  signatureLimit: SignatureLimit
}
export type NewDoctor = {
  firstName: string
  lastName: string
  fiscalCode: string
  email: string
  phone: string
}
