import api from 'src/api'
import { NewDoctor, Doctor } from './models'
import { Operation } from 'rfc6902'

export const createDoctor = (data: NewDoctor) =>
  api.post<NewDoctor>('/doctors', data)

export const getDoctors = () => api.get<Doctor[]>('/doctors')

export const getDoctor = (doctorId: string) =>
  api.get<Doctor>(`/doctors/${doctorId}`)

export const updateDoctor = (doctorId: string, data: Operation[]) =>
  api.patch(`/doctors/${doctorId}`, data)
