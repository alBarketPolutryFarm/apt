import { DateTime } from 'luxon'
import { Exam, ExamReport } from 'src/api/patients/reports/models/ExamReport'

export type ExamReportRequest = {
  createdAt: DateTime
  _id: string
  patientId?: string
  exam: Exam
  report?: ExamReport
}
