import api from 'src/api'
import { QueryDate, QueryPagination } from 'src/api/models'
import { ExamReportRequest } from './models'
import { FileEncoded } from 'src/api/files/models'
import { NewExamReport } from 'src/api/patients/reports/models'
import { Operation, Patch } from 'rfc6902'

export const getExamReportRequests = (params: QueryPagination | QueryDate) =>
  api.get<ExamReportRequest[]>(`/exam-report-requests`, { params })

export const updateExamReportRequest = (requestId: string, data: Operation[]) =>
  api.patch(`/exam-report-requests/${requestId}`, data)

export const getExamReportRequestExamEncodedFile = (requestId: string) =>
  api.get<FileEncoded>(`/exam-report-requests/${requestId}/exam`)

export const createExamReportRequestReport = (
  requestId: string,
  report: NewExamReport
) => api.post(`/exam-report-requests/${requestId}/report`, report)

export const editExamReportRequestReport = (requestId: string, patch: Patch) =>
  api.patch<FileEncoded>(`/exam-report-requests/${requestId}/report`, patch)

export const getExamReportRequestReportEncodedFile = (requestId: string) =>
  api.get<FileEncoded>(`/exam-report-requests/${requestId}/report/file`)

export const startSignatureProcessExamReportRequestReport = (
  requestId: string
) => api.post(`/exam-report-requests/${requestId}/report/signature`)
