import { DateTime } from 'luxon'

export type Screening = {
  _id: string
  title: string
  description: string
  body: string
  startAt: string
  endAt: string
  createdAt: DateTime
  createdBy: string
}
export type NewScreening = {
  title: string
  description: string
  body: string
  startAt: string
  endAt: string
}
