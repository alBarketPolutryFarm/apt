import api from 'src/api'
import { NewScreening, Screening } from './models'
import { createPatch } from 'rfc6902'
import { toRaw } from 'vue'

export const createScreening = (data: NewScreening) =>
  api.post<NewScreening>('/screenings', data)

export const getScreenings = () => api.get<Screening[]>('/screenings')

export const getScreening = (screeningId: string) =>
  api.get<Screening>(`/screenings/${screeningId}`)

export async function updateScreening(screeningId: string, data: NewScreening) {
  const { data: originalScreening } = await getScreening(screeningId)
  const strippedOriginalScreening: NewScreening = {
    title: originalScreening.title,
    body: originalScreening.body,
    description: originalScreening.description,
    endAt: originalScreening.endAt,
    startAt: originalScreening.startAt
  }
  const patch = createPatch(toRaw(strippedOriginalScreening), toRaw(data))
  return await api.patch(`/screenings/${screeningId}`, patch)
}

export const deleteScreening = (screeningId: string) =>
  api.delete(`/screenings/${screeningId}`)
