import api from 'src/api'
import { Booking, NewBooking } from 'src/api/bookings/models'
import { QueryDate, QueryPagination } from 'src/api/models'

export const getBookings = (params: QueryPagination | QueryDate) =>
  api.get<Booking[]>(`/bookings`, { params })

export const getBooking = (bookingId: string) =>
  api.get<Booking>(`/bookings/${bookingId}`)

export const createBooking = (data: NewBooking) => api.post(`/bookings`, data)

export const deleteBooking = (bookingId: string) =>
  api.delete(`/bookings/${bookingId}`)
