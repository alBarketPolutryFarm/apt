import { DateTime } from 'luxon'

export type Booking = {
  providerId: string
  description: string
  at: DateTime
  createdAt: DateTime
  createdBy: string
  _id: string
  targetId: string
  isRemote: boolean
  remoteLink?: string
}
export type NewBooking = {
  providerId: string
  targetId: string
  description: string
  at: DateTime
  isRemote?: boolean
}
