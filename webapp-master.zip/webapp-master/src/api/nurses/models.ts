import { EditLog } from 'src/api/models'

export type Nurse = {
  firstName: string
  lastName: string
  fiscalCode: string
  phone?: string
  email: string
  editsLog: EditLog[]
  createdAt: string
  createdBy: string
  _id: string
  type: 'nurse'
}
export type NewNurse = {
  firstName: string
  lastName: string
  fiscalCode: string
  phone?: string
  email: string
}
