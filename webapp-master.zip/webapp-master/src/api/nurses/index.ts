import api from 'src/api'
import { NewNurse, Nurse } from './models'
import { Operation } from 'rfc6902'

export const createNurse = (data: NewNurse) =>
  api.post<NewNurse>('/nurses', data)

export const getNurses = () => api.get<Nurse[]>('/nurses')

export const getNurse = (nurseId: string) =>
  api.get<Nurse>(`/nurses/${nurseId}`)

export const updateNurse = (nurseId: string, data: Operation[]) =>
  api.patch(`/nurses/${nurseId}`, data)
