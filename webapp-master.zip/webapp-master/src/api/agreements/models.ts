import { Revocation } from '../models'
import { UserType } from 'src/api/user/models'

export type AgreementType = 'privacy' | 'tos'
export type AgreementOption = {
  _id: string
  required: boolean
  description: string
}
export type NewAgreementSigningOption = {
  _id: string
  agree: boolean
}
export type AgreementSigning = {
  options: NewAgreementSigningOption[]
  _id: string
  agreementId: string
  userId: string
  at: string
}
export type FulfilledAgreement = {
  effectiveDate: string
  expirationDate?: string
  revocation?: Revocation
  type: AgreementType
  description: string
  content: string
  targets?: UserType[]
  _id: string
  createdAt: string
  createdBy: string
  options: AgreementOption[]
  signing?: AgreementSigning
}
export type NewAgreementOption = {
  required?: boolean
  description: string
}
export type NewAgreement = {
  effectiveDate?: string
  expirationDate?: string
  revocation?: Revocation
  type: AgreementType
  description: string
  content: string
  targets?: UserType[]
  options: NewAgreementOption[]
}
export type NewAgreementSigning = {
  options: NewAgreementSigningOption[]
}
