import api from 'src/api'
import { AgreementType, FulfilledAgreement, NewAgreement } from './models'

export const getAgreements = () => api.get<FulfilledAgreement[]>(`/agreements`)

export const getAgreementByType = (type: AgreementType) =>
  api.get<FulfilledAgreement>(`/agreements/${type}`)

export const createAgreement = (agreement: NewAgreement) =>
  api.post<NewAgreement>(`/agreements`, agreement)
