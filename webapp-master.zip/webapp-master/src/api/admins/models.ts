import { DateTime } from 'luxon';

export type Admin = {
  firstName: string;
  lastName: string;
  phone?: string;
  fiscalCode?: string;
  email: string;
  createdAt: DateTime;
  createdBy: string;
  _id: string;
  type: 'admin';
  status: 'active' | 'suspended';
  limits?: AdminLimitsBase;
};

export type SuperAdmin = {
  firstName: string;
  lastName: string;
  phone?: string;
  fiscalCode?: string;
  email: string;
  createdAt: DateTime;
  createdBy: string;
  _id: string;
  type: 'superadmin';
  status: 'active' | 'suspended';
};

export type NewAdmin = {
  firstName: string;
  lastName: string;
  fiscalCode?: string;
  phone?: string;
  email: string;
  status?: string;
  createdBy: string; 
};

export interface UpdateAdmin {
  firstName?: string;
  lastName?: string;
  phone?: string;
  fiscalCode?: string;
  email?: string;
  status?: 'active' | 'suspended';
}

export interface AdminLimitsBase {
  userCreationLimit: number;
  docuSignLimit: number;
  assistantCreationLimit: number;
  id: string;
  loaded: boolean;
}

export interface AdminLimits{
  userCreationLimit: number;
  docuSignLimit: number;
  assistantCreationLimit: number;
}