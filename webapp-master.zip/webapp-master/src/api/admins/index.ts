// src/api/admins/index.ts

import api from "src/api";
import { Admin, NewAdmin, UpdateAdmin, AdminLimitsBase ,AdminLimits} from "./models";

export const getAdmins = () => api.get<Admin[]>("/admins");

export const createAdmin = (admin: NewAdmin) => api.post("/admins", admin);

export const updateAdmin = (adminId: string, admin: UpdateAdmin) =>
    api.patch(`/admins/${adminId}`, admin);

export const suspendAdmin = (adminId: string) =>
    api.put(`/admins/${adminId}/suspend`);

export const activateAdmin = (adminId: string) =>
    api.put(`/admins/${adminId}/activate`);

export const deleteAdmin = (adminId: string) =>
    api.delete(`/admins/${adminId}`);

// Admin Limits
export const createAdminLimits = (adminId: string, limits: AdminLimits) =>
    api.post(`/admins/${adminId}/limits`, limits);

export const getAdminLimits = (adminId: string) =>
    api.get<AdminLimits>(`/admins/${adminId}/limits`);

export const updateAdminLimits = (adminId: string, limits: AdminLimitsBase) =>
    api.patch(`/admins/${adminId}/limits`, limits);

export const deleteAdminLimits = (adminId: string) =>
    api.delete(`/admins/${adminId}/limits`);

export const getAllLimits = () => api.get<AdminLimitsBase>(`/admins/limits`);