import { DateTime } from 'luxon'
import { StatusCodes } from 'http-status-codes'
import { resetToken } from 'src/redux/auth'
import { store } from 'src/redux'
import axios, { AxiosError } from 'axios'
import qs from 'qs'

// Workaround: Because whoever designed javascript (in particular JSON.stringify) should change job
DateTime.prototype.toJSON = function () {
  return this as unknown as string
}

const jsonParserKeys = {
  dateTime: [
    'createdAt',
    'at',
    'effectiveDate',
    'expirationDate',
    'birthDate',
    'notBefore',
    'notAfter',
    'claimedAt',
    'effectiveFrom',
    'date',
    'time',
    'timestamp',
    'updatedAt',
    'lastMenstruation',
    'lastUpdate',
    'nextCheck',
    'completedAt'
  ],
  time: ['time'],
  date: ['date']
}

const jsonReplacer = (key: string, value: unknown): unknown => {
  if (value === null) return undefined
  if (value instanceof DateTime && jsonParserKeys.time.includes(key))
    return value.toISOTime()
  if (value instanceof DateTime && jsonParserKeys.date.includes(key))
    return value.toISODate()
  if (value instanceof DateTime) return value.toISO()

  return value as unknown
}

const jsonReviver = (key: string, value: string): unknown => {
  if (value === null) return undefined
  if (
    jsonParserKeys.dateTime.includes(key) ||
    jsonParserKeys.time.includes(key)
  )
    return DateTime.fromISO(value)
  return value as unknown
}

const baseURL = process.env.APP_API_BASE_URL
const drugsBaseURL = process.env.APP_DRUGS_API_BASE_URL

export const apiClient = axios.create({
  withCredentials: false,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json'
  },
  baseURL,
  paramsSerializer: {
    serialize: params => {
      return qs.stringify(params, {
        arrayFormat: 'repeat',
        filter: (key, value: unknown) => {
          if (DateTime.isDateTime(value) && jsonParserKeys.time.includes(key))
            return value.toISOTime()
          if (DateTime.isDateTime(value)) return value.toISO()
          return value
        }
      })
    }
  },
  transformRequest: [
    (data, headers) => {
      if (headers.getContentType(/^application\/json$/))
        return JSON.stringify(data, jsonReplacer)

      return data as unknown
    }
  ],
  transformResponse: (data, headers) => {
    if (headers.getContentType(/^application\/json$/))
      return JSON.parse(data as string, jsonReviver) as unknown

    return data as unknown
  }
})

export const drugsApiClient = axios.create({
  withCredentials: false,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json'
  },
  baseURL: drugsBaseURL,
  paramsSerializer: apiClient.defaults.paramsSerializer,
  transformRequest: apiClient.defaults.transformRequest,
  transformResponse: apiClient.defaults.transformResponse
})

export const setupAPIQueryInterceptors = ({
  getState,
  dispatch
}: typeof store) => {
  apiClient.interceptors.request.use(config => {
    const state = getState()
    if (state.auth.token !== undefined)
      config.headers.setAuthorization(`Bearer ${state.auth.token}`)
    return config
  })

  apiClient.interceptors.response.use(
    r => {
      if (r.status === 204) r.data = undefined
      return r
    },
    (e: AxiosError<unknown, unknown>) => {
      if (
        e.response !== undefined &&
        e.status === StatusCodes.UNAUTHORIZED &&
        'Authorization' in (e.config?.headers || {})
      )
        dispatch(resetToken())

      return Promise.reject(e)
    }
  )

  drugsApiClient.interceptors.request.use(config => {
    const state = getState()
    if (state.auth.token !== undefined)
      config.headers.setAuthorization(`Bearer ${state.auth.token}`)
    return config
  })

  drugsApiClient.interceptors.response.use(
    r => {
      if (r.status === 204) r.data = undefined
      return r
    },
    (e: AxiosError<unknown, unknown>) => {
      if (
        e.response !== undefined &&
        e.status === StatusCodes.UNAUTHORIZED &&
        'Authorization' in (e.config?.headers || {})
      )
        dispatch(resetToken())

      return Promise.reject(e)
    }
  )
}

export default apiClient
