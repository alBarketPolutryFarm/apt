import api from 'src/api'
import { Diet, DietOutMeal, DietScheduleEntry, NewDiet } from './models'
import { QueryDate, QueryPagination } from 'src/api/models'

export const getPatientDiets = (patientId: string) =>
  api.get<Diet[]>(`/patients/${patientId}/diets`)

export const createNewPatientDiet = (patientId: string, data: NewDiet) =>
  api.post(`/patients/${patientId}/diets`, data)

export const getPatientCurrentDiet = (patientId: string) =>
  api.get<Diet | undefined>(`/patients/${patientId}/diets/current`)

export const getPatientDietSchedule = (patientId: string, params: QueryDate) =>
  api.get<DietScheduleEntry[]>(`/patients/${patientId}/diets/schedule`, {
    params
  })

export const getPatientDietOutMeals = (
  patientId: string,
  params: QueryDate & QueryPagination
) =>
  api.get<DietOutMeal[]>(`/patients/${patientId}/diets/out-meals`, {
    params
  })
