import { DateTime } from 'luxon'
import { Revocation } from 'src/api/models'

export type DietMeal = {
  description: string
  _id: string
}
export type DietDay = {
  breakfast: DietMeal
  morningSnack: DietMeal
  lunch: DietMeal
  afternoonSnack: DietMeal
  dinner: DietMeal
}
export type DietSchedule = {
  monday: DietDay
  tuesday: DietDay
  wednesday: DietDay
  thursday: DietDay
  friday: DietDay
  saturday: DietDay
  sunday: DietDay
}
export type Diet = {
  effectiveDate: DateTime
  expirationDate?: DateTime
  notes?: string
  createdAt: DateTime
  createdBy: string
  revocation?: Revocation
  diet: DietSchedule
  reportId: string
}
export type ValidationError = {
  loc: (string | number)[]
  msg: string
  type: string
}
export type HttpValidationError = {
  detail?: ValidationError[]
}
export type Success = {
  message?: string
}
export type NewDietMeal = {
  description: string
}
export type NewDietDay = {
  breakfast: NewDietMeal
  morningSnack: NewDietMeal
  lunch: NewDietMeal
  afternoonSnack: NewDietMeal
  dinner: NewDietMeal
}
export type NewDietSchedule = {
  monday: NewDietDay
  tuesday: NewDietDay
  wednesday: NewDietDay
  thursday: NewDietDay
  friday: NewDietDay
  saturday: NewDietDay
  sunday: NewDietDay
}
export type NewDiet = {
  effectiveDate?: DateTime
  expirationDate?: DateTime
  notes?: string
  diet: NewDietSchedule
  reportId: string
}

export type DietAdherence = {
  mealId: string
  at: DateTime
  adherence: number
  _id: string
  patientId: string
}
export type DietScheduleMealEntry = {
  description: string
  _id: string
  adherence?: DietAdherence
}
export type DietOutMeal = {
  description: string
  _id: string
  at: DateTime
}
export type DietScheduleEntry = {
  _id: string
  at: DateTime
  breakfast: DietScheduleMealEntry
  morningSnack: DietScheduleMealEntry
  lunch: DietScheduleMealEntry
  afternoonSnack: DietScheduleMealEntry
  dinner: DietScheduleMealEntry
  outMeals?: DietOutMeal[]
}
