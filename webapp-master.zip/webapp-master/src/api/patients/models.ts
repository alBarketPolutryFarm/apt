import { DateTime } from 'luxon'
import { EditLog } from 'src/api/models'

export type Gender = 'female' | 'male' | 'other' | 'unknown'
export type BloodType = '0+' | '0-' | 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-'
export type Screening = {
  name: string
}
export type NewPatient = {
  firstName: string
  fiscalCode: string
  lastName: string
  gender?: Gender
  birthDate?: DateTime
  birthPlace?: string
  phone?: string
  doctor?: string
  caregiver?: string
  email?: string
}
export type Patient = {
  firstName: string
  fiscalCode: string
  lastName: string
  gender?: Gender
  birthDate?: DateTime
  birthPlace?: string
  phone?: string
  doctor?: string
  caregiver?: string
  email?: string
  editsLog: EditLog[]
  createdAt: DateTime
  createdBy: string
  _id: string
  type: 'patient'
}
