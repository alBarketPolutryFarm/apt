import api from 'src/api'
import { Booking } from '../../bookings/models'
import { QueryDate, QueryPagination } from 'src/api/models'

export const getPatientBookings = (
  patientId: string,
  params: QueryPagination | QueryDate
) => api.get<Booking[]>(`/patients/${patientId}/bookings`, { params })

export const getPatientBooking = (patientId: string, bookingId: string) =>
  api.get<Booking>(`/patients/${patientId}/bookings/${bookingId}`)
