import api from 'src/api'
import { Gender, NewPatient, Patient } from './models'
import { Operation } from 'rfc6902'
import { QueryInfo, QueryPagination } from 'src/api/models'

export interface GetPatientsParams {
  q?: string
  target_ids?: string[]
  gender?: Gender
}

export const createPatient = (data: NewPatient) =>
  api.post<NewPatient>('/patients', data)

export const getPatients = (params: GetPatientsParams & QueryPagination) =>
  api.get<Patient[]>('/patients', { params })
export const getPatientsQueryInfo = (params: { q?: string }) =>
  api.get<QueryInfo>('/patients/info', { params })

export const getPatient = (patientId: string) =>
  api.get<Patient>(`/patients/${patientId}`)

export const updatePatient = (patientId: string, data: Operation[]) =>
  api.patch(`/patients/${patientId}`, data)
