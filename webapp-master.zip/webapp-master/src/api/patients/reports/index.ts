import api from 'src/api'
import { NewReport, Report } from './models'
import { FileEncoded } from 'src/api/files/models'
import { Patch } from 'rfc6902'
import StartSignatureProcessSuccess from './models/StartSignarureProcessResponse'

export const createPatientReport = (patientId: string, report: NewReport) =>
  api.post(`/patients/${patientId}/reports`, report)

export const getPatientReports = (patientId: string) =>
  api.get<Report[]>(`/patients/${patientId}/reports`)

export const editPatientReport = (
  patientId: string,
  reportId: string,
  patch: Patch
) => api.patch(`/patients/${patientId}/reports/${reportId}`, patch)

export const getPatientReportFile = (patientId: string, reportId: string) =>
  api.get<FileEncoded>(`/patients/${patientId}/reports/${reportId}/file`)
export const getPatientReportExamFile = (patientId: string, reportId: string) =>
  api.get<FileEncoded>(`/patients/${patientId}/reports/${reportId}/exam`)

export const startSignatureProcessPatientReport = (
  patientId: string,
  reportId: string
) =>
  api.post<StartSignatureProcessSuccess>(
    `/patients/${patientId}/reports/${reportId}/signature`
  )
