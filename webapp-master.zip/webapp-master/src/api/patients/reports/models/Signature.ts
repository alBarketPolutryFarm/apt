import { DateTime } from 'luxon'

export default interface Signature {
  _id: string
  status: 'waiting' | 'failed' | 'completed'
  link: string
  updatedAt?: DateTime
}
