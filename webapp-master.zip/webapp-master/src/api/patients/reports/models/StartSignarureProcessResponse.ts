import { Success } from '../../diets/models'
import Signature from './Signature'

export type StartSignatureProcessSuccess = Success & {
  signature: Signature
}

export default StartSignatureProcessSuccess
