import { DateTime } from 'luxon'
import {
  MonitoringPlan,
  NewMonitoringPlan
} from 'src/api/patients/monitoringPlans/models'
import { Diet, NewDiet } from 'src/api/patients/diets/models'
import {
  NewTreatmentPlan,
  TreatmentPlan
} from 'src/api/patients/treatmentsPlans/models'
import Signature from './Signature'

export type Detail = {
  head?: string
  eyes?: string
  neck?: string
  monthThroat?: string
  noseEars?: string
}
export type RespiratorySystem = {
  inspection?: string
  palpation?: string
  percussion?: string
  auscultation?: string
}
export type Abdomen = {
  inspection?: string
  palpation?: string
  percussion?: string
  auscultation?: string
}
export type NervousSystem = {
  reflexes?: string
  motility?: string
  sensitivity?: string
  gait?: string
}
export type ReproductiveSystem = {
  inspection?: string
  palpation?: string
  percussion?: string
  auscultation?: string
}
export type CardiovascularSystem = {
  inspection?: string
  palpation?: string
  percussion?: string
  auscultation?: string
  peripheralVessels?: string
}
export type ObjectiveExamination = {
  general?: string
  other?: string
  detail?: Detail
  respiratorySystem?: RespiratorySystem
  abdomen?: Abdomen
  nervousSystem?: NervousSystem
  reproductiveSystem?: ReproductiveSystem
  cardiovascularSystem?: CardiovascularSystem
}
export type Diagnosis = {
  pathology?: string
  secondaryPathologies?: string
}
export type PlannedIntervention = {
  description: string
  specialists?: string
  frequency?: string
}

export type MedicalExaminationReport = {
  remotely: boolean
  objectiveExamination?: ObjectiveExamination
  diagnosis?: Diagnosis
  plannedInterventions?: PlannedIntervention[]
  date: DateTime
  description: string
  createdAt: DateTime
  createdBy: string
  _id: string
  patientId: string
  type: 'medicalExamination'
  monitoringPlan?: MonitoringPlan
  diet?: Diet
  treatmentPlan?: TreatmentPlan
  signature: Signature
  diagnosticExaminations?: string
  conclusion?: string
}

export type NewMedicalExaminationReport = {
  remotely?: boolean
  objectiveExamination?: ObjectiveExamination
  diagnosis?: Diagnosis
  plannedInterventions?: PlannedIntervention[]
  date?: DateTime
  description: string
  type: 'medicalExamination'
  monitoringPlan?: NewMonitoringPlan
  diet?: NewDiet
  treatmentPlan?: NewTreatmentPlan
  diagnosticExaminations?: string
  conclusion?: string
}

export type FormObjectiveExamination = {
  general?: string
  other?: string
  detail: Detail
  respiratorySystem: RespiratorySystem
  abdomen: Abdomen
  nervousSystem: NervousSystem
  reproductiveSystem: ReproductiveSystem
  cardiovascularSystem: CardiovascularSystem
}

export type FormMedicalExaminationReport = {
  objectiveExamination: FormObjectiveExamination
  diagnosis: Diagnosis
} & Omit<
  NewMedicalExaminationReport,
  'type' | 'diagnosis' | 'objectiveExamination'
>

export default MedicalExaminationReport
