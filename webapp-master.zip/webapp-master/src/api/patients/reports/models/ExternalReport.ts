import { DateTime } from 'luxon'

export type NewExternalReport = {
  date?: DateTime
  description: string
  type: 'external'
  file: string
}

export type ExternalReport = {
  date: DateTime
  description: string
  createdAt: DateTime
  createdBy: string
  _id: string
  patientId: string
  type: 'external'
}

export default ExternalReport
