import Signature from './Signature'
import { DateTime } from 'luxon'

export type ExamModality = 'ECG'

export type Exam = {
  createdAt: string
  _id: string
  studyId: string
  modalities: ExamModality[]
}

export type NewExamReport = {
  conclusion: string
  date?: DateTime
  description: string
  type: 'exam'
}

export type ExamReport = {
  signature?: Signature
  conclusion: string
  date: DateTime
  description: string
  createdAt: DateTime
  createdBy: string
  _id: string
  patientId: string
  type: 'exam'
  exam: Exam
}

export type FormExamReport = {
  conclusion: string
  description: string
}

export default ExamReport
