import ExamReport, { NewExamReport } from './ExamReport'
import ExternalReport, { NewExternalReport } from './ExternalReport'
import MedicalExaminationReport, {
  NewMedicalExaminationReport
} from './MedicalExaminationReport'

export type { MedicalExaminationReport, NewMedicalExaminationReport }
export type { ExternalReport, NewExternalReport }
export type { ExamReport, NewExamReport }

export type NewReport = NewExternalReport | NewMedicalExaminationReport
export type Report = ExternalReport | MedicalExaminationReport | ExamReport
