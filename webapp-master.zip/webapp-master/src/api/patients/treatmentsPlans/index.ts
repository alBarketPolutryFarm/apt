import api from 'src/api'
import {
  NewTreatmentPlan,
  TreatmentPlan,
  TreatmentPlanScheduleEntry,
  TreatmentSideEffect
} from './models'
import { QueryDate, QueryPagination } from 'src/api/models'

export const getPatientTreatmentPlans = (patientId: string) =>
  api.get<TreatmentPlan[]>(`/patients/${patientId}/treatment-plans`)

export const createPatientTreatmentPlan = (
  patientId: string,
  data: NewTreatmentPlan
) => api.post(`/patients/${patientId}/treatment-plans`, data)

export const getPatientCurrentTreatmentPlan = (patientId: string) =>
  api.get<TreatmentPlan | undefined>(
    `/patients/${patientId}/treatment-plans/current`
  )

export const getPatientTreatmentPlanSchedule = (
  patientId: string,
  params: QueryDate
) =>
  api.get<TreatmentPlanScheduleEntry[]>(
    `/patients/${patientId}/treatment-plans/schedule`,
    {
      params
    }
  )

export const getPatientTreatmentSideEffects = (
  patientId: string,
  params: QueryDate & QueryPagination
) =>
  api.get<TreatmentSideEffect[]>(
    `/patients/${patientId}/treatment-plans/side-effects`,
    {
      params
    }
  )
