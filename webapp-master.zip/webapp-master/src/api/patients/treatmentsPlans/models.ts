import { DateTime } from 'luxon'
import { Revocation } from 'src/api/models'

export type Weekday = 0 | 1 | 2 | 3 | 4 | 5 | 6
export type TreatmentSchedule = {
  time: DateTime
  weekday: Weekday
  _id: string
}
export type Treatment = {
  description: string
  activeIngredient?: string
  dosage?: string
  administrationRoute?: string
  notes?: string
  schedule: TreatmentSchedule[] | TreatmentPeriodicSchedule | undefined
  _id: string
}
export type TreatmentPlan = {
  effectiveDate: DateTime
  expirationDate?: DateTime
  treatments: Treatment[]
  notes?: string
  createdAt: string
  createdBy: string
  revocation?: Revocation
  reportId: string
}
export type NewTreatmentSchedule = {
  time: DateTime
  weekday: Weekday
}
export type TreatmentPeriodicSchedule = Omit<
  NewTreatmentPeriodicSchedule,
  'period'
> & {
  _id: string
  period: string
}

export type NewTreatmentPeriodicSchedule = {
  period: number
  firstOccurence: string
  endPeriod: string
}

export type NewTreatment = {
  description: string
  activeIngredient?: string
  dosage?: string
  notes?: string
  schedule: NewTreatmentSchedule[] | NewTreatmentPeriodicSchedule
}
export type NewTreatmentPlan = {
  effectiveDate?: DateTime
  expirationDate?: DateTime
  treatments: NewTreatment[]
  notes?: string
  reportId: string
}

export type TreatmentIntake = {
  scheduleId: string
  at: DateTime
  isTaken: boolean
  notes?: string
  _id: string
  patientId: string
}
export type TreatmentPlanScheduleEntry = {
  _id: string
  description: string
  notes?: string
  at: DateTime
  notBefore: DateTime
  notAfter: DateTime
  intake?: TreatmentIntake
}
export type TreatmentSideEffect = {
  at: string
  description: string
  _id: string
  patientId: string
}
