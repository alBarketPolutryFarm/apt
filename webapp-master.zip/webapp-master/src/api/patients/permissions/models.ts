import { Revocation } from 'src/api/models'
import { DateTime } from 'luxon'

export type Permission = {
  createdAt: DateTime
  createdBy: string
  effectiveDate: DateTime
  expirationDate?: DateTime
  revocation?: Revocation
  targetId: string
  _id: string
  patientId: string
}
export type NewPermission = {
  effectiveDate?: DateTime
  expirationDate?: DateTime
  targetId: string
}
export type RevokePermission = {
  targetId: string
}
