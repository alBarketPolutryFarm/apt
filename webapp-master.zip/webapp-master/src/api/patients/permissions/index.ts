import api from 'src/api'
import {
  NewPermission,
  Permission,
  RevokePermission
} from 'src/api/patients/permissions/models'

export const getPatientPermissions = (patientId: string) =>
  api.get<Permission[]>(`/patients/${patientId}/permissions`)

export const getPatientCurrentPermissions = (patientId: string) =>
  api.get<Permission[]>(`/patients/${patientId}/permissions/current`)

export const createPatientPermission = (
  patientId: string,
  data: NewPermission
) => api.post<NewPermission>(`/patients/${patientId}/permissions`, data)

export const revokePatientPermission = (
  patientId: string,
  data: RevokePermission
) => api.delete(`/patients/${patientId}/permissions`, { data })
