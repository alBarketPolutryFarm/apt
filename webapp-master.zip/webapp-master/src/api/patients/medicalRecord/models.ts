import { DateTime } from 'luxon'
import { EditLog } from 'src/api/models'

export type BloodType = '0+' | '0-' | 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-'
export type Surgery = {
  date: DateTime
  cause: string
  sideEffects?: string
}
export type Injury = {
  date: DateTime
  description: string
}
export type Comorbidity = {
  congenitalMalformations?: string
  exanthematousDiseases?: string
  venerealDiseases?: string
  infectiousDiseases?: string
  respiratoryDiseases?: string
  digestiveDiseases?: string
  cardiovascularDiseases?: string
  nervousPsycheDiseases?: string
  genitourinaryDiseases?: string
  osteoarticularDiseases?: string
  bloodDiseases?: string
  skinDiseases?: string
  metabolicDiseases?: string
  otherDiseases?: string
}
export type Vaccination = {
  type: string
  date: string
}
export type Menarche = 'normal' | 'premature' | 'late' | 'absent'
export type Menopause = 'normal' | 'premature' | 'late' | 'caused' | 'absent'
export type Andropause = 'normal' | 'premature' | 'late' | 'absent'
export type Nutrition = 'normal' | 'insufficient' | 'overeating'
export type Alcohol = 'teetotaler' | 'mediumDrinker' | 'heavyDrinker'
export type Coffe = 'never' | 'mediumDrinker' | 'heavyDrinker'
export type Sleep = 'normal' | 'sleepless' | 'excessive'
export type PhysicalActivity = 'never' | 'moderate' | 'intense'
export type SexLife = 'normal' | 'low' | 'never'
export type Bowel = 'normal' | 'diarrhea' | 'constipated' | 'tenesmus'
export type Diuresis =
  | 'normal'
  | 'oliguria'
  | 'polyuria'
  | 'dysuria'
  | 'pollakiuria'
export type Appetite = 'normal' | 'increased' | 'reduced'
export type Thirst = 'normal' | 'increased' | 'reduced'
export type MedicalRecord = {
  bloodType?: BloodType
  height?: number
  weight?: number
  bmi?: number
  familyHistory?: string
  surgeries?: Surgery[]
  injuries?: Injury[]
  prostheses?: string
  comorbidity?: Comorbidity
  riskFactors?: string
  allergiesIntolerances?: string
  vaccinations?: Vaccination[]
  notes?: string
  menarche?: Menarche
  lastMenstruation?: DateTime
  pregnanciesNumber?: number
  menopause?: Menopause
  andropause?: Andropause
  nutrition?: Nutrition
  alcohol?: Alcohol
  coffe?: Coffe
  sleep?: Sleep
  physicalActivity?: PhysicalActivity
  sexLife?: SexLife
  bowel?: Bowel
  diuresis?: Diuresis
  appetite?: Appetite
  thirst?: Thirst
  drugs?: string
  editsLog: EditLog[]
  _id: string
  patientId: string
}
