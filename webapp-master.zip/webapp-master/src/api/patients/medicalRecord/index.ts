import api from 'src/api'
import { MedicalRecord } from './models'
import { Operation } from 'rfc6902'

export const getPatientMedicalRecord = (patientId: string) =>
  api.get<MedicalRecord | undefined>(`/patients/${patientId}/medical-record`)

export const updatePatientMedicalRecord = (
  patientId: string,
  data: Operation[]
) => api.patch(`/patients/${patientId}/medical-record`, data)
