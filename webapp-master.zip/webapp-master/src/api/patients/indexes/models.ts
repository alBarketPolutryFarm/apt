export type NewBarthelIndexMeasureMetadata = {
  type: 'barthel'
}
export type NewBarthelIndexMeasure = {
  metadata: NewBarthelIndexMeasureMetadata
  timestamp?: string
  notes?: string
  nextCheck?: string
  value: number
}
export type NewBradenIndexMeasureMetadata = {
  type: 'braden'
}
export type NewBradenIndexMeasure = {
  metadata: NewBradenIndexMeasureMetadata
  timestamp?: string
  notes?: string
  nextCheck?: string
  value: number
}
export type NewBrassIndexMeasureMetadata = {
  type: 'brass'
}
export type NewBrassIndexMeasure = {
  metadata: NewBrassIndexMeasureMetadata
  timestamp?: string
  notes?: string
  nextCheck?: string
  value: number
}
export type NewConleyIndexMeasureMetadata = {
  type: 'conley'
}
export type NewConleyIndexMeasure = {
  metadata: NewConleyIndexMeasureMetadata
  timestamp?: string
  notes?: string
  nextCheck?: string
  value: number
}
export type NewMustIndexMeasureMetadata = {
  type: 'must'
}
export type NewMustIndexMeasure = {
  metadata: NewMustIndexMeasureMetadata
  timestamp?: string
  notes?: string
  nextCheck?: string
  value: number
}
export type NewNpiIndexMeasureMetadata = {
  type: 'npi'
}
export type NewNpiIndexMeasure = {
  metadata: NewNpiIndexMeasureMetadata
  timestamp?: string
  notes?: string
  nextCheck?: string
  value: number
}
export type BarthelIndexMeasureMetadata = {
  type: 'barthel'
}
export type BarthelIndexMeasure = {
  metadata: BarthelIndexMeasureMetadata
  timestamp: string
  notes?: string
  nextCheck?: string
  _id: string
  value: number
}
export type BradenIndexMeasureMetadata = {
  type: 'braden'
}
export type BradenIndexMeasure = {
  metadata: BradenIndexMeasureMetadata
  timestamp: string
  notes?: string
  nextCheck?: string
  _id: string
  value: number
}
export type BrassIndexMeasureMetadata = {
  type: 'brass'
}
export type BrassIndexMeasure = {
  metadata: BrassIndexMeasureMetadata
  timestamp: string
  notes?: string
  nextCheck?: string
  _id: string
  value: number
}
export type ConleyIndexMeasureMetadata = {
  type: 'conley'
}
export type ConleyIndexMeasure = {
  metadata: ConleyIndexMeasureMetadata
  timestamp: string
  notes?: string
  nextCheck?: string
  _id: string
  value: number
}
export type MustIndexMeasureMetadata = {
  type: 'must'
}
export type MustIndexMeasure = {
  metadata: MustIndexMeasureMetadata
  timestamp: string
  notes?: string
  nextCheck?: string
  _id: string
  value: number
}
export type NpiIndexMeasureMetadata = {
  type: 'npi'
}
export type NpiIndexMeasure = {
  metadata: NpiIndexMeasureMetadata
  timestamp: string
  notes?: string
  nextCheck?: string
  _id: string
  value: number
}
export type IndexMeasuresSummary = {
  barthel?: BarthelIndexMeasure
  braden?: BradenIndexMeasure
  brass?: BrassIndexMeasure
  conley?: ConleyIndexMeasure
  must?: MustIndexMeasure
  npi?: NpiIndexMeasure
}
export type IndexMeasureType =
  | 'barthel'
  | 'braden'
  | 'brass'
  | 'conley'
  | 'must'
  | 'npi'
export type IndexMeasure =
  | BarthelIndexMeasure
  | BradenIndexMeasure
  | BrassIndexMeasure
  | ConleyIndexMeasure
  | MustIndexMeasure
  | NpiIndexMeasure
export type NewIndexMeasure =
  | NewBarthelIndexMeasure
  | NewBradenIndexMeasure
  | NewBrassIndexMeasure
  | NewConleyIndexMeasure
  | NewMustIndexMeasure
  | NewNpiIndexMeasure
