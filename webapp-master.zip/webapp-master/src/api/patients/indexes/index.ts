import api from 'src/api'
import {
  IndexMeasure,
  IndexMeasuresSummary,
  IndexMeasureType,
  NewIndexMeasure
} from './models'
import { QueryDate, QueryPagination } from 'src/api/models'

export const addPatientIndexMeasures = (
  patientId: string,
  measures: NewIndexMeasure[]
) => api.post(`/patients/${patientId}/indexes`, measures)

export const getPatientIndexMeasuresSummary = (patientId: string) =>
  api.get<IndexMeasuresSummary>(`/patients/${patientId}/indexes/summary`)

export const getPatientIndexMeasures = (
  patientId: string,
  indexType: IndexMeasureType,
  params: QueryPagination & QueryDate
) =>
  api.get<IndexMeasure>(`/patients/${patientId}/indexes/${indexType}`, {
    params
  })
