import api from 'src/api'
import { Nurse } from 'src/api/nurses/models'

export const getPatientNurses = (patientId: string) =>
  api.get<Nurse[]>(`/patients/${patientId}/nurses`)

export const getPatientNurse = (patientId: string, nurseId: string) =>
  api.get<Nurse>(`/patients/${patientId}/nurses/${nurseId}`)
