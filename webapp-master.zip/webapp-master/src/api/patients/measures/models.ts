import { DateTime } from 'luxon'

export type TemperatureUnit = '\u00B0C' | '\u00B0F'
export type NewTemperatureMetadata = {
  unit?: TemperatureUnit
  type: 'temperature'
}
export type NewTemperature = {
  metadata: NewTemperatureMetadata
  timestamp: DateTime
  notes?: string
  value: number
}
export type WeightUnit = 'kg'
export type NewWeightMetadata = {
  unit?: WeightUnit
  type: 'weight'
}
export type NewWeight = {
  metadata: NewWeightMetadata
  timestamp: DateTime
  notes?: string
  value: number
}
export type BloodPressureUnit = 'mmHg'
export type NewBloodPressureMetadata = {
  unit?: BloodPressureUnit
  type: 'bloodPressure'
}
export type NewBloodPressure = {
  metadata: NewBloodPressureMetadata
  timestamp: DateTime
  notes?: string
  systolic: number
  diastolic: number
}
export type GlycaemiaUnit = 'mg/dl' | 'mmol/l'
export type NewGlycaemiaMetadata = {
  unit?: GlycaemiaUnit
  type: 'glycaemia'
}
export type NewGlycaemia = {
  metadata: NewGlycaemiaMetadata
  timestamp: DateTime
  notes?: string
  value: number
}
export type OxygenSaturationUnit = '%'
export type NewOxygenSaturationMetadata = {
  unit?: OxygenSaturationUnit
  type: 'oxygenSaturation'
}
export type NewOxygenSaturation = {
  metadata: NewOxygenSaturationMetadata
  timestamp: DateTime
  notes?: string
  value: number
}
export type PainUnit = 'NRS'
export type NewPainMetadata = {
  unit?: PainUnit
  type: 'pain'
}
export type NewPain = {
  metadata: NewPainMetadata
  timestamp: DateTime
  notes?: string
  value: number
}
export type PulseUnit = 'bpm'
export type NewPulseMetadata = {
  unit?: PulseUnit
  type: 'pulse'
}
export type NewPulse = {
  metadata: NewPulseMetadata
  timestamp: DateTime
  notes?: string
  value: number
}
export type RespiratoryRateUnit = 'bpm'
export type NewRespiratoryRateMetadata = {
  unit?: RespiratoryRateUnit
  type: 'respiratoryRate'
}
export type NewRespiratoryRate = {
  metadata: NewRespiratoryRateMetadata
  timestamp: DateTime
  notes?: string
  value: number
}
export type WaterBalanceUnit = 'ml'
export type NewWaterBalanceMetadata = {
  unit?: WaterBalanceUnit
  type: 'waterBalance'
}
export type NewWaterBalance = {
  metadata: NewWaterBalanceMetadata
  timestamp: DateTime
  notes?: string
  value: number
}
export type TemperatureMetadata = {
  unit: TemperatureUnit
  type: 'temperature'
}
export type Temperature = {
  metadata: TemperatureMetadata
  timestamp: DateTime
  notes?: string
  _id: string
  value: number
}
export type WeightMetadata = {
  unit: WeightUnit
  type: 'weight'
}
export type Weight = {
  metadata: WeightMetadata
  timestamp: DateTime
  notes?: string
  _id: string
  value: number
}
export type BloodPressureMetadata = {
  unit: BloodPressureUnit
  type: 'bloodPressure'
}
export type BloodPressure = {
  metadata: BloodPressureMetadata
  timestamp: DateTime
  notes?: string
  _id: string
  systolic: number
  diastolic: number
}
export type GlycaemiaMetadata = {
  unit: GlycaemiaUnit
  type: 'glycaemia'
}
export type Glycaemia = {
  metadata: GlycaemiaMetadata
  timestamp: DateTime
  notes?: string
  _id: string
  value: number
}
export type OxygenSaturationMetadata = {
  unit: OxygenSaturationUnit
  type: 'oxygenSaturation'
}
export type OxygenSaturation = {
  metadata: OxygenSaturationMetadata
  timestamp: DateTime
  notes?: string
  _id: string
  value: number
}
export type PainMetadata = {
  unit: PainUnit
  type: 'pain'
}
export type Pain = {
  metadata: PainMetadata
  timestamp: DateTime
  notes?: string
  _id: string
  value: number
}
export type PulseMetadata = {
  unit: PulseUnit
  type: 'pulse'
}
export type Pulse = {
  metadata: PulseMetadata
  timestamp: DateTime
  notes?: string
  _id: string
  value: number
}
export type RespiratoryRateMetadata = {
  unit: RespiratoryRateUnit
  type: 'respiratoryRate'
}
export type RespiratoryRate = {
  metadata: RespiratoryRateMetadata
  timestamp: DateTime
  notes?: string
  _id: string
  value: number
}
export type WaterBalanceMetadata = {
  unit: WaterBalanceUnit
  type: 'waterBalance'
}
export type WaterBalance = {
  metadata: WaterBalanceMetadata
  timestamp: DateTime
  notes?: string
  _id: string
  value: number
  total: number
}
export type MeasureType =
  | 'bloodPressure'
  | 'weight'
  | 'temperature'
  | 'pain'
  | 'respiratoryRate'
  | 'pulse'
  | 'glycaemia'
  | 'oxygenSaturation'
  | 'waterBalance'
export type Measure =
  | BloodPressure
  | Weight
  | Temperature
  | Pain
  | RespiratoryRate
  | Pulse
  | Glycaemia
  | OxygenSaturation
  | WaterBalance
export type MeasuresSummary = {
  bloodPressure?: BloodPressure
  weight?: Weight
  temperature?: Temperature
  pain?: Pain
  respiratoryRate?: RespiratoryRate
  pulse?: Pulse
  glycaemia?: Glycaemia
  oxygenSaturation?: OxygenSaturation
  waterBalance?: WaterBalance
}
