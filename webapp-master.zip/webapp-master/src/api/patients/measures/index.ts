import api from 'src/api'
import { Measure, MeasuresSummary } from './models'
import { QueryDate, QueryPagination } from 'src/api/models'
import { MeasureType } from 'src/const/Measure'

export const getPatientMeasuresSummary = (patientId: string) =>
  api.get<MeasuresSummary>(`/patients/${patientId}/measures/summary`)

export const getPatientMeasuresByType = (
  patientId: string,
  measureType: MeasureType,
  params: QueryPagination & QueryDate
) =>
  api.get<Measure[]>(`/patients/${patientId}/measures/${measureType}`, {
    params
  })
