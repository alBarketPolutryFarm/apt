import { Revocation } from 'src/api/models'
import { DateTime } from 'luxon'
import { MeasureType } from 'src/const/Measure'

export type Weekday = 0 | 1 | 2 | 3 | 4 | 5 | 6
export type MonitoredMeasureSchedule = {
  time: DateTime
  weekday?: Weekday
  _id: string
}
export type MonitoredMeasureBase = {
  notes?: string
  schedule: MonitoredMeasureSchedule[]
  _id: string
}
export type MonitoredMeasure = {
  limitMin?: number
  limitMax?: number
} & MonitoredMeasureBase
export type MonitoredPainMeasure = {
  limitMax?: number
} & MonitoredMeasureBase
export type MonitoredOxygenSaturationMeasure = {
  limitMin?: number
} & MonitoredMeasureBase
export type MonitoredBloodPressureMeasure = {
  limitMinSystolic?: number
  limitMaxSystolic?: number
  limitMinDiastolic?: number
  limitMaxDiastolic?: number
} & MonitoredMeasureBase
export type MonitoringPlan = {
  effectiveDate: DateTime
  expirationDate?: DateTime
  notes?: string
  createdAt: DateTime
  createdBy: string
  revocation?: Revocation
  reportId: string
  bloodPressure: MonitoredBloodPressureMeasure
  oxygenSaturation: MonitoredOxygenSaturationMeasure
  pain: MonitoredPainMeasure
} & Record<
  Exclude<MeasureType, 'bloodPressure' | 'oxygenSaturation' | 'pain'>,
  MonitoredMeasure
>
export type NewMonitoredMeasureSchedule = {
  time: DateTime
  weekday?: Weekday
}
export type NewMonitoredMeasureBase = {
  notes?: string
  schedule: NewMonitoredMeasureSchedule[]
}
export type NewMonitoredMeasure = {
  limitMin?: number
  limitMax?: number
} & NewMonitoredMeasureBase
export type NewMonitoredPainMeasure = {
  limitMax?: number
} & NewMonitoredMeasureBase
export type NewMonitoredOxygenSaturationMeasure = {
  limitMin?: number
} & NewMonitoredMeasureBase
export type NewMonitoredBloodPressureMeasure = {
  limitMinSystolic?: number
  limitMaxSystolic?: number
  limitMinDiastolic?: number
  limitMaxDiastolic?: number
} & NewMonitoredMeasureBase
export type NewMonitoringPlan = {
  effectiveDate?: DateTime
  expirationDate?: DateTime
  notes?: string
  reportId: string
  bloodPressure: NewMonitoredBloodPressureMeasure
  oxygenSaturation: NewMonitoredOxygenSaturationMeasure
  pain: NewMonitoredPainMeasure
} & Record<
  Exclude<MeasureType, 'bloodPressure' | 'oxygenSaturation' | 'pain'>,
  NewMonitoredMeasure
>
