import api from 'src/api'
import {
  MonitoringPlan,
  NewMonitoringPlan
} from 'src/api/patients/monitoringPlans/models'

export const getPatientMonitoringPlans = (patientId: string) =>
  api.get<MonitoringPlan[]>(`/patients/${patientId}/monitoring-plans`)

export const getPatientCurrentMonitoringPlan = (patientId: string) =>
  api.get<MonitoringPlan | undefined>(
    `/patients/${patientId}/monitoring-plans/current`
  )

export const createPatientMonitoringPlan = (
  patientId: string,
  data: NewMonitoringPlan
) =>
  api.post<NewMonitoringPlan>(`/patients/${patientId}/monitoring-plans`, data)

export const revokePatientMonitoringPlan = (
  patientId: string,
  monitoringPlanId: string
) => api.delete(`/patients/${patientId}/monitoring-plans/${monitoringPlanId}`)
