import api from 'src/api'
import { NewPAI, NewPAIHistoryEntry, PAI, PAIStatus } from './models'
import { QueryPagination } from 'src/api/models'

export const createPatientPAI = (patientId: string, pai: NewPAI) =>
  api.post(`/patients/${patientId}/pai`, pai)

export const getPatientPAI = (
  patientId: string,
  params: QueryPagination & { status?: PAIStatus }
) => api.get<PAI[]>(`/patients/${patientId}/pai`, { params })

export const getPatientPAIById = (patientId: string, paiId: string) =>
  api.get<PAI>(`/patients/${patientId}/pai/${paiId}`)

export const updatePatientPAIHistory = (
  patientId: string,
  paiId: string,
  historyEntry: NewPAIHistoryEntry
) => api.post(`/patients/${patientId}/pai/${paiId}/history`, historyEntry)

export const setPatientPAIAsCompleted = (
  patientId: string,
  paiId: string,
  reason: string
) =>
  api.post(`/patients/${patientId}/pai/${paiId}/completed`, {
    reason: reason
  })
