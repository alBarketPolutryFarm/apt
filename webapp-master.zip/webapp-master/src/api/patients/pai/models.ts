import { DateTime } from 'luxon'

export type PAIStatus = 'active' | 'completed'
export type PAICondition = 'improved' | 'stationary' | 'deteriorated'
export type PAIHistoryEntry = {
  _id: string
  description: string
  condition: PAICondition
  hostStructure: string
  nextCheck: string
  at: DateTime
  createdByName: string | null
  createdBy: string | null
}
export type PAI = {
  closedBy: string | null
  reason: string
  diagnosis: string
  goal: string
  _id: string
  createdAt: DateTime
  createdBy: string
  patientId: string
  history: PAIHistoryEntry[]
  completedAt?: DateTime
  lastUpdate: DateTime
  createdByName: string | null
}
export type NewPAI = {
  diagnosis: string
  goal: string
}
export type NewPAIHistoryEntry = {
  description: string
  condition: PAICondition
  hostStructure: string
  nextCheck: DateTime
}
