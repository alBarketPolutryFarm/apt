import { Patient } from 'src/api/patients/models'
import { Admin, SuperAdmin } from 'src/api/admins/models'
import { Nurse } from 'src/api/nurses/models'
import { Doctor } from 'src/api/doctors/models'
import { Operator } from 'src/api/operators/models'
import { Caregiver } from 'src/api/caregivers/models'

export type User = Patient | Admin | Nurse | Doctor | Operator | Caregiver | SuperAdmin
export type UserType = User['type']
