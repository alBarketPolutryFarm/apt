import api from 'src/api'
import { User } from './models'

export const getUser = () => api.get<User>('/user')
